﻿#include "stdafx.h"
#include "FFT_windows.h"


void wind_blackman(double *window, int len)
{
	const double a0 = 0.42;
	const double a1 = 0.5;
	const double a2 = 0.08;

	double len_mult = 1 / (double)(len - 1);
	for (int i = 0; i < len; i++)
	{
		window[i] = a0 - a1 * cos(i * 2 * M_PI * len_mult) + a2 * cos(i * 4 * M_PI * len_mult);
	}
}

void wind_blackman_harris(double *window, int len)
{
	const double a0 = 0.35875;
	const double a1 = 0.48829;
	const double a2 = 0.14128;
	const double a3 = 0.01168;

	double len_mult = 1 / (double)(len - 1);
	for (int i = 0; i < len; i++)
	{
		window[i] = a0
			- a1 * cos(i * 2 * M_PI * len_mult)
			+ a2 * cos(i * 4 * M_PI * len_mult)
			- a3 * cos(i * 6 * M_PI * len_mult);
	}
}

void wind_blackman_nuttall(double *window, int len)
{
	const double a0 = 0.3635819;
	const double a1 = 0.4891775;
	const double a2 = 0.1365995;
	const double a3 = 0.0106411;

	double len_mult = 1 / (double)(len - 1);
	for (int i = 0; i < len; i++)
	{
		window[i] = a0
			- a1 * cos(i * 2 * M_PI * len_mult)
			+ a2 * cos(i * 4 * M_PI * len_mult)
			- a3 * cos(i * 6 * M_PI * len_mult);
	}
}

void wind_flat_top(double *window, int len)
{
	const double a0 = 0.21557895;
	const double a1 = 0.41663158;
	const double a2 = 0.277263158;
	const double a3 = 0.083578947;
	const double a4 = 0.006947368;

	double len_mult = 1 / (double)(len - 1);
	for (int i = 0; i < len; i++)
	{
		window[i] = a0
			- a1 * cos(i * 2 * M_PI * len_mult)
			+ a2 * cos(i * 4 * M_PI * len_mult)
			- a3 * cos(i * 6 * M_PI * len_mult)
			+ a4 * cos(i * 8 * M_PI * len_mult);
	}
}

void wind_hann(double *window, int len)
{
	double len_mult = 1 / (double)(len - 1);
	for (int i = 0; i < len; i++)
	{
		window[i] = 0.5 * (1 - cos(i * 2 * M_PI * len_mult));
	}
}

void wind_hamm(double *window, int len)
{
	double len_mult = 1 / (double)(len - 1);
	for (int i = 0; i < len; i++)
	{
		window[i] = 0.54 - 0.46 * cos(i * 2 * M_PI * len_mult);
	}
}

void wind_nuttall(double *window, int len)
{
	const double a0 = 0.355768;
	const double a1 = 0.487396;
	const double a2 = 0.144232;
	const double a3 = 0.012604;

	double len_mult = 1 / (double)(len - 1);
	for (int i = 0; i < len; i++)
	{
		window[i] = a0
			- a1 * cos(i * 2 * M_PI * len_mult)
			+ a2 * cos(i * 4 * M_PI * len_mult)
			- a3 * cos(i * 6 * M_PI * len_mult);
	}
}

void wind_rectangle(double *window, int len)
{
	for (int i = 0; i < len; i++)
	{
		window[i] = 1;
	}
}

void Window_process(double *data_pre, double *data_post, int len, Wind_Type wind)
{
	double *window_data = new double[len];

	if (wind == blackman) wind_blackman(window_data, len);
	if (wind == blackman_harris) wind_blackman_harris(window_data, len);
	if (wind == blackman_nuttall) wind_blackman_nuttall(window_data, len);
	if (wind == flat_top) wind_flat_top(window_data, len);
	if (wind == hann) wind_hann(window_data, len);
	if (wind == hamm) wind_hamm(window_data, len);
	if (wind == nuttall) wind_nuttall(window_data, len);
	if (wind == rectangle) wind_rectangle(window_data, len);

	for (int i = 0; i < len; i++)
	{
		data_post[i] = data_pre[i] * window_data[i];
	}

	delete[] window_data;

}

void FFT_execute(double* data_input, double* data_output, int samples, FFT_RET_TYPE type)
{
	STSGetFFTData(data_input, data_output, samples);
	
	for (int i = 0; i < samples; i++)
	{
		data_output[i] = data_output[i] * 2 / samples;//Vpeak
		if(type == RMS_VALUE) data_output[i] = data_output[i] / 1.414213562373;//Vrms
	}
}

double Aweighting_Vcoef(double frequency) 
{

	double ff = frequency * frequency;
	double ffff = ff * ff;

	double numerator = 148693636 * ffff;
	double denominator = (ff + 424.36) * sqrt((ff + 11599.29) * (ff + 544496.41)) * (ff + 148693636);

	return numerator / denominator * 1.2589048990582917;//1kz = 1
}

void Aweighting(double* data_pre, double* data_post, int samples, double Tsample)
{

	for (int i = 0; i < samples; i++)
	{
		data_post[i] = data_pre[i] * Aweighting_Vcoef(1 / Tsample * i / samples);
	}
}

double Noise_with_Aweighting(double* data_input, int samples, double Tsample)
{
	double data_FFT[SAMPLE_NUM];
	double data_Win[SAMPLE_NUM];
	double data_Aweight[SAMPLE_NUM];
	double noise = 0;

	Window_process(data_input, data_Win, samples, blackman_harris);//window
	FFT_execute(data_Win, data_FFT, samples, RMS_VALUE);
	Aweighting(data_FFT, data_Aweight, samples, Tsample);

    int data_range_h;
    int data_range_l;
    data_range_h = (int)floor(20000 * Tsample * samples);
    data_range_l = (int)ceil(20 * Tsample * samples);

    for (int i = data_range_l; i < data_range_h; i++)
	{
		noise = noise + data_Aweight[i] * data_Aweight[i];
	}



	return sqrt(noise);
}

double THDN_with_Aweighting(double* data_input, int samples, double Tsample, double fundamental_freq, int fundamental_point_num)
{
	//double* data_FFT = new double[samples];
	//double* data_Aweight = new double[samples];
	//double* data_Win = new double[samples];
	double data_FFT[SAMPLE_NUM];
	double data_Aweight[SAMPLE_NUM];
	double data_Win[SAMPLE_NUM];
	double noise = 0;
	double numerator = 0;
	double denominator = 0;

	int fundamental;
	int fundamental_h;
	int fundamental_l;
	int data_range_l;
	int data_range_h;

	Window_process(data_input, data_Win, samples, hann);//window
	FFT_execute(data_Win, data_FFT, samples, RMS_VALUE);//FFT
	Aweighting(data_FFT, data_Aweight, samples, Tsample);//Aweight

	fundamental = round(fundamental_freq * Tsample * samples);//mid
	fundamental_l = fundamental - fundamental_point_num;//low
	if (fundamental_l < 0) fundamental_l = 0;
	fundamental_h = fundamental + fundamental_point_num;//high

	data_range_l = 0;
	data_range_h = floor(20000 * Tsample * samples);//20KHZ向下取整


	for (int i = data_range_l; i < data_range_h; i++)
	{
		if (i < fundamental_l || i > fundamental_h) numerator = numerator + data_Aweight[i] * data_Aweight[i];
		if (i >= fundamental_l && i <= fundamental_h) denominator = denominator + data_Aweight[i] * data_Aweight[i];
	}

	//delete[] data_FFT;
	//delete[] data_Aweight;
	//delete[] data_Win;

	//return numerator / denominator;
	return sqrt(numerator / denominator);
}