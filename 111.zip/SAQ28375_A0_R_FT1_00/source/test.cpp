#include "stdafx.h"


//need consider cancel warning disable?
//#pragma   warning ( disable: 4244 )// no express warning 4244 in programing
//#pragma   warning ( disable: 4305 )
//#pragma   warning ( disable: 4800 )

char oper_id[20];
int  globalsite;
BYTE sitesta[SITE_NUM];
UINT16 debug_reg[SITE_NUM];
bool DEBUG = false;
bool Char_enable = false;
bool GNG_FLAG = false;
bool TTR_FLAG = false;

//special 
double OUTPN_Vcoef[SITE_NUM];
double Rload[SITE_NUM];
double Vcoef_gain = 0.9944;
double Vcoef_Isns = 1.0000;
double Vcoef_Vsns[SITE_NUM];
double FAB_TEMP = 25;

TREG dut;
SPEC spec;
Test_Method test_method;
string pathofini;



//TREG
extern "C" int GetPgsFullPath(LPTSTR pgsPath, int chNum);
bool DO_TRIM = true;
bool QC = false;
//board check coding
bool DO_BoardCheck = true;
extern BOOL run_diags();
//FMEA
bool DO_FMEA = false;
eFMEA efmea;
//IC_stack
int IC_stack = 3;//check repeat times 0:disable IC stack check
BYTE CODE[SITE_NUM][BANK_NUM];
BYTE CODE_LAST[SITE_NUM][BANK_NUM];
int count_flag[SITE_NUM] = { 0 };
int stack_count[SITE_NUM] = { 0 };

//////normal use
int ScanLoad_flag = -1;
bool burn_flag[SITE_NUM];
int flag[SITE_NUM];
double adresult[SITE_NUM];
double adresult_R[SITE_NUM];
double adresult_F[SITE_NUM];
double adresult_BF[SITE_NUM];
double adresult_AF[SITE_NUM];
UINT16 reg_code[SITE_NUM];
double Freq_384K[SITE_NUM];

struct IQ IQ;
struct CLASSD OUTP, OUTN;
struct BOOST boost;
struct REG reg_0x88;
struct LEAK BCK_M, WCK_M, DATAI_M, SCL_M, SDA_M, AD_M, INTN_M;
struct LEAK VLDO_M, DVDD_M, VOP_M, VON_M;
struct LEAK VBAT_M, SW_M, PVDD_M;
struct LEAK* STRU_PIN_LIST[14] = { &BCK_M, &WCK_M, &DATAI_M, &SCL_M, &SDA_M, &AD_M, &INTN_M, &VLDO_M, &DVDD_M, &VOP_M, &VON_M, &VBAT_M, &SW_M, &PVDD_M };


FOVI FOVI_List[12] = { FOVI0, FOVI1, FOVI2, FOVI3, FOVI4, FOVI5, FOVI6, FOVI7, FOVI32, FOVI33, FOVI34, FOVI35 };

//multisite settings should be included here
DUT_API void HardWareCfg()
{
    //FOVI source setting

    StsSetModuleToSite(MD_FOVI, SITE_1, 0, 1, 2, 3, 4, 5, 6, 7, 32, 33, 34, 35, -1); //SITE1
    StsSetModuleToSite(MD_FOVI, SITE_2, 8, 9, 10, 11, 12, 13, 14, 15, 36, 37, 38, 39, -1);//SITE2
    StsSetModuleToSite(MD_FOVI, SITE_3, 16, 17, 18, 19, 20, 21, 22, 23, 40, 41, 42, 43, -1); //SITE3
    StsSetModuleToSite(MD_FOVI, SITE_4, 24, 25, 26, 27, 28, 29, 30, 31, 44, 45, 46, 47, -1);//SITE4

    //FPVI source setting
    StsSetModuleToSite(MD_FPVI10, SITE_1, 0, 1, -1);//set channels 0-1 to SITE1
    StsSetModuleToSite(MD_FPVI10, SITE_2, 2, 3, -1);//set channels 2-3 to SITE2
    StsSetModuleToSite(MD_FPVI10, SITE_3, 4, 5, -1);//set channels 4-5 to SITE3
    StsSetModuleToSite(MD_FPVI10, SITE_4, 6, 7, -1);//set channels 6-7 to SITE4

    //QTMU setting
    StsSetModuleToSite(MD_QTMUPLUS, SITE_1, 0, -1);
    StsSetModuleToSite(MD_QTMUPLUS, SITE_2, 1, -1);
    StsSetModuleToSite(MD_QTMUPLUS, SITE_3, 2, -1);
    StsSetModuleToSite(MD_QTMUPLUS, SITE_4, 3, -1);


    //QVM setting
    StsSetModuleToSite(MD_QVM, SITE_1, 0, -1);
    StsSetModuleToSite(MD_QVM, SITE_2, 1, -1);
    StsSetModuleToSite(MD_QVM, SITE_3, 2, -1);
    StsSetModuleToSite(MD_QVM, SITE_4, 3, -1);


}

DUT_API void UserLoad()
{
    StsGetOperatorID(oper_id, 20);
    if (strcmp(oper_id, "admin") == 0 || strcmp(oper_id, "eng") == 0) IC_stack = 0;

    HardWareCfg();
    AstBindingAllModule();
    STSSetSiteStatus(0xFFFFFFFF);

    ScanLoad_flag = dio_plus.LoadVectorFile("beethoven_1P1_full.vecdio",true);


    //define I2C freq
    dio_plus.Init();
    I2C_setup(2.5e-6);

    dio_plus.SetVIH(1.8); //set driver high voltage
    dio_plus.SetVIL(0.0); //set driver low voltage
    dio_plus.SetVOH(0.5); //set compare high voltage
    dio_plus.SetVOL(0.5); //set compare low voltage



    dio_plus.I2CSetAddresByteCount(1); //address
    dio_plus.I2CSetRegAddresByteCount(1);

    i2c_site0.dataByteCount = 2;//Set the byte count=1 and need not to change it.
    i2c_site1.dataByteCount = 2;
    i2c_site2.dataByteCount = 2;
    i2c_site3.dataByteCount = 2;

    //TREG
    char pgspath[300];
    char pgsname[300];
    char pgsfullpath[300];
    char pathoftreg[300];

    STSGetPgsPath(pgspath, 300);
    STSGetPgsName(pgsname, 300);

    //pathofpgs
    strcat(strcpy(pgsfullpath, pgspath), pgsname);
    //pathoftreg
    strcat(strcpy(pathoftreg, pgspath), "Beethoven_1P1.treg");

    reg_0x88.initial(DEV_AD_DEF, "Beethoven_1P1.ini");

    dut.init(pathoftreg, SITE_NUM, QC, DO_TRIM);

    spec.init(pgsfullpath);

    //BC
    if (DO_BoardCheck)	run_diags();
    //FMEA
    if (DO_FMEA)	efmea.fmea_2_enable = 1;//efmea.fmea_2_enable = 1;  efmea.fmea_enable = 1;
    //treg2pgs();



    qtmu0.Init();
    qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
    qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
    qtmu0.SetStartTrigger(0.62, QTMU_PLUS_POS_SLOPE);
    qtmu0.SetStopTrigger(0.62, QTMU_PLUS_NEG_SLOPE);
    qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
    qtmu0.SetTimeOut(10);
}

DUT_API void BinOutDut()
{
	dut.eot();
    efmea.eot();
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initialize function will be called before all the test functions.
DUT_API void InitBeforeTestFlow()
{
    RES_INITIAL(ONE_BY_ONE, RES_RELAY_OFF);
    dio_plus.Connect();
    qtmu0.Connect();
    qvm0.Connect();
    cbit.SetOn(-1);

    dut.sot();
    efmea.sot();

    reg_0x88.reset();
    dut.force_table_char_active(0);
    dut.trim("CLSD_OS_L").set_working(0);
    dut.trim("I_SENSE_OS_CAL_L").set_working(0);
    dut.trim("ISNS_CMRR_L").set_working(0);
    dut.trim("TSNS_DGE_L").set_working(0);
    dut.trim("TSNS_OFFSET_L").set_working(0);
    dut.trim("I_SENSE_CAL_L").set_working(0);

}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initializefunction will be called after all the test functions.
DUT_API void InitAfterTestFlow()
{
    dio_plus.Stop();
    RES_INITIAL(ONE_BY_ONE, RES_RELAY_OFF);
    qtmu0.Disconnect();
    qvm0.Disconnect();
    dio_plus.Disconnect();
    cbit.SetOn(-1);

}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//Fail site hardware set function will be called after failed params, it can be called for serveral times. 
DUT_API void SetupFailSite(const unsigned char* byFailSite)
{
    dio_plus.Stop();
    RES_INITIAL(ONE_BY_ONE, RES_RELAY_OFF);
    qtmu0.Disconnect();
    qvm0.Disconnect();
    efmea.fmea_onfailsite();

}
/************************************************************************/
/*                                                                      */
/************************************************************************/
 
DUT_API int Info(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Part_No = StsGetParam(funcindex, "Part_No");
    CParam *X_Coordinate = StsGetParam(funcindex, "X_Coordinate");
    CParam *Y_Coordinate = StsGetParam(funcindex, "Y_Coordinate");
    CParam *Scan_load = StsGetParam(funcindex, "Scan_load");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here


    int X[SITE_NUM], Y[SITE_NUM];
    char waferid[255];



    SERIAL Part_No->SetTestResult(SITE, 0, 28375);
    SERIAL Scan_load->SetTestResult(SITE, 0, ScanLoad_flag);


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int Kelvin(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Kelvin_DVDD = StsGetParam(funcindex, "Kelvin_DVDD");
    CParam *Kelvin_SW = StsGetParam(funcindex, "Kelvin_SW");
    CParam *Kelvin_PVDD = StsGetParam(funcindex, "Kelvin_PVDD");
    CParam *Kelvin_VBAT = StsGetParam(funcindex, "Kelvin_VBAT");
    CParam *Kelvin_VOP = StsGetParam(funcindex, "Kelvin_VOP");
    CParam *Kelvin_BGND = StsGetParam(funcindex, "Kelvin_BGND");
    CParam *Kelvin_VON = StsGetParam(funcindex, "Kelvin_VON");
    CParam *Kelvin_PVDD1 = StsGetParam(funcindex, "Kelvin_PVDD1");
    CParam *Kelvin_BGND1 = StsGetParam(funcindex, "Kelvin_BGND1");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here

    GPFOVI KELVIN_CHECK("KELVIN_CHECK", VBAT, PVDD, DVDD, SW, PWR_UP);//PWR_UP=GND FOVI

    cbit.SetOn(K_Kelvin, KGND, -1);
    delay_ms(3);
    KELVIN_CHECK.Set(FI, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
    KELVIN_CHECK.Set(FI, 0.1, FOVI_10V, FOVI_100MA, RELAY_ON);
    delay_ms(1);
    KELVIN_CHECK.MeasureVI(10, 10);
    KELVIN_CHECK.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);


    cbit.SetOn(K99_FPVI0_FS, K39_FPVIFH0_To_GND, K97_FPVI01L2GND, KGND, -1);
    delay_ms(3);
    FPVI0.Set(FI, 0.1, FPVI10_10V, FPVI10_100MA, RELAY_ON);
    delay_ms(1);
    FPVI0.MeasureVI(10, 10);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    cbit.SetOn(K100_FPVI1_FS, K40_FPVIFH1_To_PVDD, K98_FPVI01L2PVDD, KGND, -1);
    delay_ms(3);
    FPVI1.Set(FI, 0.1, FPVI10_10V, FPVI10_100MA, RELAY_ON);
    delay_ms(1);
    FPVI1.MeasureVI(10, 10);
    FPVI1.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);

    SERIAL adresult[SITE] = VBAT.GetMeasResult(SITE, MVRET);
    SERIAL Kelvin_VBAT->SetTestResult(SITE, 0, adresult[SITE] * 10);
    SERIAL adresult[SITE] = PVDD.GetMeasResult(SITE, MVRET);
    SERIAL Kelvin_PVDD->SetTestResult(SITE, 0, adresult[SITE] * 10);
    SERIAL adresult[SITE] = DVDD.GetMeasResult(SITE, MVRET);
    SERIAL Kelvin_DVDD->SetTestResult(SITE, 0, adresult[SITE] * 10);
    SERIAL adresult[SITE] = SW.GetMeasResult(SITE, MVRET);
    SERIAL Kelvin_SW->SetTestResult(SITE, 0, adresult[SITE] * 10);
    SERIAL adresult[SITE] = PWR_UP.GetMeasResult(SITE, MVRET);
    SERIAL Kelvin_BGND->SetTestResult(SITE, 0, adresult[SITE] * 10);

    SERIAL adresult[SITE] = FPVI0.GetMeasResult(SITE, MVRET);
    SERIAL Kelvin_PVDD1->SetTestResult(SITE, 0, adresult[SITE] * 10);
    SERIAL adresult[SITE] = FPVI1.GetMeasResult(SITE, MVRET);
    SERIAL Kelvin_BGND1->SetTestResult(SITE, 0, adresult[SITE] * 10);




    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int OS_pre(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *OS_SHORT = StsGetParam(funcindex, "OS_SHORT");
    CParam *OS_SOME_OPEN = StsGetParam(funcindex, "OS_SOME_OPEN");
    CParam *OS_ALL_OPEN = StsGetParam(funcindex, "OS_ALL_OPEN");
    CParam *OS_ALAM = StsGetParam(funcindex, "OS_ALAM");
    CParam *OS_BCK_pre = StsGetParam(funcindex, "OS_BCK_pre");
    CParam *OS_WCK_pre = StsGetParam(funcindex, "OS_WCK_pre");
    CParam *OS_DATAI_pre = StsGetParam(funcindex, "OS_DATAI_pre");
    CParam *OS_SCL_pre = StsGetParam(funcindex, "OS_SCL_pre");
    CParam *OS_SDA_pre = StsGetParam(funcindex, "OS_SDA_pre");
    CParam *OS_AD_pre = StsGetParam(funcindex, "OS_AD_pre");
    CParam *OS_ININ_pre = StsGetParam(funcindex, "OS_ININ_pre");
    CParam *OS_VLDO_pre = StsGetParam(funcindex, "OS_VLDO_pre");
    CParam *OS_DVDD_pre = StsGetParam(funcindex, "OS_DVDD_pre");
    CParam *OS_VOP_pre = StsGetParam(funcindex, "OS_VOP_pre");
    CParam *OS_VON_pre = StsGetParam(funcindex, "OS_VON_pre");
    CParam *OS_VBAT_pre = StsGetParam(funcindex, "OS_VBAT_pre");
    CParam *OS_SW_pre = StsGetParam(funcindex, "OS_SW_pre");
    CParam *OS_PVDD_pre = StsGetParam(funcindex, "OS_PVDD_pre");
    CParam *OS_VLDO_H_pre = StsGetParam(funcindex, "OS_VLDO_H_pre");
    CParam *OS_VOP_H_pre = StsGetParam(funcindex, "OS_VOP_H_pre");
    CParam *OS_VON_H_pre = StsGetParam(funcindex, "OS_VON_H_pre");
    CParam *OS_SW_H_pre = StsGetParam(funcindex, "OS_SW_H_pre");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here

    const int PIN_NUM = 18;
    const int LEAK_NUM = 0;
    const int exclude_NUM = 0;
    double os_result[PIN_NUM][SITE_NUM] = { 0 };
    vector<string> vec_exclude;
    string pin_str_array[PIN_NUM] = { "OS_BCK_pre", "OS_WCK_pre", "OS_DATAI_pre", "OS_SCL_pre", "OS_SDA_pre", "OS_AD_pre", "OS_ININ_pre", "OS_VLDO_pre", "OS_DVDD_pre", "OS_VOP_pre", "OS_VON_pre", "OS_VBAT_pre", "OS_SW_pre", "OS_PVDD_pre", "OS_VLDO_H_pre", "OS_VOP_H_pre", "OS_VON_H_pre", "OS_SW_H_pre" };

    GPFOVI OS_GP1("OS_GP1", BCK, WCK, DATAI, INTN, VLDO, DVDD, VOP, VON, VBAT, SW, PVDD);
    GPFOVI OS_GP2("OS_GP2", SCL, SDA, AD);
    GPFOVI OS_GP3("OS_GP3", VLDO, VOP, VON, SW);


    cbit.SetOn(K35_BCK2FOVI, K34_WCK2FOVI, -1);
    delay_ms(3);

    OS_GP1.Set(FI, -1e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
    delay_us(500);
    OS_GP1.MeasureVI(10, 10);
    OS_GP1.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);

    //BCK
    SERIAL os_result[0][SITE] = BCK.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[0].c_str())->SetTestResult(SITE, 0, os_result[0][SITE]);
    //WCK
    SERIAL os_result[1][SITE] = WCK.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[1].c_str())->SetTestResult(SITE, 0, os_result[1][SITE]);
    //DATAI
    SERIAL os_result[2][SITE] = DATAI.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[2].c_str())->SetTestResult(SITE, 0, os_result[2][SITE]);
    //INTN
    SERIAL os_result[6][SITE] = INTN.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[6].c_str())->SetTestResult(SITE, 0, os_result[6][SITE]);
    //VLDO
    SERIAL os_result[7][SITE] = VLDO.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[7].c_str())->SetTestResult(SITE, 0, os_result[7][SITE]);
    //DVDD
    SERIAL os_result[8][SITE] = DVDD.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[8].c_str())->SetTestResult(SITE, 0, os_result[8][SITE]);
    //VOP
    SERIAL os_result[9][SITE] = VOP.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[9].c_str())->SetTestResult(SITE, 0, os_result[9][SITE]);
    //VON
    SERIAL os_result[10][SITE] = VON.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[10].c_str())->SetTestResult(SITE, 0, os_result[10][SITE]);
    //VBAT
    SERIAL os_result[11][SITE] = VBAT.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[11].c_str())->SetTestResult(SITE, 0, os_result[11][SITE]);
    //SW
    SERIAL os_result[12][SITE] = SW.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[12].c_str())->SetTestResult(SITE, 0, os_result[12][SITE]);
    //PVDD
    SERIAL os_result[13][SITE] = PVDD.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[13].c_str())->SetTestResult(SITE, 0, os_result[13][SITE]);


    cbit.SetOn(K31_IIC2FOVI, K32_IIC2FOVI, K33_IIC_DIS_PU, -1);
    delay_ms(3);

    OS_GP2.Set(FI, -1e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
    delay_us(500);
    OS_GP2.MeasureVI(10, 10);
    OS_GP2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);

    //SCL
    SERIAL os_result[3][SITE] = SCL.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[3].c_str())->SetTestResult(SITE, 0, os_result[3][SITE]);
    //SDA
    SERIAL os_result[4][SITE] = SDA.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[4].c_str())->SetTestResult(SITE, 0, os_result[4][SITE]);
    //AD
    SERIAL os_result[5][SITE] = AD.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[5].c_str())->SetTestResult(SITE, 0, os_result[5][SITE]);


    OS_GP3.Set(FI, 1e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
    delay_us(500);
    OS_GP3.MeasureVI(10, 10);
    OS_GP3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);

    //VLDO
    SERIAL os_result[14][SITE] = VLDO.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[14].c_str())->SetTestResult(SITE, 0, os_result[14][SITE]);
    //VOP
    SERIAL os_result[15][SITE] = VOP.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[15].c_str())->SetTestResult(SITE, 0, os_result[15][SITE]);
    //VON
    SERIAL os_result[16][SITE] = VON.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[16].c_str())->SetTestResult(SITE, 0, os_result[16][SITE]);
    //SW
    SERIAL os_result[17][SITE] = SW.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[17].c_str())->SetTestResult(SITE, 0, os_result[17][SITE]);



    //************************************ Add OS classify delog ***********************************************
    test_method.OS_Classify(funcindex, pin_str_array, PIN_NUM, NULL, LEAK_NUM, os_result, NULL, vec_exclude);
    //************************************ Add OS classify delog end *******************************************


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int P2P_Leak_pre(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *P2P_BCK_pre = StsGetParam(funcindex, "P2P_BCK_pre");
    CParam *P2P_WCK_pre = StsGetParam(funcindex, "P2P_WCK_pre");
    CParam *P2P_DATAI_pre = StsGetParam(funcindex, "P2P_DATAI_pre");
    CParam *P2P_SCL_pre = StsGetParam(funcindex, "P2P_SCL_pre");
    CParam *P2P_SDA_pre = StsGetParam(funcindex, "P2P_SDA_pre");
    CParam *P2P_AD_pre = StsGetParam(funcindex, "P2P_AD_pre");
    CParam *P2P_ININ_pre = StsGetParam(funcindex, "P2P_ININ_pre");
    CParam *P2P_VLDO_pre = StsGetParam(funcindex, "P2P_VLDO_pre");
    CParam *P2P_DVDD_pre = StsGetParam(funcindex, "P2P_DVDD_pre");
    CParam *P2P_VOP_pre = StsGetParam(funcindex, "P2P_VOP_pre");
    CParam *P2P_VON_pre = StsGetParam(funcindex, "P2P_VON_pre");
    CParam *P2P_VBAT_pre = StsGetParam(funcindex, "P2P_VBAT_pre");
    CParam *P2P_SW_pre = StsGetParam(funcindex, "P2P_SW_pre");
    CParam *P2P_PVDD_pre = StsGetParam(funcindex, "P2P_PVDD_pre");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here

    ALL_PIN.Set(FV, 0, FOVI_1V, FOVI_100UA, RELAY_ON);

    cbit.SetOn(K35_BCK2FOVI, K34_WCK2FOVI, -1);
    delay_ms(3);


    p2p_leakage_test(BCK, 50e-3, FOVI_1V, FOVI_100UA, 300, BCK_M.P2P_leak_pre);
    p2p_leakage_test(WCK, 50e-3, FOVI_1V, FOVI_100UA, 300, WCK_M.P2P_leak_pre);
    p2p_leakage_test(DATAI, 50e-3, FOVI_1V, FOVI_100UA, 300, DATAI_M.P2P_leak_pre);
    p2p_leakage_test(INTN, 50e-3, FOVI_1V, FOVI_100UA, 300, INTN_M.P2P_leak_pre);
    p2p_leakage_test(VOP, 50e-3, FOVI_1V, FOVI_100UA, 300, VOP_M.P2P_leak_pre);
    p2p_leakage_test(VON, 50e-3, FOVI_1V, FOVI_100UA, 300, VON_M.P2P_leak_pre);
    p2p_leakage_test(SW, 50e-3, FOVI_1V, FOVI_100UA, 300, SW_M.P2P_leak_pre);
    p2p_leakage_test(VBAT, 50e-3, FOVI_1V, FOVI_100UA, 5000, VBAT_M.P2P_leak_pre);
    p2p_leakage_test(PVDD, 50e-3, FOVI_1V, FOVI_100UA, 5000, PVDD_M.P2P_leak_pre);
    p2p_leakage_test(VLDO, 50e-3, FOVI_1V, FOVI_100UA, 5000, VLDO_M.P2P_leak_pre);
    p2p_leakage_test(DVDD, 50e-3, FOVI_1V, FOVI_100UA, 5000, DVDD_M.P2P_leak_pre);


    cbit.SetOn(K31_IIC2FOVI, K32_IIC2FOVI, K33_IIC_DIS_PU, -1);
    delay_ms(3);
    p2p_leakage_test(SCL, 50e-3, FOVI_1V, FOVI_100UA, 300, SCL_M.P2P_leak_pre);
    p2p_leakage_test(SDA, 50e-3, FOVI_1V, FOVI_100UA, 300, SDA_M.P2P_leak_pre);
    p2p_leakage_test(AD, 50e-3, FOVI_1V, FOVI_100UA, 300, AD_M.P2P_leak_pre);


    for (int i = 0; i < 14; ++i)
    {
        SERIAL AstGetParam(funcindex, i)->SetTestResult(SITE, 0, STRU_PIN_LIST[i]->P2P_leak_pre[SITE] * 1e9);
    }


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int PIN_LEAK_pre(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *PIN_LEAK_BCK_pre = StsGetParam(funcindex, "PIN_LEAK_BCK_pre");
    CParam *PIN_LEAK_WCK_pre = StsGetParam(funcindex, "PIN_LEAK_WCK_pre");
    CParam *PIN_LEAK_DATAI_pre = StsGetParam(funcindex, "PIN_LEAK_DATAI_pre");
    CParam *PIN_LEAK_SCL_pre = StsGetParam(funcindex, "PIN_LEAK_SCL_pre");
    CParam *PIN_LEAK_SDA_pre = StsGetParam(funcindex, "PIN_LEAK_SDA_pre");
    CParam *PIN_LEAK_AD_pre = StsGetParam(funcindex, "PIN_LEAK_AD_pre");
    CParam *PIN_LEAK_ININ_pre = StsGetParam(funcindex, "PIN_LEAK_ININ_pre");
    CParam *PIN_LEAK_VLDO_delta_pre = StsGetParam(funcindex, "PIN_LEAK_VLDO_delta_pre");
    CParam *PIN_LEAK_DVDD_pre = StsGetParam(funcindex, "PIN_LEAK_DVDD_pre");
    CParam *PIN_LEAK_VOP_pre = StsGetParam(funcindex, "PIN_LEAK_VOP_pre");
    CParam *PIN_LEAK_VON_pre = StsGetParam(funcindex, "PIN_LEAK_VON_pre");
    CParam *PIN_LEAK_VBAT_pre = StsGetParam(funcindex, "PIN_LEAK_VBAT_pre");
    CParam *PIN_LEAK_SW_pre = StsGetParam(funcindex, "PIN_LEAK_SW_pre");
    CParam *PIN_LEAK_PVDD_pre = StsGetParam(funcindex, "PIN_LEAK_PVDD_pre");
    CParam *PIN_LEAK_VLDO_pre = StsGetParam(funcindex, "PIN_LEAK_VLDO_pre");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here


    ALL_PIN.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);

    cbit.SetOn(K35_BCK2FOVI, K34_WCK2FOVI, -1);
    delay_ms(3);
    pin_leakage_test(BCK, 1.8, FOVI_20V, FOVI_100UA, 1, BCK_M.PIN_leak_pre);
    pin_leakage_test(WCK, 1.8, FOVI_20V, FOVI_100UA, 1, WCK_M.PIN_leak_pre);
    pin_leakage_test(DATAI, 1.8, FOVI_20V, FOVI_100UA, 1, DATAI_M.PIN_leak_pre);
    pin_leakage_test(INTN, 1.8, FOVI_20V, FOVI_100UA, 1, INTN_M.PIN_leak_pre);

    cbit.SetOn(K31_IIC2FOVI, K32_IIC2FOVI, K33_IIC_DIS_PU, -1);
    delay_ms(3);
    pin_leakage_test(SCL, 1.8, FOVI_20V, FOVI_100UA, 1, SCL_M.PIN_leak_pre);
    pin_leakage_test(SDA, 1.8, FOVI_20V, FOVI_100UA, 1, SDA_M.PIN_leak_pre);
    pin_leakage_test(AD, 1.8, FOVI_20V, FOVI_100UA, 1, AD_M.PIN_leak_pre);


    for (int i = 0; i < 7; ++i)
    {
        SERIAL AstGetParam(funcindex, i)->SetTestResult(SITE, 0, STRU_PIN_LIST[i]->PIN_leak_pre[SITE] * 1e9);
    }

    pin_leakage_test(VBAT, 5, FOVI_20V, FOVI_100UA, 5, VBAT_M.PIN_leak_pre);
    pin_leakage_test(PVDD, 10, FOVI_20V, FOVI_100UA, 5, PVDD_M.PIN_leak_pre);

    VBAT.Set(FV, 5, FOVI_20V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_20V, FOVI_100MA, RELAY_ON);
    pin_leakage_test(DVDD, 1.8, FOVI_20V, FOVI_100UA, 50, DVDD_M.PIN_leak_pre);
    DVDD.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);


    VBAT.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
    PVDD.Set(FV, 10, FOVI_20V, FOVI_100MA, RELAY_ON);
    pin_leakage_test(SW, 10, FOVI_20V, FOVI_100UA, 5, SW_M.PIN_leak_pre);


    VOP.Set(FV, 10, FOVI_20V, FOVI_100MA, RELAY_ON);
    VON.Set(FV, 10, FOVI_20V, FOVI_100MA, RELAY_ON);
    delay_ms(15);
    VON.MeasureVI(100, 10);
    VOP.MeasureVI(100, 10);
    SERIAL VON_M.PIN_leak_pre[SITE] = VON.GetMeasResult(SITE, MIRET);
    SERIAL VOP_M.PIN_leak_pre[SITE] = VOP.GetMeasResult(SITE, MIRET);


    VOP.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    VON.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    PVDD.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);


    VBAT.Set(FV, 5, FOVI_20V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_20V, FOVI_100MA, RELAY_ON);

    VLDO.Set(FV, 1.55, FOVI_20V, FOVI_100UA, RELAY_ON);
    delay_ms(1);
    VLDO.MeasureVI(100, 10);
    SERIAL adresult_BF[SITE] = VLDO.GetMeasResult(SITE,MIRET);

    VLDO.Set(FV, 1.60, FOVI_20V, FOVI_100UA, RELAY_ON);
    delay_ms(1);
    VLDO.MeasureVI(100, 10);
    SERIAL adresult_AF[SITE] = VLDO.GetMeasResult(SITE, MIRET);
    SERIAL VLDO_M.PIN_leak_pre[SITE] = adresult_AF[SITE] - adresult_BF[SITE];


    VLDO.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    VBAT.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    DVDD.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    ALL_PIN.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);


    SERIAL PIN_LEAK_DVDD_pre->SetTestResult(SITE, 0, DVDD_M.PIN_leak_pre[SITE] * 1e6);
    SERIAL PIN_LEAK_PVDD_pre->SetTestResult(SITE, 0, PVDD_M.PIN_leak_pre[SITE] * 1e9);
    SERIAL PIN_LEAK_VBAT_pre->SetTestResult(SITE, 0, VBAT_M.PIN_leak_pre[SITE] * 1e9);
    SERIAL PIN_LEAK_SW_pre->SetTestResult(SITE, 0, SW_M.PIN_leak_pre[SITE] * 1e9);
    SERIAL PIN_LEAK_VOP_pre->SetTestResult(SITE, 0, VOP_M.PIN_leak_pre[SITE] * 1e3);
    SERIAL PIN_LEAK_VON_pre->SetTestResult(SITE, 0, VON_M.PIN_leak_pre[SITE] * 1e3);
    SERIAL PIN_LEAK_VLDO_pre->SetTestResult(SITE, 0, adresult_AF[SITE] * 1e6);
    SERIAL PIN_LEAK_VLDO_delta_pre->SetTestResult(SITE, 0, VLDO_M.PIN_leak_pre[SITE] * 1e6);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int IIC_AD_CHECK(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *AD_GND = StsGetParam(funcindex, "AD_GND");
    CParam *AD_VDDIO = StsGetParam(funcindex, "AD_VDDIO");
    CParam *AD_SDA = StsGetParam(funcindex, "AD_SDA");
    CParam *AD_SCL = StsGetParam(funcindex, "AD_SCL");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here
    
    UINT16 CHIP_ID[SITE_NUM];

    cbit.SetOn(-1);

    VBAT.Set(FV, 5, FOVI_10V, FOVI_10MA, RELAY_ON);
    PWR_UP.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);

    ///////////////////////////////////////////////////////////////VDDIO
    AD.Set(FV, 1.15, FOVI_10V, FOVI_10MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);
    delay_ms(2);

    I2C_RD(DEV_AD_VDDIO, 0x00, CHIP_ID);
    SERIAL AD_VDDIO->SetTestResult(SITE, 0, CHIP_ID[SITE]);

    DVDD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    ///////////////////////////////////////////////////////////////GND
    AD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);
    delay_ms(2);

    I2C_RD(DEV_AD_GND, 0x00, CHIP_ID);
    SERIAL AD_GND->SetTestResult(SITE, 0, CHIP_ID[SITE]);

    AD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    DVDD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    ///////////////////////////////////////////////////////////////SDA
    cbit.SetOn(K37_AD2SDA, -1);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);
    delay_ms(3);

    I2C_RD(DEV_AD_SDA, 0x00, CHIP_ID);
    SERIAL AD_SDA->SetTestResult(SITE, 0, CHIP_ID[SITE]);

    DVDD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    ///////////////////////////////////////////////////////////////SCL
    cbit.SetOn(K36_AD2SCL, -1);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);
    delay_ms(3);

    I2C_RD(DEV_AD_SCL, 0x00, CHIP_ID);
    SERIAL AD_SCL->SetTestResult(SITE, 0, CHIP_ID[SITE]);

    DVDD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    VBAT.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);




    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int EE_INIT(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *EEPROM0_READ = StsGetParam(funcindex, "EEPROM0_READ");
    CParam *EEPROM1_READ = StsGetParam(funcindex, "EEPROM1_READ");
    CParam *EEPROM2_READ = StsGetParam(funcindex, "EEPROM2_READ");
    CParam *EEPROM3_READ = StsGetParam(funcindex, "EEPROM3_READ");
    CParam *EEPROM4_READ = StsGetParam(funcindex, "EEPROM4_READ");
    CParam *EEPROM5_READ = StsGetParam(funcindex, "EEPROM5_READ");
    CParam *EEPROM6_READ = StsGetParam(funcindex, "EEPROM6_READ");
    CParam *EEPROM7_READ = StsGetParam(funcindex, "EEPROM7_READ");
    CParam *BG_TC_PRE = StsGetParam(funcindex, "BG_TC_PRE");
    CParam *BG_1P2_PRE = StsGetParam(funcindex, "BG_1P2_PRE");
    CParam *IBIAS_500N_PRE = StsGetParam(funcindex, "IBIAS_500N_PRE");
    CParam *DAC_GAIN_PRE = StsGetParam(funcindex, "DAC_GAIN_PRE");
    CParam *OSC_FREQ_PRE = StsGetParam(funcindex, "OSC_FREQ_PRE");
    CParam *LDO_LP_VREF_PRE = StsGetParam(funcindex, "LDO_LP_VREF_PRE");
    CParam *LDO_LP_BG_TC_PRE = StsGetParam(funcindex, "LDO_LP_BG_TC_PRE");
    CParam *RAMP_PRE = StsGetParam(funcindex, "RAMP_PRE");
    CParam *RAMP_VCM_PRE = StsGetParam(funcindex, "RAMP_VCM_PRE");
    CParam *CLSD_OS_L_PRE = StsGetParam(funcindex, "CLSD_OS_L_PRE");
    CParam *CLSD_OS_H_PRE = StsGetParam(funcindex, "CLSD_OS_H_PRE");
    CParam *V_SENSE_CAL_PRE = StsGetParam(funcindex, "V_SENSE_CAL_PRE");
    CParam *I_SENSE_OS_CAL_L_PRE = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_PRE");
    CParam *I_SENSE_OS_CAL_H_PRE = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_PRE");
    CParam *ISNS_CMRR_H_PRE = StsGetParam(funcindex, "ISNS_CMRR_H_PRE");
    CParam *ISNS_CMRR_L_PRE = StsGetParam(funcindex, "ISNS_CMRR_L_PRE");
    CParam *ISNS_GAIN_ADJ_PRE = StsGetParam(funcindex, "ISNS_GAIN_ADJ_PRE");
    CParam *TVP_SNS_OS_PRE = StsGetParam(funcindex, "TVP_SNS_OS_PRE");
    CParam *BOOST_DAC_BUF_PRE = StsGetParam(funcindex, "BOOST_DAC_BUF_PRE");
    CParam *BOOST_ZCD_PRE = StsGetParam(funcindex, "BOOST_ZCD_PRE");
    CParam *BOOST_ISNS_PRE = StsGetParam(funcindex, "BOOST_ISNS_PRE");
    CParam *BOOST_IPKL_PRE = StsGetParam(funcindex, "BOOST_IPKL_PRE");
    CParam *BOOST_IPFM_PRE = StsGetParam(funcindex, "BOOST_IPFM_PRE");
    CParam *CLSD_PWM_PRE = StsGetParam(funcindex, "CLSD_PWM_PRE");
    CParam *PV_OFFSET_PRE = StsGetParam(funcindex, "PV_OFFSET_PRE");
    CParam *TSNS_DGE_H_PRE = StsGetParam(funcindex, "TSNS_DGE_H_PRE");
    CParam *TSNS_DGE_L_PRE = StsGetParam(funcindex, "TSNS_DGE_L_PRE");
    CParam *TSNS_OFFSET_H_PRE = StsGetParam(funcindex, "TSNS_OFFSET_H_PRE");
    CParam *TSNS_OFFSET_L_PRE = StsGetParam(funcindex, "TSNS_OFFSET_L_PRE");
    CParam *I_SENSE_CAL_H_PRE = StsGetParam(funcindex, "I_SENSE_CAL_H_PRE");
    CParam *I_SENSE_CAL_L_PRE = StsGetParam(funcindex, "I_SENSE_CAL_L_PRE");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here


    UINT16 EE_READ[BANK_NUM][SITE_NUM] = { 0 };


    cbit.SetOn(-1);
    delay_ms(3);

    POWER_ON(WITH_TM);

    //reg_0x88.WRITE_DEFAULT_REG_TO_INI("Beethoven_1P1.ini");

    SERIAL burn_flag[SITE] = true;
    SERIAL if (QC) burn_flag[SITE] = false;
    //1.set readback 2.copy to programmed 3.find trimmed node and disable trim
    for (int reg = 0; reg < dut.assy.count(); ++reg)
    {
        string EE_str = string(dut.assy[reg].get_name());
        I2C_RD(DEV_AD_DEF, TRIM_BANK_ST + reg, EE_READ[reg]);
        SERIAL dut.assy(EE_str.c_str()).set_read_back(EE_READ[reg][SITE], SITE);
        SERIAL dut.assy(EE_str.c_str()).copy_read_to_prog(SITE);
        SERIAL if (EE_READ[reg][SITE]) burn_flag[SITE] = false;
        //SERIAL burn_flag[SITE] = true;
    }
    for (int reg = 0; reg < dut.assy.count(); ++reg)
    {
        string EE_str = string(dut.assy[reg].get_name());
        SERIAL if (!burn_flag[SITE]) dut.assy(EE_str.c_str()).copy_read_to_work(SITE);
    }
    SERIAL dut.set_trim_allowed(burn_flag[SITE], SITE);
    // make sure readback value is stored in TREG read_back
    //Bank READ
    for (int reg = 0; reg < dut.assy.count(); ++reg)
    {
        string EE_str = string(dut.assy[reg].get_name()) + "_READ";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].get_read_back(SITE));
    }

    //TRIM PRE
    for (int reg = 0; reg < dut.trim.count(); ++reg)
    {
        string EE_str = string(dut.trim[reg].get_name()) + "_PRE";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.trim[reg].get_read_back(SITE));
    }

    //SEL PRE
    for (int reg = 0; reg < dut.sel.count(); ++reg)
    {
        string EE_str = string(dut.sel[reg].get_name()) + "_PRE";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.sel[reg].get_read_back(SITE));
    }

    //check device trimmed
    POWER_OFF(NORMAL, RES_RELAY_OFF);


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM1_BG_TC(short funcindex, LPCTSTR funclabel)
{

    cbit.SetOn(K81_INTN_FOVI2BUF, K_CAP_ALL, K82_BUFIN2GND, -1);

    INTN.Set(FI, 0, FOVI_2V, FOVI_10UA, RELAY_SENSE_ON);
    AD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);

    VBAT.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_100MA, RELAY_ON);
    delay_ms(2);
    Enter_TM();
    I2C_WR(DEV_AD_DEF, 0x33, 0x0000);//iv sns dis
    I2C_WR(DEV_AD_DEF, 0x07, 0x4E80);//32bit
    I2C_WR(DEV_AD_DEF, 0x39, 0x7CDB);//PLL 32bit 48K cfg

    I2C_WR(DEV_AD_DEF, 0x5B, 0x8000);//PLL FORCE LOCK
    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);//sys work
    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(5);
    dio_plus.Stop();


    I2C_WR(DEV_AD_DEF, 0x06, 0x0000);//dis classd boost sar


    I2C_WR(DEV_AD_DEF, 0x05, 0x0000);//intn push pull
    I2C_WR(DEV_AD_DEF, 0x81, 0x8000);//AMUX BGTC

    //dut.trim("BG_TC").execute(measure_BG_TC, spec, funcindex, funclabel, 1, 0, "BG_TC");

    SERIAL if (burn_flag[SITE]) dut.trim("BG_TC").set_working(3, SITE);

    EFUSE_Preview(0);
    delay_us(100);
    INTN.MeasureVI(50, 10);
    SERIAL adresult[SITE] = INTN.GetMeasResult(SITE, MVRET);

    SERIAL StsGetParam(funcindex, "BG_TC_post")->SetTestResult(SITE, 0, adresult[SITE]);
    SERIAL StsGetParam(funcindex, "BG_TC_post_bit")->SetTestResult(SITE, 0, dut.trim("BG_TC").get_working(SITE));


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM2_BG_1P2(short funcindex, LPCTSTR funclabel)
{

    I2C_WR(DEV_AD_DEF, 0x81, 0x8100);//AMUX BG_1P2

    dut.trim("BG_1P2").execute(measure_BG_1P2, spec, funcindex, funclabel, 1, 0, "BG_1P2");


    I2C_WR(DEV_AD_DEF, 0x81, 0x0000);//recover

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM3_IBIAS_500N(short funcindex, LPCTSTR funclabel)
{


    cbit.SetOn(K_CAP_ALL, -1);
    delay_ms(3);

    I2C_WR(DEV_AD_DEF, 0x81, 0x8200);//AMUX IBIAS
    INTN.Set(FV, 0, FOVI_2V, FOVI_10UA, RELAY_ON);
    delay_ms(1);

    dut.trim("IBIAS_500N").execute(measure_IBIAS_500N, spec, funcindex, funclabel, 1, 0, "IBIAS_500N");


    I2C_WR(DEV_AD_DEF, 0x81, 0x0000);//recover
    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM4_LDO_LP_BG_TC(short funcindex, LPCTSTR funclabel)
{

    INTN.Set(FI, 0, FOVI_2V, FOVI_10UA, RELAY_SENSE_ON);
    cbit.SetOn(K81_INTN_FOVI2BUF, K_CAP_ALL, K82_BUFIN2GND, -1);
    delay_ms(3);


    dut.trim("LDO_LP_BG_TC").execute(measure_LDO_LP_BG_TC, spec, funcindex, funclabel, 1, 0, "LDO_LP_BG_TC");


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM5_LDO_LP_VREF(short funcindex, LPCTSTR funclabel)
{

    I2C_WR(DEV_AD_DEF, 0x81, 0x840D);//AMUX LDO_VREF

    dut.trim("LDO_LP_VREF").execute(measure_LDO_LP_VREF, spec, funcindex, funclabel, 1, 0, "LDO_LP_VREF");


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM6_BOOST_DAC_BUF(short funcindex, LPCTSTR funclabel)
{

    INTN.Set(FI, 0, FOVI_1V, FOVI_10UA, RELAY_SENSE_ON);

    I2C_WR(DEV_AD_DEF, 0x81, 0x8610);//AMUX VREF DAC
    I2C_WR(DEV_AD_DEF, 0x13, 0x7FCC);//VREF DAC ALWAYS ON
    I2C_WR(DEV_AD_DEF, 0x14, 0xFC00);//VREF DAC 252*44/16mV=693mV


    dut.trim("BOOST_DAC_BUF").execute(measure_BOOST_DAC_BUF, spec, funcindex, funclabel, 1, 0, "BOOST_DAC_BUF");


    //recover
    I2C_WR(DEV_AD_DEF, 0x13, reg_0x88.default[0x13]);
    I2C_WR(DEV_AD_DEF, 0x14, reg_0x88.default[0x14]);



    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM7_TVP_SNS_OS(short funcindex, LPCTSTR funclabel)
{

    INTN.Set(FI, 0, FOVI_2V, FOVI_10UA, RELAY_SENSE_ON);

    I2C_WR(DEV_AD_DEF, 0x81, 0x8300);//AMUX sns vref
    I2C_WR(DEV_AD_DEF, 0x06, 0x0100);//sns en
    I2C_WR(DEV_AD_DEF, 0x82, 0x4000);//sns vref

    dut.trim("TVP_SNS_OS").execute(measure_TVP_SNS_OS, spec, funcindex, funclabel, 1, 0, "TVP_SNS_OS");


    //recover
    I2C_WR(DEV_AD_DEF, 0x06, 0x0000);
    I2C_WR(DEV_AD_DEF, 0x82, 0x0000);


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM8_OSC_FREQ(short funcindex, LPCTSTR funclabel)
{
    cbit.SetOn(K_CAP_ALL, K18_INTN2QTMU, K81_INTN_FOVI2BUF, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x81, 0xC100);//OSC 1MHZ mux

    dut.trim("OSC_FREQ").execute(measure_OSC_FREQ, spec, funcindex, funclabel, 1, 0, "OSC_FREQ");

    I2C_WR(DEV_AD_DEF, 0x81, 0x0000);//OSC 1MHZ mux


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM20_TSNS_OFFSET(short funcindex, LPCTSTR funclabel)
{

    CParam* TSNS_OFFSET = StsGetParam(funcindex, "TSNS_OFFSET");
    CParam* TSNS_DOUT = StsGetParam(funcindex, "TSNS_DOUT");
    UINT16 TSNS_CODE[SITE_NUM];

    cbit.SetOn(K_CAP_ALL, -1);
    delay_ms(3);

    I2C_WR(DEV_AD_DEF, 0x06, 0x0100);//sar en
    I2C_WR(DEV_AD_DEF, 0x5B, 0x8000);//PLL FORCE LOCK
    I2C_RD(DEV_AD_DEF, 0x12, TSNS_CODE);//DOUT

    SERIAL TSNS_CODE[SITE] = TSNS_CODE[SITE] + round(FAB_TEMP - 25);

    SERIAL if (burn_flag[SITE]) dut.trim("TSNS_OFFSET_H").set_working(TSNS_CODE[SITE] >> 4, SITE);
    SERIAL if (burn_flag[SITE]) dut.trim("TSNS_OFFSET_L").set_working((TSNS_CODE[SITE] & 0x0F), SITE);

    EFUSE_Preview(6);
    SERIAL reg_code[SITE] = (dut.trim("TSNS_OFFSET_H").get_working(SITE) << 4) + dut.trim("TSNS_OFFSET_L").get_working(SITE);
    SERIAL TSNS_OFFSET->SetTestResult(SITE, 0, reg_code[SITE]);
    I2C_RD(DEV_AD_DEF, 0x12, TSNS_CODE);//DOUT
    SERIAL TSNS_DOUT->SetTestResult(SITE, 0, 25 - 1.213 * (signed char)TSNS_CODE[SITE]);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM21_TSNS_DGE_H(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam* TSNS_DGE_H_Step0 = StsGetParam(funcindex, "TSNS_DGE_H_Step0");
    CParam* TSNS_DGE_H_Step1 = StsGetParam(funcindex, "TSNS_DGE_H_Step1");
    CParam* TSNS_DGE_H_Step2 = StsGetParam(funcindex, "TSNS_DGE_H_Step2");
    CParam* TSNS_DGE_H_Step3 = StsGetParam(funcindex, "TSNS_DGE_H_Step3");
    CParam* TSNS_DGE_H_Step4 = StsGetParam(funcindex, "TSNS_DGE_H_Step4");
    CParam* TSNS_DGE_H_Step5 = StsGetParam(funcindex, "TSNS_DGE_H_Step5");
    CParam* TSNS_DGE_H_Step6 = StsGetParam(funcindex, "TSNS_DGE_H_Step6");
    CParam* TSNS_DGE_H_Step7 = StsGetParam(funcindex, "TSNS_DGE_H_Step7");
    CParam* TSNS_DGE_H_pre = StsGetParam(funcindex, "TSNS_DGE_H_pre");
    CParam* TSNS_DGE_H_pre_bit = StsGetParam(funcindex, "TSNS_DGE_H_pre_bit");
    CParam* TSNS_DGE_H_post = StsGetParam(funcindex, "TSNS_DGE_H_post");
    CParam* TSNS_DGE_H_post_bit = StsGetParam(funcindex, "TSNS_DGE_H_post_bit");
    CParam* TSNS_DGE_H_target = StsGetParam(funcindex, "TSNS_DGE_H_target");
    CParam* TSNS_DGE_H_guessed = StsGetParam(funcindex, "TSNS_DGE_H_guessed");
    CParam* TSNS_DGE_H_updated = StsGetParam(funcindex, "TSNS_DGE_H_updated");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your functOion code here

    I2C_WR(DEV_AD_DEF, 0x81, 0x8300);//AMUX TSNS
    I2C_WR(DEV_AD_DEF, 0x83, 0x0018);//force Test
	
    I2C_WR(DEV_AD_DEF, 0x34, 0xBB00);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0100);//sar en
    I2C_WR(DEV_AD_DEF, 0x5B, 0x8000);//PLL FORCE LOCK

	dut.trim("TSNS_DGE_H").execute(measure_TSNS_DGE, spec, funcindex, funclabel, 1, 0, "TSNS_DGE_H");



    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM22_TSNS_DGE_L(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam* TSNS_DGE_L_Step0 = StsGetParam(funcindex, "TSNS_DGE_L_Step0");
    CParam* TSNS_DGE_L_Step1 = StsGetParam(funcindex, "TSNS_DGE_L_Step1");
    CParam* TSNS_DGE_L_Step2 = StsGetParam(funcindex, "TSNS_DGE_L_Step2");
    CParam* TSNS_DGE_L_Step3 = StsGetParam(funcindex, "TSNS_DGE_L_Step3");
    CParam* TSNS_DGE_L_Step4 = StsGetParam(funcindex, "TSNS_DGE_L_Step4");
    CParam* TSNS_DGE_L_Step5 = StsGetParam(funcindex, "TSNS_DGE_L_Step5");
    CParam* TSNS_DGE_L_Step6 = StsGetParam(funcindex, "TSNS_DGE_L_Step6");
    CParam* TSNS_DGE_L_Step7 = StsGetParam(funcindex, "TSNS_DGE_L_Step7");
    CParam* TSNS_DGE_L_Step8 = StsGetParam(funcindex, "TSNS_DGE_L_Step8");
    CParam* TSNS_DGE_L_Step9 = StsGetParam(funcindex, "TSNS_DGE_L_Step9");
    CParam* TSNS_DGE_L_Step10 = StsGetParam(funcindex, "TSNS_DGE_L_Step10");
    CParam* TSNS_DGE_L_Step11 = StsGetParam(funcindex, "TSNS_DGE_L_Step11");
    CParam* TSNS_DGE_L_Step12 = StsGetParam(funcindex, "TSNS_DGE_L_Step12");
    CParam* TSNS_DGE_L_Step13 = StsGetParam(funcindex, "TSNS_DGE_L_Step13");
    CParam* TSNS_DGE_L_Step14 = StsGetParam(funcindex, "TSNS_DGE_L_Step14");
    CParam* TSNS_DGE_L_Step15 = StsGetParam(funcindex, "TSNS_DGE_L_Step15");
    CParam* TSNS_DGE_L_pre = StsGetParam(funcindex, "TSNS_DGE_L_pre");
    CParam* TSNS_DGE_L_pre_bit = StsGetParam(funcindex, "TSNS_DGE_L_pre_bit");
    CParam* TSNS_DGE_L_post = StsGetParam(funcindex, "TSNS_DGE_L_post");
    CParam* TSNS_DGE_L_post_bit = StsGetParam(funcindex, "TSNS_DGE_L_post_bit");
    CParam* TSNS_DGE_L_target = StsGetParam(funcindex, "TSNS_DGE_L_target");
    CParam* TSNS_DGE_L_guessed = StsGetParam(funcindex, "TSNS_DGE_L_guessed");
    CParam* TSNS_DGE_L_updated = StsGetParam(funcindex, "TSNS_DGE_L_updated");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your functOion code here


	dut.trim("TSNS_DGE_L").execute(measure_TSNS_DGE, spec, funcindex, funclabel, 1, 0, "TSNS_DGE_L");



    I2C_WR(DEV_AD_DEF, 0x81, 0x0000);//recovery
    I2C_WR(DEV_AD_DEF, 0x83, 0x0000);//recovery


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM23_PV_OFFSET(short funcindex, LPCTSTR funclabel)
{


    dut.trim("PV_OFFSET").execute(measure_PV_OFFSET, spec, funcindex, funclabel, 1, 0, "PV_OFFSET");

    I2C_WR(DEV_AD_DEF, 0x06, 0x0000);//sar dis

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM9_BOOST_ISNS(short funcindex, LPCTSTR funclabel)
{
    cbit.SetOn(K_CAP_ALL, K96_FPVI01H2SW, K97_FPVI01L2GND, K99_FPVI0_FS, K100_FPVI1_FS, -1);
    delay_ms(3);

    INTN.Set(FI, 0, FOVI_2V, FOVI_10UA, RELAY_SENSE_ON);
    PVDD.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
    ALL_FPVI.Set(FI, 0, FPVI10_1V, FPVI10_1MA, RELAY_ON);//SPIKE

    I2C_WR(DEV_AD_DEF, 0x82, 0x000C);//BOOST VCC HSD ON
    I2C_WR(DEV_AD_DEF, 0x82, 0x0004);//BOOST VCC
    I2C_WR(DEV_AD_DEF, 0x81, 0xC090);//DMUX BOOST PWM logic lsd on


    dut.trim("BOOST_ISNS").execute(measure_BOOST_ISNS, spec, funcindex, funclabel, 1, 0, "BOOST_ISNS");

    FPVI0.Set(FI, 0, FPVI10_5V, FPVI10_10A, RELAY_ON);
    FPVI1.Set(FI, 0, FPVI10_5V, FPVI10_10A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    FPVI1.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM10_BOOST_IPKL(short funcindex, LPCTSTR funclabel)
{

    CParam* BOOST_4P5A = StsGetParam(funcindex, "BOOST_4P5A");

    I2C_WR(DEV_AD_DEF, 0x13, 0x5F4C);//3.0A

    dut.trim("BOOST_IPKL").execute(measure_BOOST_IPKL, spec, funcindex, funclabel, 1, 0, "BOOST_IPKL");

    I2C_WR(DEV_AD_DEF, 0x13, 0x7E4C);//4.5A
    test_method.ramp_2FPVI(FPVI0, FPVI1, FPVI10_5V, FPVI10_10A, INTN, 0.0, 5.5, 0.01, 10, 1, TRIG_RISING, adresult);
    SERIAL adresult[SITE] = adresult[SITE] + 0.37;//bench corr

    SERIAL BOOST_4P5A->SetTestResult(SITE, 0, adresult[SITE]);

    FPVI0.Set(FI, 0, FPVI10_5V, FPVI10_10A, RELAY_ON);
    FPVI1.Set(FI, 0, FPVI10_5V, FPVI10_10A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    FPVI1.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM11_BOOST_IPFM(short funcindex, LPCTSTR funclabel)
{


    I2C_WR(DEV_AD_DEF, 0x13, 0x6000);//
    I2C_WR(DEV_AD_DEF, 0x14, 0x0000);//boost dac min

    dut.trim("BOOST_IPFM").execute(measure_BOOST_IPFM, spec, funcindex, funclabel, 1, 0, "BOOST_IPFM");


    //recover
    I2C_WR(DEV_AD_DEF, 0x13, 0xFF4C);
    I2C_WR(DEV_AD_DEF, 0x14, 0xEF50);

    FPVI0.Set(FI, 0, FPVI10_5V, FPVI10_1A, RELAY_ON);
    FPVI1.Set(FI, 0, FPVI10_5V, FPVI10_1A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    FPVI1.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM12_BOOST_ZCD(short funcindex, LPCTSTR funclabel)
{

    cbit.SetOn(K_CAP_ALL, K96_FPVI01H2SW, K98_FPVI01L2PVDD, K99_FPVI0_FS, K100_FPVI1_FS, -1);
    delay_ms(3);

    I2C_WR(DEV_AD_DEF, 0x04, 0x8001);//standby = 1 iis en
    //I2C_WR(DEV_AD_DEF, 0x05, 0x2000);
    //I2C_WR(DEV_AD_DEF, 0x06, 0x0000);
    I2C_WR(DEV_AD_DEF, 0x33, 0x4000);//default


    I2C_WR(DEV_AD_DEF, 0x83, 0x0200);//EN BG
    I2C_WR(DEV_AD_DEF, 0x81, 0xC050);//DMUX BOOST ZCD logic
    I2C_WR(DEV_AD_DEF, 0x82, 0xC00C);//BOOST VCC hsd on

    PVDD.Set(FV, 2, FOVI_10V, FOVI_100MA, RELAY_ON);
    AD.Set(FV, 6, FOVI_10V, FOVI_100MA, RELAY_ON);


    dut.trim("BOOST_ZCD").execute(measure_BOOST_ZCD, spec, funcindex, funclabel, 1, 0, "BOOST_ZCD");


    //recover
    FPVI0.Set(FI, 0, FPVI10_5V, FPVI10_1A, RELAY_ON);
    FPVI1.Set(FI, 0, FPVI10_5V, FPVI10_1A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    FPVI1.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    I2C_WR(DEV_AD_DEF, 0x81, 0xC000);
    I2C_WR(DEV_AD_DEF, 0x82, 0x0000);
    I2C_WR(DEV_AD_DEF, 0x83, 0x0000);

    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);
    I2C_WR(DEV_AD_DEF, 0x33, 0x0000);
    AD.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM13_CLSD_OS_H(short funcindex, LPCTSTR funclabel)
{
    cbit.SetOn(K_CAP_ALL, K61_VOP2LC, K62_VON2LC, -1);
    delay_ms(3);

    PVDD.Set(FV, 4, FOVI_5V, FOVI_100MA, RELAY_ON);//FOR ALL SITE STABLE

    //I2C_WR(DEV_AD_DEF, 0x44, 0x4000);//SR = 12nS
    I2C_WR(DEV_AD_DEF, 0x05, 0x0000);//intn push pull YB dis
    I2C_WR(DEV_AD_DEF, 0x06, 0x0200);//classd en
    I2C_WR(DEV_AD_DEF, 0x13, 0x0000);//boost pass through
    I2C_WR(DEV_AD_DEF, 0x33, 0x0000);//isns en = 0
    I2C_WR(DEV_AD_DEF, 0x82, 0x0004);
    I2C_WR(DEV_AD_DEF, 0x5B, 0x0000);//PLL FORCE LOCK DIS
    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);//standby = 0 iis en
    delay_ms(3);

    dut.trim("CLSD_OS_H").execute(measure_CLSD_OS_H, spec, funcindex, funclabel, 1, 0, "CLSD_OS_H");

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM14_CLSD_OS_L(short funcindex, LPCTSTR funclabel)
{

    dut.trim("CLSD_OS_L").execute(measure_CLSD_OS_L, spec, funcindex, funclabel, 1, 0, "CLSD_OS_L");

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM15_CLSD_PWM(short funcindex, LPCTSTR funclabel)
{


    cbit.SetOn(K_CAP_ALL, K18_INTN2QTMU, K81_INTN_FOVI2BUF, -1);
    delay_ms(3);

    I2C_WR(DEV_AD_DEF, 0x05, 0x0000);
    //I2C_WR(DEV_AD_DEF, 0x44, 0x0000);//SR = 12nS

    I2C_WR(DEV_AD_DEF, 0x83, 0x1000);//en PWM_anti ���ռ�ձ����

    I2C_WR(DEV_AD_DEF, 0x81, 0xE000);//DDMUX en
    I2C_WR(DEV_AD_DEF, 0xA1, 72 << 9);//CD_PWMP

    dut.trim("CLSD_PWM").execute(measure_CLSD_PWM, spec, funcindex, funclabel, 1, 0, "CLSD_PWM");

    //recover
    I2C_WR(DEV_AD_DEF, 0x83, 0x0000);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM16_RAMP_VCM(short funcindex, LPCTSTR funclabel)
{

    cbit.SetOn(K_CAP_ALL, K17_VON2QTMU, K81_INTN_FOVI2BUF,-1);
    delay_ms(3);

    I2C_WR(DEV_AD_DEF, 0x05, 0x0000);
    //I2C_WR(DEV_AD_DEF, 0x44, 0x4000);//SR = 12nS
    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);//standby = 0 iis en MUTE

    dut.trim("RAMP_VCM").execute(measure_RAMP_VCM, spec, funcindex, funclabel, 1, 0, "RAMP_VCM");


    qtmu0.SetStartTrigger(0.62, QTMU_PLUS_POS_SLOPE);
    qtmu0.SetStopTrigger(0.62, QTMU_PLUS_NEG_SLOPE);
    qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TIME_US, 100, 10);

    SERIAL Freq_384K[SITE] = qtmu0.GetMeasureResult(SITE);


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM17_RAMP(short funcindex, LPCTSTR funclabel)
{
    //cbit.SetOn(K_CAP_ALL, -1);
    //delay_ms(1);


    INTN.Set(FI, 0, FOVI_2V, FOVI_10UA, RELAY_SENSE_ON);



    I2C_WR(DEV_AD_DEF, 0x82, 0x0000);//recovery

    I2C_WR(DEV_AD_DEF, 0x81, 0xC300);//ramp dmux
    I2C_WR(DEV_AD_DEF, 0x83, 0x0100);//ramp test en

    //dut.trim("RAMP").execute(measure_RAMP, spec, funcindex, funclabel, 1, 0, "RAMP");


    //recover
    I2C_WR(DEV_AD_DEF, 0x81, 0x0000);
    I2C_WR(DEV_AD_DEF, 0x82, 0x0000);
    I2C_WR(DEV_AD_DEF, 0x83, 0x0000);


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM18_DAC_GAIN(short funcindex, LPCTSTR funclabel)
{

    cbit.SetOn(K_CAP_ALL, K61_VOP2LC, K62_VON2LC, -1);
    delay_ms(3);


    PVDD.Set(FV, 4, FOVI_10V, FOVI_100MA, RELAY_ON);
    //I2C_WR(DEV_AD_DEF, 0x3E, 0x0000);//fade
    //I2C_WR(DEV_AD_DEF, 0x44, 0x4000);//SR = 12nS
    I2C_WR(DEV_AD_DEF, 0x04, 0x8800);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0786);//10DB
    //I2C_WR(DEV_AD_DEF, 0x06, 0x07E6);//19DB
    I2C_WR(DEV_AD_DEF, 0x13, 0x0000);//boost pass through
    I2C_WR(DEV_AD_DEF, 0x14, 0xFF00);//VBST_MAX 11.22V
    I2C_WR(DEV_AD_DEF, 0x33, 0x4000);//default

    dut.trim("DAC_GAIN").execute(measure_DAC_GAIN, spec, funcindex, funclabel, 1, 0, "DAC_GAIN");

    SERIAL Vcoef_Vsns[SITE] = StsGetParam(funcindex, "DAC_GAIN_post")->GetTestResult(SITE, 0) * 1.0148;

    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM19_ISNS_CMRR(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *ISNS_CMRR_H_Step0 = StsGetParam(funcindex, "ISNS_CMRR_H_Step0");
    CParam *ISNS_CMRR_H_Step1 = StsGetParam(funcindex, "ISNS_CMRR_H_Step1");
    CParam *ISNS_CMRR_H_Step2 = StsGetParam(funcindex, "ISNS_CMRR_H_Step2");
    CParam *ISNS_CMRR_H_Step3 = StsGetParam(funcindex, "ISNS_CMRR_H_Step3");
    CParam *ISNS_CMRR_H_Step4 = StsGetParam(funcindex, "ISNS_CMRR_H_Step4");
    CParam *ISNS_CMRR_H_Step5 = StsGetParam(funcindex, "ISNS_CMRR_H_Step5");
    CParam *ISNS_CMRR_H_Step6 = StsGetParam(funcindex, "ISNS_CMRR_H_Step6");
    CParam *ISNS_CMRR_H_Step7 = StsGetParam(funcindex, "ISNS_CMRR_H_Step7");
    CParam *ISNS_CMRR_H_Step8 = StsGetParam(funcindex, "ISNS_CMRR_H_Step8");
    CParam *ISNS_CMRR_H_Step9 = StsGetParam(funcindex, "ISNS_CMRR_H_Step9");
    CParam *ISNS_CMRR_H_Step10 = StsGetParam(funcindex, "ISNS_CMRR_H_Step10");
    CParam *ISNS_CMRR_H_Step11 = StsGetParam(funcindex, "ISNS_CMRR_H_Step11");
    CParam *ISNS_CMRR_H_Step12 = StsGetParam(funcindex, "ISNS_CMRR_H_Step12");
    CParam *ISNS_CMRR_H_Step13 = StsGetParam(funcindex, "ISNS_CMRR_H_Step13");
    CParam *ISNS_CMRR_H_Step14 = StsGetParam(funcindex, "ISNS_CMRR_H_Step14");
    CParam *ISNS_CMRR_H_Step15 = StsGetParam(funcindex, "ISNS_CMRR_H_Step15");
    CParam *ISNS_CMRR_H_Step16 = StsGetParam(funcindex, "ISNS_CMRR_H_Step16");
    CParam *ISNS_CMRR_H_Step17 = StsGetParam(funcindex, "ISNS_CMRR_H_Step17");
    CParam *ISNS_CMRR_H_Step18 = StsGetParam(funcindex, "ISNS_CMRR_H_Step18");
    CParam *ISNS_CMRR_H_Step19 = StsGetParam(funcindex, "ISNS_CMRR_H_Step19");
    CParam *ISNS_CMRR_H_Step20 = StsGetParam(funcindex, "ISNS_CMRR_H_Step20");
    CParam *ISNS_CMRR_H_Step21 = StsGetParam(funcindex, "ISNS_CMRR_H_Step21");
    CParam *ISNS_CMRR_H_Step22 = StsGetParam(funcindex, "ISNS_CMRR_H_Step22");
    CParam *ISNS_CMRR_H_Step23 = StsGetParam(funcindex, "ISNS_CMRR_H_Step23");
    CParam *ISNS_CMRR_H_Step24 = StsGetParam(funcindex, "ISNS_CMRR_H_Step24");
    CParam *ISNS_CMRR_H_Step25 = StsGetParam(funcindex, "ISNS_CMRR_H_Step25");
    CParam *ISNS_CMRR_H_Step26 = StsGetParam(funcindex, "ISNS_CMRR_H_Step26");
    CParam *ISNS_CMRR_H_Step27 = StsGetParam(funcindex, "ISNS_CMRR_H_Step27");
    CParam *ISNS_CMRR_H_Step28 = StsGetParam(funcindex, "ISNS_CMRR_H_Step28");
    CParam *ISNS_CMRR_H_Step29 = StsGetParam(funcindex, "ISNS_CMRR_H_Step29");
    CParam *ISNS_CMRR_H_Step30 = StsGetParam(funcindex, "ISNS_CMRR_H_Step30");
    CParam *ISNS_CMRR_H_Step31 = StsGetParam(funcindex, "ISNS_CMRR_H_Step31");
    CParam *ISNS_CMRR_H_Step32 = StsGetParam(funcindex, "ISNS_CMRR_H_Step32");
    CParam *ISNS_CMRR_H_Step33 = StsGetParam(funcindex, "ISNS_CMRR_H_Step33");
    CParam *ISNS_CMRR_H_Step34 = StsGetParam(funcindex, "ISNS_CMRR_H_Step34");
    CParam *ISNS_CMRR_H_Step35 = StsGetParam(funcindex, "ISNS_CMRR_H_Step35");
    CParam *ISNS_CMRR_H_Step36 = StsGetParam(funcindex, "ISNS_CMRR_H_Step36");
    CParam *ISNS_CMRR_H_Step37 = StsGetParam(funcindex, "ISNS_CMRR_H_Step37");
    CParam *ISNS_CMRR_H_Step38 = StsGetParam(funcindex, "ISNS_CMRR_H_Step38");
    CParam *ISNS_CMRR_H_Step39 = StsGetParam(funcindex, "ISNS_CMRR_H_Step39");
    CParam *ISNS_CMRR_H_Step40 = StsGetParam(funcindex, "ISNS_CMRR_H_Step40");
    CParam *ISNS_CMRR_H_Step41 = StsGetParam(funcindex, "ISNS_CMRR_H_Step41");
    CParam *ISNS_CMRR_H_Step42 = StsGetParam(funcindex, "ISNS_CMRR_H_Step42");
    CParam *ISNS_CMRR_H_Step43 = StsGetParam(funcindex, "ISNS_CMRR_H_Step43");
    CParam *ISNS_CMRR_H_Step44 = StsGetParam(funcindex, "ISNS_CMRR_H_Step44");
    CParam *ISNS_CMRR_H_Step45 = StsGetParam(funcindex, "ISNS_CMRR_H_Step45");
    CParam *ISNS_CMRR_H_Step46 = StsGetParam(funcindex, "ISNS_CMRR_H_Step46");
    CParam *ISNS_CMRR_H_Step47 = StsGetParam(funcindex, "ISNS_CMRR_H_Step47");
    CParam *ISNS_CMRR_H_Step48 = StsGetParam(funcindex, "ISNS_CMRR_H_Step48");
    CParam *ISNS_CMRR_H_Step49 = StsGetParam(funcindex, "ISNS_CMRR_H_Step49");
    CParam *ISNS_CMRR_H_Step50 = StsGetParam(funcindex, "ISNS_CMRR_H_Step50");
    CParam *ISNS_CMRR_H_Step51 = StsGetParam(funcindex, "ISNS_CMRR_H_Step51");
    CParam *ISNS_CMRR_H_Step52 = StsGetParam(funcindex, "ISNS_CMRR_H_Step52");
    CParam *ISNS_CMRR_H_Step53 = StsGetParam(funcindex, "ISNS_CMRR_H_Step53");
    CParam *ISNS_CMRR_H_Step54 = StsGetParam(funcindex, "ISNS_CMRR_H_Step54");
    CParam *ISNS_CMRR_H_Step55 = StsGetParam(funcindex, "ISNS_CMRR_H_Step55");
    CParam *ISNS_CMRR_H_Step56 = StsGetParam(funcindex, "ISNS_CMRR_H_Step56");
    CParam *ISNS_CMRR_H_Step57 = StsGetParam(funcindex, "ISNS_CMRR_H_Step57");
    CParam *ISNS_CMRR_H_Step58 = StsGetParam(funcindex, "ISNS_CMRR_H_Step58");
    CParam *ISNS_CMRR_H_Step59 = StsGetParam(funcindex, "ISNS_CMRR_H_Step59");
    CParam *ISNS_CMRR_H_Step60 = StsGetParam(funcindex, "ISNS_CMRR_H_Step60");
    CParam *ISNS_CMRR_H_Step61 = StsGetParam(funcindex, "ISNS_CMRR_H_Step61");
    CParam *ISNS_CMRR_H_Step62 = StsGetParam(funcindex, "ISNS_CMRR_H_Step62");
    CParam *ISNS_CMRR_H_Step63 = StsGetParam(funcindex, "ISNS_CMRR_H_Step63");
    CParam *ISNS_CMRR_H_pre = StsGetParam(funcindex, "ISNS_CMRR_H_pre");
    CParam *ISNS_CMRR_H_pre_bit = StsGetParam(funcindex, "ISNS_CMRR_H_pre_bit");
    CParam *ISNS_CMRR_H_post = StsGetParam(funcindex, "ISNS_CMRR_H_post");
    CParam *ISNS_CMRR_H_post_bit = StsGetParam(funcindex, "ISNS_CMRR_H_post_bit");
    CParam *ISNS_CMRR_H_target = StsGetParam(funcindex, "ISNS_CMRR_H_target");
    CParam *ISNS_CMRR_H_guessed = StsGetParam(funcindex, "ISNS_CMRR_H_guessed");
    CParam *ISNS_CMRR_H_updated = StsGetParam(funcindex, "ISNS_CMRR_H_updated");
    CParam *ISNS_CMRR_L_Step0 = StsGetParam(funcindex, "ISNS_CMRR_L_Step0");
    CParam *ISNS_CMRR_L_Step1 = StsGetParam(funcindex, "ISNS_CMRR_L_Step1");
    CParam *ISNS_CMRR_L_Step2 = StsGetParam(funcindex, "ISNS_CMRR_L_Step2");
    CParam *ISNS_CMRR_L_Step3 = StsGetParam(funcindex, "ISNS_CMRR_L_Step3");
    CParam *ISNS_CMRR_L_Step4 = StsGetParam(funcindex, "ISNS_CMRR_L_Step4");
    CParam *ISNS_CMRR_L_Step5 = StsGetParam(funcindex, "ISNS_CMRR_L_Step5");
    CParam *ISNS_CMRR_L_Step6 = StsGetParam(funcindex, "ISNS_CMRR_L_Step6");
    CParam *ISNS_CMRR_L_Step7 = StsGetParam(funcindex, "ISNS_CMRR_L_Step7");
    CParam *ISNS_CMRR_L_Step8 = StsGetParam(funcindex, "ISNS_CMRR_L_Step8");
    CParam *ISNS_CMRR_L_Step9 = StsGetParam(funcindex, "ISNS_CMRR_L_Step9");
    CParam *ISNS_CMRR_L_Step10 = StsGetParam(funcindex, "ISNS_CMRR_L_Step10");
    CParam *ISNS_CMRR_L_Step11 = StsGetParam(funcindex, "ISNS_CMRR_L_Step11");
    CParam *ISNS_CMRR_L_Step12 = StsGetParam(funcindex, "ISNS_CMRR_L_Step12");
    CParam *ISNS_CMRR_L_Step13 = StsGetParam(funcindex, "ISNS_CMRR_L_Step13");
    CParam *ISNS_CMRR_L_Step14 = StsGetParam(funcindex, "ISNS_CMRR_L_Step14");
    CParam *ISNS_CMRR_L_Step15 = StsGetParam(funcindex, "ISNS_CMRR_L_Step15");
    CParam *ISNS_CMRR_L_Step16 = StsGetParam(funcindex, "ISNS_CMRR_L_Step16");
    CParam *ISNS_CMRR_L_Step17 = StsGetParam(funcindex, "ISNS_CMRR_L_Step17");
    CParam *ISNS_CMRR_L_Step18 = StsGetParam(funcindex, "ISNS_CMRR_L_Step18");
    CParam *ISNS_CMRR_L_Step19 = StsGetParam(funcindex, "ISNS_CMRR_L_Step19");
    CParam *ISNS_CMRR_L_Step20 = StsGetParam(funcindex, "ISNS_CMRR_L_Step20");
    CParam *ISNS_CMRR_L_Step21 = StsGetParam(funcindex, "ISNS_CMRR_L_Step21");
    CParam *ISNS_CMRR_L_Step22 = StsGetParam(funcindex, "ISNS_CMRR_L_Step22");
    CParam *ISNS_CMRR_L_Step23 = StsGetParam(funcindex, "ISNS_CMRR_L_Step23");
    CParam *ISNS_CMRR_L_Step24 = StsGetParam(funcindex, "ISNS_CMRR_L_Step24");
    CParam *ISNS_CMRR_L_Step25 = StsGetParam(funcindex, "ISNS_CMRR_L_Step25");
    CParam *ISNS_CMRR_L_Step26 = StsGetParam(funcindex, "ISNS_CMRR_L_Step26");
    CParam *ISNS_CMRR_L_Step27 = StsGetParam(funcindex, "ISNS_CMRR_L_Step27");
    CParam *ISNS_CMRR_L_Step28 = StsGetParam(funcindex, "ISNS_CMRR_L_Step28");
    CParam *ISNS_CMRR_L_Step29 = StsGetParam(funcindex, "ISNS_CMRR_L_Step29");
    CParam *ISNS_CMRR_L_Step30 = StsGetParam(funcindex, "ISNS_CMRR_L_Step30");
    CParam *ISNS_CMRR_L_Step31 = StsGetParam(funcindex, "ISNS_CMRR_L_Step31");
    CParam *ISNS_CMRR_L_Step32 = StsGetParam(funcindex, "ISNS_CMRR_L_Step32");
    CParam *ISNS_CMRR_L_Step33 = StsGetParam(funcindex, "ISNS_CMRR_L_Step33");
    CParam *ISNS_CMRR_L_Step34 = StsGetParam(funcindex, "ISNS_CMRR_L_Step34");
    CParam *ISNS_CMRR_L_Step35 = StsGetParam(funcindex, "ISNS_CMRR_L_Step35");
    CParam *ISNS_CMRR_L_Step36 = StsGetParam(funcindex, "ISNS_CMRR_L_Step36");
    CParam *ISNS_CMRR_L_Step37 = StsGetParam(funcindex, "ISNS_CMRR_L_Step37");
    CParam *ISNS_CMRR_L_Step38 = StsGetParam(funcindex, "ISNS_CMRR_L_Step38");
    CParam *ISNS_CMRR_L_Step39 = StsGetParam(funcindex, "ISNS_CMRR_L_Step39");
    CParam *ISNS_CMRR_L_Step40 = StsGetParam(funcindex, "ISNS_CMRR_L_Step40");
    CParam *ISNS_CMRR_L_Step41 = StsGetParam(funcindex, "ISNS_CMRR_L_Step41");
    CParam *ISNS_CMRR_L_Step42 = StsGetParam(funcindex, "ISNS_CMRR_L_Step42");
    CParam *ISNS_CMRR_L_Step43 = StsGetParam(funcindex, "ISNS_CMRR_L_Step43");
    CParam *ISNS_CMRR_L_Step44 = StsGetParam(funcindex, "ISNS_CMRR_L_Step44");
    CParam *ISNS_CMRR_L_Step45 = StsGetParam(funcindex, "ISNS_CMRR_L_Step45");
    CParam *ISNS_CMRR_L_Step46 = StsGetParam(funcindex, "ISNS_CMRR_L_Step46");
    CParam *ISNS_CMRR_L_Step47 = StsGetParam(funcindex, "ISNS_CMRR_L_Step47");
    CParam *ISNS_CMRR_L_Step48 = StsGetParam(funcindex, "ISNS_CMRR_L_Step48");
    CParam *ISNS_CMRR_L_Step49 = StsGetParam(funcindex, "ISNS_CMRR_L_Step49");
    CParam *ISNS_CMRR_L_Step50 = StsGetParam(funcindex, "ISNS_CMRR_L_Step50");
    CParam *ISNS_CMRR_L_Step51 = StsGetParam(funcindex, "ISNS_CMRR_L_Step51");
    CParam *ISNS_CMRR_L_Step52 = StsGetParam(funcindex, "ISNS_CMRR_L_Step52");
    CParam *ISNS_CMRR_L_Step53 = StsGetParam(funcindex, "ISNS_CMRR_L_Step53");
    CParam *ISNS_CMRR_L_Step54 = StsGetParam(funcindex, "ISNS_CMRR_L_Step54");
    CParam *ISNS_CMRR_L_Step55 = StsGetParam(funcindex, "ISNS_CMRR_L_Step55");
    CParam *ISNS_CMRR_L_Step56 = StsGetParam(funcindex, "ISNS_CMRR_L_Step56");
    CParam *ISNS_CMRR_L_Step57 = StsGetParam(funcindex, "ISNS_CMRR_L_Step57");
    CParam *ISNS_CMRR_L_Step58 = StsGetParam(funcindex, "ISNS_CMRR_L_Step58");
    CParam *ISNS_CMRR_L_Step59 = StsGetParam(funcindex, "ISNS_CMRR_L_Step59");
    CParam *ISNS_CMRR_L_Step60 = StsGetParam(funcindex, "ISNS_CMRR_L_Step60");
    CParam *ISNS_CMRR_L_Step61 = StsGetParam(funcindex, "ISNS_CMRR_L_Step61");
    CParam *ISNS_CMRR_L_Step62 = StsGetParam(funcindex, "ISNS_CMRR_L_Step62");
    CParam *ISNS_CMRR_L_Step63 = StsGetParam(funcindex, "ISNS_CMRR_L_Step63");
    CParam *ISNS_CMRR_L_pre = StsGetParam(funcindex, "ISNS_CMRR_L_pre");
    CParam *ISNS_CMRR_L_pre_bit = StsGetParam(funcindex, "ISNS_CMRR_L_pre_bit");
    CParam *ISNS_CMRR_L_post = StsGetParam(funcindex, "ISNS_CMRR_L_post");
    CParam *ISNS_CMRR_L_post_bit = StsGetParam(funcindex, "ISNS_CMRR_L_post_bit");
    CParam *ISNS_CMRR_L_target = StsGetParam(funcindex, "ISNS_CMRR_L_target");
    CParam *ISNS_CMRR_L_guessed = StsGetParam(funcindex, "ISNS_CMRR_L_guessed");
    CParam *ISNS_CMRR_L_updated = StsGetParam(funcindex, "ISNS_CMRR_L_updated");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM24_ISNS_GAIN_ADJ(short funcindex, LPCTSTR funclabel)
{
    CParam* ISNS_GAIN_ADJ_post = StsGetParam(funcindex, "ISNS_GAIN_ADJ_post");
    CParam* R40mohm = StsGetParam(funcindex, "R40mohm");

    double Rsense[SITE_NUM];
    double Rsns_adj_step[8] = { -70, -61.333, -52.075, -45.246, -40, -35.844, -32.471, -29.677 };
    double Rsns_find_flow[SITE_NUM][8];
    long Rsns_adj_code[SITE_NUM];
    double min_value;

    cbit.SetOn(K_CAP_ALL, -1);
    delay_ms(3);

    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);

    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);
    I2C_WR(DEV_AD_DEF, 0x05, 0x0000);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0000);
    I2C_WR(DEV_AD_DEF, 0x13, 0x0000);
    I2C_WR(DEV_AD_DEF, 0x33, 0x0000);//default
    I2C_WR(DEV_AD_DEF, 0x81, 0xC200);


    //////////////////////////////////////////////////////////LSD
    PVDD.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
    AD.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);

    cbit.SetOn(K_CAP_ALL, K90_FPVI0H2VOP, K93_FPVI0L2GND, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x82, 0x0604);
    //I2C_WR(DEV_AD_DEF, 0x44, 3 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, 0.4, 1.5, 0.01, 100, 1, TRIG_RISING, OUTP.DB.LS.OCP[3]);
    //I2C_WR(DEV_AD_DEF, 0x44, 2 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, 0.4, 1.5, 0.01, 100, 1, TRIG_RISING, OUTP.DB.LS.OCP[2]);
    //I2C_WR(DEV_AD_DEF, 0x44, 1 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, 0.4, 1.5, 0.01, 100, 1, TRIG_RISING, OUTP.DB.LS.OCP[1]);
    I2C_WR(DEV_AD_DEF, 0x44, 0 << 10);
    test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, 0.4, 1.5, 0.01, 100, 1, TRIG_RISING, OUTP.DB.LS.OCP[0]);
    FPVI0.Set(FI, 0.6, FPVI10_1V, FPVI10_1A, RELAY_ON);
    delay_ms(1);
	FPVI0.MeasureVI(50, 10);
	SERIAL adresult_BF[SITE] = FPVI0.GetMeasResult(SITE, MVRET);
	FPVI0.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI0.MeasureVI(50, 10);
	SERIAL adresult_AF[SITE] = FPVI0.GetMeasResult(SITE, MVRET);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
	SERIAL OUTP.DB.LS.Rdson[SITE] = (adresult_BF[SITE] - adresult_AF[SITE]) * 2;


    cbit.SetOn(K_CAP_ALL, K91_FPVI0H2VON, K93_FPVI0L2GND, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x82, 0x0704);
    //I2C_WR(DEV_AD_DEF, 0x44, 3 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, 0.4, 1.5, 0.01, 100, 1, TRIG_RISING, OUTN.DB.LS.OCP[3]);
    //I2C_WR(DEV_AD_DEF, 0x44, 2 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, 0.4, 1.5, 0.01, 100, 1, TRIG_RISING, OUTN.DB.LS.OCP[2]);
    //I2C_WR(DEV_AD_DEF, 0x44, 1 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, 0.4, 1.5, 0.01, 100, 1, TRIG_RISING, OUTN.DB.LS.OCP[1]);
    I2C_WR(DEV_AD_DEF, 0x44, 0 << 10);
	test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, 0.4, 1.5, 0.01, 100, 1, TRIG_RISING, OUTN.DB.LS.OCP[0]);
	FPVI0.Set(FI, 0.6, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI0.MeasureVI(50, 10);
	SERIAL adresult_BF[SITE] = FPVI0.GetMeasResult(SITE, MVRET);
	FPVI0.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI0.MeasureVI(50, 10);
	SERIAL adresult_AF[SITE] = FPVI0.GetMeasResult(SITE, MVRET);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
	SERIAL OUTN.DB.LS.Rdson[SITE] = (adresult_BF[SITE] - adresult_AF[SITE]) * 2;

    FPVI0.Set(FV, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);//SPIKE
    //////////////////////////////////////////////////////////HSD
    AD.Set(FV, 6, FOVI_10V, FOVI_100MA, RELAY_ON);

    cbit.SetOn(K_CAP_ALL, K90_FPVI0H2VOP, K94_FPVI0L2PVDD, -1);
    delay_ms(3);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);//SPIKE
    I2C_WR(DEV_AD_DEF, 0x82, 0x0686);
    PVDD.Set(FV, 3, FOVI_10V, FOVI_100MA, RELAY_ON);
    //I2C_WR(DEV_AD_DEF, 0x44, 3 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, -0.0, -1, -0.01, 100, 1, TRIG_RISING, OUTP.DB.HS.OCP[3]);
    //I2C_WR(DEV_AD_DEF, 0x44, 2 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, -0.0, -1, -0.01, 100, 1, TRIG_RISING, OUTP.DB.HS.OCP[2]);
    //I2C_WR(DEV_AD_DEF, 0x44, 1 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, -0.0, -1, -0.01, 100, 1, TRIG_RISING, OUTP.DB.HS.OCP[1]);
    I2C_WR(DEV_AD_DEF, 0x44, 0 << 10);
    test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, -0.0, -1, -0.01, 100, 1, TRIG_RISING, OUTP.DB.HS.OCP[0]);
	PVDD.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	FPVI0.Set(FI, -0.6, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI0.MeasureVI(50, 10);
	SERIAL adresult_BF[SITE] = FPVI0.GetMeasResult(SITE, MVRET);
	FPVI0.Set(FI, -0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI0.MeasureVI(50, 10);
	SERIAL adresult_AF[SITE] = FPVI0.GetMeasResult(SITE, MVRET);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
	SERIAL OUTP.DB.HS.Rdson[SITE] = (adresult_AF[SITE] - adresult_BF[SITE]) * 2;


    AD.Set(FV, 6, FOVI_10V, FOVI_100MA, RELAY_ON);
    cbit.SetOn(K_CAP_ALL, K91_FPVI0H2VON, K94_FPVI0L2PVDD, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x82, 0x0786);
    PVDD.Set(FV, 3, FOVI_10V, FOVI_100MA, RELAY_ON);
    //I2C_WR(DEV_AD_DEF, 0x44, 3 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, -0.0, -1, -0.01, 100, 1, TRIG_RISING, OUTN.DB.HS.OCP[3]);
    //I2C_WR(DEV_AD_DEF, 0x44, 2 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, -0.0, -1, -0.01, 100, 1, TRIG_RISING, OUTN.DB.HS.OCP[2]);
    //I2C_WR(DEV_AD_DEF, 0x44, 1 << 10);
    //test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, -0.0, -1, -0.01, 100, 1, TRIG_RISING, OUTN.DB.HS.OCP[1]);
    I2C_WR(DEV_AD_DEF, 0x44, 0 << 10);
    test_method.ramp(FPVI0, FPVI10_1V, FPVI10_10A, INTN, -0.0, -1, -0.01, 100, 1, TRIG_RISING, OUTN.DB.HS.OCP[0]);
	PVDD.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	FPVI0.Set(FI, -0.6, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI0.MeasureVI(50, 10);
	SERIAL adresult_BF[SITE] = FPVI0.GetMeasResult(SITE, MVRET);
	FPVI0.Set(FI, -0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI0.MeasureVI(50, 10);
	SERIAL adresult_AF[SITE] = FPVI0.GetMeasResult(SITE, MVRET);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
	SERIAL OUTN.DB.HS.Rdson[SITE] = (adresult_AF[SITE] - adresult_BF[SITE]) * 2;

    SERIAL Rsense[SITE] = (OUTP.DB.HS.Rdson[SITE] + OUTP.DB.LS.Rdson[SITE] - OUTN.DB.HS.Rdson[SITE] - OUTN.DB.LS.Rdson[SITE]) / 2;
    //SERIAL OUTP.DB.HS.Rdson[SITE] = OUTP.DB.HS.Rdson[SITE] - Rsense[SITE];//decrease rsense
    //SERIAL OUTP.DB.LS.Rdson[SITE] = OUTP.DB.LS.Rdson[SITE] - Rsense[SITE];//decrease rsense

    //SERIAL R40mohm->SetTestResult(SITE, 0, Rsense[SITE] * 1000);



    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    INTN.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    AD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    POWER_OFF(NORMAL, RES_RELAY_OFF);



    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM25_I_SENSE_CAL_H(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *I_SENSE_CAL_H_Step0 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step0");
    CParam *I_SENSE_CAL_H_Step1 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step1");
    CParam *I_SENSE_CAL_H_Step2 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step2");
    CParam *I_SENSE_CAL_H_Step3 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step3");
    CParam *I_SENSE_CAL_H_Step4 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step4");
    CParam *I_SENSE_CAL_H_Step5 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step5");
    CParam *I_SENSE_CAL_H_Step6 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step6");
    CParam *I_SENSE_CAL_H_Step7 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step7");
    CParam *I_SENSE_CAL_H_Step8 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step8");
    CParam *I_SENSE_CAL_H_Step9 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step9");
    CParam *I_SENSE_CAL_H_Step10 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step10");
    CParam *I_SENSE_CAL_H_Step11 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step11");
    CParam *I_SENSE_CAL_H_Step12 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step12");
    CParam *I_SENSE_CAL_H_Step13 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step13");
    CParam *I_SENSE_CAL_H_Step14 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step14");
    CParam *I_SENSE_CAL_H_Step15 = StsGetParam(funcindex, "I_SENSE_CAL_H_Step15");
    CParam *I_SENSE_CAL_H_pre = StsGetParam(funcindex, "I_SENSE_CAL_H_pre");
    CParam *I_SENSE_CAL_H_pre_bit = StsGetParam(funcindex, "I_SENSE_CAL_H_pre_bit");
    CParam *I_SENSE_CAL_H_post = StsGetParam(funcindex, "I_SENSE_CAL_H_post");
    CParam *I_SENSE_CAL_H_post_bit = StsGetParam(funcindex, "I_SENSE_CAL_H_post_bit");
    CParam *I_SENSE_CAL_H_target = StsGetParam(funcindex, "I_SENSE_CAL_H_target");
    CParam *I_SENSE_CAL_H_guessed = StsGetParam(funcindex, "I_SENSE_CAL_H_guessed");
    CParam *I_SENSE_CAL_H_updated = StsGetParam(funcindex, "I_SENSE_CAL_H_updated");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here
    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM26_I_SENSE_CAL_L(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *I_SENSE_CAL_L_Step0 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step0");
    CParam *I_SENSE_CAL_L_Step1 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step1");
    CParam *I_SENSE_CAL_L_Step2 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step2");
    CParam *I_SENSE_CAL_L_Step3 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step3");
    CParam *I_SENSE_CAL_L_Step4 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step4");
    CParam *I_SENSE_CAL_L_Step5 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step5");
    CParam *I_SENSE_CAL_L_Step6 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step6");
    CParam *I_SENSE_CAL_L_Step7 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step7");
    CParam *I_SENSE_CAL_L_Step8 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step8");
    CParam *I_SENSE_CAL_L_Step9 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step9");
    CParam *I_SENSE_CAL_L_Step10 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step10");
    CParam *I_SENSE_CAL_L_Step11 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step11");
    CParam *I_SENSE_CAL_L_Step12 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step12");
    CParam *I_SENSE_CAL_L_Step13 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step13");
    CParam *I_SENSE_CAL_L_Step14 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step14");
    CParam *I_SENSE_CAL_L_Step15 = StsGetParam(funcindex, "I_SENSE_CAL_L_Step15");
    CParam *I_SENSE_CAL_L_pre = StsGetParam(funcindex, "I_SENSE_CAL_L_pre");
    CParam *I_SENSE_CAL_L_pre_bit = StsGetParam(funcindex, "I_SENSE_CAL_L_pre_bit");
    CParam *I_SENSE_CAL_L_post = StsGetParam(funcindex, "I_SENSE_CAL_L_post");
    CParam *I_SENSE_CAL_L_post_bit = StsGetParam(funcindex, "I_SENSE_CAL_L_post_bit");
    CParam *I_SENSE_CAL_L_target = StsGetParam(funcindex, "I_SENSE_CAL_L_target");
    CParam *I_SENSE_CAL_L_guessed = StsGetParam(funcindex, "I_SENSE_CAL_L_guessed");
    CParam *I_SENSE_CAL_L_updated = StsGetParam(funcindex, "I_SENSE_CAL_L_updated");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here
    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM27_I_SENSE_OS_CAL_H(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *I_SENSE_OS_CAL_H_Step0 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step0");
    CParam *I_SENSE_OS_CAL_H_Step1 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step1");
    CParam *I_SENSE_OS_CAL_H_Step2 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step2");
    CParam *I_SENSE_OS_CAL_H_Step3 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step3");
    CParam *I_SENSE_OS_CAL_H_Step4 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step4");
    CParam *I_SENSE_OS_CAL_H_Step5 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step5");
    CParam *I_SENSE_OS_CAL_H_Step6 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step6");
    CParam *I_SENSE_OS_CAL_H_Step7 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step7");
    CParam *I_SENSE_OS_CAL_H_Step8 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step8");
    CParam *I_SENSE_OS_CAL_H_Step9 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step9");
    CParam *I_SENSE_OS_CAL_H_Step10 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step10");
    CParam *I_SENSE_OS_CAL_H_Step11 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step11");
    CParam *I_SENSE_OS_CAL_H_Step12 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step12");
    CParam *I_SENSE_OS_CAL_H_Step13 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step13");
    CParam *I_SENSE_OS_CAL_H_Step14 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step14");
    CParam *I_SENSE_OS_CAL_H_Step15 = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_Step15");
    CParam *I_SENSE_OS_CAL_H_pre = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_pre");
    CParam *I_SENSE_OS_CAL_H_pre_bit = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_pre_bit");
    CParam *I_SENSE_OS_CAL_H_post = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_post");
    CParam *I_SENSE_OS_CAL_H_post_bit = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_post_bit");
    CParam *I_SENSE_OS_CAL_H_target = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_target");
    CParam *I_SENSE_OS_CAL_H_guessed = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_guessed");
    CParam *I_SENSE_OS_CAL_H_updated = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_updated");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here
    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM28_I_SENSE_OS_CAL_L(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *I_SENSE_OS_CAL_L_Step0 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step0");
    CParam *I_SENSE_OS_CAL_L_Step1 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step1");
    CParam *I_SENSE_OS_CAL_L_Step2 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step2");
    CParam *I_SENSE_OS_CAL_L_Step3 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step3");
    CParam *I_SENSE_OS_CAL_L_Step4 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step4");
    CParam *I_SENSE_OS_CAL_L_Step5 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step5");
    CParam *I_SENSE_OS_CAL_L_Step6 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step6");
    CParam *I_SENSE_OS_CAL_L_Step7 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step7");
    CParam *I_SENSE_OS_CAL_L_Step8 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step8");
    CParam *I_SENSE_OS_CAL_L_Step9 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step9");
    CParam *I_SENSE_OS_CAL_L_Step10 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step10");
    CParam *I_SENSE_OS_CAL_L_Step11 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step11");
    CParam *I_SENSE_OS_CAL_L_Step12 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step12");
    CParam *I_SENSE_OS_CAL_L_Step13 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step13");
    CParam *I_SENSE_OS_CAL_L_Step14 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step14");
    CParam *I_SENSE_OS_CAL_L_Step15 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step15");
    CParam *I_SENSE_OS_CAL_L_Step16 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step16");
    CParam *I_SENSE_OS_CAL_L_Step17 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step17");
    CParam *I_SENSE_OS_CAL_L_Step18 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step18");
    CParam *I_SENSE_OS_CAL_L_Step19 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step19");
    CParam *I_SENSE_OS_CAL_L_Step20 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step20");
    CParam *I_SENSE_OS_CAL_L_Step21 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step21");
    CParam *I_SENSE_OS_CAL_L_Step22 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step22");
    CParam *I_SENSE_OS_CAL_L_Step23 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step23");
    CParam *I_SENSE_OS_CAL_L_Step24 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step24");
    CParam *I_SENSE_OS_CAL_L_Step25 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step25");
    CParam *I_SENSE_OS_CAL_L_Step26 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step26");
    CParam *I_SENSE_OS_CAL_L_Step27 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step27");
    CParam *I_SENSE_OS_CAL_L_Step28 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step28");
    CParam *I_SENSE_OS_CAL_L_Step29 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step29");
    CParam *I_SENSE_OS_CAL_L_Step30 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step30");
    CParam *I_SENSE_OS_CAL_L_Step31 = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_Step31");
    CParam *I_SENSE_OS_CAL_L_pre = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_pre");
    CParam *I_SENSE_OS_CAL_L_pre_bit = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_pre_bit");
    CParam *I_SENSE_OS_CAL_L_post = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_post");
    CParam *I_SENSE_OS_CAL_L_post_bit = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_post_bit");
    CParam *I_SENSE_OS_CAL_L_target = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_target");
    CParam *I_SENSE_OS_CAL_L_guessed = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_guessed");
    CParam *I_SENSE_OS_CAL_L_updated = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_updated");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here
    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int TRIM29_V_SENSE_CAL(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *V_SENSE_CAL_Step0 = StsGetParam(funcindex, "V_SENSE_CAL_Step0");
    CParam *V_SENSE_CAL_Step1 = StsGetParam(funcindex, "V_SENSE_CAL_Step1");
    CParam *V_SENSE_CAL_Step2 = StsGetParam(funcindex, "V_SENSE_CAL_Step2");
    CParam *V_SENSE_CAL_Step3 = StsGetParam(funcindex, "V_SENSE_CAL_Step3");
    CParam *V_SENSE_CAL_Step4 = StsGetParam(funcindex, "V_SENSE_CAL_Step4");
    CParam *V_SENSE_CAL_Step5 = StsGetParam(funcindex, "V_SENSE_CAL_Step5");
    CParam *V_SENSE_CAL_Step6 = StsGetParam(funcindex, "V_SENSE_CAL_Step6");
    CParam *V_SENSE_CAL_Step7 = StsGetParam(funcindex, "V_SENSE_CAL_Step7");
    CParam *V_SENSE_CAL_Step8 = StsGetParam(funcindex, "V_SENSE_CAL_Step8");
    CParam *V_SENSE_CAL_Step9 = StsGetParam(funcindex, "V_SENSE_CAL_Step9");
    CParam *V_SENSE_CAL_Step10 = StsGetParam(funcindex, "V_SENSE_CAL_Step10");
    CParam *V_SENSE_CAL_Step11 = StsGetParam(funcindex, "V_SENSE_CAL_Step11");
    CParam *V_SENSE_CAL_Step12 = StsGetParam(funcindex, "V_SENSE_CAL_Step12");
    CParam *V_SENSE_CAL_Step13 = StsGetParam(funcindex, "V_SENSE_CAL_Step13");
    CParam *V_SENSE_CAL_Step14 = StsGetParam(funcindex, "V_SENSE_CAL_Step14");
    CParam *V_SENSE_CAL_Step15 = StsGetParam(funcindex, "V_SENSE_CAL_Step15");
    CParam *V_SENSE_CAL_pre = StsGetParam(funcindex, "V_SENSE_CAL_pre");
    CParam *V_SENSE_CAL_pre_bit = StsGetParam(funcindex, "V_SENSE_CAL_pre_bit");
    CParam *V_SENSE_CAL_post = StsGetParam(funcindex, "V_SENSE_CAL_post");
    CParam *V_SENSE_CAL_post_bit = StsGetParam(funcindex, "V_SENSE_CAL_post_bit");
    CParam *V_SENSE_CAL_target = StsGetParam(funcindex, "V_SENSE_CAL_target");
    CParam *V_SENSE_CAL_guessed = StsGetParam(funcindex, "V_SENSE_CAL_guessed");
    CParam *V_SENSE_CAL_updated = StsGetParam(funcindex, "V_SENSE_CAL_updated");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here
    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int EE_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam* EE0_trim_bit = StsGetParam(funcindex, "EE0_trim_bit");
    CParam* EE1_trim_bit = StsGetParam(funcindex, "EE1_trim_bit");
    CParam* EE2_trim_bit = StsGetParam(funcindex, "EE2_trim_bit");
    CParam* EE3_trim_bit = StsGetParam(funcindex, "EE3_trim_bit");
    CParam* EE4_trim_bit = StsGetParam(funcindex, "EE4_trim_bit");
    CParam* EE5_trim_bit = StsGetParam(funcindex, "EE5_trim_bit");
    CParam* EE6_trim_bit = StsGetParam(funcindex, "EE6_trim_bit");
    CParam* EE7_trim_bit = StsGetParam(funcindex, "EE7_trim_bit");
    CParam* EE_burn_flag = StsGetParam(funcindex, "EE_burn_flag");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here


    if (QC || !DO_TRIM)   return 0;


    cbit.SetOn(-1);
    delay_ms(1);

    POWER_ON(WITH_TM);

    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);//en iis sys work


    UINT16 EE_BYTE_DATA[BANK_NUM][SITE_NUM];
    UINT16 EE_BURN_REG[SITE_NUM];
    //EE_TRIM
    for (int reg = 0; reg < dut.assy.count(); ++reg)
    {
        string EE_str = string(dut.assy[reg].get_name());
        SERIAL EE_BYTE_DATA[reg][SITE] = dut.assy(EE_str.c_str()).get_working(SITE);
        I2C_WR_DIFF(DEV_AD_DEF, TRIM_BANK_ST + reg, EE_BYTE_DATA[reg]);
    }

    SERIAL EE_BURN_REG[SITE] = burn_flag[SITE] ? 0x8001 : 0x0000;//BURN
    I2C_WR_DIFF(DEV_AD_DEF, 0xA0, EE_BURN_REG);//burn

    delay_ms(5);/////////WAII DEBUG
    //I2C_RD_ALL();

    ////DLOG_OUT
    for (int reg = 0; reg < dut.assy.count(); ++reg)
    {
        string EE_str = string(dut.assy[reg].get_name());
        string param_str = "EE" + int2str(reg) + "_trim_bit";
        SERIAL
        {
            if (burn_flag[SITE])
            {
                dut.assy(EE_str.c_str()).programmed(SITE);
                dut.assy(EE_str.c_str()).copy_work_to_prog(SITE);
            }
            else
            {
                dut.assy(EE_str.c_str()).copy_read_to_prog(SITE);
            }
            StsGetParam(funcindex, param_str.c_str())->SetTestResult(SITE, 0, dut.assy(EE_str.c_str()).get_working(SITE));
        }
    }
    SERIAL EE_burn_flag->SetTestResult(SITE, 0, burn_flag[SITE]);


    POWER_OFF(NORMAL, RES_RELAY_OFF);


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int IQ_pre(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IQ_DVDD_STBY_pre = StsGetParam(funcindex, "IQ_DVDD_STBY_pre");
    CParam *IQ_VBAT_STBY_pre = StsGetParam(funcindex, "IQ_VBAT_STBY_pre");
    CParam *IQ_DVDD_IDLE_NG_ON_pre = StsGetParam(funcindex, "IQ_DVDD_IDLE_NG_ON_pre");
    CParam *IQ_VBAT_IDLE_NG_ON_pre = StsGetParam(funcindex, "IQ_VBAT_IDLE_NG_ON_pre");
    CParam *IQ_DVDD_IDLE_DB_pre = StsGetParam(funcindex, "IQ_DVDD_IDLE_DB_pre");
    CParam *IQ_VBAT_IDLE_DB_pre = StsGetParam(funcindex, "IQ_VBAT_IDLE_DB_pre");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here



    cbit.SetOn(K60_LR_Load, K14_BOOST_L, -1);
    delay_ms(3);



    VBAT.Set(FV, 4.2, FOVI_10V, FOVI_1MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_100UA, RELAY_ON);
    delay_ms(5);


    DVDD.MeasureVI(50, 10);
    VBAT.MeasureVI(50, 10);

    SERIAL IQ.VBAT.pre.STBY[SITE] = VBAT.GetMeasResult(SITE, MIRET);
    SERIAL IQ.DVDD.pre.STBY[SITE] = DVDD.GetMeasResult(SITE, MIRET);


    SERIAL IQ_VBAT_STBY_pre->SetTestResult(SITE, 0, IQ.VBAT.pre.STBY[SITE] * 1e6);
    SERIAL IQ_DVDD_STBY_pre->SetTestResult(SITE, 0, IQ.DVDD.pre.STBY[SITE] * 1e6);



    VBAT.Set(FV, 4.2, FOVI_10V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);
    delay_ms(3);

    I2C_WR(DEV_AD_DEF, 0x07, 0x4E80);//32bit
    I2C_WR(DEV_AD_DEF, 0x39, 0x7CDB);//PLL 32bit 48K cfg
    I2C_WR(DEV_AD_DEF, 0x05, 0xB000);//YB dis
    I2C_WR(DEV_AD_DEF, 0x13, 0x0000);//boost pass through
    I2C_WR(DEV_AD_DEF, 0x06, 0x06E7);//classd en
    I2C_WR(DEV_AD_DEF, 0x33, 0x0000);//ivsns_dis
    I2C_WR(DEV_AD_DEF, 0x1E, 0x0800);//iv_psm_disable
    I2C_WR(DEV_AD_DEF, 0x04, 0xBA52);//sys working NG ON

    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(2);

    VBAT.Set(FV, 4.2, FOVI_10V, FOVI_100UA, RELAY_ON);
    delay_ms(5);
    DVDD.MeasureVI(50, 10);
    VBAT.MeasureVI(50, 10);


    SERIAL IQ.VBAT.pre.IDLE_NG_ON[SITE] = VBAT.GetMeasResult(SITE, MIRET);
    SERIAL IQ.DVDD.pre.IDLE_NG_ON[SITE] = DVDD.GetMeasResult(SITE, MIRET);

    SERIAL IQ_VBAT_IDLE_NG_ON_pre->SetTestResult(SITE, 0, IQ.VBAT.pre.IDLE_NG_ON[SITE] * 1e6);
    SERIAL IQ_DVDD_IDLE_NG_ON_pre->SetTestResult(SITE, 0, IQ.DVDD.pre.IDLE_NG_ON[SITE] * 1e3);


    VBAT.Set(FV, 4.2, FOVI_10V, FOVI_100MA, RELAY_ON);
    I2C_WR(DEV_AD_DEF, 0x04, 0x9A52);//sys working NG OFF

    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(2);

    DVDD.MeasureVI(50, 10);
    VBAT.MeasureVI(50, 10);

    SERIAL IQ.VBAT.pre.IDLE_DB[SITE] = VBAT.GetMeasResult(SITE, MIRET);
    SERIAL IQ.DVDD.pre.IDLE_DB[SITE] = DVDD.GetMeasResult(SITE, MIRET);

    SERIAL IQ_VBAT_IDLE_DB_pre->SetTestResult(SITE, 0, IQ.VBAT.pre.IDLE_DB[SITE] * 1e3);
    SERIAL IQ_DVDD_IDLE_DB_pre->SetTestResult(SITE, 0, IQ.DVDD.pre.IDLE_DB[SITE] * 1e3);



    dio_plus.Stop();
    POWER_OFF(NORMAL, RES_RELAY_OFF);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int Ioff_pre(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Ioff_VOP_DB_LSD_pre = StsGetParam(funcindex, "Ioff_VOP_DB_LSD_pre");
    CParam *Ioff_VOP_DB_HSD_pre = StsGetParam(funcindex, "Ioff_VOP_DB_HSD_pre");
    CParam *Ioff_VON_DB_LSD_pre = StsGetParam(funcindex, "Ioff_VON_DB_LSD_pre");
    CParam *Ioff_VON_DB_HSD_pre = StsGetParam(funcindex, "Ioff_VON_DB_HSD_pre");
    CParam *Ioff_BOOST_LSD_pre = StsGetParam(funcindex, "Ioff_BOOST_LSD_pre");
    CParam *Ioff_BOOST_HSD_pre = StsGetParam(funcindex, "Ioff_BOOST_HSD_pre");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here



    cbit.SetOn(-1);

    POWER_ON(WITH_TM);

    I2C_WR(DEV_AD_DEF, 0x83, 0x0200);//BG EN
    //I2C_WR(DEV_AD_DEF, 0x44, 0x0100);//dis DB PD
    //I2C_WR(DEV_AD_DEF, 0x45, 0x4000);//dis YB PD

    PVDD.Set(FV, 5, FOVI_20V, FOVI_100MA, RELAY_ON);

    //////////////////////////////////////////////////////////VON
    I2C_WR(DEV_AD_DEF, 0x82, 0x0204);

    VON.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(1);
    VON.MeasureVI(100, 10);
    SERIAL OUTN.DB.LS.Ioff_pre[SITE] = VON.GetMeasResult(SITE, MIRET);

    I2C_WR(DEV_AD_DEF, 0x82, 0x0200);

    VON.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(1);
    VON.MeasureVI(100, 10);
    SERIAL OUTN.DB.HS.Ioff_pre[SITE] = VON.GetMeasResult(SITE, MIRET);

    //////////////////////////////////////////////////////////VOP
    I2C_WR(DEV_AD_DEF, 0x82, 0x0304);

    VOP.Set(FV, 5, FOVI_10V, FOVI_10MA, RELAY_ON);
    delay_ms(1);
    VOP.MeasureVI(100, 10);
    SERIAL OUTP.DB.LS.Ioff_pre[SITE] = VOP.GetMeasResult(SITE, MIRET);

    I2C_WR(DEV_AD_DEF, 0x82, 0x0300);

    VOP.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_ON);
    delay_ms(1);
    VOP.MeasureVI(100, 10);
    SERIAL OUTP.DB.HS.Ioff_pre[SITE] = VOP.GetMeasResult(SITE, MIRET);




    I2C_WR(DEV_AD_DEF, 0x82, 0x0000);
    PVDD.Set(FV, 12, FOVI_20V, FOVI_100MA, RELAY_ON);


    SW.Set(FV, 0, FOVI_20V, FOVI_1MA, RELAY_ON);
    delay_ms(1);
    SW.Set(FV, 0, FOVI_20V, FOVI_10UA, RELAY_ON);
    delay_ms(1);
    SW.MeasureVI(100, 10);
    SERIAL boost.HS.Ioff_pre[SITE] = SW.GetMeasResult(SITE, MIRET);

    SW.Set(FV, 12, FOVI_20V, FOVI_1MA, RELAY_ON);
    delay_ms(1);
    SW.Set(FV, 12, FOVI_20V, FOVI_10UA, RELAY_ON);
    delay_ms(1);
    SW.MeasureVI(100, 10);
    SERIAL boost.LS.Ioff_pre[SITE] = SW.GetMeasResult(SITE, MIRET);


    SERIAL Ioff_VOP_DB_LSD_pre->SetTestResult(SITE, 0, OUTP.DB.LS.Ioff_pre[SITE] * 1e6);
    SERIAL Ioff_VOP_DB_HSD_pre->SetTestResult(SITE, 0, OUTP.DB.HS.Ioff_pre[SITE] * 1e6);
    SERIAL Ioff_VON_DB_LSD_pre->SetTestResult(SITE, 0, OUTN.DB.LS.Ioff_pre[SITE] * 1e6);
    SERIAL Ioff_VON_DB_HSD_pre->SetTestResult(SITE, 0, OUTN.DB.HS.Ioff_pre[SITE] * 1e6);
    SERIAL Ioff_BOOST_LSD_pre->SetTestResult(SITE, 0, boost.LS.Ioff_pre[SITE] * 1e9);
    SERIAL Ioff_BOOST_HSD_pre->SetTestResult(SITE, 0, boost.HS.Ioff_pre[SITE] * 1e9);


    SW.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    VOP.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    VON.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    POWER_OFF(NORMAL, RES_RELAY_OFF);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int Idrive_pre(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Idrive_VOP_DB_LSD_pre = StsGetParam(funcindex, "Idrive_VOP_DB_LSD_pre");
    CParam *Idrive_VON_DB_LSD_pre = StsGetParam(funcindex, "Idrive_VON_DB_LSD_pre");
    CParam *Idrive_VOP_DB_HSD_pre = StsGetParam(funcindex, "Idrive_VOP_DB_HSD_pre");
    CParam *Idrive_VON_DB_HSD_pre = StsGetParam(funcindex, "Idrive_VON_DB_HSD_pre");
    CParam *Idrive_BOOST_LSD_pre = StsGetParam(funcindex, "Idrive_BOOST_LSD_pre");
    CParam *Idrive_BOOST_HSD_pre = StsGetParam(funcindex, "Idrive_BOOST_HSD_pre");
    CParam *Rdson_VOP_DB_LSD = StsGetParam(funcindex, "Rdson_VOP_DB_LSD");
    CParam *Rdson_VON_DB_LSD = StsGetParam(funcindex, "Rdson_VON_DB_LSD");
    CParam *Rdson_VOP_DB_HSD = StsGetParam(funcindex, "Rdson_VOP_DB_HSD");
    CParam *Rdson_VON_DB_HSD = StsGetParam(funcindex, "Rdson_VON_DB_HSD");
    CParam *Rdson_BOOST_LSD = StsGetParam(funcindex, "Rdson_BOOST_LSD");
    CParam *Rdson_BOOST_HSD = StsGetParam(funcindex, "Rdson_BOOST_HSD");
    CParam *OC_DB_VOP_HSD = StsGetParam(funcindex, "OC_DB_VOP_HSD");
    CParam *OC_DB_VON_HSD = StsGetParam(funcindex, "OC_DB_VON_HSD");
    CParam *OC_DB_VOP_LSD = StsGetParam(funcindex, "OC_DB_VOP_LSD");
    CParam *OC_DB_VON_LSD = StsGetParam(funcindex, "OC_DB_VON_LSD");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here


    GPFOVI OUTPN_GP("OUTPN_GP", VOP, VON);

    double OVST_TIME = 100;

    OUTPN_GP.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    ALL_FPVI.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    cbit.SetOn(-1);
    delay_ms(3);

    POWER_ON(WITH_TM);

    I2C_WR(DEV_AD_DEF, 0x83, 0x0200);//bg tm en
    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);//
    delay_ms(3);


    PVDD.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	AD.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(3);


    ////////////////////////////////////////////////////DB
    //OUTP_LS
    I2C_WR(DEV_AD_DEF, 0x82, 0x0206);// test TM_DB = 1 TM_DBRON = 00  tm vcc vcc sel
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL OUTP.DB.LS.Idrive_pre[SITE] = AD.GetMeasResult(SITE, MIRET);

    AD.Set(FV, 8, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(OVST_TIME);

    AD.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL OUTP.DB.LS.Idrive_post[SITE] = AD.GetMeasResult(SITE, MIRET);

    //OUTN_LS
    I2C_WR(DEV_AD_DEF, 0x82, 0x0306);// test TM_DB = 1 TM_DBRON = 10  tm vcc vcc sel
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL OUTN.DB.LS.Idrive_pre[SITE] = AD.GetMeasResult(SITE, MIRET);

    AD.Set(FV, 8, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(OVST_TIME);

    AD.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL OUTN.DB.LS.Idrive_post[SITE] = AD.GetMeasResult(SITE, MIRET);



    ////HS
    PVDD.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);


    //OUTP_HS
    I2C_WR(DEV_AD_DEF, 0x82, 0x0280);// test TM_DB = 1 TM_DBRON = 01  tm vcc vcc sel
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL OUTP.DB.HS.Idrive_pre[SITE] = AD.GetMeasResult(SITE, MIRET);

    AD.Set(FV, 8, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(OVST_TIME);

    AD.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL OUTP.DB.HS.Idrive_post[SITE] = AD.GetMeasResult(SITE, MIRET);


    //OUTN_HS
    I2C_WR(DEV_AD_DEF, 0x82, 0x0380);// test TM_DB = 1 TM_DBRON = 11  tm vcc vcc sel
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL OUTN.DB.HS.Idrive_pre[SITE] = AD.GetMeasResult(SITE, MIRET);

    AD.Set(FV, 8, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(OVST_TIME);

    AD.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL OUTN.DB.HS.Idrive_post[SITE] = AD.GetMeasResult(SITE, MIRET);


    //boost_hsd
    I2C_WR(DEV_AD_DEF, 0x81, 0x8600);//AMUX BOOST
    I2C_WR(DEV_AD_DEF, 0x82, 0x0008);//boost hsd on
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL boost.HS.Idrive_pre[SITE] = AD.GetMeasResult(SITE, MIRET);

    AD.Set(FV, 8, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(OVST_TIME);

    AD.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL boost.HS.Idrive_post[SITE] = AD.GetMeasResult(SITE, MIRET);

    
    //hsd rdson
    cbit.SetOn(K96_FPVI01H2SW, K98_FPVI01L2PVDD, K99_FPVI0_FS, K100_FPVI1_FS, -1);
    delay_ms(3);

    FPVI0.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
    delay_ms(1);
	FPVI1.MeasureVI(50, 10);
	SERIAL adresult_BF[SITE] = FPVI1.GetMeasResult(SITE, MVRET);
	FPVI0.Set(FI, 0.6, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI1.MeasureVI(50, 10);
	SERIAL adresult_AF[SITE] = FPVI1.GetMeasResult(SITE, MVRET);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
	SERIAL boost.HS.Rdson[SITE] = (adresult_AF[SITE] - adresult_BF[SITE]) * 2;
    

    PVDD.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
    //boost_lsd
    I2C_WR(DEV_AD_DEF, 0x81, 0x8680);//boost lsd on
    I2C_WR(DEV_AD_DEF, 0x82, 0x0006);//boost vcc vccsel
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL boost.LS.Idrive_pre[SITE] = AD.GetMeasResult(SITE, MIRET);

    AD.Set(FV, 8, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(OVST_TIME);

    AD.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(3);
    AD.MeasureVI(50, 10);
    SERIAL boost.LS.Idrive_post[SITE] = AD.GetMeasResult(SITE, MIRET);



    //lsd rdson
    cbit.SetOn(K96_FPVI01H2SW, K97_FPVI01L2GND, K99_FPVI0_FS, K100_FPVI1_FS, -1);
    delay_ms(3);

	FPVI0.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI1.MeasureVI(50, 10);
	SERIAL adresult_BF[SITE] = FPVI1.GetMeasResult(SITE, MVRET);
	FPVI0.Set(FI, 0.6, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(1);
	FPVI1.MeasureVI(50, 10);
	SERIAL adresult_AF[SITE] = FPVI1.GetMeasResult(SITE, MVRET);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
    FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
	SERIAL boost.LS.Rdson[SITE] = (adresult_AF[SITE] - adresult_BF[SITE]) * 2;



    SERIAL Idrive_VOP_DB_LSD_pre->SetTestResult(SITE, 0, OUTP.DB.LS.Idrive_pre[SITE] * 1e6);
    SERIAL Idrive_VOP_DB_HSD_pre->SetTestResult(SITE, 0, OUTP.DB.HS.Idrive_pre[SITE] * 1e6);
    SERIAL Idrive_VON_DB_LSD_pre->SetTestResult(SITE, 0, OUTN.DB.LS.Idrive_pre[SITE] * 1e6);
    SERIAL Idrive_VON_DB_HSD_pre->SetTestResult(SITE, 0, OUTN.DB.HS.Idrive_pre[SITE] * 1e6);
    SERIAL Idrive_BOOST_LSD_pre->SetTestResult(SITE, 0, boost.LS.Idrive_pre[SITE] * 1e6);
    SERIAL Idrive_BOOST_HSD_pre->SetTestResult(SITE, 0, boost.HS.Idrive_pre[SITE] * 1e6);

    SERIAL Rdson_BOOST_LSD->SetTestResult(SITE, 0, boost.LS.Rdson[SITE] * 1e3);
    SERIAL Rdson_BOOST_HSD->SetTestResult(SITE, 0, boost.HS.Rdson[SITE] * 1e3);

    SERIAL Rdson_VOP_DB_LSD->SetTestResult(SITE, 0, OUTP.DB.LS.Rdson[SITE] * 1e3 - 180);
    SERIAL Rdson_VOP_DB_HSD->SetTestResult(SITE, 0, OUTP.DB.HS.Rdson[SITE] * 1e3 - 180);
    SERIAL Rdson_VON_DB_LSD->SetTestResult(SITE, 0, OUTN.DB.LS.Rdson[SITE] * 1e3 - 180);
    SERIAL Rdson_VON_DB_HSD->SetTestResult(SITE, 0, OUTN.DB.HS.Rdson[SITE] * 1e3 - 180);



    for (int i = 0; i < 1; ++i)
    {
        SERIAL OC_DB_VOP_LSD->SetTestResult(SITE, i, OUTP.DB.LS.OCP[i][SITE]);
        SERIAL OC_DB_VON_LSD->SetTestResult(SITE, i, OUTN.DB.LS.OCP[i][SITE]);
        SERIAL OC_DB_VOP_HSD->SetTestResult(SITE, i, -OUTP.DB.HS.OCP[i][SITE]);
        SERIAL OC_DB_VON_HSD->SetTestResult(SITE, i, -OUTN.DB.HS.OCP[i][SITE]);
    }





    AD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    POWER_OFF(NORMAL, RES_RELAY_OFF);
    OUTPN_GP.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int ABS_LEAK(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *ABS_LEAK_BCK = StsGetParam(funcindex, "ABS_LEAK_BCK");
    CParam *ABS_LEAK_WCK = StsGetParam(funcindex, "ABS_LEAK_WCK");
    CParam *ABS_LEAK_DATAI = StsGetParam(funcindex, "ABS_LEAK_DATAI");
    CParam *ABS_LEAK_SCL = StsGetParam(funcindex, "ABS_LEAK_SCL");
    CParam *ABS_LEAK_SDA = StsGetParam(funcindex, "ABS_LEAK_SDA");
    CParam *ABS_LEAK_AD = StsGetParam(funcindex, "ABS_LEAK_AD");
    CParam *ABS_LEAK_ININ = StsGetParam(funcindex, "ABS_LEAK_ININ");
    CParam *ABS_LEAK_VLDO_delta = StsGetParam(funcindex, "ABS_LEAK_VLDO_delta");
    CParam *ABS_LEAK_DVDD = StsGetParam(funcindex, "ABS_LEAK_DVDD");
    CParam *ABS_LEAK_VOP = StsGetParam(funcindex, "ABS_LEAK_VOP");
    CParam *ABS_LEAK_VON = StsGetParam(funcindex, "ABS_LEAK_VON");
    CParam *ABS_LEAK_VBAT = StsGetParam(funcindex, "ABS_LEAK_VBAT");
    CParam *ABS_LEAK_SW = StsGetParam(funcindex, "ABS_LEAK_SW");
    CParam *ABS_LEAK_PVDD = StsGetParam(funcindex, "ABS_LEAK_PVDD");
    CParam *ABS_LEAK_VLDO = StsGetParam(funcindex, "ABS_LEAK_VLDO");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here


    ALL_PIN.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);

    cbit.SetOn(K35_BCK2FOVI, K34_WCK2FOVI, -1);
    delay_ms(3);
    pin_leakage_test(BCK, 2, FOVI_20V, FOVI_100UA, 1, BCK_M.ABS_LEAK);
    pin_leakage_test(WCK, 2, FOVI_20V, FOVI_100UA, 1, WCK_M.ABS_LEAK);
    pin_leakage_test(DATAI, 2, FOVI_20V, FOVI_100UA, 1, DATAI_M.ABS_LEAK);
    pin_leakage_test(INTN, 2, FOVI_20V, FOVI_100UA, 1, INTN_M.ABS_LEAK);

    cbit.SetOn(K31_IIC2FOVI, K32_IIC2FOVI, K33_IIC_DIS_PU, -1);
    delay_ms(3);
    pin_leakage_test(SCL, 2, FOVI_20V, FOVI_100UA, 1, SCL_M.ABS_LEAK);
    pin_leakage_test(SDA, 2, FOVI_20V, FOVI_100UA, 1, SDA_M.ABS_LEAK);
    pin_leakage_test(AD, 2, FOVI_20V, FOVI_100UA, 1, AD_M.ABS_LEAK);


    for (int i = 0; i < 7; ++i)
    {
        SERIAL AstGetParam(funcindex, i)->SetTestResult(SITE, 0, STRU_PIN_LIST[i]->ABS_LEAK[SITE] * 1e9);
    }

    pin_leakage_test(VBAT, 6, FOVI_20V, FOVI_100UA, 5, VBAT_M.ABS_LEAK);
    pin_leakage_test(PVDD, 12, FOVI_20V, FOVI_100UA, 5, PVDD_M.ABS_LEAK);

    VBAT.Set(FV, 5, FOVI_20V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 2.0, FOVI_20V, FOVI_100MA, RELAY_ON);
    pin_leakage_test(DVDD, 2.0, FOVI_20V, FOVI_100UA, 50, DVDD_M.ABS_LEAK);
    DVDD.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);


    VBAT.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
    PVDD.Set(FV, 12, FOVI_20V, FOVI_100MA, RELAY_ON);
    pin_leakage_test(SW, 12, FOVI_20V, FOVI_100UA, 5, SW_M.ABS_LEAK);


    VOP.Set(FV, 12, FOVI_20V, FOVI_100MA, RELAY_ON, 2);//SPIKE
    VON.Set(FV, 12, FOVI_20V, FOVI_100MA, RELAY_ON, 2);//SPIKE
    delay_ms(15);
    VON.MeasureVI(100, 10);
    VOP.MeasureVI(100, 10);
    SERIAL VON_M.ABS_LEAK[SITE] = VON.GetMeasResult(SITE, MIRET);
    SERIAL VOP_M.ABS_LEAK[SITE] = VOP.GetMeasResult(SITE, MIRET);


    VOP.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    VON.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    PVDD.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);


    VBAT.Set(FV, 6, FOVI_20V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 2, FOVI_20V, FOVI_100MA, RELAY_ON);

    VLDO.Set(FV, 1.60, FOVI_20V, FOVI_100UA, RELAY_ON);
    delay_ms(1);
    VLDO.MeasureVI(100, 10);
    SERIAL adresult_BF[SITE] = VLDO.GetMeasResult(SITE, MIRET);

    VLDO.Set(FV, 1.65, FOVI_20V, FOVI_100UA, RELAY_ON);
    delay_ms(1);
    VLDO.MeasureVI(100, 10);
    SERIAL adresult_AF[SITE] = VLDO.GetMeasResult(SITE, MIRET);
    SERIAL VLDO_M.ABS_LEAK[SITE] = adresult_AF[SITE] - adresult_BF[SITE];


    VLDO.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    VBAT.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    DVDD.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    ALL_PIN.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);


    SERIAL ABS_LEAK_DVDD->SetTestResult(SITE, 0, DVDD_M.ABS_LEAK[SITE] * 1e6);
    SERIAL ABS_LEAK_PVDD->SetTestResult(SITE, 0, PVDD_M.ABS_LEAK[SITE] * 1e9);
    SERIAL ABS_LEAK_VBAT->SetTestResult(SITE, 0, VBAT_M.ABS_LEAK[SITE] * 1e9);
    SERIAL ABS_LEAK_SW->SetTestResult(SITE, 0, SW_M.ABS_LEAK[SITE] * 1e9);
    SERIAL ABS_LEAK_VOP->SetTestResult(SITE, 0, VOP_M.ABS_LEAK[SITE] * 1e3);
    SERIAL ABS_LEAK_VON->SetTestResult(SITE, 0, VON_M.ABS_LEAK[SITE] * 1e3);
    SERIAL ABS_LEAK_VLDO->SetTestResult(SITE, 0, adresult_AF[SITE] * 1e6);
    SERIAL ABS_LEAK_VLDO_delta->SetTestResult(SITE, 0, VLDO_M.ABS_LEAK[SITE] * 1e6);




    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int SYS(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VLDO_STBY = StsGetParam(funcindex, "VLDO_STBY");
    CParam *VLDO_STBY_ILIM = StsGetParam(funcindex, "VLDO_STBY_ILIM");
    CParam *VLDO_NOM = StsGetParam(funcindex, "VLDO_NOM");
    CParam *VLDO_NOM_ILIM = StsGetParam(funcindex, "VLDO_NOM_ILIM");
    CParam *NOM_STATUS = StsGetParam(funcindex, "NOM_STATUS");
    CParam *PVDD_V = StsGetParam(funcindex, "PVDD_V");
    CParam *SNS_PVDD = StsGetParam(funcindex, "SNS_PVDD");
    CParam *SNS_VBAT = StsGetParam(funcindex, "SNS_VBAT");
    CParam *SNS_Temperature = StsGetParam(funcindex, "SNS_Temperature");
    CParam *Vnoise_LG = StsGetParam(funcindex, "Vnoise_LG");
    CParam *Vnoise_HG = StsGetParam(funcindex, "Vnoise_HG");
    CParam *FPWM_384K = StsGetParam(funcindex, "FPWM_384K");
    CParam *THD = StsGetParam(funcindex, "THD");
    CParam *Gain_N3DB = StsGetParam(funcindex, "Gain_N3DB");
    CParam *Gain_1DB = StsGetParam(funcindex, "Gain_1DB");
    CParam *Gain_3P5DB = StsGetParam(funcindex, "Gain_3P5DB");
    CParam *Gain_6DB = StsGetParam(funcindex, "Gain_6DB");
    CParam *Gain_10DB = StsGetParam(funcindex, "Gain_10DB");
    CParam *Gain_13DB = StsGetParam(funcindex, "Gain_13DB");
    CParam *Gain_16DB = StsGetParam(funcindex, "Gain_16DB");
	CParam *Gain_19DB = StsGetParam(funcindex, "Gain_19DB");
	CParam *Gain_100HZ_ERR = StsGetParam(funcindex, "Gain_100HZ_ERR");
	CParam *Gain_6KHZ_ERR = StsGetParam(funcindex, "Gain_6KHZ_ERR");
    CParam *HAGC = StsGetParam(funcindex, "HAGC");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here

    double qvm_data[SITE_NUM][SAMPLE_NUM];
    double FFT_data[SITE_NUM][SAMPLE_NUM];
    double THD_result[SITE_NUM];
    double Noise_result[SITE_NUM];


    /////////////////////////////////////////////////////////////VLDO_ST
    VLDO.Set(FI, 0, FOVI_2V, FOVI_10UA, RELAY_ON);
    cbit.SetOn(-1);
    delay_ms(3);

    POWER_ON(FIX_AD);
    DVDD.Set(FV, 1.8, FOVI_2V, FOVI_100MA, RELAY_ON);
    delay_ms(10);

    VLDO.MeasureVI(50, 10);
    SERIAL VLDO_STBY->SetTestResult(SITE, 0, VLDO.GetMeasResult(SITE,MVRET));

    VLDO.Set(FI, -1e-3, FOVI_2V, FOVI_100MA, RELAY_ON, 1);
    delay_ms(2);
    VLDO.MeasureVI(50, 10);
    SERIAL VLDO_STBY_ILIM->SetTestResult(SITE, 0, VLDO.GetMeasResult(SITE, MVRET));


    VLDO.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
    delay_ms(1);

    I2C_WR(DEV_AD_DEF, 0x04, 0x9A52);//sys working
    delay_ms(1);
    VLDO.MeasureVI(50, 10);
    SERIAL VLDO_NOM->SetTestResult(SITE, 0, VLDO.GetMeasResult(SITE, MVRET));


    VLDO.Set(FI, -60e-3, FOVI_2V, FOVI_100MA, RELAY_ON, 1);
    delay_ms(2);
    VLDO.MeasureVI(50, 10);
    SERIAL VLDO_NOM_ILIM->SetTestResult(SITE, 0, VLDO.GetMeasResult(SITE, MVRET));

    I2C_RD(DEV_AD_DEF, 0x04, reg_code);
    SERIAL NOM_STATUS->SetTestResult(SITE, 0, reg_code[SITE] & 1);
    VLDO.Set(FI, 0, FOVI_2V, FOVI_100MA, RELAY_ON, 1);


    //POWER DOWN
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);
    POWER_OFF(NORMAL, RES_RELAY_OFF);
    VLDO.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);

    /////////////////////////////////////////////////////////////VLDO_ED




    /////////////////////////////////////////////////////////////PVDD_BST_ST
    /*
    PVDD.Set(FI, 0, FOVIe_20V, FOVIe_10UA, FOVIe_RELAY_SENSE_ON);
    cbit.SetOn(K1_AD2DCM, K_CAP_ALL, K22_BOOST_L, K_FPVI_H_GND, K_FPVI_L_VBAT, -1);
    delay_ms(3);

    FPVI_RES.Set(FV, -5, FPVIe_10V, FPVIe_10A, FPVIe_RELAY_ON);
    DVDD.Set(FV, 1.8, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON);
    dcm.SetPPMU("AD_D", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
    RSTN.Set(FV, 1.8, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON);
    delay_ms(2);
    Enter_TM();


    I2C_WR(DEV_AD_DEF, 0x06, 0x0401);//boost en
    I2C_WR(DEV_AD_DEF, 0x5B, 0x8000);//PLL FORCE LOCK
    I2C_WR(DEV_AD_DEF, 0x53, 0x0278);//VBAT UVLO MIN
    I2C_WR(DEV_AD_DEF, 0x14, 0x50 + (109 << 8));//bst 5V
    I2C_WR(DEV_AD_DEF, 0x13, 0x7F4C);//boost always on
    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);//sys working



    for (int i = 106; i < 137; i = i + 5)
    {
        I2C_WR(DEV_AD_DEF, 0x14, 0x50 + (i << 8));//bst 5V
    }
    PVDD.MeasureVI(50, 10);

    SERIAL PVDD_V->SetTestResult(SITE, 0, PVDD.GetMeasResult(SITE, MVRET));



    POWER_OFF(NORMAL, RES_RELAY_OFF);
    FPVI_RES.Set(FV, 0, FPVIe_10V, FPVIe_10A, FPVIe_RELAY_OFF);*/
    /////////////////////////////////////////////////////////////PVDD_BST_ED


    /////////////////////////////////////////////////////////////performance

    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);


    VBAT.Set(FV, 4.2, FOVI_10V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_100MA, RELAY_ON);
    AD.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
    PVDD.Set(FV, 4.2, FOVI_10V, FOVI_100MA, RELAY_ON);
    delay_ms(2);


    //I2C_WR(DEV_AD_DEF, 0x44, 0x4000);//SR = 12nS
    I2C_WR(DEV_AD_DEF, 0x07, 0x4E80);//32bit
    I2C_WR(DEV_AD_DEF, 0x39, 0x7CDB);//PLL 32bit 48K cfg
    I2C_WR(DEV_AD_DEF, 0x05, 0x2000);//YB dis
    I2C_WR(DEV_AD_DEF, 0x13, 0x0000);//boost pass through
    I2C_WR(DEV_AD_DEF, 0x06, 0x0BC7);//dis boost   16DB
    I2C_WR(DEV_AD_DEF, 0x33, 0x0000);//isns en = 0
    I2C_WR(DEV_AD_DEF, 0x04, 0x9A52);//sys working


    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_N10DB_1K_ST", "IIS_N10DB_1K_ED", -2);
    delay_ms(10);

    qvm0.MeasureLADC(SAMPLE_NUM, T_SAMPLE, QVM_LADC_5V, QVM_LADC_40KHz);
    SERIAL qvm0.BlockRead(SITE, 0, SAMPLE_NUM, qvm_data[SITE]);

    SERIAL THD_result[SITE] = THDN_with_Aweighting(qvm_data[SITE], SAMPLE_NUM, T_SAMPLE * 1e-6, 1007.414, 10);
    SERIAL THD->SetTestResult(SITE, 0, 20 * log10(THD_result[SITE]));


    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);

	I2C_WR(DEV_AD_DEF, 0x06, 0x0B07);//dis boost   -3DB

	dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
	delay_ms(10);
	qvm0.MeasureLADC(SAMPLE_NUM, 1, QVM_LADC_500MV);
	SERIAL qvm0.BlockRead(SITE, 0, SAMPLE_NUM, qvm_data[SITE]);

	SERIAL Noise_result[SITE] = Noise_with_Aweighting(qvm_data[SITE], SAMPLE_NUM, 1e-6);
	SERIAL Vnoise_LG->SetTestResult(SITE, 0, Noise_result[SITE] * 1e6);

    I2C_WR(DEV_AD_DEF, 0x06, 0x0BE7);//dis boost   19DB

    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(SAMPLE_NUM, 1, QVM_LADC_500MV);
    SERIAL qvm0.BlockRead(SITE, 0, SAMPLE_NUM, qvm_data[SITE]);

    SERIAL Noise_result[SITE] = Noise_with_Aweighting(qvm_data[SITE], SAMPLE_NUM, 1e-6);
    SERIAL Vnoise_HG->SetTestResult(SITE, 0, Noise_result[SITE] * 1e6);

	dio_plus.Stop();

    //////////////////////////////////////////////////////N3DB
    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0B07);//dis boost  N3DB

    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_0DB_1K_ST", "IIS_0DB_1K_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1.0, QVM_LADC_2V);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

    SERIAL Gain_N3DB->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain * 1.412538) - 3);
    //////////////////////////////////////////////////////N3DB

    //////////////////////////////////////////////////////1DB
    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0B27);//dis boost  1DB
    I2C_WR(DEV_AD_DEF, 0x05, 0x2000 + 11);//dis boost  -1DB


    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_0DB_1K_ST", "IIS_0DB_1K_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1.0, QVM_LADC_2V);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

    SERIAL Gain_1DB->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain * 1.004) + 1);
    //////////////////////////////////////////////////////1DB
    // 
	//////////////////////////////////////////////////////3P5DB
    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0B47);//dis boost  3P5DB
    I2C_WR(DEV_AD_DEF, 0x05, 0x2000 + 37);//dis boost  -3P5DB


    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_0DB_1K_ST", "IIS_0DB_1K_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1.0, QVM_LADC_2V);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

    SERIAL Gain_3P5DB->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain) + 3.5);
    //////////////////////////////////////////////////////3P5DB
    // 
	// 
	//////////////////////////////////////////////////////6DB
    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0B67);//dis boost  6DB
    I2C_WR(DEV_AD_DEF, 0x05, 0x2000 + 64);//dis boost  -6DB


    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_0DB_1K_ST", "IIS_0DB_1K_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1.0, QVM_LADC_2V);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

    SERIAL Gain_6DB->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain * 1.002305) + 6);
    //////////////////////////////////////////////////////6DB
    // 
	// 
	//////////////////////////////////////////////////////10DB
    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0B87);//dis boost  10DB
    I2C_WR(DEV_AD_DEF, 0x05, 0x2000 + 106);//dis boost  -1DB


    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_0DB_1K_ST", "IIS_0DB_1K_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1.0, QVM_LADC_2V);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

    SERIAL Gain_10DB->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain * 0.996624) + 10);
    //////////////////////////////////////////////////////10DB

	//////////////////////////////////////////////////////13DB
    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0BA7);//dis boost  13DB
    I2C_WR(DEV_AD_DEF, 0x05, 0x2000 + 138);//dis boost  -13DB


    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_0DB_1K_ST", "IIS_0DB_1K_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1.0, QVM_LADC_2V);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

    SERIAL Gain_13DB->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain * 0.997772) + 13);
    //////////////////////////////////////////////////////13DB

    //////////////////////////////////////////////////////16DB
    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0BC7);//dis boost  16DB
    I2C_WR(DEV_AD_DEF, 0x05, 0x2000 + 170);//dis boost  -16DB


    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_0DB_1K_ST", "IIS_0DB_1K_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1.0, QVM_LADC_2V);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

    SERIAL Gain_16DB->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain * 0.998921) + 16);
    //////////////////////////////////////////////////////16DB

	//////////////////////////////////////////////////////19DB
    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x06, 0x0BE7);//dis boost  19DB
    I2C_WR(DEV_AD_DEF, 0x05, 0x2000 + 202);//dis boost  -19DB


    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_0DB_1K_ST", "IIS_0DB_1K_ED", -2);
    delay_ms(10);
	qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1.0, QVM_LADC_2V);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

    SERIAL Gain_19DB->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain) + 19);

	double Gain_19DB_BASE[SITE_NUM];
	SERIAL Gain_19DB_BASE[SITE] = Gain_19DB->GetTestResult(SITE, 0);
	
    dio_plus.Run("IIS_0DB_6K_ST", "IIS_0DB_6K_ED", -2);
	delay_ms(10);
	qvm0.MeasureLADC(2873, 1.0, QVM_LADC_2V, QVM_LADC_40KHz);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

	SERIAL Gain_6KHZ_ERR->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain) + 19 - Gain_19DB_BASE[SITE]);


	dio_plus.Run("IIS_0DB_100_ST", "IIS_0DB_100_ED", -2);
	delay_ms(10);
	qvm0.MeasureLADC(10304, 1.0, QVM_LADC_2V);
	dio_plus.Stop();
	SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

	SERIAL Gain_100HZ_ERR->SetTestResult(SITE, 0, conv_db(adresult[SITE] / Vcoef_gain) + 19 - Gain_19DB_BASE[SITE]);






    //////////////////////////////////////////////////////19DB

    //////////////////////////////////////////////////////HAGC
    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x04, 0x9E52);//HAGC EN
    I2C_WR(DEV_AD_DEF, 0x0A, (70 << 8) + 81);//HAGC CFG
    I2C_WR(DEV_AD_DEF, 0x0C, 0xFFFF);//HAGC ATT TIME MIN
    I2C_WR(DEV_AD_DEF, 0x0D, 0x2B0A);//HAGC ATT TIME MIN
    I2C_WR(DEV_AD_DEF, 0x05, 0x2000);//

    cbit.SetOn(K_CAP_ALL, K_OUTPN, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);
    dio_plus.Run("IIS_0DB_1K_ST", "IIS_0DB_1K_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1.0, QVM_LADC_5V);
    dio_plus.Stop();
    SERIAL adresult[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);

    SERIAL HAGC->SetTestResult(SITE, 0, (adresult[SITE] / Vcoef_gain)* (adresult[SITE] / Vcoef_gain) / 8);
    //////////////////////////////////////////////////////HAGC


    SERIAL FPWM_384K->SetTestResult(SITE, 0, Freq_384K[SITE] * 1.01376);
    PVDD.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
    VBAT.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);

    cbit.SetOn(K_CAP_ALL, K_OUTPN, -1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x5B, 0x8000);//PLL FORCE LOCK
    delay_ms(1);//SW SPIKE
    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(5);
    dio_plus.Stop();

    I2C_WR(DEV_AD_DEF, 0x06, 0x0100);//sar en
    delay_ms(5);


    I2C_RD(DEV_AD_DEF, 0x10, reg_code);//DOUT
    SERIAL SNS_VBAT->SetTestResult(SITE, 0, 28 * reg_code[SITE] / 1000.0);
    I2C_RD(DEV_AD_DEF, 0x11, reg_code);//DOUT
    SERIAL SNS_PVDD->SetTestResult(SITE, 0, 56 * reg_code[SITE] / 1000.0);
    I2C_RD(DEV_AD_DEF, 0x12, reg_code);//DOUT
    SERIAL SNS_Temperature->SetTestResult(SITE, 0, 25 - 1.213 * (signed char)reg_code[SITE]);
    /////////////////////////////////////////////////////////////performance



    POWER_OFF(NORMAL, RES_RELAY_OFF);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int Function(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VBAT_UVLO_F = StsGetParam(funcindex, "VBAT_UVLO_F");
    CParam *VBAT_UVLO_R = StsGetParam(funcindex, "VBAT_UVLO_R");
    CParam* DVDD_POR_R = StsGetParam(funcindex, "DVDD_POR_R");
    CParam* DVDD_POR_F = StsGetParam(funcindex, "DVDD_POR_F");
    CParam *OSC_32K = StsGetParam(funcindex, "OSC_32K");
    CParam *VBAT_LOW = StsGetParam(funcindex, "VBAT_LOW");
    CParam *VBAT_LOW_HYS = StsGetParam(funcindex, "VBAT_LOW_HYS");
    CParam *OUT_COMP = StsGetParam(funcindex, "OUT_COMP");
    CParam *OVP1 = StsGetParam(funcindex, "OVP1");
    CParam *OVP1_HYS = StsGetParam(funcindex, "OVP1_HYS");
    CParam *OVP2 = StsGetParam(funcindex, "OVP2");
    CParam *PFM_TIMER_H = StsGetParam(funcindex, "PFM_TIMER_H");
    CParam *PFM_TIMER_L = StsGetParam(funcindex, "PFM_TIMER_L");
    CParam *VCC = StsGetParam(funcindex, "VCC");
    CParam *SLP_RAMP = StsGetParam(funcindex, "SLP_RAMP");
    CParam *PLL_frequency = StsGetParam(funcindex, "PLL_frequency");
    CParam *OTP_CHECK = StsGetParam(funcindex, "OTP_CHECK");
    CParam *DDMUX_CHECK = StsGetParam(funcindex, "DDMUX_CHECK");
    CParam *SNS_VBE = StsGetParam(funcindex, "SNS_VBE");
    CParam *INT_VOL = StsGetParam(funcindex, "INT_VOL");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here


    cbit.SetOn(-1);
    delay_ms(3);

    VLDO.Set(FI, 0, FOVI_2V, FOVI_10UA, RELAY_ON);
    POWER_ON(WITH_TM);

    //UVLO
    I2C_WR(DEV_AD_DEF, 0x81, 0xE000);//DDMUX en
    I2C_WR(DEV_AD_DEF, 0x05, 0x0000);//PUSH PULL
    I2C_WR(DEV_AD_DEF, 0xA1, 48 << 9);//VBAT UVLO

    test_method.ramp_v(VBAT, FOVI_5V, FOVI_100MA, BUF, 1.95, 1.80, -0.01, 100, 1, TRIG_RISING, adresult_F, 1);
    test_method.ramp_v(VBAT, FOVI_5V, FOVI_100MA, BUF, 1.80, 2.10, 0.01, 100, 1, TRIG_FALLING, adresult_R, 1);


    SERIAL VBAT_UVLO_F->SetTestResult(SITE, 0, adresult_F[SITE]);
    SERIAL VBAT_UVLO_R->SetTestResult(SITE, 0, adresult_R[SITE]);



    test_method.ramp_v(DVDD, FOVI_5V, FOVI_100MA, VLDO, 1.5, 1.0, -0.01, 100, 0.5, TRIG_FALLING, adresult_F, 1);
    test_method.ramp_v(DVDD, FOVI_5V, FOVI_100MA, VLDO, 1.2, 1.5, 0.01, 100, 0.5, TRIG_RISING, adresult_R, 1);


    SERIAL DVDD_POR_R->SetTestResult(SITE, 0, adresult_R[SITE]);
    SERIAL DVDD_POR_F->SetTestResult(SITE, 0, adresult_F[SITE]);


    cbit.SetOn(K18_INTN2QTMU, K81_INTN_FOVI2BUF, -1);
    delay_ms(3);
    VBAT.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_100MA, RELAY_ON, 2);
    Enter_TM();
    reg_0x88.reset();

    /////////////////////////////////////////////////////////////OSC_32K
    I2C_WR(DEV_AD_DEF, 0x81, 0xC600);//OSC 32KHZ mux
    I2C_WR(DEV_AD_DEF, 0x05, 0x0000);//PUSH PULL

    qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TIME_US, 10, 10);
    SERIAL adresult[SITE] = qtmu0.GetMeasureResult(SITE);
    SERIAL OSC_32K->SetTestResult(SITE, 0, adresult[SITE]);



    I2C_WR(DEV_AD_DEF, 0x5B, 0x8000);//PLL FORCE LOCK
    I2C_WR(DEV_AD_DEF, 0x07, 0x4E80);//32bit
    I2C_WR(DEV_AD_DEF, 0x39, 0x7CDB);//PLL 32bit 48K cfg
    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);//sys work
    I2C_WR(DEV_AD_DEF, 0x13, 0x0000);//boost pass through
    PVDD.Set(FV, 6, FOVI_10V, FOVI_100MA, RELAY_ON);
    AD.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

    /////////////////////////////////////////////////////////////PLL
    I2C_WR(DEV_AD_DEF, 0x81, 0xC800);//PLL_FB

    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_us(10);
    qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TIME_US, 100, 10);
    SERIAL adresult[SITE] = qtmu0.GetMeasureResult(SITE) / 1000;
    SERIAL PLL_frequency->SetTestResult(SITE, 0, adresult[SITE]);

    /////////////////////////////////////////////////////////////DDMUX
    I2C_WR(DEV_AD_DEF, 0x81, 0xE000);//DDMUX
    I2C_WR(DEV_AD_DEF, 0xA1, 0x1200);//WCK

    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(10);
    qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TIME_US, 10, 10);
    SERIAL adresult[SITE] = qtmu0.GetMeasureResult(SITE);

    SERIAL DDMUX_CHECK->SetTestResult(SITE, 0, adresult[SITE]);

    /////////////////////////////////////////////////////////////VCC
    I2C_WR(DEV_AD_DEF, 0x82, 0x0006);//TM Vcc Vcc sel
    delay_ms(1);
    AD.MeasureVI(50, 10);
    SERIAL VCC->SetTestResult(SITE, 0, AD.GetMeasResult(SITE, MVRET));
    I2C_WR(DEV_AD_DEF, 0x82, 0x0004);//TM Vcc Vcc sel


    /////////////////////////////////////////////////////////////VBE
    I2C_WR(DEV_AD_DEF, 0x81, 0x8300);//AMUX TSNS
    I2C_WR(DEV_AD_DEF, 0x83, 0x0010);//en VBE
    I2C_WR(DEV_AD_DEF, 0x06, 0x0100);//sar en
    delay_ms(1);
    AD.MeasureVI(50, 10);
    SERIAL SNS_VBE->SetTestResult(SITE, 0, AD.GetMeasResult(SITE, MVRET));

    /////////////////////////////////////////////////////////////VBAT_LOW
    cbit.SetOn(-1);
    delay_ms(3);
    I2C_WR(DEV_AD_DEF, 0x81, 0xE000);//DDMUX
    I2C_WR(DEV_AD_DEF, 0xA1, 47 << 9);//VBAT_LOW

    test_method.ramp_v(VBAT, FOVI_5V, FOVI_100MA, BUF, 2.78, 3.32, 0.01, 100, 1, TRIG_FALLING, adresult_R, 1);
    test_method.ramp_v(VBAT, FOVI_5V, FOVI_100MA, BUF, 2.92, 2.68, -0.01, 100, 1, TRIG_RISING, adresult_F, 1);

    SERIAL VBAT_LOW->SetTestResult(SITE, 0, adresult_F[SITE]);
    SERIAL VBAT_LOW_HYS->SetTestResult(SITE, 0, (adresult_R[SITE] - adresult_F[SITE]) * 1000);



    /////////////////////////////////////////////////////////////OUT_COMP
    I2C_WR(DEV_AD_DEF, 0x13, 0x7FCC);
    I2C_WR(DEV_AD_DEF, 0x14, 0xEF50);
    I2C_WR(DEV_AD_DEF, 0x81, 0xC020);//boost ota tog
    //test_method.ramp_v(PVDD, FOVIe_10V, FOVIe_100MA, BUF, 10, 5, -0.01, 10, 1, TRIG_RISING, adresult);
    test_method.ramp_v(PVDD, FOVI_20V, FOVI_100MA, BUF, 10, 11, 0.01, 100, 1, TRIG_FALLING, adresult);
    SERIAL OUT_COMP->SetTestResult(SITE, 0, adresult[SITE]);
    /////////////////////////////////////////////////////////////OTP
    I2C_WR(DEV_AD_DEF, 0x81, 0xC700);//OTP
    BUF.MeasureVI(50, 10);
    SERIAL OTP_CHECK->SetTestResult(SITE, 0, BUF.GetMeasResult(SITE, MVRET));
    /////////////////////////////////////////////////////////////SLP_RAMP
    I2C_WR(DEV_AD_DEF, 0x81, 0x8620);//boost amux slp ramp
    BUF.MeasureVI(50, 10);
    SERIAL SLP_RAMP->SetTestResult(SITE, 0, BUF.GetMeasResult(SITE, MVRET));

    /////////////////////////////////////////////////////////////PFM_TIMER
    PVDD.Set(FV, 6, FOVI_10V, FOVI_100MA, RELAY_ON);
    I2C_WR(DEV_AD_DEF, 0x81, 0xC060);//boost PFM

    I2C_WR(DEV_AD_DEF, 0x14, 0x0000);
    delay_ms(1);
    BUF.MeasureVI(50, 10);

    SERIAL PFM_TIMER_H->SetTestResult(SITE, 0, BUF.GetMeasResult(SITE, MVRET));

    I2C_WR(DEV_AD_DEF, 0x14, 0xFF00);
    delay_ms(1);
    BUF.MeasureVI(50, 10);
    SERIAL PFM_TIMER_L->SetTestResult(SITE, 0, BUF.GetMeasResult(SITE, MVRET));

    INTN.Set(FI, 1e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
    delay_ms(1);
    INTN.MeasureVI(50, 10);
    INTN.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
    SERIAL INT_VOL->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET));

    /////////////////////////////////////////////////////////////OVP
    I2C_WR(DEV_AD_DEF, 0x5B, 0x0000);//PLL FORCE LOCK
    I2C_WR(DEV_AD_DEF, 0x81, 0xC030);//boost ovp1
    PVDD.Set(FV, 12, FOVI_20V, FOVI_100MA, RELAY_ON);
    delay_ms(1);
    test_method.ramp_v(PVDD, FOVI_20V, FOVI_100MA, BUF, 12, 14, 0.01, 100, 1, TRIG_RISING, adresult_R, 1);

    PVDD.Set(FV, 14, FOVI_20V, FOVI_100MA, RELAY_ON);
    delay_ms(1);
    test_method.ramp_v(PVDD, FOVI_20V, FOVI_100MA, BUF, 14, 12, -0.01, 100, 1, TRIG_FALLING, adresult_F, 1);
    SERIAL OVP1->SetTestResult(SITE, 0, adresult_R[SITE]);
    SERIAL OVP1_HYS->SetTestResult(SITE, 0, 1000 * (adresult_R[SITE] - adresult_F[SITE]));

    //I2C_WR(DEV_AD_DEF, 0x81, 0xC040);//boost ovp2
    //delay_ms(1);
    //test_method.ramp_v(PVDD, FOVI_20V, FOVI_100MA, BUF, 15, 17, 0.01, 100, 1, TRIG_FALLING, adresult, 1);
    //SERIAL OVP2->SetTestResult(SITE, 0, adresult[SITE]);



    POWER_OFF(NORMAL, RES_RELAY_OFF);
    INTN.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    AD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    VLDO.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);



    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int DIGITAL_TEST(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *MBIST = StsGetParam(funcindex, "MBIST");
    CParam *SCAN_CHAIN_TS1 = StsGetParam(funcindex, "SCAN_CHAIN_TS1");
    CParam *SCAN_CHAIN_TS2 = StsGetParam(funcindex, "SCAN_CHAIN_TS2");
    CParam *Vbox_high = StsGetParam(funcindex, "Vbox_high");
    CParam *Vbox_low = StsGetParam(funcindex, "Vbox_low");
    CParam *IDDQ = StsGetParam(funcindex, "IDDQ");
    CParam *IDDQ_BASE = StsGetParam(funcindex, "IDDQ_BASE");
    CParam *IDDQ1 = StsGetParam(funcindex, "IDDQ1");
    CParam *IDDQ2 = StsGetParam(funcindex, "IDDQ2");
    CParam *IDDQ3 = StsGetParam(funcindex, "IDDQ3");
    CParam *IDDQ4 = StsGetParam(funcindex, "IDDQ4");
    CParam *IDDQ5 = StsGetParam(funcindex, "IDDQ5");
    CParam *IDDQ6 = StsGetParam(funcindex, "IDDQ6");
    CParam *IDDQ7 = StsGetParam(funcindex, "IDDQ7");
    CParam *IDDQ8 = StsGetParam(funcindex, "IDDQ8");
    CParam *IDDQ9 = StsGetParam(funcindex, "IDDQ9");
    CParam *IDDQ10 = StsGetParam(funcindex, "IDDQ10");
    CParam *SDA_VIH = StsGetParam(funcindex, "SDA_VIH");
    CParam *SDA_VIL = StsGetParam(funcindex, "SDA_VIL");
    CParam *SCL_VIH = StsGetParam(funcindex, "SCL_VIH");
    CParam *SCL_VIL = StsGetParam(funcindex, "SCL_VIL");
    CParam *FSCL = StsGetParam(funcindex, "FSCL");
    CParam *BCK_VIH = StsGetParam(funcindex, "BCK_VIH");
    CParam *BCK_VIL = StsGetParam(funcindex, "BCK_VIL");
    CParam *WCK_VIH = StsGetParam(funcindex, "WCK_VIH");
    CParam *WCK_VIL = StsGetParam(funcindex, "WCK_VIL");
    CParam *SDI_VIH = StsGetParam(funcindex, "SDI_VIH");
    CParam *SDI_VIL = StsGetParam(funcindex, "SDI_VIL");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here


    UINT16 mbist_result[SITE_NUM];
    ULONG failcount[SITE_NUM];

    UINT16 CHIP_ID[SITE_NUM];
    double VIH[SITE_NUM];
    double VIL[SITE_NUM];

    cbit.SetOn(K1_VBAT_CAP, K3_PVDD_CAP, K5_DVDD_CAP, -1);
    delay_ms(1);


    INTN.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
    VLDO.Set(FV, 1.5, FOVI_10V, FOVI_100MA, RELAY_ON);
    POWER_ON(WITH_TM);


    ////MBIST
    I2C_WR(DEV_AD_DEF, 0x5B, 0x8000);//PLL FORCE LOCK
    I2C_WR(DEV_AD_DEF, 0x04, 0x8100);//en hmute sys work
    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(5);
    dio_plus.Stop();

    I2C_WR(DEV_AD_DEF, 0x05, 0x0000);//intn push pull
    I2C_WR(DEV_AD_DEF, 0x83, 0x8000);//normal mode
    I2C_WR(DEV_AD_DEF, 0xA3, 0x8000);//ate en
    I2C_WR(DEV_AD_DEF, 0xA2, 0xC000);//SRAM bist
    delay_ms(1);
    I2C_RD(DEV_AD_DEF, 0xA2, mbist_result);//SRAM bist

    SERIAL MBIST->SetTestResult(SITE, 0, (mbist_result[SITE] & 0x0F00) >> 8);


    cbit.SetOn(K1_VBAT_CAP, K3_PVDD_CAP, K5_DVDD_CAP, K35_BCK2FOVI, K34_WCK2FOVI,-1);
    delay_ms(3);
    BCK.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_ON);
    WCK.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_ON);
    DATAI.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_ON);

    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_100MA, RELAY_ON);

    I2C_WR(DEV_AD_DEF, 0x04, 0x8000);//standby = 1 iis en
    //IIS
    I2C_WR(DEV_AD_DEF, 0x81, 0xE000);//DDMUX en


    //WCK
    I2C_WR(DEV_AD_DEF, 0xA1, 9 << 9);//WCK

    WCK.Set(FV, 0.54, FOVI_1V, FOVI_10MA, RELAY_ON, 1);
    delay_ms(1);
    INTN.MeasureVI(10, 10);
    SERIAL WCK_VIL->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);

    WCK.Set(FV, 0.84, FOVI_1V, FOVI_10MA, RELAY_ON, 1);
    delay_ms(1);
    INTN.MeasureVI(10, 10);
    SERIAL WCK_VIH->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);
    WCK.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);


    //DATAI
    I2C_WR(DEV_AD_DEF, 0xA1, 10 << 9);//SDI

    DATAI.Set(FV, 0.54, FOVI_1V, FOVI_10MA, RELAY_ON, 1);
    delay_ms(1);
    INTN.MeasureVI(10, 10);
    SERIAL SDI_VIL->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);

    DATAI.Set(FV, 0.84, FOVI_1V, FOVI_10MA, RELAY_ON, 1);
    delay_ms(1);
    INTN.MeasureVI(10, 10);
    SERIAL SDI_VIH->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);
    DATAI.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);


    //BCK
    I2C_WR(DEV_AD_DEF, 0xA1, 8 << 9);//BCK

    BCK.Set(FV, 0.54, FOVI_1V, FOVI_10MA, RELAY_ON, 1);
    delay_ms(1);
    INTN.MeasureVI(10, 10);
    SERIAL BCK_VIL->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);

    BCK.Set(FV, 0.85, FOVI_1V, FOVI_10MA, RELAY_ON, 1);
    delay_ms(1);
    INTN.MeasureVI(10, 10);
    SERIAL BCK_VIH->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);
    BCK.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);


	
	//SCL
	I2C_WR(DEV_AD_DEF, 0xA1, 5 << 9);//SCL
	dio_plus.Run("BC_DIO_ST", "BC_DIO_ST");//HIZ

	PWR_UP.Set(FV, 0.54, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	INTN.MeasureVI(10, 10);
	SERIAL SCL_VIL->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);

	PWR_UP.Set(FV, 0.85, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	INTN.MeasureVI(10, 10);
	SERIAL SCL_VIH->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);

	PWR_UP.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);
	//SDA
	I2C_WR(DEV_AD_DEF, 0xA1, 6 << 9);//SDA
	dio_plus.Run("BC_DIO_ST", "BC_DIO_ST");//HIZ

	PWR_UP.Set(FV, 0.54, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	INTN.MeasureVI(10, 10);
	SERIAL SDA_VIL->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);

	PWR_UP.Set(FV, 0.85, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(1);
	INTN.MeasureVI(10, 10);
	SERIAL SDA_VIH->SetTestResult(SITE, 0, INTN.GetMeasResult(SITE, MVRET) > 0.6 ? 1 : 0);

	PWR_UP.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);

	/*
    I2C_setup(10e-6);
    //1P8 IIC
    //VIH
    SERIAL flag[SITE] = 0;
    SERIAL VIH[SITE] = 0;
    for (double i = 0.50; i < 1.1; i = i + 0.05)
    {
        dio_plus.SetVIH(i); //set driver high voltage
        dio_plus.SetVIL(0); //set driver low voltage
        delay_ms(3);

        I2C_RD(DEV_AD_DEF, 0x00, CHIP_ID);

        SERIAL
        {
            if (CHIP_ID[SITE] == 0x8565 && flag[SITE] == 0)
            {
                flag[SITE] = 1;
                VIH[SITE] = i;
            }
        }
    }


    SERIAL SDA_VIH->SetTestResult(SITE, 0, VIH[SITE]);
    SERIAL SCL_VIH->SetTestResult(SITE, 0, VIH[SITE]);

    //VIL
    SERIAL flag[SITE] = 0;
    SERIAL VIL[SITE] = 0;
    for (double i = 0.8; i > 0.35; i = i - 0.05)
    {
        dio_plus.SetVIH(1.8); //set driver high voltage
        dio_plus.SetVIL(i); //set driver low voltage
        delay_ms(3);

        I2C_RD(DEV_AD_DEF, 0x00, CHIP_ID);

        SERIAL
        {
            if (CHIP_ID[SITE] == 0x8565 && flag[SITE] == 0)
            {
                flag[SITE] = 1;
                VIL[SITE] = i;
            }
        }
    }

    SERIAL SDA_VIL->SetTestResult(SITE, 0, VIL[SITE]);
    SERIAL SCL_VIL->SetTestResult(SITE, 0, VIL[SITE]);

	*/

    //FSCL
    I2C_setup(0.8e-6);
    dio_plus.SetVIH(1.8); //set driver high voltage
    dio_plus.SetVIL(0); //set driver low voltage
    delay_ms(3);
    I2C_RD(DEV_AD_DEF, 0x00, CHIP_ID);
    SERIAL FSCL->SetTestResult(SITE, 0, CHIP_ID[SITE] == 0x8565 ? 1.25 : 9999);
    I2C_setup(2.5e-6);



    ////SCAN
    bool get_result_flag[SITE_NUM];
    int FAIL_FLAG[SITE_NUM];
    int FAIL_COUNT[SITE_NUM];

    WCK.Set(FV, 1.8, FOVI_2V, FOVI_10MA, RELAY_ON);
    I2C_WR(DEV_AD_DEF, 0xFF, 0xFFFF, true);//Scan en

    cbit.SetOn(K1_VBAT_CAP, K3_PVDD_CAP, K5_DVDD_CAP, K31_IIC2FOVI, K32_IIC2FOVI, K34_WCK2FOVI, -1);
    delay_ms(3);


    dio_plus.Run("Scan_ts1_st", "Scan_ts1_ed");

    SERIAL FAIL_COUNT[SITE] = 9999;
    SERIAL
    {
        FAIL_FLAG[SITE] = dio_plus.GetChannelFail((SITE * 4), &get_result_flag[SITE]);//��ȡ�ɹ���ֵtrue

        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 1))//��ȡ����ɹ�����PASS
        {
            FAIL_COUNT[SITE] = dio_plus.GetChannelFailCount((SITE * 4), &get_result_flag[SITE]); //get fail count
        }
        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 0))
        {
            FAIL_COUNT[SITE] = 0;
        }
    }
    SERIAL SCAN_CHAIN_TS1->SetTestResult(SITE, 0, FAIL_COUNT[SITE]);


    dio_plus.Run("Scan_ts2_st", "Scan_ts2_ed");

    SERIAL FAIL_COUNT[SITE] = 9999;
    SERIAL
    {
        FAIL_FLAG[SITE] = dio_plus.GetChannelFail((SITE * 4), &get_result_flag[SITE]);//��ȡ�ɹ���ֵtrue

        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 1))//��ȡ����ɹ�����PASS
        {
            FAIL_COUNT[SITE] = dio_plus.GetChannelFailCount((SITE * 4), &get_result_flag[SITE]); //get fail count
        }
        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 0))
        {
            FAIL_COUNT[SITE] = 0;
        }
    }
    SERIAL SCAN_CHAIN_TS2->SetTestResult(SITE, 0, FAIL_COUNT[SITE]);


    VLDO.Set(FV, 1.35, FOVI_10V, FOVI_100MA, RELAY_ON);
    dio_plus.Run("Scan_ts1_st", "Scan_ts1_ed");

    SERIAL FAIL_COUNT[SITE] = 9999;
    SERIAL
    {
        FAIL_FLAG[SITE] = dio_plus.GetChannelFail((SITE * 4), &get_result_flag[SITE]);//��ȡ�ɹ���ֵtrue

        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 1))//��ȡ����ɹ�����PASS
        {
            FAIL_COUNT[SITE] = dio_plus.GetChannelFailCount((SITE * 4), &get_result_flag[SITE]); //get fail count
        }
        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 0))
        {
            FAIL_COUNT[SITE] = 0;
        }
    }
    SERIAL Vbox_low->SetTestResult(SITE, 0, FAIL_COUNT[SITE]);


    VLDO.Set(FV, 1.65, FOVI_10V, FOVI_100MA, RELAY_ON);
    dio_plus.Run("Scan_ts1_st", "Scan_ts1_ed");

    SERIAL FAIL_COUNT[SITE] = 9999;
    SERIAL
    {
        FAIL_FLAG[SITE] = dio_plus.GetChannelFail((SITE * 4), &get_result_flag[SITE]);//��ȡ�ɹ���ֵtrue

        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 1))//��ȡ����ɹ�����PASS
        {
            FAIL_COUNT[SITE] = dio_plus.GetChannelFailCount((SITE * 4), &get_result_flag[SITE]); //get fail count
        }
        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 0))
        {
            FAIL_COUNT[SITE] = 0;
        }
    }
    SERIAL Vbox_high->SetTestResult(SITE, 0, FAIL_COUNT[SITE]);

	/*
    dio_plus.Run("IDDQ_st", "IDDQ_ed");

    SERIAL FAIL_COUNT[SITE] = 9999;
    SERIAL
    {
        FAIL_FLAG[SITE] = dio_plus.GetChannelFail((SITE * 4), &get_result_flag[SITE]);//��ȡ�ɹ���ֵtrue

        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 1))//��ȡ����ɹ�����PASS
        {
            FAIL_COUNT[SITE] = dio_plus.GetChannelFailCount((SITE * 4), &get_result_flag[SITE]); //get fail count
        }
        if (get_result_flag[SITE] && (FAIL_FLAG[SITE] == 0))
        {
            FAIL_COUNT[SITE] = 0;
        }
    }
    SERIAL IDDQ->SetTestResult(SITE, 0, FAIL_COUNT[SITE]);
	*/


    double I_BASE[SITE_NUM];

    VLDO.Set(FV, 1.65, FOVI_10V, FOVI_100UA, RELAY_ON);
    delay_ms(10);
    VLDO.MeasureVI(100, 10);
    SERIAL I_BASE[SITE] = VLDO.GetMeasResult(SITE, MIRET);
    SERIAL IDDQ_BASE->SetTestResult(SITE, 0, I_BASE[SITE] * 1e6);


    const char* IDDQ_Lable[12] = { "IDDQ_st", "IDDQ1", "IDDQ2", "IDDQ3", "IDDQ4", "IDDQ5", "IDDQ6", "IDDQ7", "IDDQ8", "IDDQ9", "IDDQ10","IDDQ_ed" };
	SERIAL FAIL_FLAG[SITE] = 0;
    for (int i = 0; i < 10; ++i)
    {
        VLDO.Set(FV, 1.65, FOVI_10V, FOVI_100MA, RELAY_ON);
		dio_plus.Run(IDDQ_Lable[i], IDDQ_Lable[i + 1]);
		SERIAL FAIL_FLAG[SITE] = FAIL_FLAG[SITE] + dio_plus.GetChannelFail((SITE * 4), &get_result_flag[SITE]);
        VLDO.Set(FV, 1.65, FOVI_10V, FOVI_100UA, RELAY_ON);
        delay_ms(1);
        VLDO.MeasureVI(100, 10);
        SERIAL adresult[SITE] = VLDO.GetMeasResult(SITE, MIRET) - I_BASE[SITE];
        SERIAL AstGetParam(funcindex, i + 7)->SetTestResult(SITE, 0, adresult[SITE] * 1e9);
    }

	SERIAL IDDQ->SetTestResult(SITE, 0, FAIL_FLAG[SITE]);

    INTN.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    WCK.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    VLDO.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    POWER_OFF(NORMAL, RES_RELAY_OFF);


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int Idrive_post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Idrive_VOP_DB_LSD_post = StsGetParam(funcindex, "Idrive_VOP_DB_LSD_post");
    CParam *Idrive_VON_DB_LSD_post = StsGetParam(funcindex, "Idrive_VON_DB_LSD_post");
    CParam *Idrive_VOP_DB_HSD_post = StsGetParam(funcindex, "Idrive_VOP_DB_HSD_post");
    CParam *Idrive_VON_DB_HSD_post = StsGetParam(funcindex, "Idrive_VON_DB_HSD_post");
    CParam *Idrive_BOOST_LSD_post = StsGetParam(funcindex, "Idrive_BOOST_LSD_post");
    CParam *Idrive_BOOST_HSD_post = StsGetParam(funcindex, "Idrive_BOOST_HSD_post");
    CParam *Idrive_VOP_DB_LSD_delta = StsGetParam(funcindex, "Idrive_VOP_DB_LSD_delta");
    CParam *Idrive_VON_DB_LSD_delta = StsGetParam(funcindex, "Idrive_VON_DB_LSD_delta");
    CParam *Idrive_VOP_DB_HSD_delta = StsGetParam(funcindex, "Idrive_VOP_DB_HSD_delta");
    CParam *Idrive_VON_DB_HSD_delta = StsGetParam(funcindex, "Idrive_VON_DB_HSD_delta");
    CParam *Idrive_BOOST_LSD_delta = StsGetParam(funcindex, "Idrive_BOOST_LSD_delta");
    CParam *Idrive_BOOST_HSD_delta = StsGetParam(funcindex, "Idrive_BOOST_HSD_delta");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here

    SERIAL Idrive_VOP_DB_LSD_post->SetTestResult(SITE, 0, OUTP.DB.LS.Idrive_post[SITE] * 1e6);
    SERIAL Idrive_VOP_DB_HSD_post->SetTestResult(SITE, 0, OUTP.DB.HS.Idrive_post[SITE] * 1e6);
    SERIAL Idrive_VON_DB_LSD_post->SetTestResult(SITE, 0, OUTN.DB.LS.Idrive_post[SITE] * 1e6);
    SERIAL Idrive_VON_DB_HSD_post->SetTestResult(SITE, 0, OUTN.DB.HS.Idrive_post[SITE] * 1e6);
    SERIAL Idrive_BOOST_LSD_post->SetTestResult(SITE, 0, boost.LS.Idrive_post[SITE] * 1e6);
    SERIAL Idrive_BOOST_HSD_post->SetTestResult(SITE, 0, boost.HS.Idrive_post[SITE] * 1e6);

    OUTP.DB.LS.get_delta();
    OUTP.DB.HS.get_delta();
    OUTN.DB.LS.get_delta();
    OUTN.DB.HS.get_delta();
    boost.LS.get_delta();
    boost.HS.get_delta();

    SERIAL Idrive_VOP_DB_LSD_delta->SetTestResult(SITE, 0, OUTP.DB.LS.Idrive_delta[SITE] * 1e6);
    SERIAL Idrive_VOP_DB_HSD_delta->SetTestResult(SITE, 0, OUTP.DB.HS.Idrive_delta[SITE] * 1e6);
    SERIAL Idrive_VON_DB_LSD_delta->SetTestResult(SITE, 0, OUTN.DB.LS.Idrive_delta[SITE] * 1e6);
    SERIAL Idrive_VON_DB_HSD_delta->SetTestResult(SITE, 0, OUTN.DB.HS.Idrive_delta[SITE] * 1e6);
    SERIAL Idrive_BOOST_LSD_delta->SetTestResult(SITE, 0, boost.LS.Idrive_delta[SITE] * 1e6);
    SERIAL Idrive_BOOST_HSD_delta->SetTestResult(SITE, 0, boost.HS.Idrive_delta[SITE] * 1e6);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int Ioff_post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Ioff_VOP_DB_LSD_post = StsGetParam(funcindex, "Ioff_VOP_DB_LSD_post");
    CParam *Ioff_VOP_DB_HSD_post = StsGetParam(funcindex, "Ioff_VOP_DB_HSD_post");
    CParam *Ioff_VON_DB_LSD_post = StsGetParam(funcindex, "Ioff_VON_DB_LSD_post");
    CParam *Ioff_VON_DB_HSD_post = StsGetParam(funcindex, "Ioff_VON_DB_HSD_post");
    CParam *Ioff_BOOST_LSD_post = StsGetParam(funcindex, "Ioff_BOOST_LSD_post");
    CParam *Ioff_BOOST_HSD_post = StsGetParam(funcindex, "Ioff_BOOST_HSD_post");
    CParam *Ioff_VOP_DB_LSD_delta = StsGetParam(funcindex, "Ioff_VOP_DB_LSD_delta");
    CParam *Ioff_VOP_DB_HSD_delta = StsGetParam(funcindex, "Ioff_VOP_DB_HSD_delta");
    CParam *Ioff_VON_DB_LSD_delta = StsGetParam(funcindex, "Ioff_VON_DB_LSD_delta");
    CParam *Ioff_VON_DB_HSD_delta = StsGetParam(funcindex, "Ioff_VON_DB_HSD_delta");
    CParam *Ioff_BOOST_LSD_delta = StsGetParam(funcindex, "Ioff_BOOST_LSD_delta");
    CParam *Ioff_BOOST_HSD_delta = StsGetParam(funcindex, "Ioff_BOOST_HSD_delta");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here



    cbit.SetOn(-1);

    POWER_ON(WITH_TM);

    I2C_WR(DEV_AD_DEF, 0x83, 0x0200);//BG EN
    //I2C_WR(DEV_AD_DEF, 0x44, 0x0100);//dis DB PD
    //I2C_WR(DEV_AD_DEF, 0x45, 0x4000);//dis YB PD

    PVDD.Set(FV, 5, FOVI_20V, FOVI_100MA, RELAY_ON);

    //////////////////////////////////////////////////////////VON
    I2C_WR(DEV_AD_DEF, 0x82, 0x0204);

    VON.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(1);
    VON.MeasureVI(100, 10);
    SERIAL OUTN.DB.LS.Ioff_post[SITE] = VON.GetMeasResult(SITE, MIRET);

    I2C_WR(DEV_AD_DEF, 0x82, 0x0200);

    VON.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
    delay_ms(1);
    VON.MeasureVI(100, 10);
    SERIAL OUTN.DB.HS.Ioff_post[SITE] = VON.GetMeasResult(SITE, MIRET);

    //////////////////////////////////////////////////////////VOP
    I2C_WR(DEV_AD_DEF, 0x82, 0x0304);

    VOP.Set(FV, 5, FOVI_10V, FOVI_10MA, RELAY_ON);
    delay_ms(1);
    VOP.MeasureVI(100, 10);
    SERIAL OUTP.DB.LS.Ioff_post[SITE] = VOP.GetMeasResult(SITE, MIRET);

    I2C_WR(DEV_AD_DEF, 0x82, 0x0300);

    VOP.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_ON);
    delay_ms(1);
    VOP.MeasureVI(100, 10);
    SERIAL OUTP.DB.HS.Ioff_post[SITE] = VOP.GetMeasResult(SITE, MIRET);




    I2C_WR(DEV_AD_DEF, 0x82, 0x0000);
    PVDD.Set(FV, 12, FOVI_20V, FOVI_100MA, RELAY_ON);


    SW.Set(FV, 0, FOVI_20V, FOVI_1MA, RELAY_ON);
    delay_ms(1);
    SW.Set(FV, 0, FOVI_20V, FOVI_10UA, RELAY_ON);
    delay_ms(1);
    SW.MeasureVI(100, 10);
    SERIAL boost.HS.Ioff_post[SITE] = SW.GetMeasResult(SITE, MIRET);

    SW.Set(FV, 12, FOVI_20V, FOVI_1MA, RELAY_ON);
    delay_ms(1);
    SW.Set(FV, 12, FOVI_20V, FOVI_10UA, RELAY_ON);
    delay_ms(1);
    SW.MeasureVI(100, 10);
    SERIAL boost.LS.Ioff_post[SITE] = SW.GetMeasResult(SITE, MIRET);


    SERIAL Ioff_VOP_DB_LSD_post->SetTestResult(SITE, 0, OUTP.DB.LS.Ioff_post[SITE] * 1e6);
    SERIAL Ioff_VOP_DB_HSD_post->SetTestResult(SITE, 0, OUTP.DB.HS.Ioff_post[SITE] * 1e6);
    SERIAL Ioff_VON_DB_LSD_post->SetTestResult(SITE, 0, OUTN.DB.LS.Ioff_post[SITE] * 1e6);
    SERIAL Ioff_VON_DB_HSD_post->SetTestResult(SITE, 0, OUTN.DB.HS.Ioff_post[SITE] * 1e6);
    SERIAL Ioff_BOOST_LSD_post->SetTestResult(SITE, 0, boost.LS.Ioff_post[SITE] * 1e9);
    SERIAL Ioff_BOOST_HSD_post->SetTestResult(SITE, 0, boost.HS.Ioff_post[SITE] * 1e9);

    OUTP.DB.LS.get_delta();
    OUTP.DB.HS.get_delta();
    OUTN.DB.LS.get_delta();
    OUTN.DB.HS.get_delta();
    boost.LS.get_delta();
    boost.HS.get_delta();

    SERIAL Ioff_VOP_DB_LSD_delta->SetTestResult(SITE, 0, OUTP.DB.LS.Ioff_delta[SITE] * 1e6);
    SERIAL Ioff_VOP_DB_HSD_delta->SetTestResult(SITE, 0, OUTP.DB.HS.Ioff_delta[SITE] * 1e6);
    SERIAL Ioff_VON_DB_LSD_delta->SetTestResult(SITE, 0, OUTN.DB.LS.Ioff_delta[SITE] * 1e6);
    SERIAL Ioff_VON_DB_HSD_delta->SetTestResult(SITE, 0, OUTN.DB.HS.Ioff_delta[SITE] * 1e6);
    SERIAL Ioff_BOOST_LSD_delta->SetTestResult(SITE, 0, boost.LS.Ioff_delta[SITE] * 1e9);
    SERIAL Ioff_BOOST_HSD_delta->SetTestResult(SITE, 0, boost.HS.Ioff_delta[SITE] * 1e9);


    SW.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    VOP.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    VON.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    POWER_OFF(NORMAL, RES_RELAY_OFF);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int IQ_post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IQ_DVDD_STBY_post = StsGetParam(funcindex, "IQ_DVDD_STBY_post");
    CParam *IQ_VBAT_STBY_post = StsGetParam(funcindex, "IQ_VBAT_STBY_post");
    CParam *IQ_DVDD_IDLE_NG_ON_post = StsGetParam(funcindex, "IQ_DVDD_IDLE_NG_ON_post");
    CParam *IQ_VBAT_IDLE_NG_ON_post = StsGetParam(funcindex, "IQ_VBAT_IDLE_NG_ON_post");
    CParam *IQ_DVDD_IDLE_DB_post = StsGetParam(funcindex, "IQ_DVDD_IDLE_DB_post");
    CParam *IQ_VBAT_IDLE_DB_post = StsGetParam(funcindex, "IQ_VBAT_IDLE_DB_post");
    CParam *IQ_DVDD_STBY_delta = StsGetParam(funcindex, "IQ_DVDD_STBY_delta");
    CParam *IQ_VBAT_STBY_delta = StsGetParam(funcindex, "IQ_VBAT_STBY_delta");
    CParam *IQ_DVDD_IDLE_NG_ON_delta = StsGetParam(funcindex, "IQ_DVDD_IDLE_NG_ON_delta");
    CParam *IQ_VBAT_IDLE_NG_ON_delta = StsGetParam(funcindex, "IQ_VBAT_IDLE_NG_ON_delta");
    CParam *IQ_DVDD_IDLE_DB_delta = StsGetParam(funcindex, "IQ_DVDD_IDLE_DB_delta");
    CParam *IQ_VBAT_IDLE_DB_delta = StsGetParam(funcindex, "IQ_VBAT_IDLE_DB_delta");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here



    cbit.SetOn(K60_LR_Load, K14_BOOST_L, -1);
    delay_ms(3);



    VBAT.Set(FV, 4.2, FOVI_10V, FOVI_1MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_100UA, RELAY_ON);
    delay_ms(5);


    DVDD.MeasureVI(50, 10);
    VBAT.MeasureVI(50, 10);

    SERIAL IQ.VBAT.post.STBY[SITE] = VBAT.GetMeasResult(SITE, MIRET);
    SERIAL IQ.DVDD.post.STBY[SITE] = DVDD.GetMeasResult(SITE, MIRET);


    SERIAL IQ_VBAT_STBY_post->SetTestResult(SITE, 0, IQ.VBAT.post.STBY[SITE] * 1e6);
    SERIAL IQ_DVDD_STBY_post->SetTestResult(SITE, 0, IQ.DVDD.post.STBY[SITE] * 1e6);



    VBAT.Set(FV, 4.2, FOVI_10V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_10MA, RELAY_ON);
    delay_ms(3);

    I2C_WR(DEV_AD_DEF, 0x07, 0x4E80);//32bit
    I2C_WR(DEV_AD_DEF, 0x39, 0x7CDB);//PLL 32bit 48K cfg
    I2C_WR(DEV_AD_DEF, 0x05, 0xB000);//YB dis
    I2C_WR(DEV_AD_DEF, 0x13, 0x0000);//boost pass through
    I2C_WR(DEV_AD_DEF, 0x06, 0x06E7);//classd en
    I2C_WR(DEV_AD_DEF, 0x33, 0x0000);//ivsns_dis
    I2C_WR(DEV_AD_DEF, 0x1E, 0x0800);//iv_psm_disable
    I2C_WR(DEV_AD_DEF, 0x04, 0xBA52);//sys working NG ON

    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(2);

    VBAT.Set(FV, 4.2, FOVI_10V, FOVI_100UA, RELAY_ON);
    delay_ms(5);
    DVDD.MeasureVI(50, 10);
    VBAT.MeasureVI(50, 10);


    SERIAL IQ.VBAT.post.IDLE_NG_ON[SITE] = VBAT.GetMeasResult(SITE, MIRET);
    SERIAL IQ.DVDD.post.IDLE_NG_ON[SITE] = DVDD.GetMeasResult(SITE, MIRET);

    SERIAL IQ_VBAT_IDLE_NG_ON_post->SetTestResult(SITE, 0, IQ.VBAT.post.IDLE_NG_ON[SITE] * 1e6);
    SERIAL IQ_DVDD_IDLE_NG_ON_post->SetTestResult(SITE, 0, IQ.DVDD.post.IDLE_NG_ON[SITE] * 1e3);


    VBAT.Set(FV, 4.2, FOVI_10V, FOVI_100MA, RELAY_ON);
    I2C_WR(DEV_AD_DEF, 0x04, 0x9A52);//sys working NG OFF

    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(2);

    DVDD.MeasureVI(50, 10);
    VBAT.MeasureVI(50, 10);

    SERIAL IQ.VBAT.post.IDLE_DB[SITE] = VBAT.GetMeasResult(SITE, MIRET);
    SERIAL IQ.DVDD.post.IDLE_DB[SITE] = DVDD.GetMeasResult(SITE, MIRET);

    SERIAL IQ_VBAT_IDLE_DB_post->SetTestResult(SITE, 0, IQ.VBAT.post.IDLE_DB[SITE] * 1e3);
    SERIAL IQ_DVDD_IDLE_DB_post->SetTestResult(SITE, 0, IQ.DVDD.post.IDLE_DB[SITE] * 1e3);
    IQ.VBAT.get_delta();
    IQ.DVDD.get_delta();

    SERIAL IQ_DVDD_STBY_delta->SetTestResult(SITE, 0, IQ.DVDD.delta.STBY[SITE] * 1e6);
    SERIAL IQ_VBAT_STBY_delta->SetTestResult(SITE, 0, IQ.VBAT.delta.STBY[SITE] * 1e6);

    SERIAL IQ_DVDD_IDLE_NG_ON_delta->SetTestResult(SITE, 0, IQ.DVDD.delta.IDLE_NG_ON[SITE] * 1e3);
    SERIAL IQ_VBAT_IDLE_NG_ON_delta->SetTestResult(SITE, 0, IQ.VBAT.delta.IDLE_NG_ON[SITE] * 1e6);

    SERIAL IQ_DVDD_IDLE_DB_delta->SetTestResult(SITE, 0, IQ.DVDD.delta.IDLE_DB[SITE] * 1e3);
    SERIAL IQ_VBAT_IDLE_DB_delta->SetTestResult(SITE, 0, IQ.VBAT.delta.IDLE_DB[SITE] * 1e3);



    dio_plus.Stop();
    POWER_OFF(NORMAL, RES_RELAY_OFF);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int EE_FINAL(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *EEPROM0_COMP = StsGetParam(funcindex, "EEPROM0_COMP");
    CParam *EEPROM1_COMP = StsGetParam(funcindex, "EEPROM1_COMP");
    CParam *EEPROM2_COMP = StsGetParam(funcindex, "EEPROM2_COMP");
    CParam *EEPROM3_COMP = StsGetParam(funcindex, "EEPROM3_COMP");
    CParam *EEPROM4_COMP = StsGetParam(funcindex, "EEPROM4_COMP");
    CParam *EEPROM5_COMP = StsGetParam(funcindex, "EEPROM5_COMP");
    CParam *EEPROM6_COMP = StsGetParam(funcindex, "EEPROM6_COMP");
    CParam *EEPROM7_COMP = StsGetParam(funcindex, "EEPROM7_COMP");
    CParam *EEPROM0_FINAL = StsGetParam(funcindex, "EEPROM0_FINAL");
    CParam *EEPROM1_FINAL = StsGetParam(funcindex, "EEPROM1_FINAL");
    CParam *EEPROM2_FINAL = StsGetParam(funcindex, "EEPROM2_FINAL");
    CParam *EEPROM3_FINAL = StsGetParam(funcindex, "EEPROM3_FINAL");
    CParam *EEPROM4_FINAL = StsGetParam(funcindex, "EEPROM4_FINAL");
    CParam *EEPROM5_FINAL = StsGetParam(funcindex, "EEPROM5_FINAL");
    CParam *EEPROM6_FINAL = StsGetParam(funcindex, "EEPROM6_FINAL");
    CParam *EEPROM7_FINAL = StsGetParam(funcindex, "EEPROM7_FINAL");
    CParam *BG_TC_FINAL = StsGetParam(funcindex, "BG_TC_FINAL");
    CParam *BG_1P2_FINAL = StsGetParam(funcindex, "BG_1P2_FINAL");
    CParam *IBIAS_500N_FINAL = StsGetParam(funcindex, "IBIAS_500N_FINAL");
    CParam *DAC_GAIN_FINAL = StsGetParam(funcindex, "DAC_GAIN_FINAL");
    CParam *OSC_FREQ_FINAL = StsGetParam(funcindex, "OSC_FREQ_FINAL");
    CParam *LDO_LP_VREF_FINAL = StsGetParam(funcindex, "LDO_LP_VREF_FINAL");
    CParam *LDO_LP_BG_TC_FINAL = StsGetParam(funcindex, "LDO_LP_BG_TC_FINAL");
    CParam *RAMP_FINAL = StsGetParam(funcindex, "RAMP_FINAL");
    CParam *RAMP_VCM_FINAL = StsGetParam(funcindex, "RAMP_VCM_FINAL");
    CParam *CLSD_OS_L_FINAL = StsGetParam(funcindex, "CLSD_OS_L_FINAL");
    CParam *CLSD_OS_H_FINAL = StsGetParam(funcindex, "CLSD_OS_H_FINAL");
    CParam *V_SENSE_CAL_FINAL = StsGetParam(funcindex, "V_SENSE_CAL_FINAL");
    CParam *I_SENSE_OS_CAL_L_FINAL = StsGetParam(funcindex, "I_SENSE_OS_CAL_L_FINAL");
    CParam *I_SENSE_OS_CAL_H_FINAL = StsGetParam(funcindex, "I_SENSE_OS_CAL_H_FINAL");
    CParam *ISNS_CMRR_H_FINAL = StsGetParam(funcindex, "ISNS_CMRR_H_FINAL");
    CParam *ISNS_CMRR_L_FINAL = StsGetParam(funcindex, "ISNS_CMRR_L_FINAL");
    CParam *ISNS_GAIN_ADJ_FINAL = StsGetParam(funcindex, "ISNS_GAIN_ADJ_FINAL");
    CParam *TVP_SNS_OS_FINAL = StsGetParam(funcindex, "TVP_SNS_OS_FINAL");
    CParam *BOOST_DAC_BUF_FINAL = StsGetParam(funcindex, "BOOST_DAC_BUF_FINAL");
    CParam *BOOST_ZCD_FINAL = StsGetParam(funcindex, "BOOST_ZCD_FINAL");
    CParam *BOOST_ISNS_FINAL = StsGetParam(funcindex, "BOOST_ISNS_FINAL");
    CParam *BOOST_IPKL_FINAL = StsGetParam(funcindex, "BOOST_IPKL_FINAL");
    CParam *BOOST_IPFM_FINAL = StsGetParam(funcindex, "BOOST_IPFM_FINAL");
    CParam *CLSD_PWM_FINAL = StsGetParam(funcindex, "CLSD_PWM_FINAL");
    CParam *PV_OFFSET_FINAL = StsGetParam(funcindex, "PV_OFFSET_FINAL");
    CParam *TSNS_DGE_H_FINAL = StsGetParam(funcindex, "TSNS_DGE_H_FINAL");
    CParam *TSNS_DGE_L_FINAL = StsGetParam(funcindex, "TSNS_DGE_L_FINAL");
    CParam *TSNS_OFFSET_H_FINAL = StsGetParam(funcindex, "TSNS_OFFSET_H_FINAL");
    CParam *TSNS_OFFSET_L_FINAL = StsGetParam(funcindex, "TSNS_OFFSET_L_FINAL");
    CParam *I_SENSE_CAL_H_FINAL = StsGetParam(funcindex, "I_SENSE_CAL_H_FINAL");
    CParam *I_SENSE_CAL_L_FINAL = StsGetParam(funcindex, "I_SENSE_CAL_L_FINAL");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here



    UINT16 EE_READ[BANK_NUM][SITE_NUM] = { 0 };


    cbit.SetOn(-1);
    delay_ms(3);

    POWER_ON(WITH_TM);

    //1.set readback 2.copy to programmed 3.find trimmed node and disable trim
    for (int reg = 0; reg < dut.assy.count(); ++reg)
    {
        string EE_str = string(dut.assy[reg].get_name());
        I2C_RD(DEV_AD_DEF, TRIM_BANK_ST + reg, EE_READ[reg]);
        SERIAL dut.assy(EE_str.c_str()).set_read_back(EE_READ[reg][SITE], SITE);
    }


    //Bank FINAL
    for (int reg = 0; reg < dut.assy.count(); ++reg)
    {
        string EE_str = string(dut.assy[reg].get_name()) + "_FINAL";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].get_read_back(SITE));

        EE_str = string(dut.assy[reg].get_name()) + "_COMP";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].comp_read_to_work(SITE));
    }

    //TRIM FINAL
    for (int reg = 0; reg < dut.trim.count(); ++reg)
    {
        string EE_str = string(dut.trim[reg].get_name()) + "_FINAL";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.trim[reg].get_read_back(SITE));
    }

    //SEL FINAL
    for (int reg = 0; reg < dut.sel.count(); ++reg)
    {
        string EE_str = string(dut.sel[reg].get_name()) + "_FINAL";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.sel[reg].get_read_back(SITE));
    }

    //check device trimmed
    POWER_OFF(NORMAL, RES_RELAY_OFF);
    //RES_INITIAL(ONE_BY_ONE, RES_RELAY_ON);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int PIN_LEAK_post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *PIN_LEAK_BCK_post = StsGetParam(funcindex, "PIN_LEAK_BCK_post");
    CParam *PIN_LEAK_WCK_post = StsGetParam(funcindex, "PIN_LEAK_WCK_post");
    CParam *PIN_LEAK_DATAI_post = StsGetParam(funcindex, "PIN_LEAK_DATAI_post");
    CParam *PIN_LEAK_SCL_post = StsGetParam(funcindex, "PIN_LEAK_SCL_post");
    CParam *PIN_LEAK_SDA_post = StsGetParam(funcindex, "PIN_LEAK_SDA_post");
    CParam *PIN_LEAK_AD_post = StsGetParam(funcindex, "PIN_LEAK_AD_post");
    CParam *PIN_LEAK_ININ_post = StsGetParam(funcindex, "PIN_LEAK_ININ_post");
    CParam *PIN_LEAK_VLDO_delta_post = StsGetParam(funcindex, "PIN_LEAK_VLDO_delta_post");
    CParam *PIN_LEAK_DVDD_post = StsGetParam(funcindex, "PIN_LEAK_DVDD_post");
    CParam *PIN_LEAK_VOP_post = StsGetParam(funcindex, "PIN_LEAK_VOP_post");
    CParam *PIN_LEAK_VON_post = StsGetParam(funcindex, "PIN_LEAK_VON_post");
    CParam *PIN_LEAK_VBAT_post = StsGetParam(funcindex, "PIN_LEAK_VBAT_post");
    CParam *PIN_LEAK_SW_post = StsGetParam(funcindex, "PIN_LEAK_SW_post");
    CParam *PIN_LEAK_PVDD_post = StsGetParam(funcindex, "PIN_LEAK_PVDD_post");
    CParam *PIN_LEAK_BCK_delta = StsGetParam(funcindex, "PIN_LEAK_BCK_delta");
    CParam *PIN_LEAK_WCK_delta = StsGetParam(funcindex, "PIN_LEAK_WCK_delta");
    CParam *PIN_LEAK_DATAI_delta = StsGetParam(funcindex, "PIN_LEAK_DATAI_delta");
    CParam *PIN_LEAK_SCL_delta = StsGetParam(funcindex, "PIN_LEAK_SCL_delta");
    CParam *PIN_LEAK_SDA_delta = StsGetParam(funcindex, "PIN_LEAK_SDA_delta");
    CParam *PIN_LEAK_AD_delta = StsGetParam(funcindex, "PIN_LEAK_AD_delta");
    CParam *PIN_LEAK_ININ_delta = StsGetParam(funcindex, "PIN_LEAK_ININ_delta");
    CParam *PIN_LEAK_VLDO_delta = StsGetParam(funcindex, "PIN_LEAK_VLDO_delta");
    CParam *PIN_LEAK_DVDD_delta = StsGetParam(funcindex, "PIN_LEAK_DVDD_delta");
    CParam *PIN_LEAK_VOP_delta = StsGetParam(funcindex, "PIN_LEAK_VOP_delta");
    CParam *PIN_LEAK_VON_delta = StsGetParam(funcindex, "PIN_LEAK_VON_delta");
    CParam *PIN_LEAK_VBAT_delta = StsGetParam(funcindex, "PIN_LEAK_VBAT_delta");
    CParam *PIN_LEAK_SW_delta = StsGetParam(funcindex, "PIN_LEAK_SW_delta");
    CParam *PIN_LEAK_PVDD_delta = StsGetParam(funcindex, "PIN_LEAK_PVDD_delta");
    CParam *PIN_LEAK_VLDO_post = StsGetParam(funcindex, "PIN_LEAK_VLDO_post");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here


    ALL_PIN.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);

    cbit.SetOn(K35_BCK2FOVI, K34_WCK2FOVI, -1);
    delay_ms(3);
    pin_leakage_test(BCK, 1.8, FOVI_20V, FOVI_100UA, 1, BCK_M.PIN_leak_post);
    pin_leakage_test(WCK, 1.8, FOVI_20V, FOVI_100UA, 1, WCK_M.PIN_leak_post);
    pin_leakage_test(DATAI, 1.8, FOVI_20V, FOVI_100UA, 1, DATAI_M.PIN_leak_post);
    pin_leakage_test(INTN, 1.8, FOVI_20V, FOVI_100UA, 1, INTN_M.PIN_leak_post);

    cbit.SetOn(K31_IIC2FOVI, K32_IIC2FOVI, K33_IIC_DIS_PU, -1);
    delay_ms(3);
    pin_leakage_test(SCL, 1.8, FOVI_20V, FOVI_100UA, 1, SCL_M.PIN_leak_post);
    pin_leakage_test(SDA, 1.8, FOVI_20V, FOVI_100UA, 1, SDA_M.PIN_leak_post);
    pin_leakage_test(AD, 1.8, FOVI_20V, FOVI_100UA, 1, AD_M.PIN_leak_post);


    for (int i = 0; i < 7; ++i)
    {
        SERIAL AstGetParam(funcindex, i)->SetTestResult(SITE, 0, STRU_PIN_LIST[i]->PIN_leak_post[SITE] * 1e9);
    }

    pin_leakage_test(VBAT, 5, FOVI_20V, FOVI_100UA, 5, VBAT_M.PIN_leak_post);
    pin_leakage_test(PVDD, 10, FOVI_20V, FOVI_100UA, 5, PVDD_M.PIN_leak_post);

    VBAT.Set(FV, 5, FOVI_20V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_20V, FOVI_100MA, RELAY_ON);
    pin_leakage_test(DVDD, 1.8, FOVI_20V, FOVI_100UA, 50, DVDD_M.PIN_leak_post);
    DVDD.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);


    VBAT.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
    PVDD.Set(FV, 10, FOVI_20V, FOVI_100MA, RELAY_ON);
    pin_leakage_test(SW, 10, FOVI_20V, FOVI_100UA, 5, SW_M.PIN_leak_post);


    VOP.Set(FV, 10, FOVI_20V, FOVI_100MA, RELAY_ON);
    VON.Set(FV, 10, FOVI_20V, FOVI_100MA, RELAY_ON);
    delay_ms(15);
    VON.MeasureVI(100, 10);
    VOP.MeasureVI(100, 10);
    SERIAL VON_M.PIN_leak_post[SITE] = VON.GetMeasResult(SITE, MIRET);
    SERIAL VOP_M.PIN_leak_post[SITE] = VOP.GetMeasResult(SITE, MIRET);


    VOP.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    VON.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    PVDD.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);


    VBAT.Set(FV, 5, FOVI_20V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_20V, FOVI_100MA, RELAY_ON);

    VLDO.Set(FV, 1.55, FOVI_20V, FOVI_100UA, RELAY_ON);
    delay_ms(1);
    VLDO.MeasureVI(100, 10);
    SERIAL adresult_BF[SITE] = VLDO.GetMeasResult(SITE, MIRET);

    VLDO.Set(FV, 1.60, FOVI_20V, FOVI_100UA, RELAY_ON);
    delay_ms(1);
    VLDO.MeasureVI(100, 10);
    SERIAL adresult_AF[SITE] = VLDO.GetMeasResult(SITE, MIRET);
    SERIAL VLDO_M.PIN_leak_post[SITE] = adresult_AF[SITE] - adresult_BF[SITE];


    VLDO.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    VBAT.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    DVDD.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
    ALL_PIN.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);


    SERIAL PIN_LEAK_DVDD_post->SetTestResult(SITE, 0, DVDD_M.PIN_leak_post[SITE] * 1e6);
    SERIAL PIN_LEAK_PVDD_post->SetTestResult(SITE, 0, PVDD_M.PIN_leak_post[SITE] * 1e9);
    SERIAL PIN_LEAK_VBAT_post->SetTestResult(SITE, 0, VBAT_M.PIN_leak_post[SITE] * 1e9);
    SERIAL PIN_LEAK_SW_post->SetTestResult(SITE, 0, SW_M.PIN_leak_post[SITE] * 1e9);
    SERIAL PIN_LEAK_VOP_post->SetTestResult(SITE, 0, VOP_M.PIN_leak_post[SITE] * 1e3);
    SERIAL PIN_LEAK_VON_post->SetTestResult(SITE, 0, VON_M.PIN_leak_post[SITE] * 1e3);
    SERIAL PIN_LEAK_VLDO_post->SetTestResult(SITE, 0, adresult_AF[SITE] * 1e6);
    SERIAL PIN_LEAK_VLDO_delta_post->SetTestResult(SITE, 0, VLDO_M.PIN_leak_post[SITE] * 1e6);

    for (int i = 0; i < 14; ++i)
    {
        STRU_PIN_LIST[i]->get_delta();
        SERIAL AstGetParam(funcindex, i + 14)->SetTestResult(SITE, 0, STRU_PIN_LIST[i]->PIN_leak_delta[SITE] * 1e9);
    }

    SERIAL AstGetParam(funcindex, 7 + 14)->SetTestResult(SITE, 0, STRU_PIN_LIST[7]->PIN_leak_delta[SITE] * 1e6);
    SERIAL AstGetParam(funcindex, 9 + 14)->SetTestResult(SITE, 0, STRU_PIN_LIST[9]->PIN_leak_delta[SITE] * 1e3);
    SERIAL AstGetParam(funcindex, 10 + 14)->SetTestResult(SITE, 0, STRU_PIN_LIST[10]->PIN_leak_delta[SITE] * 1e3);

    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int P2P_Leak_post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *P2P_BCK_post = StsGetParam(funcindex, "P2P_BCK_post");
    CParam *P2P_WCK_post = StsGetParam(funcindex, "P2P_WCK_post");
    CParam *P2P_DATAI_post = StsGetParam(funcindex, "P2P_DATAI_post");
    CParam *P2P_SCL_post = StsGetParam(funcindex, "P2P_SCL_post");
    CParam *P2P_SDA_post = StsGetParam(funcindex, "P2P_SDA_post");
    CParam *P2P_AD_post = StsGetParam(funcindex, "P2P_AD_post");
    CParam *P2P_ININ_post = StsGetParam(funcindex, "P2P_ININ_post");
    CParam *P2P_VLDO_post = StsGetParam(funcindex, "P2P_VLDO_post");
    CParam *P2P_DVDD_post = StsGetParam(funcindex, "P2P_DVDD_post");
    CParam *P2P_VOP_post = StsGetParam(funcindex, "P2P_VOP_post");
    CParam *P2P_VON_post = StsGetParam(funcindex, "P2P_VON_post");
    CParam *P2P_VBAT_post = StsGetParam(funcindex, "P2P_VBAT_post");
    CParam *P2P_SW_post = StsGetParam(funcindex, "P2P_SW_post");
    CParam *P2P_PVDD_post = StsGetParam(funcindex, "P2P_PVDD_post");
    CParam *P2P_BCK_delta = StsGetParam(funcindex, "P2P_BCK_delta");
    CParam *P2P_WCK_delta = StsGetParam(funcindex, "P2P_WCK_delta");
    CParam *P2P_DATAI_delta = StsGetParam(funcindex, "P2P_DATAI_delta");
    CParam *P2P_SCL_delta = StsGetParam(funcindex, "P2P_SCL_delta");
    CParam *P2P_SDA_delta = StsGetParam(funcindex, "P2P_SDA_delta");
    CParam *P2P_AD_delta = StsGetParam(funcindex, "P2P_AD_delta");
    CParam *P2P_ININ_delta = StsGetParam(funcindex, "P2P_ININ_delta");
    CParam *P2P_VLDO_delta = StsGetParam(funcindex, "P2P_VLDO_delta");
    CParam *P2P_DVDD_delta = StsGetParam(funcindex, "P2P_DVDD_delta");
    CParam *P2P_VOP_delta = StsGetParam(funcindex, "P2P_VOP_delta");
    CParam *P2P_VON_delta = StsGetParam(funcindex, "P2P_VON_delta");
    CParam *P2P_VBAT_delta = StsGetParam(funcindex, "P2P_VBAT_delta");
    CParam *P2P_SW_delta = StsGetParam(funcindex, "P2P_SW_delta");
    CParam *P2P_PVDD_delta = StsGetParam(funcindex, "P2P_PVDD_delta");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here

    ALL_PIN.Set(FV, 0, FOVI_1V, FOVI_100UA, RELAY_ON);

    cbit.SetOn(K35_BCK2FOVI, K34_WCK2FOVI, -1);
    delay_ms(3);


    p2p_leakage_test(BCK, 50e-3, FOVI_1V, FOVI_100UA, 300, BCK_M.P2P_leak_post);
    p2p_leakage_test(WCK, 50e-3, FOVI_1V, FOVI_100UA, 300, WCK_M.P2P_leak_post);
    p2p_leakage_test(DATAI, 50e-3, FOVI_1V, FOVI_100UA, 300, DATAI_M.P2P_leak_post);
    p2p_leakage_test(INTN, 50e-3, FOVI_1V, FOVI_100UA, 300, INTN_M.P2P_leak_post);
    p2p_leakage_test(VOP, 50e-3, FOVI_1V, FOVI_100UA, 300, VOP_M.P2P_leak_post);
    p2p_leakage_test(VON, 50e-3, FOVI_1V, FOVI_100UA, 300, VON_M.P2P_leak_post);
    p2p_leakage_test(SW, 50e-3, FOVI_1V, FOVI_100UA, 300, SW_M.P2P_leak_post);
    p2p_leakage_test(VBAT, 50e-3, FOVI_1V, FOVI_100UA, 5000, VBAT_M.P2P_leak_post);
    p2p_leakage_test(PVDD, 50e-3, FOVI_1V, FOVI_100UA, 5000, PVDD_M.P2P_leak_post);
    p2p_leakage_test(VLDO, 50e-3, FOVI_1V, FOVI_100UA, 5000, VLDO_M.P2P_leak_post);
    p2p_leakage_test(DVDD, 50e-3, FOVI_1V, FOVI_100UA, 5000, DVDD_M.P2P_leak_post);


    cbit.SetOn(K31_IIC2FOVI, K32_IIC2FOVI, K33_IIC_DIS_PU, -1);
    delay_ms(3);
    p2p_leakage_test(SCL, 50e-3, FOVI_1V, FOVI_100UA, 300, SCL_M.P2P_leak_post);
    p2p_leakage_test(SDA, 50e-3, FOVI_1V, FOVI_100UA, 300, SDA_M.P2P_leak_post);
    p2p_leakage_test(AD, 50e-3, FOVI_1V, FOVI_100UA, 300, AD_M.P2P_leak_post);


    for (int i = 0; i < 14; ++i)
    {
        STRU_PIN_LIST[i]->get_delta();
        SERIAL AstGetParam(funcindex, i)->SetTestResult(SITE, 0, STRU_PIN_LIST[i]->P2P_leak_post[SITE] * 1e9);
        SERIAL AstGetParam(funcindex, i + 14)->SetTestResult(SITE, 0, STRU_PIN_LIST[i]->P2P_leak_delta[SITE] * 1e9);
    }


    efmea.fmea_checking(funcindex);
    return 0;
}
 
DUT_API int OS_post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *OS_BCK_post = StsGetParam(funcindex, "OS_BCK_post");
    CParam *OS_WCK_post = StsGetParam(funcindex, "OS_WCK_post");
    CParam *OS_DATAI_post = StsGetParam(funcindex, "OS_DATAI_post");
    CParam *OS_SCL_post = StsGetParam(funcindex, "OS_SCL_post");
    CParam *OS_SDA_post = StsGetParam(funcindex, "OS_SDA_post");
    CParam *OS_AD_post = StsGetParam(funcindex, "OS_AD_post");
    CParam *OS_ININ_post = StsGetParam(funcindex, "OS_ININ_post");
    CParam *OS_VLDO_post = StsGetParam(funcindex, "OS_VLDO_post");
    CParam *OS_DVDD_post = StsGetParam(funcindex, "OS_DVDD_post");
    CParam *OS_VOP_post = StsGetParam(funcindex, "OS_VOP_post");
    CParam *OS_VON_post = StsGetParam(funcindex, "OS_VON_post");
    CParam *OS_VBAT_post = StsGetParam(funcindex, "OS_VBAT_post");
    CParam *OS_SW_post = StsGetParam(funcindex, "OS_SW_post");
    CParam *OS_PVDD_post = StsGetParam(funcindex, "OS_PVDD_post");
    CParam *OS_VLDO_H_post = StsGetParam(funcindex, "OS_VLDO_H_post");
    CParam *OS_VOP_H_post = StsGetParam(funcindex, "OS_VOP_H_post");
    CParam *OS_VON_H_post = StsGetParam(funcindex, "OS_VON_H_post");
    CParam *OS_SW_H_post = StsGetParam(funcindex, "OS_SW_H_post");
    //}}AFX_STS_PARAM_PROTOTYPES
    // TODO: Add your function code here

    const int PIN_NUM = 18;
    const int LEAK_NUM = 0;
    const int exclude_NUM = 0;
    double os_result[PIN_NUM][SITE_NUM] = { 0 };
    vector<string> vec_exclude;
    string pin_str_array[PIN_NUM] = { "OS_BCK_post", "OS_WCK_post", "OS_DATAI_post", "OS_SCL_post", "OS_SDA_post", "OS_AD_post", "OS_ININ_post", "OS_VLDO_post", "OS_DVDD_post", "OS_VOP_post", "OS_VON_post", "OS_VBAT_post", "OS_SW_post", "OS_PVDD_post", "OS_VLDO_H_post", "OS_VOP_H_post", "OS_VON_H_post", "OS_SW_H_post" };

    GPFOVI OS_GP1("OS_GP1", BCK, WCK, DATAI, INTN, VLDO, DVDD, VOP, VON, VBAT, SW, PVDD);
    GPFOVI OS_GP2("OS_GP2", SCL, SDA, AD);
    GPFOVI OS_GP3("OS_GP3", VLDO, VOP, VON, SW);


    cbit.SetOn(K35_BCK2FOVI, K34_WCK2FOVI, -1);
    delay_ms(3);

    OS_GP1.Set(FI, -1e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
    delay_us(500);
    OS_GP1.MeasureVI(10, 10);
    OS_GP1.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);

    //BCK
    SERIAL os_result[0][SITE] = BCK.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[0].c_str())->SetTestResult(SITE, 0, os_result[0][SITE]);
    //WCK
    SERIAL os_result[1][SITE] = WCK.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[1].c_str())->SetTestResult(SITE, 0, os_result[1][SITE]);
    //DATAI
    SERIAL os_result[2][SITE] = DATAI.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[2].c_str())->SetTestResult(SITE, 0, os_result[2][SITE]);
    //INTN
    SERIAL os_result[6][SITE] = INTN.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[6].c_str())->SetTestResult(SITE, 0, os_result[6][SITE]);
    //VLDO
    SERIAL os_result[7][SITE] = VLDO.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[7].c_str())->SetTestResult(SITE, 0, os_result[7][SITE]);
    //DVDD
    SERIAL os_result[8][SITE] = DVDD.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[8].c_str())->SetTestResult(SITE, 0, os_result[8][SITE]);
    //VOP
    SERIAL os_result[9][SITE] = VOP.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[9].c_str())->SetTestResult(SITE, 0, os_result[9][SITE]);
    //VON
    SERIAL os_result[10][SITE] = VON.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[10].c_str())->SetTestResult(SITE, 0, os_result[10][SITE]);
    //VBAT
    SERIAL os_result[11][SITE] = VBAT.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[11].c_str())->SetTestResult(SITE, 0, os_result[11][SITE]);
    //SW
    SERIAL os_result[12][SITE] = SW.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[12].c_str())->SetTestResult(SITE, 0, os_result[12][SITE]);
    //PVDD
    SERIAL os_result[13][SITE] = PVDD.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[13].c_str())->SetTestResult(SITE, 0, os_result[13][SITE]);


    cbit.SetOn(K31_IIC2FOVI, K32_IIC2FOVI, K33_IIC_DIS_PU, -1);
    delay_ms(3);

    OS_GP2.Set(FI, -1e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
    delay_us(500);
    OS_GP2.MeasureVI(10, 10);
    OS_GP2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);

    //SCL
    SERIAL os_result[3][SITE] = SCL.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[3].c_str())->SetTestResult(SITE, 0, os_result[3][SITE]);
    //SDA
    SERIAL os_result[4][SITE] = SDA.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[4].c_str())->SetTestResult(SITE, 0, os_result[4][SITE]);
    //AD
    SERIAL os_result[5][SITE] = AD.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[5].c_str())->SetTestResult(SITE, 0, os_result[5][SITE]);


    OS_GP3.Set(FI, 1e-3, FOVI_2V, FOVI_10MA, RELAY_ON);
    delay_us(500);
    OS_GP3.MeasureVI(10, 10);
    OS_GP3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);

    //VLDO
    SERIAL os_result[14][SITE] = VLDO.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[14].c_str())->SetTestResult(SITE, 0, os_result[14][SITE]);
    //VOP
    SERIAL os_result[15][SITE] = VOP.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[15].c_str())->SetTestResult(SITE, 0, os_result[15][SITE]);
    //VON
    SERIAL os_result[16][SITE] = VON.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[16].c_str())->SetTestResult(SITE, 0, os_result[16][SITE]);
    //SW
    SERIAL os_result[17][SITE] = SW.GetMeasResult(SITE, MVRET);
    SERIAL StsGetParam(funcindex, pin_str_array[17].c_str())->SetTestResult(SITE, 0, os_result[17][SITE]);

    efmea.fmea_checking(funcindex);
    return 0;
}
