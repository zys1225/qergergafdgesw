#include "stdafx.h"
#define TEST_POINT 20

extern struct CLASSD OUTP, OUTN;
extern struct REG reg_0x88;
extern UINT16 debug_reg[SITE_NUM];
extern FOVI FOVI_List[12];
extern Test_Method test_method;

extern double OUTPN_Vcoef[SITE_NUM];
extern double Vcoef_gain;
extern double Vcoef_Isns;
extern double Vcoef_Vsns[SITE_NUM];


int check_all_flag(int* flag)
{
    int ALL_ONE_FLAG;

    ALL_ONE_FLAG = 1;

    for (globalsite = 0; globalsite < SITE_NUM; globalsite++)
    {
        if (StsGetsSiteStatus() & (1 << globalsite))
        {
            ALL_ONE_FLAG = ALL_ONE_FLAG & flag[SITE];
        }
    }

    return ALL_ONE_FLAG;
}

double conv_db(double input)
{
    if (input <= 0) return 9999;
    return 20 * log10(input);
}

//I2C CMD
void I2C_setup(double clk_period)
{
    dio_plus.I2CSetClockPeriod(clk_period);
    dio_plus.I2CSetSCLDelay(0, 0.7 * clk_period);//clk
    dio_plus.I2CSetSDADelay(0.1 * clk_period, 0.99 * clk_period, 0.95 * clk_period);//sdaʱ���������
}

void I2C_WR(BYTE DEV_ADDR, BYTE reg_addr, UINT16 data, bool Force_WR)
{
    //if (reg_0x88.check_wr_eq_work(reg_addr, data) && (!Force_WR)) return;

    BYTE Indata[2];
    Indata[0] = data >> 8;
    Indata[1] = data & 0xFF;

    dio_plus.I2CWriteAll(DEV_ADDR, reg_addr, Indata, 2);

    reg_0x88.set_working(reg_addr, data);
}

void I2C_WR_DIFF(BYTE DEV_ADDR, BYTE reg_addr, UINT16 *data)
{
    BYTE data_byte[SITE_NUM][2];

    SERIAL data_byte[SITE][1] = data[SITE] & 0xFF;
    SERIAL data_byte[SITE][0] = data[SITE] >> 8;

    SERIAL pI2CSites[SITE]->address = DEV_ADDR;
    SERIAL pI2CSites[SITE]->regAddress = reg_addr;
    //SERIAL pI2CSites[SITE]->dataByteCount = 2;
    SERIAL pI2CSites[SITE]->data = data_byte[SITE];

    dio_plus.I2CWrite(pI2CSites, 4);

    reg_0x88.set_working(reg_addr, data);
}

void I2C_RD(BYTE DEV_ADDR, BYTE reg_addr, UINT16 *data)
{

    dio_plus.I2CReadAll(DEV_ADDR, reg_addr, 2);

    data[0] = i2c_site0.GetDataByteValue(1) + (i2c_site0.GetDataByteValue(0) << 8);
    data[1] = i2c_site1.GetDataByteValue(1) + (i2c_site1.GetDataByteValue(0) << 8);
    data[2] = i2c_site2.GetDataByteValue(1) + (i2c_site2.GetDataByteValue(0) << 8);
    data[3] = i2c_site3.GetDataByteValue(1) + (i2c_site3.GetDataByteValue(0) << 8);


    reg_0x88.set_working(reg_addr, data);
}


void I2C_RD_ALL(BYTE DEV_ADDR)
{
    UINT16 temp_code[SITE_NUM];
    for (int i = 0; i < REG_NUM; ++i)
    {
        I2C_RD(DEV_ADDR, i, temp_code);
    }
}

void EFUSE_Preview(int Bank_num)
{
    string EE_str;
    if (Bank_num == -1)
    {
        for (int i = 0; i < BANK_NUM; ++i)
        {
            UINT16 temp_data[SITE_NUM] = { 0 };
            EE_str = "EEPROM" + int2str(i);
            SERIAL temp_data[SITE] = dut.assy(EE_str.c_str()).get_working(SITE);
            I2C_WR_DIFF(DEV_AD_DEF, TRIM_BANK_ST + i, temp_data);
        }
    }
    else
    {
        UINT16 temp_data[SITE_NUM] = { 0 };
        EE_str = "EEPROM" + int2str(Bank_num);
        SERIAL temp_data[SITE] = dut.assy(EE_str.c_str()).get_working(SITE);
        I2C_WR_DIFF(DEV_AD_DEF, TRIM_BANK_ST + Bank_num, temp_data);
    }
}

void Enter_TM()
{
    I2C_WR(DEV_AD_DEF, 0x7F, 0x0000, true);
    I2C_WR(DEV_AD_DEF, 0x7F, 0x0053, true);
    I2C_WR(DEV_AD_DEF, 0x7F, 0x5400, true);
    I2C_WR(DEV_AD_DEF, 0x7F, 0x5645, true);
    I2C_WR(DEV_AD_DEF, 0x7F, 0x5645, true);
    I2C_WR(DEV_AD_DEF, 0x7F, 0x4E45, true);
    I2C_WR(DEV_AD_DEF, 0x7F, 0x4E45, true);
    I2C_WR(DEV_AD_DEF, 0x7F, 0x4040, true);
}


void FORCE_ALLPIN_0V_OFF(int sel)//0:all 1:ovi 2:pvi
{
    if (sel == 0)
    {
        FOVI0.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI1.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI2.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI3.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI4.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI5.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI6.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI7.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI32.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI33.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI34.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI35.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_OFF);
        FPVI1.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_OFF);
    }
    if (sel == 1)
    {
        FOVI0.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI1.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI2.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI3.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI4.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI5.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI6.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI7.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI32.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI33.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI34.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
        FOVI35.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
    }
    if (sel == 2)
    {
        FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_OFF);
        FPVI1.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_OFF);
    }

}


int cmpDouble(const void* a, const void* b) {
	double num1 = *(const double*)a;
	double num2 = *(const double*)b;

	if (num1 < num2) return -1;
	if (num1 > num2) return 1;
	return 0;
}

double getMedian(double arr[], int len) {
	qsort(arr, len, sizeof(double), cmpDouble);

	if (len % 2 == 1) {
		return arr[len / 2];
	}
	else {
		return (arr[len / 2 - 1] + arr[len / 2]) / 2.0;
	}
}
double getMin(double arr[], int len)
{
	double min = arr[0];
	for (int i = 1; i < len; i++)
	{
		if (arr[i] < min) min = arr[i];
	}
	return min;
}
double getMax(double arr[], int len)
{
	double max = arr[0];
	for (int i = 1; i < len; i++)
	{
		if (arr[i] > max) max = arr[i];
	}
	return max;
}
double getAve(double arr[], int len)
{
	double sum = 0;
	for (int i = 0; i < len; i++)
	{
		sum = sum + arr[i];
	}
	return sum / len;
}

//POWER
void POWER_ON(PWR_ON_SEL sel)
{
    VBAT.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
    DVDD.Set(FV, 1.8, FOVI_10V, FOVI_100MA, RELAY_ON);
    AD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    delay_ms(2);
    if (sel == FIX_AD)
    {
        I2C_WR(DEV_AD_DEF, 0x00, 0x0000);
    }

    if (sel == WITH_TM)
    {
        Enter_TM();
    }
    if (sel == WITH_NORMAL_SET)
    {
        I2C_WR(DEV_AD_DEF, 0x04, 0x8000);
        I2C_WR(DEV_AD_DEF, 0x05, 0x2000);
        I2C_WR(DEV_AD_DEF, 0x06, 0x0000);
        I2C_WR(DEV_AD_DEF, 0x33, 0x0000);
        Enter_TM();
    }
}

void POWER_OFF(PWR_OFF_SEL sel, INITIAL relay)
{

	AD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    DVDD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    PVDD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    VBAT.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
    if (relay == RES_RELAY_OFF)
    {
		delay_ms(1);
		AD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
        DVDD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
        PVDD.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
        VBAT.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    }
    reg_0x88.reset();
}

void RES_INITIAL(INITIAL choose, INITIAL relay)
{
    if (choose == GROUP)
    {
        ALL_FOVI.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
        ALL_FPVI.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    }
    if (choose == ONE_BY_ONE)
    {
        for (int i = 0; i < 12; ++i)
        {
            FOVI_List[i].Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
        }
        FPVI0.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
        FPVI1.Set(FI, 0, FPVI10_1V, FPVI10_10UA, RELAY_ON);
    }
    if (relay == RES_RELAY_OFF)
    {
        ALL_FOVI.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
    }

}


void p2p_leakage_test(FOVI fovi, double force_v, FOVI_VRNG v_range, FOVI_IRNG i_range, int delay_time, double* result)
{
    fovi.Set(FV, force_v, v_range, i_range, RELAY_ON);
    delay_us(delay_time);
    fovi.MeasureVI(50, 10);
    SERIAL result[SITE] = fovi.GetMeasResult(SITE, MIRET);
    fovi.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_ON);
}
void pin_leakage_test(FOVI fovi, double force_v, FOVI_VRNG v_range, FOVI_IRNG i_range, int delay_time, double* result)
{
    fovi.Set(FV, force_v, v_range, i_range, RELAY_ON, 0.5);
    delay_ms(delay_time);
    fovi.MeasureVI(100, 10);
    SERIAL result[SITE] = fovi.GetMeasResult(SITE, MIRET);
    fovi.Set(FV, 0, FOVI_20V, FOVI_10MA, RELAY_OFF);
}



void measure_BG_TC(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}

    EFUSE_Preview(0);
    delay_us(100);
    INTN.MeasureVI(50, 10);
    SERIAL results[SITE] = INTN.GetMeasResult(SITE, MVRET);
}
void measure_BG_1P2(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}


    EFUSE_Preview(0);
    delay_us(100);
    INTN.MeasureVI(50, 10);
    SERIAL results[SITE] = INTN.GetMeasResult(SITE, MVRET);
}
void measure_IBIAS_500N(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}


    EFUSE_Preview(0);

    delay_us(100);
    INTN.MeasureVI(50, 10);

    SERIAL results[SITE] = -INTN.GetMeasResult(SITE, MIRET) * 1e9;

}
void measure_LDO_LP_BG_TC(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}

    double result_vctat[SITE_NUM];
    double result_vptat[SITE_NUM];
    ////WAIT_TIME_TOO_LONG
    EFUSE_Preview(1);
    I2C_WR(DEV_AD_DEF, 0x81, 0x840F);//AMUX ldo vctat
    delay_ms(10);
    INTN.MeasureVI(50, 10);
    SERIAL result_vctat[SITE] = INTN.GetMeasResult(SITE, MVRET);

    I2C_WR(DEV_AD_DEF, 0x81, 0x840E);//AMUX ldo vptat
    delay_ms(10);
    INTN.MeasureVI(50, 10);
    SERIAL result_vptat[SITE] = INTN.GetMeasResult(SITE, MVRET);


    SERIAL results[SITE] = result_vctat[SITE] / (result_vptat[SITE] + DBL_EPSILON);


}
void measure_LDO_LP_VREF(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}

    ////WAIT_TIME_TOO_LONG
    EFUSE_Preview(1);
    delay_ms(10);
    INTN.MeasureVI(50, 10);
    SERIAL results[SITE] = INTN.GetMeasResult(SITE, MVRET);

}
void measure_BOOST_DAC_BUF(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}

    EFUSE_Preview(4);
    //dcm.RunVectorWithGroup("IIS", "IIS_EMPTY_ST", "", FALSE);
    delay_us(100);
    INTN.MeasureVI(50, 10);
    SERIAL results[SITE] = INTN.GetMeasResult(SITE, MVRET);

}
void measure_TVP_SNS_OS(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}



    EFUSE_Preview(4);
    //dcm.RunVectorWithGroup("IIS", "IIS_EMPTY_ST", "", FALSE);
    delay_us(100);
    INTN.MeasureVI(50, 10);
    SERIAL results[SITE] = INTN.GetMeasResult(SITE, MVRET);

}
void measure_OSC_FREQ(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}


    EFUSE_Preview(1);
    delay_us(100);
    qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TIME_US, 10, 10);
    SERIAL results[SITE] = qtmu0.GetMeasureResult(SITE) / 1000;//Mhz


}
void measure_TSNS_DGE_H(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}

    double sum[2][SITE_NUM] = { 0 };
    UINT16 TSNS_CODE_BF[TEST_POINT][SITE_NUM];
    UINT16 TSNS_CODE_AF[TEST_POINT][SITE_NUM];
    signed char byte_BF[SITE_NUM][TEST_POINT] = { 0 };
    signed char byte_AF[SITE_NUM][TEST_POINT] = { 0 };

    EFUSE_Preview(6);

    AD.Set(FV, 0.42, FOVI_1V, FOVI_100MA, RELAY_ON);
    delay_ms(1);

    for (int i = 0; i < TEST_POINT; ++i)
    {
        I2C_RD(DEV_AD_DEF, 0x12, TSNS_CODE_BF[i]);//DOUT
        SERIAL byte_BF[SITE][i] = TSNS_CODE_BF[i][SITE];
        SERIAL sum[0][SITE] = sum[0][SITE] + byte_BF[SITE][i];

    }

    AD.Set(FV, 0.72, FOVI_1V, FOVI_100MA, RELAY_ON);
    delay_ms(1);

    for (int i = 0; i < TEST_POINT; ++i)
    {
        I2C_RD(DEV_AD_DEF, 0x12, TSNS_CODE_AF[i]);//DOUT
        SERIAL byte_AF[SITE][i] = TSNS_CODE_AF[i][SITE];
        SERIAL sum[1][SITE] = sum[1][SITE] + byte_AF[SITE][i];
    }

    SERIAL results[SITE] = (sum[1][SITE] - sum[0][SITE]) / TEST_POINT;
}
void measure_TSNS_DGE_L(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}

    double sum[2][SITE_NUM] = { 0 };
    UINT16 TSNS_CODE_BF[TEST_POINT][SITE_NUM];
    UINT16 TSNS_CODE_AF[TEST_POINT][SITE_NUM];
    signed char byte_BF[SITE_NUM][TEST_POINT] = { 0 };
    signed char byte_AF[SITE_NUM][TEST_POINT] = { 0 };

    EFUSE_Preview(6);

    AD.Set(FV, 0.42, FOVI_1V, FOVI_100MA, RELAY_ON);
    delay_ms(1);

    for (int i = 0; i < TEST_POINT; ++i)
    {
        I2C_RD(DEV_AD_DEF, 0x12, TSNS_CODE_BF[i]);//DOUT
        SERIAL byte_BF[SITE][i] = TSNS_CODE_BF[i][SITE];
        SERIAL sum[0][SITE] = sum[0][SITE] + byte_BF[SITE][i];

    }

    AD.Set(FV, 0.72, FOVI_1V, FOVI_100MA, RELAY_ON);
    delay_ms(1);

    for (int i = 0; i < TEST_POINT; ++i)
    {
        I2C_RD(DEV_AD_DEF, 0x12, TSNS_CODE_AF[i]);//DOUT
        SERIAL byte_AF[SITE][i] = TSNS_CODE_AF[i][SITE];
        SERIAL sum[1][SITE] = sum[1][SITE] + byte_AF[SITE][i];
    }

    SERIAL results[SITE] = (sum[1][SITE] - sum[0][SITE]) / TEST_POINT;
}
void measure_TSNS_DGE(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
	if (treg_measure_flag == TREG_MEASURE_CHAR) {}
	if (treg_measure_flag == TREG_MEASURE_PRE) {}
	if (treg_measure_flag == TREG_MEASURE_POST) {}

	UINT16 TSNS_CODE_BF[TEST_POINT][SITE_NUM];
	UINT16 TSNS_CODE_AF[TEST_POINT][SITE_NUM];
	signed char byte_BF[SITE_NUM][TEST_POINT] = { 0 };
	signed char byte_AF[SITE_NUM][TEST_POINT] = { 0 };
	double double_BF[SITE_NUM][TEST_POINT] = { 0 };
	double double_AF[SITE_NUM][TEST_POINT] = { 0 };

	EFUSE_Preview(6);

	AD.Set(FV, 0.42, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(1);

	for (int i = 0; i < TEST_POINT; ++i)
	{
		I2C_RD(DEV_AD_DEF, 0x12, TSNS_CODE_BF[i]);//DOUT
		SERIAL byte_BF[SITE][i] = TSNS_CODE_BF[i][SITE];
		SERIAL double_BF[SITE][i] = byte_BF[SITE][i];

	}

	AD.Set(FV, 0.72, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(1);

	for (int i = 0; i < TEST_POINT; ++i)
	{
		I2C_RD(DEV_AD_DEF, 0x12, TSNS_CODE_AF[i]);//DOUT
		SERIAL byte_AF[SITE][i] = TSNS_CODE_AF[i][SITE];
		SERIAL double_AF[SITE][i] = byte_AF[SITE][i];
	}

	SERIAL results[SITE] = getMedian(double_AF[SITE], 20) - getMedian(double_BF[SITE], 20);
}
void measure_PV_OFFSET(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}


    UINT16 REG_TSNS[SITE_NUM];
    UINT16 REG_VSNS[SITE_NUM];
    double SUM_CODE[SITE_NUM];
    double VBAT_V[SITE_NUM];


    EFUSE_Preview(5);
    EFUSE_Preview(6);


    SERIAL SUM_CODE[SITE] = 0;
	for (int i = 0; i < TEST_POINT; i++)
	{
        I2C_RD(DEV_AD_DEF, 0x10, REG_VSNS);
        SERIAL SUM_CODE[SITE] = SUM_CODE[SITE] + REG_VSNS[SITE];
    }



	SERIAL VBAT_V[SITE] = SUM_CODE[SITE] * 0.028 / TEST_POINT;


    SERIAL results[SITE] = VBAT_V[SITE];


}
void measure_BOOST_ISNS(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}
    double result_2p0A[SITE_NUM];
    double result_4p0A[SITE_NUM];


    EFUSE_Preview(5);

    I2C_WR(DEV_AD_DEF, 0x13, 0x4B4C);//2.0A
    //dcm.RunVectorWithGroup("IIS", "IIS_EMPTY_ST", "", FALSE);
    test_method.ramp_2FPVI(FPVI0, FPVI1, FPVI10_5V, FPVI10_10A, INTN, 0.0, 3.5, 0.01, 10, 1, TRIG_RISING, result_2p0A);

    I2C_WR(DEV_AD_DEF, 0x13, 0x734C);//4.0A
    //dcm.RunVectorWithGroup("IIS", "IIS_EMPTY_ST", "", FALSE);
    test_method.ramp_2FPVI(FPVI0, FPVI1, FPVI10_5V, FPVI10_10A, INTN, 0.0, 6.5, 0.01, 10, 1, TRIG_RISING, result_4p0A);


    SERIAL results[SITE] = result_4p0A[SITE] - result_2p0A[SITE];
}
void measure_BOOST_IPKL(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}

    EFUSE_Preview(5);

    //dcm.RunVectorWithGroup("IIS", "IIS_EMPTY_ST", "", FALSE);
    //delay_ms(5);
    test_method.ramp_2FPVI(FPVI0, FPVI1, FPVI10_5V, FPVI10_10A, INTN, 0.0, 5.5, 0.01, 10, 1, TRIG_RISING, results);
    SERIAL results[SITE] = results[SITE] + 0.37;//bench corr
}
void measure_BOOST_IPFM(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}


    EFUSE_Preview(5);
    delay_us(100);
    test_method.ramp_2FPVI(FPVI0, FPVI1, FPVI10_5V, FPVI10_1A, INTN, 0.0, 1.5, 0.01, 50, 0.5, TRIG_RISING, results);

}
void measure_BOOST_ZCD(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}


    EFUSE_Preview(4);
    delay_us(100);
    test_method.ramp_2FPVI_ZCD(FPVI0, FPVI1, FPVI10_5V, FPVI10_1A, INTN, -1, 1, 0.01, 20, 1, TRIG_RISING, results);
    SERIAL results[SITE] = results[SITE] * 1000;

}
void measure_CLSD_OS_L(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}


    EFUSE_Preview(2);

    dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(10);
    qvm0.MeasureLADC(1000, 1, QVM_LADC_500MV);
    SERIAL results[SITE] = qvm0.GetMeasResult(SITE) * 1000;

    SERIAL if (dut.trim("CLSD_OS_H").get_working(SITE) < 8) results[SITE] = -results[SITE];



}
void measure_CLSD_OS_H(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    dut.force_post_measurement(1);
    int best_code[SITE_NUM];
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST)
    {
        SERIAL best_code[SITE] = dut.trim("CLSD_OS_H").get_working(SITE);
        SERIAL if (best_code[SITE] == 0) best_code[SITE] = 8;
        SERIAL if (best_code[SITE] < 8 && best_code[SITE] > 0) best_code[SITE] = best_code[SITE] - 1;
        SERIAL if (burn_flag[SITE]) dut.trim("CLSD_OS_H").set_working(best_code[SITE], SITE);
        dut.force_post_measurement(0);
    }


    EFUSE_Preview(2);
    EFUSE_Preview(3);


	dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
	delay_ms(10);
    qvm0.MeasureLADC(1000, 1, QVM_LADC_500MV);
    SERIAL results[SITE] = qvm0.GetMeasResult(SITE) * 1000;

}
void measure_CLSD_PWM(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}


    EFUSE_Preview(5);
	dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
	delay_ms(10);

    qtmu0.Meas(QTMU_PLUS_FINE, QTMU_PLUS_TRNG_NS, 10);
    //qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 1);

    SERIAL results[SITE] = qtmu0.GetMeasureResult(SITE) * 1e3 / 1.2;//nS


}
void measure_RAMP_VCM(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}

    double result_vop[SITE_NUM];
    double result_von[SITE_NUM];

    EFUSE_Preview(2);


	dio_plus.Run("IIS_EMPTY_ST", "IIS_EMPTY_ED", -2);
    delay_ms(10);

    qtmu0.MeasDutyCycle(1.6, QTMU_PLUS_HIGH_DUTY, 5);

    SERIAL results[SITE] = qtmu0.GetMeasureResult(SITE);


}
void measure_DAC_GAIN(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results)
{
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {}


    EFUSE_Preview(0);
    EFUSE_Preview(1);

    cbit.SetOn(K_CAP_ALL, K61_VOP2LC, K62_VON2LC, K31_IIC2FOVI, K32_IIC2FOVI, -1);
    delay_ms(3);

	dio_plus.Run("IIS_N10DB_1K_ST", "IIS_N10DB_1K_ED", -2);
	delay_ms(10);

    qvm0.MeasureLADC(SAMPLE_NUM_CYCLE, 1, QVM_LADC_5V);
    SERIAL results[SITE] = qvm0.GetMeasResult(SITE, RMS_RESULT);


    //SERIAL results[SITE] = results[SITE] * OUTPN_Vcoef[SITE] * Vcoef_gain;
    SERIAL results[SITE] = results[SITE] * Vcoef_gain;

    cbit.SetOn(K_CAP_ALL, K61_VOP2LC, K62_VON2LC, -1);
    delay_ms(3);
}