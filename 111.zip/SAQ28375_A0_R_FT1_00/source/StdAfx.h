// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_)
#define AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>
#define DUT_API extern "C" __declspec(dllexport)
#include <string> 
using namespace std;
#include "usertype.h"
#include "userres.h"

#define DEBUG_MODE 0
#define SITE_NUM 4
#define BANK_NUM 8
#define DEV_AD_DEF 0x90
#define DEV_AD_GND 0x90
#define DEV_AD_SCL 0x92
#define DEV_AD_SDA 0x94
#define DEV_AD_VDDIO 0x96

#define TRIM_BANK_ST 0x90
#define SAMPLE_NUM_CYCLE 2978
#define SAMPLE_NUM 8192
#define T_SAMPLE 1.2


//#define assert(_Expression) (void)( (!!(_Expression)) || (_wassert(_CRT_WIDE(#_Expression), _CRT_WIDE(__FILE__), __LINE__), 0) )
#define SITE globalsite
#define SERIAL for(globalsite=0;globalsite<SITE_NUM;globalsite++)
#define SERIAL_ACTIVE for(globalsite=0;globalsite<SITE_NUM;globalsite++)  if (StsGetsSiteStatus() & (1<< globalsite))


extern int  globalsite;
extern string int2str(DWORD n);
extern BYTE sitesta[SITE_NUM];
extern bool burn_flag[SITE_NUM];
extern int flag[SITE_NUM];




#include "treg.h"
#include "BoardCheck.h"
#include "Test_Method.h"
#include "treg.h"
#include "FMEA.h"
#include "SPEC.h"
#include "sub.h"
#include "FFT_windows.h"
#include <iostream>
#include <fstream>  // �����ļ�����

/////////// Resource ///////////////////////////////////////////
extern DIO_PLUS dio_plus;
extern DIO_PLUS::I2CSite i2c_site0;
extern DIO_PLUS::I2CSite i2c_site1;
extern DIO_PLUS::I2CSite i2c_site2;
extern DIO_PLUS::I2CSite i2c_site3;
extern DIO_PLUS::I2CSite* pI2CSites[];

extern FOVI FOVI0;
extern FOVI FOVI1;
extern FOVI FOVI2;
extern FOVI FOVI3;
extern FOVI FOVI4;
extern FOVI FOVI5;
extern FOVI FOVI6;
extern FOVI FOVI7;
extern FOVI FOVI32;
extern FOVI FOVI33;
extern FOVI FOVI34;
extern FOVI FOVI35;

extern FOVI VBAT;//0                      
extern FOVI PVDD;//1						
extern FOVI DVDD;//2			
extern FOVI VLDO;//3			
extern FOVI SCL;//4		
extern FOVI INTN;//4		
extern FOVI BUF;//4		
extern FOVI SCL_INTN;//4		
extern FOVI SDA;//5          
extern FOVI DATAI;//5          
extern FOVI SDA_DATAI;//5          
extern FOVI BCK;//6			
extern FOVI WCK;//7			
extern FOVI AD;//7			
extern FOVI WCK_AD;//7			
extern FOVI PWR_UP;//32	
extern FOVI SW;//33					
extern FOVI VOP;//34               
extern FOVI VON;//35		

extern GPFOVI ALL_FOVI;
extern GPFOVI ALL_PIN;

////////////////////////// FPVI /////////////////////////
extern FPVI10 FPVI0;
extern FPVI10 FPVI1;

extern GPFPVI10 ALL_FPVI;
////////////////////////// DIO /////////////////////////
extern DIO dio;

////////////////////////// QTMU /////////////////////////
extern QTMU_PLUS qtmu0;

////////////////////////// CBIT /////////////////////////
extern CBIT128 cbit;

////////////////////////// QVM /////////////////////////
extern QVM qvm0;

////////////////////////// TREG /////////////////////////
extern TREG dut;


struct CLASSD
{
    struct BRIDGE
    {
        struct SIDE
        {
            double OCP[4][SITE_NUM];
            double OCP_REV[4][SITE_NUM];
            double Rdson[SITE_NUM];
            double Ioff_pre[SITE_NUM];
            double Ioff_post[SITE_NUM];
            double Ioff_delta[SITE_NUM];
            double Idrive_pre[SITE_NUM];
            double Idrive_post[SITE_NUM];
            double Idrive_delta[SITE_NUM];

            void get_delta()
            {
                SERIAL Ioff_delta[SITE] = Ioff_post[SITE] - Ioff_pre[SITE];
                SERIAL Idrive_delta[SITE] = Idrive_post[SITE] - Idrive_pre[SITE];
            }
        } HS, LS;
        struct SEL
        {
            double Rdson[SITE_NUM];
            double Ioff_pre[SITE_NUM];
            double Ioff_post[SITE_NUM];
            double Ioff_delta[SITE_NUM];
            double Idrive_pre[SITE_NUM];
            double Idrive_post[SITE_NUM];
            double Idrive_delta[SITE_NUM];

            void get_delta()
            {
                SERIAL Ioff_delta[SITE] = Ioff_post[SITE] - Ioff_pre[SITE];
                SERIAL Idrive_delta[SITE] = Idrive_post[SITE] - Idrive_pre[SITE];
            }
        } YB_SEL;
    } DB, YB;
};

struct BOOST
{
    struct SIDE
    {
        double Rdson[SITE_NUM];
        double Ioff_pre[SITE_NUM];
        double Ioff_post[SITE_NUM];
        double Ioff_delta[SITE_NUM];
        double Idrive_pre[SITE_NUM];
        double Idrive_post[SITE_NUM];
        double Idrive_delta[SITE_NUM];

        void get_delta()
        {
            SERIAL Ioff_delta[SITE] = Ioff_post[SITE] - Ioff_pre[SITE];
            SERIAL Idrive_delta[SITE] = Idrive_post[SITE] - Idrive_pre[SITE];
        }
    } HS, LS;
};

struct LEAK
{
    double P2P_leak_pre[SITE_NUM];
    double P2P_leak_post[SITE_NUM];
    double P2P_leak_delta[SITE_NUM];
    double PIN_leak_pre[SITE_NUM];
    double PIN_leak_post[SITE_NUM];
    double PIN_leak_delta[SITE_NUM];
    double ABS_LEAK[SITE_NUM];
    void get_delta()
    {
        SERIAL P2P_leak_delta[SITE] = P2P_leak_post[SITE] - P2P_leak_pre[SITE];
        SERIAL PIN_leak_delta[SITE] = PIN_leak_post[SITE] - PIN_leak_pre[SITE];
    }
};

struct IQ
{
    struct PIN
    {
        struct status
        {
            double PD[SITE_NUM];
            double STBY[SITE_NUM];
            double IDLE_NG_ON[SITE_NUM];
            double IDLE_DB[SITE_NUM];
            double IDLE_YB[SITE_NUM];

        } pre, post, delta;
        void get_delta()
        {
            SERIAL delta.PD[SITE] = post.PD[SITE] - pre.PD[SITE];
            SERIAL delta.STBY[SITE] = post.STBY[SITE] - pre.STBY[SITE];
            SERIAL delta.IDLE_NG_ON[SITE] = post.IDLE_NG_ON[SITE] - pre.IDLE_NG_ON[SITE];
            SERIAL delta.IDLE_DB[SITE] = post.IDLE_DB[SITE] - pre.IDLE_DB[SITE];
            SERIAL delta.IDLE_YB[SITE] = post.IDLE_YB[SITE] - pre.IDLE_YB[SITE];
        }


    } DVDD, VBAT;

};

///////////////////////////////////////////////////////////////////////////////////////
////======= CBIT Name=========================
#define K0_VBAT_KEL                         56
#define K1_VBAT_CAP                         81
#define K2_PVDD_KEL                         58
#define K3_PVDD_CAP                         79
#define K4_DVDD_KEL                         64
#define K5_DVDD_CAP                         59
                                            
#define K7_VLDO_CAP                         57
                                            
#define K12_SW_KEL                          80
                                            
#define K14_BOOST_L                         82
#define K15_SW2QTMU                         0
#define K16_VOP2QTMU                        16
#define K17_VON2QTMU                        18
#define K18_INTN2QTMU                       20
                                            
                                            
#define K31_IIC2FOVI                        55
#define K32_IIC2FOVI                        84
#define K33_IIC_DIS_PU                      53
#define K34_WCK2FOVI                        86
#define K35_BCK2FOVI                        51
#define K36_AD2SCL                          22
#define K37_AD2SDA                          24
#define K38_SITE_CHECK                      88
#define K39_FPVIFH0_To_GND                  52
#define K40_FPVIFH1_To_PVDD                 54
                                            
#define K60_LR_Load                         26
#define K61_VOP2LC                          32
#define K62_VON2LC                          48
#define K63_VOP2VON                         50
                                            
#define K81_INTN_FOVI2BUF                   90
#define K82_BUFIN2GND                       49
#define K83_QTMU2BUF                        96
                                            
#define K90_FPVI0H2VOP                      47
#define K91_FPVI0H2VON                      112
#define K92_FPVI0H2VBAT                     27
#define K93_FPVI0L2GND                      114
#define K94_FPVI0L2PVDD                     25
#define K95_FPVI0L2DVDD                     116
#define K96_FPVI01H2SW                      23
#define K97_FPVI01L2GND                     118
#define K98_FPVI01L2PVDD                    21
#define K99_FPVI0_FS                        120
#define K100_FPVI1_FS                       19
                                            
#define K101_NTC                            122
#define K102_NTC                            17
                                            
                                            
#define KGND                                15

#define K_Kelvin K0_VBAT_KEL, K2_PVDD_KEL, K12_SW_KEL, K4_DVDD_KEL
#define K_CAP_ALL K1_VBAT_CAP, K3_PVDD_CAP, K5_DVDD_CAP, K7_VLDO_CAP
#define K_OUTPN K61_VOP2LC, K62_VON2LC

#define REG_NUM 0x100//0xFF+1
struct REG
{
    BYTE DEV_ADDR;
    UINT16 default[REG_NUM];
    UINT16 working[SITE_NUM][REG_NUM];
    bool diff_with_defalut[SITE_NUM][REG_NUM];

    void WRITE_DEFAULT_REG_TO_INI(char* ini_name)
    {
        char pgspath[300];
        char pathofini[300];
        char dev_addr[100];

        STSGetPgsPath(pgspath, 300);
        //pathofini
        strcat(strcpy(pathofini, pgspath), ini_name);

        sprintf_s(dev_addr, sizeof(dev_addr), "0x%02X", DEV_ADDR);//address format:0xFF

        //////////////////////////////////////NEED_MODIFY
        for (int i = 0; i < REG_NUM; ++i)
        {
            char reg_str[100];
            char reg_default[100];
            UINT16 reg_code[SITE_NUM];

            I2C_RD(DEV_AD_DEF, i, reg_code);//get default

            sprintf_s(reg_str, sizeof(reg_str), "0x%02X", i);//address format:0xFF
            SERIAL_ACTIVE sprintf_s(reg_default, sizeof(reg_default), "0x%04X", reg_code[SITE]);//data format:0xFFFF

            WritePrivateProfileString(dev_addr, reg_str, reg_default, pathofini);
        }
        //////////////////////////////////////NEED_MODIFY_END
    }

    void GET_DEFAULT_REG_FROM_INI(char* ini_name)
    {
        char pgspath[300];
        char pathofini[300];
        char dev_addr[100];

        STSGetPgsPath(pgspath, 300);
        //pathofini
        strcat(strcpy(pathofini, pgspath), ini_name);

        sprintf_s(dev_addr, sizeof(dev_addr), "0x%02X", DEV_ADDR);//address format:0xFF
        for (int i = 0; i < REG_NUM; ++i)
        {
            char reg_str[100];
            sprintf_s(reg_str, sizeof(reg_str), "0x%02X", i);
            default[i] = GetPrivateProfileInt(dev_addr, reg_str, 0xFFFF, pathofini);
        }

    }

    void reset()
    {
        SERIAL memcpy(working[SITE], default, sizeof(default));
        memset(diff_with_defalut, 0, sizeof(diff_with_defalut));
    };

    void initial(BYTE dev_addr, char* ini_name)
    {
        DEV_ADDR = dev_addr;
        GET_DEFAULT_REG_FROM_INI(ini_name);
        reset();
    }

    void set_working(BYTE reg_address, UINT16 data)
    {
        SERIAL_ACTIVE working[SITE][reg_address] = data;
        SERIAL_ACTIVE diff_with_defalut[SITE][reg_address] = (working[SITE][reg_address] == default[reg_address]) ? false : true;
    }
    void set_working(BYTE reg_address, UINT16* data)
    {
        SERIAL_ACTIVE working[SITE][reg_address] = data[SITE];
        SERIAL_ACTIVE diff_with_defalut[SITE][reg_address] = (working[SITE][reg_address] == default[reg_address]) ? false : true;
    }
    bool check_wr_eq_work(BYTE reg_address, UINT16 data)
    {
        bool result = true;
        SERIAL_ACTIVE if (working[SITE][reg_address] != data) result = false;

        return result;
    }

};




// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_)
