#include "stdafx.h"
#include "BoardCheck.h"

#define		YES 	6
#define		NO		7
#define SERIAL_BC for(SITE=0;SITE<SITE_NUM;SITE++) 	if(bc.GetSiteConnected(SITE)) 

extern FOVI FOVI_List[12];

/* No repeat: board_check_repeat = -1 */
int board_check_repeat = -1; // set repeat count

void connected_site_check(BoardCheck& bc)
{
	double site_check_specl = 0;
	double site_check_spech = 0;
	double result[SITE_NUM] = { 0 };
	//////////////////////////////////////////////////////////////////
	/********************** User Define Begin ***********************/
	site_check_specl = 4;
	site_check_spech = 6;


    cbit.SetOn(K38_SITE_CHECK, KGND, -1);
    delay_ms(3);

    PWR_UP.Set(FI, 1e-3, FOVI_10V, FOVI_100MA, RELAY_ON);
    delay_ms(10);
    PWR_UP.MeasureVI(20, 10);
    SERIAL result[SITE] = PWR_UP.GetMeasResult(SITE, MVRET);

    PWR_UP.Set(FI, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
    PWR_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);

    PWR_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);

	/********************** User Define End ***********************/
	//////////////////////////////////////////////////////////////////

	for (int site = 0; site<SITE_NUM; ++site) bc.SetSiteConnected(site, 0); // clear site check flag
	for (int site = 0; site<SITE_NUM; ++site)
	{
		// reset site check flag base on component measure
		if (site == 0){ site_check_specl = 0.5; site_check_spech = 1.5; }//site1 1K����
		if (site == 1){ site_check_specl = 1.5; site_check_spech = 2.5; }//site2 2K����
		if (site == 2){ site_check_specl = 2.5; site_check_spech = 3.5; }//site3 3K����
		if (site == 3){ site_check_specl = 3.5; site_check_spech = 4.5; }//site4 4K����

        char oper_id[20];
        StsGetOperatorID(oper_id, 20);
        if (strcmp(oper_id, "admin") == 0 || strcmp(oper_id, "eng") == 0)
        {
            site_check_specl = 0.5;
            site_check_spech = 4.5;
        }
		if ((result[site] > site_check_specl) && (result[site] < site_check_spech))
			bc.SetSiteConnected(site, 1);
		else
			bc.SetSiteConnected(site, 0);
	}

}


BOOL board_check_function(int &nBtn, BOOL &flag_pass)
{
	//////////////////////////////////////////////////////////////////
	/* Common usage format, don't change this if no specific need   */
	BoardCheck bc;
    double result[SITE_NUM];
    double result1[SITE_NUM];
    double result2[SITE_NUM];
	double result_V[SITE_NUM];
	double bc_awg[1000] = { 0.0 };
	string board_name;
	string board_rev;
	string board_number;

	for (int site = 0; site<SITE_NUM; ++site) result[site] = 9999;
	DWORD tnum = 1;

	int sel_flag = NO;
	bc.ClearSiteConnected();
	while ((bc.IsNoSiteConnected() || (sel_flag == NO)) && (board_check_repeat == -1))
	{
		connected_site_check(bc);

		if (bc.IsNoSiteConnected())

		{
			if (MessageBoxA(NULL, "û�м�⵽�κι�λ! \n��ȷ��: ���԰�������Ƿ�������ȷ��\n\n���������ѡ��-��(Y)\n����˳���ѡ��-��(N)", "�����ʾ�Ի���", MB_YESNO) == IDNO)
			{
				nBtn = BTN_EXIT;
				return FALSE;
			}
			continue;
		}

		string msg("��ǰʹ�ù�λ��ţ�");
		for (int site = 0; site<SITE_NUM; ++site)
		{
			if (bc.GetSiteConnected(site))
				msg = msg + "��λ(" + int2str(site + 1) + ") ��";
		}
		msg = msg + "\n\n�����ȷ: \n(��һ��) ѡ��-��(Y)�����򽫿�ʼ�������\n\n�������:\n(��һ��) ������������\n(�ڶ���) ѡ��-��(N)���������¼�⹤λ";
		sel_flag = MessageBoxA(NULL, msg.c_str(), "�����ʾ�Ի���", MB_YESNO);
	}
	if (board_check_repeat != -1) connected_site_check(bc);	// repeat always check site connect
	/* Common usage format, don't change this if no specific need   */
	//////////////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////////////////
	/********************** User Define Begin ***********************/

	Cvi_config vi; // default FV,3V,0A,FOVI_5V,FOVI_10MA,10ms,100 sample times,10 us interval

	/*** Connections and components ***/
	double spec_h = vi.v + 0.01;
	double spec_l = vi.v - 0.01;

	double leak_spel = -100; //nA
	double leak_speh = 100;  //nA

	vi.init();	//Init the class. The default config is: FV,3V,0A,FOVI_5V,FOVI_10MA,10ms,100 sample times,10 us interval


    cbit.SetOn(K_Kelvin, KGND, -1);
    delay_ms(3);

    bc.test_cap(VBAT, tnum++, "VBAT_10nF_CAP", 5, 15, "nF");
    bc.test_cap(PVDD, tnum++, "PVDD_10nF_CAP", 5, 15, "nF");
    bc.test_cap(DVDD, tnum++, "DVDD_10nF_CAP", 5, 15, "nF");
    bc.test_cap(VLDO, tnum++, "VLDO_10nF_CAP", 5, 15, "nF");

    cbit.SetOn(K_Kelvin, K_CAP_ALL, KGND, -1);
    delay_ms(3);

    bc.test_cap(VBAT, tnum++, "VBAT_10uF_CAP", 5, 15, "uF");
    bc.test_cap(PVDD, tnum++, "PVDD_10uF_CAP", 5, 15, "uF");
    bc.test_cap(DVDD, tnum++, "DVDD_1uF_CAP", 0.5, 1.5, "uF");
    bc.test_cap(VLDO, tnum++, "VLDO_1uF_CAP", 0.5, 1.5, "uF");


    cbit.SetOn(K_Kelvin, K32_IIC2FOVI, K31_IIC2FOVI, KGND, -1);
    delay_ms(3);
    PWR_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);

    SDA.Set(FV, 1, FOVI_10V, FOVI_100MA, RELAY_ON);
    delay_ms(3);
    SDA.MeasureVI(100, 10);
    SERIAL result[SITE] = SDA.GetMeasResult(SITE, MIRET);
    SERIAL result[SITE] = 1e-3 / (result[SITE] + DBL_EPSILON);
    bc.log(tnum++, "SDA_PU_1kohm", result, 0.9, 1.1, "kohm");
    SDA.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);


    SCL.Set(FV, 1, FOVI_10V, FOVI_100MA, RELAY_ON);
    delay_ms(3);
    SCL.MeasureVI(100, 10);
    SERIAL result[SITE] = SCL.GetMeasResult(SITE, MIRET);
    SERIAL result[SITE] = 1e-3 / (result[SITE] + DBL_EPSILON);
    bc.log(tnum++, "SCL_PU_1kohm", result, 0.9, 1.1, "kohm");
    SCL.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);

    PWR_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);


    ///////////////////////////////////////////////////test_CONN
    cbit.SetOn(K_Kelvin, K31_IIC2FOVI, K32_IIC2FOVI, K14_BOOST_L, K37_AD2SDA, K33_IIC_DIS_PU, K36_AD2SCL, KGND, -1);
    delay_ms(3);
    bc.test_v(SW, VBAT, vi, tnum++, "K14_L3_CONN", 2.99, 3.01, "V");
    bc.test_v(SCL, AD, vi, tnum++, "K36_K32_CONN", 2.99, 3.01, "V");
    bc.test_v(SDA, AD, vi, tnum++, "K37_K32_CONN", 2.99, 3.01, "V");
    //////////////OP97
    cbit.SetOn(K_Kelvin, K36_AD2SCL, K31_IIC2FOVI, K32_IIC2FOVI, K81_INTN_FOVI2BUF, K82_BUFIN2GND, KGND, -1);
    delay_ms(3);
    bc.test_v(AD, SCL, vi, tnum++, "K81_K82_OP97", 2.995, 3.005, "V");
    //////////////Rload    //////////////K63_short
    cbit.SetOn(K_Kelvin, K60_LR_Load, KGND, -1);
    delay_ms(3);
    VOP.Set(FI, 0.05, FOVI_10V, FOVI_100MA, RELAY_ON);
    VON.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
    delay_ms(3);
    VOP.MeasureVI(100, 10);
    SERIAL result[SITE] = VOP.GetMeasResult(SITE, MVRET) * 20;
    bc.log(tnum++, "Rload_K60", result, 7, 10, "ohm");

    cbit.SetOn(K_Kelvin, K63_VOP2VON, KGND, -1);
    delay_ms(3);
    VOP.MeasureVI(100, 10);
    SERIAL result[SITE] = VOP.GetMeasResult(SITE, MVRET) * 20;
    bc.log(tnum++, "K63_short", result, 0, 2, "ohm");

    VOP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
    VON.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
    //////////////QVM
    double QVM_V[SITE_NUM] = { 1, 2, 3, 4 };
    cbit.SetOn(K_Kelvin, K61_VOP2LC, K62_VON2LC, KGND, -1);
    delay_ms(3);
    VOP.SetSyn(FV, QVM_V, 4, FOVI_10V, FOVI_100MA, RELAY_ON);
    VON.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
    delay_ms(3);
    qvm0.Connect();
    qvm0.MeasureLADC(1000, 10, QVM_LADC_10V);
    SERIAL result[SITE] = qvm0.GetMeasResult(SITE) / (SITE + 1);
    bc.log(tnum++, "K61_K62_QVM", result, 0.9, 1.1, "V");
    VOP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
    VON.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);

    ///////////////////////////////////////////////////test_QTMU
    cbit.SetOn(K_Kelvin, K14_BOOST_L, K15_SW2QTMU, KGND, -1);
    delay_ms(3);
    bc.test_qtmu(SW, qtmu0, tnum++, "SW_K15_QTMU", 800, 1200, "uS");
    cbit.SetOn(K_Kelvin, K16_VOP2QTMU, KGND, -1);
    delay_ms(3);
    bc.test_qtmu(VOP, qtmu0, tnum++, "VOP_K16_QTMU", 800, 1200, "uS");
    cbit.SetOn(K_Kelvin, K17_VON2QTMU, KGND, -1);
    delay_ms(3);
    bc.test_qtmu(VON, qtmu0, tnum++, "VON_K17_QTMU", 800, 1200, "uS");
    cbit.SetOn(K_Kelvin, K18_INTN2QTMU, K83_QTMU2BUF, KGND, -1);
    delay_ms(3);
    bc.test_qtmu(INTN, qtmu0, tnum++, "INTN_K83_SN74_K18_QTMU", 800, 1200, "uS");


    ///////////////////////////////////////////////////test_DIO
    cbit.SetOn(K_Kelvin, K31_IIC2FOVI, KGND, -1);
    delay_ms(3);

    dio_plus.Connect();

    SCL_INTN.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
    SDA_DATAI.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

    //////////////DIO0
    dio_plus.SetEnabled(false);
    SERIAL_BC
    {
        dio_plus.SetEnabled("DATAO_D", SITE, true);
        dio_plus.SetEnabled("DATAI_D", SITE, true);
        dio_plus.SetEnabled("BCK_D", SITE, true);
        dio_plus.SetEnabled("WCK_D", SITE, true);
        dio_plus.Run("check0_L", "check0_L");
        delay_ms(1);

        SCL_INTN.MeasureVI(50, 10);
        result[SITE] = SCL_INTN.GetMeasResult(SITE, MVRET);
    }
    bc.log(tnum++, "DIO0_SCL_K31_L", result, -0.2, 0.2, "V");

    dio_plus.SetEnabled(false);
    SERIAL_BC
    {
        dio_plus.SetEnabled("DATAO_D", SITE, true);
        dio_plus.SetEnabled("DATAI_D", SITE, true);
        dio_plus.SetEnabled("BCK_D", SITE, true);
        dio_plus.SetEnabled("WCK_D", SITE, true);
        dio_plus.Run("check0_H", "check0_H");
        delay_ms(1);

        SCL_INTN.MeasureVI(50, 10);
        result[SITE] = SCL_INTN.GetMeasResult(SITE, MVRET);
    }

    bc.log(tnum++, "DIO0_SCL_K31_H", result, 1.6, 2.0, "V");

    //////////////DIO1
    dio_plus.SetEnabled(false);
    SERIAL_BC
    {
        dio_plus.SetEnabled("DATAO_D", SITE, true);
        dio_plus.SetEnabled("DATAI_D", SITE, true);
        dio_plus.SetEnabled("BCK_D", SITE, true);
        dio_plus.SetEnabled("WCK_D", SITE, true);
        dio_plus.Run("check1_L", "check1_L");
        delay_ms(1);

        SDA_DATAI.MeasureVI(50, 10);
        result[SITE] = SDA_DATAI.GetMeasResult(SITE, MVRET);
    }
    bc.log(tnum++, "DIO1_SDA_K31_L", result, -0.2, 0.2, "V");

    dio_plus.Run("check1_H", "check1_H");
    delay_ms(1);

    SDA_DATAI.MeasureVI(50, 10);
    SERIAL result[SITE] = SDA_DATAI.GetMeasResult(SITE, MVRET);
    bc.log(tnum++, "DIO1_SDA_K31_H", result, 1.6, 2.0, "V");

    //////////////DIO3
    cbit.SetOn(K_Kelvin, K34_WCK2FOVI, K36_AD2SCL, K31_IIC2FOVI, K32_IIC2FOVI, KGND, -1);
    delay_ms(3);

    dio_plus.SetEnabled(false);
    SERIAL_BC
    {
        dio_plus.SetEnabled("DATAO_D", SITE, true);
        dio_plus.SetEnabled("DATAI_D", SITE, true);
        dio_plus.SetEnabled("BCK_D", SITE, true);
        dio_plus.SetEnabled("WCK_D", SITE, true);
        dio_plus.Run("check3_L", "check3_L");
        delay_ms(1);

        SCL_INTN.MeasureVI(50, 10);
        result[SITE] = SCL_INTN.GetMeasResult(SITE, MVRET);
    }
    bc.log(tnum++, "DIO3_K34_K36_K32_L", result, -0.2, 0.2, "V");

    dio_plus.SetEnabled(false);
    SERIAL_BC
    {
        dio_plus.SetEnabled("DATAO_D", SITE, true);
        dio_plus.SetEnabled("DATAI_D", SITE, true);
        dio_plus.SetEnabled("BCK_D", SITE, true);
        dio_plus.SetEnabled("WCK_D", SITE, true);
        dio_plus.Run("check3_H", "check3_H");
        delay_ms(1);

        SCL_INTN.MeasureVI(50, 10);
        result[SITE] = SCL_INTN.GetMeasResult(SITE, MVRET);
    }
    bc.log(tnum++, "DIO3_K34_K36_K32_L", result, 1.6, 2.0, "V");

    dio_plus.Run("BC_DIO_ED", "BC_DIO_ED");

    string FOVI_List_Str[12] = { "FOVI0_LEAK", "FOVI1_LEAK", "FOVI2_LEAK", "FOVI3_LEAK", "FOVI4_LEAK", "FOVI5_LEAK", "FOVI6_LEAK", "FOVI7_LEAK", "FOVI32_LEAK", "FOVI33_LEAK", "FOVI34_LEAK", "FOVI35_LEAK" };

    RES_INITIAL(ONE_BY_ONE, RES_RELAY_OFF);

    cbit.SetOn(K_Kelvin,K33_IIC_DIS_PU, KGND, -1);



    vi.i_range = FOVI_10UA;
    vi.delay = 50;

    char testitem_name[50];

    for (int i = 0; i < 12; ++i)
    {
        bc.test_i(FOVI_List[i], vi, tnum++, FOVI_List_Str[i].c_str(), -200, 200, "nA");
    }

    RES_INITIAL(ONE_BY_ONE, RES_RELAY_OFF);




	/*********************** User Define End ************************/
	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	/* Common usage format, don't change this if no specific need   */
	if (board_check_repeat < 0)
		bc.Display();
	nBtn = bc.get_nBtn();
	flag_pass = bc.IsCheckPass();
	bc.report();
	//////////////////////////////////////////////////////////////////
	return TRUE;
}


///////////////////////////////////////////////////////////////////////////
/* run_diags() define the boardcheck flow, as a part of boardcheck library
don't change this function if no specific need       				 */
///////////////////////////////////////////////////////////////////////////
BOOL run_diags(void)
{
	int nBtn = BTN_REDO;
    BOOL flag_pass = FALSE;
    char oper_id[20];
    StsGetOperatorID(oper_id, 20);
    if (strcmp(oper_id, "admin") == 0 || strcmp(oper_id, "eng") == 0)
    {
        if (MessageBoxA(NULL, "��ǰ�˺�Ϊadmin���Ƿ���Ҫ��ϣ�\nѡ���������ϡ�", "�����ʾ�Ի���", MB_YESNO) == IDNO)
        {
            return TRUE;
        }
    }

	if (MessageBoxA(NULL, "��ϼ�����ʼ! \n\n�����������ȷ�ϲ�������û����Ʒ��ѡ��-��(Y)\n����˳���ѡ��-��(N)", "�����ʾ�Ի���", MB_YESNO) == IDNO){
		PostQuitMessage(0);
		return FALSE;
	}

	if (board_check_repeat < 0){
		while ((nBtn == BTN_REDO) && (flag_pass == FALSE))
		{
			board_check_function(nBtn, flag_pass);
		}
		if ((nBtn == BTN_EXIT) || (nBtn == BTN_CANCEL))
			PostQuitMessage(0);
		if (flag_pass == TRUE)
			MessageBoxA(NULL, "��ϳɹ���\n����ȷ�ϣ���ʼ����", "�����ʾ�Ի���", MB_OK);
	}

	string message_str;
	message_str = "�ظ�����" + int2str(board_check_repeat) + "��\n����ȷ����ť��ʼ\n����������Զ��˳�\n������鿴 bc.csv";
	if (board_check_repeat > 0)
		MessageBoxA(NULL, message_str.c_str(), "�����ʾ�Ի���", MB_OK);

	while (board_check_repeat-- > 0)
	{
		board_check_function(nBtn, flag_pass);
		delay_ms(100);

		if (board_check_repeat == 1)
			PostQuitMessage(0);
	}
	return TRUE;
}
