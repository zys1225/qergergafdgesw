#include "stdafx.h"
enum INITIAL
{
    GROUP,
    ONE_BY_ONE,
    RES_RELAY_ON,
    RES_RELAY_OFF,
};

enum PWR_ON_SEL
{
    ONLY,
    WITH_TM,
    WITH_NORMAL_SET,
    FIX_AD,
};


enum PWR_OFF_SEL
{
    NORMAL,
};



int check_all_flag(int* flag);

double conv_db(double input);

void I2C_setup(double clk_period);

void I2C_WR(BYTE DEV_ADDR, BYTE reg_addr, UINT16 data, bool Force_WR = 0);

void I2C_WR_DIFF(BYTE DEV_ADDR, BYTE reg_addr, UINT16 *data);

void I2C_RD(BYTE DEV_ADDR, BYTE reg_addr, UINT16 *data);

void I2C_RD_ALL(BYTE DEV_ADDR = DEV_AD_DEF);

void EFUSE_Preview(int Bank_num = -1);

void Enter_TM();

void FORCE_ALLPIN_0V_OFF(int sel = 0);



//POWER
void POWER_ON(PWR_ON_SEL sel);

void POWER_OFF(PWR_OFF_SEL sel, INITIAL relay = RES_RELAY_ON);

void RES_INITIAL(INITIAL choose, INITIAL relay);

void p2p_leakage_test(FOVI fovi, double force_v, FOVI_VRNG v_range, FOVI_IRNG i_range, int delay_time, double* result);
void pin_leakage_test(FOVI fovi, double force_v, FOVI_VRNG v_range, FOVI_IRNG i_range, int delay_time, double* result);

















void measure_BG_TC(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_BG_1P2(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_IBIAS_500N(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_DAC_GAIN(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_OSC_FREQ(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_LDO_LP_VREF(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_LDO_LP_BG_TC(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_RAMP(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_RAMP_VCM(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_CLSD_OS_L(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_CLSD_OS_H(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_V_SENSE_CAL(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_I_SENSE_OS_CAL_L(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_I_SENSE_OS_CAL_H(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_ISNS_CMRR_H(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_ISNS_CMRR_L(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_ISNS_GAIN_ADJ(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_TVP_SNS_OS(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_BOOST_DAC_BUF(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_BOOST_ZCD(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_BOOST_ISNS(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_BOOST_IPKL(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_BOOST_IPFM(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_CLSD_PWM(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_PV_OFFSET(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_TSNS_DGE_H(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_TSNS_DGE_L(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_TSNS_DGE(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_TSNS_OFFSET_H(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_TSNS_OFFSET_L(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_I_SENSE_CAL_H(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);
void measure_I_SENSE_CAL_L(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results);