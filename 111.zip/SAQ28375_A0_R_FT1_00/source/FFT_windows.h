﻿#define M_PI       3.14159265358979323846
#pragma once

enum Wind_Type
{
	blackman,
	blackman_harris,
	blackman_nuttall,
	flat_top,
	hann,
	hamm,
	nuttall,
	rectangle,
};

enum FFT_RET_TYPE
{
	RMS_VALUE,
	VPEAK,
};

void wind_blackman(double *window, int len);
void wind_blackman_harris(double *window, int len);
void wind_blackman_nuttall(double *window, int len);
void wind_flat_top(double *window, int len);
void wind_hann(double *window, int len);
void wind_hamm(double *window, int len);
void wind_nuttall(double *window, int len);
void wind_rectangle(double *window, int len);

void Window_process(double *data_pre, double *data_post, int len, Wind_Type wind);





void FFT_execute(double* data_input, double* data_output, int samples, FFT_RET_TYPE type = RMS_VALUE);

double Aweighting_Vcoef(double frequency);

void Aweighting(double* data_pre, double* data_post, int samples, double Tsample);

double Noise_with_Aweighting(double* data_input, int samples, double Tsample);

double THDN_with_Aweighting(double* data_input, int samples, double Tsample, double fundamental_freq, int fundamental_point_num);