/*****************************************************************************
*                                                                            *
*       Source title:   Test_Method.h                                        *
*                       (Universal functions for all SC test projects)       *
*         Written by:   SC TE                                                *
*        Description:			                                             *
*                                                                            *
*   Revision History:                                                        *
*                                                                            *
*     mm/dd/yy  r.rr  - Original coding.                                     *
*                                                                            *
*****************************************************************************/

/*
 REVISION BLOCK:
 -Rev. -- Date --------------------------------------------------
   00   08/24/18  Initial.						Alan Luo
   01   09/04/18  Reset ERROR_RES to 9999		Alan Luo
				  Remove fpvi current ramp 1ms capload at start for EOS damage risk 
   02   10/31/18  Fix "Enable log" alarm issue  Alan
				  Change "fovi_cap.Set" from RELAY_SENSE_ON to RELAY_ON
 ----------------------------------------------------------------
*/

#pragma once
#include "stdafx.h"

#define MAX_SAMPLES 2000
#define ERROR_RES	9999
#define START_DELAY	0

class Test_Method {
public:
	Test_Method() {}
	~Test_Method() {}

	FOVI_VRNG get_fovi_v_range(double v){
		if(v < 0)
			v = -v;
		if(v <= 1)
			return FOVI_1V;
		else if(v <= 5)
			return FOVI_5V;
		else if(v <= 10)
			return FOVI_10V;
		else if(v <= 20)
			return FOVI_20V;
		else if(v <= 50)
			return FOVI_50V;
		else 
			return FOVI_5V;
	}

	FOVI_IRNG get_fovi_i_range(double i){
		if(i < 0)
			i = -i;
		if(i <= 1e-6)
			return FOVI_1UA;
		else if(i <= 10e-6)
			return FOVI_10UA;
		else if(i <= 100e-6)
			return FOVI_100UA;
		else if(i <= 1e-3)
			return FOVI_1MA;
		else if(i <= 10e-3)
			return FOVI_10MA;
		else if(i <= 100e-3)
			return FOVI_100MA;
		else if(i <= 1)
			return FOVI_1A;
		else 
			return FOVI_1MA;
	}

	// Use fovi, ramp one pin volatege, capture another pin voltage, trig stop
	// The ramp pin i_range fixed 1A, v_range auto changed by force value
	// Good for UVLO, threshold, power good measurement
	// fovi_cap no current loading
	BOOL ramp(FOVI fovi_ramp, FOVI fovi_cap, double start_point, double stop_point, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result){
		if(interval < 10)	return FALSE;
		if(step == 0)	return FALSE;

		FOVI_VRNG v_range = FOVI_5V;
		FOVI_IRNG i_range = FOVI_1A;
		if(fabs(start_point) < fabs(stop_point))
			v_range = get_fovi_v_range(stop_point);
		else
			v_range = get_fovi_v_range(start_point);

		int samples;
		double pat[MAX_SAMPLES];
		samples = int (fabs((stop_point - start_point) / step));
		if((samples <= 1) || (samples > MAX_SAMPLES)){
			samples = MAX_SAMPLES;
		}

		fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

		STSAWGCreateRampData(&pat[0], samples, 1, start_point, stop_point);
		fovi_ramp.AwgClear();
		fovi_ramp.AwgLoader("awg", FV, v_range, i_range, pat, samples);
		fovi_ramp.AwgSelect("awg", 0, samples-1, samples-1, interval);
		fovi_cap.SetMeasVTrig(trig_level, trig_mode);

		fovi_ramp.Set(FV, start_point, v_range, i_range, RELAY_ON);

		fovi_ramp.MeasureVI(samples, interval, MEAS_AWG);
		fovi_cap.MeasureVI(samples, interval, MEAS_AWG);

		STSEnableAWG(&fovi_ramp, &fovi_cap);
		STSEnableMeas(&fovi_ramp, &fovi_cap);
		STSAWGRunTriggerStop(&fovi_cap, &fovi_ramp, &fovi_cap);

		int Trig_Point[SITE_NUM];
		SERIAL {
			Trig_Point[SITE] = (int) fovi_cap.GetMeasResult(SITE, TRIG_RESULT);
			if(((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < samples - 2)){
				//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
				result[SITE] = fovi_ramp.GetMeasResult(SITE,MVRET,Trig_Point[SITE]-1);
			} else {
				result[SITE] = ERROR_RES;
			}
		}

		return TRUE;
	}


	
	BOOL ramp(FPVI10 fpvi_ramp, FOVI fovi_cap, FPVI10_VRNG v_range, FPVI10_IRNG i_range, double start_point, double stop_point, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result){
		if (interval < 10)	return FALSE;
		if (step == 0)	return FALSE;

		int samples;
		double pat[MAX_SAMPLES];
		samples = int(fabs((stop_point - start_point) / step));
		if ((samples <= 1) || (samples > MAX_SAMPLES)){
			samples = MAX_SAMPLES;
		}

		fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

		STSAWGCreateRampData(&pat[0], samples, 1, start_point, stop_point);
		fpvi_ramp.AwgClear();
		fpvi_ramp.AwgLoader("awg", FI, v_range, i_range, pat, samples);
		fpvi_ramp.AwgSelect("awg", 0, samples - 1, samples - 1, interval);
		fovi_cap.SetMeasVTrig(trig_level, trig_mode);

		fpvi_ramp.Set(FI, start_point, v_range, i_range, RELAY_ON);
		delay_ms(2);
		if (!START_DELAY)
			delay_ms(START_DELAY);
		pat[samples - 1] = 0;

		fpvi_ramp.MeasureVI(samples, interval, MEAS_AWG);
		fovi_cap.MeasureVI(samples, interval, MEAS_AWG);
		STSEnableAWG(&fpvi_ramp, &fovi_cap);
		STSEnableMeas(&fpvi_ramp, &fovi_cap);
		STSAWGRunTriggerStop(&fovi_cap, &fpvi_ramp, &fovi_cap);

		fpvi_ramp.Set(FI, 0, v_range, i_range, RELAY_ON);

		fpvi_ramp.AwgClear();
		int Trig_Point[SITE_NUM];

		SERIAL{
			//BEGIN_SINGLE_SITE(SITE)
			Trig_Point[SITE] = ((int)fovi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT))-1;
			if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < samples - 2)){
				result[SITE] = -1000 * pat[Trig_Point[SITE]-1];
			}
			else {
				result[SITE] = ERROR_RES;
			}
		}
		//////////////////////////////////////////////
		///////////////////////////////////////////////
		return TRUE;
    }
    BOOL ramp_v(FPVI10 fpvi_ramp, FOVI fovi_cap, FPVI10_VRNG v_range, FPVI10_IRNG i_range, double start_point, double stop_point, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result)
    {
        if (interval < 10)	return FALSE;
        if (step == 0)	return FALSE;

        int samples;
        double pat[MAX_SAMPLES];
        samples = int(fabs((stop_point - start_point) / step));
        if ((samples <= 1) || (samples > MAX_SAMPLES))
        {
            samples = MAX_SAMPLES;
        }

        fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

        STSAWGCreateRampData(&pat[0], samples, 1, start_point, stop_point);
        fpvi_ramp.AwgClear();
        fpvi_ramp.AwgLoader("awg", FV, v_range, i_range, pat, samples);
        fpvi_ramp.AwgSelect("awg", 0, samples - 1, samples - 1, interval);
        fovi_cap.SetMeasVTrig(trig_level, trig_mode);

        fpvi_ramp.Set(FV, start_point, v_range, i_range, RELAY_ON);
        delay_ms(1);
        if (!START_DELAY)
            delay_ms(START_DELAY);
        pat[samples - 1] = 0;

        fpvi_ramp.MeasureVI(samples, interval, MEAS_AWG);
        fovi_cap.MeasureVI(samples, interval, MEAS_AWG);
        STSEnableAWG(&fpvi_ramp, &fovi_cap);
        STSEnableMeas(&fpvi_ramp, &fovi_cap);
        STSAWGRunTriggerStop(&fovi_cap, &fpvi_ramp, &fovi_cap);

        fpvi_ramp.Set(FV, 0, v_range, i_range, RELAY_ON);

        fpvi_ramp.AwgClear();
        int Trig_Point[SITE_NUM];

        SERIAL{
            //BEGIN_SINGLE_SITE(SITE)
            Trig_Point[SITE] = ((int)fovi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT)) - 1;
            if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < samples - 2))
            {
                //result[SITE] = -1000 * pat[Trig_Point[SITE] - 1];
                result[SITE] = fpvi_ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
            }
            else
            {
                result[SITE] = ERROR_RES;
            }
        }
            //////////////////////////////////////////////
            ///////////////////////////////////////////////
        return TRUE;
    }
	// Use fovi, ramp one pin volatege, capture same pin current, trig stop
	// Can set fovi_ramp v_range and i_range 
	// Good for UVLO
	BOOL ramp(FOVI fovi_ramp, FOVI_VRNG v_range, FOVI_IRNG i_range, double start_point, double stop_point, double step, int interval, double trig_level, TRIG_MODE trig_mode, double *result){
		if(interval < 10)	return FALSE;
		if(step == 0)	return FALSE;

		int samples;
		double pat[MAX_SAMPLES];
		samples = int (fabs((stop_point - start_point) / step));
		if((samples <= 1) || (samples > MAX_SAMPLES)){
			samples = MAX_SAMPLES;
		}

		STSAWGCreateRampData(&pat[0], samples, 1, start_point, stop_point);
		fovi_ramp.AwgClear();
		fovi_ramp.AwgLoader("awg", FV, v_range, i_range, pat, samples);
		fovi_ramp.AwgSelect("awg", 0, samples-1, samples-1, interval);
		fovi_ramp.Set(FV, start_point, v_range, i_range, RELAY_ON, 1);
		if(!START_DELAY)
			delay_ms(START_DELAY);

		fovi_ramp.SetMeasITrig(trig_level, trig_mode);
		fovi_ramp.MeasureVI(samples, interval, MEAS_AWG);
		STSEnableAWG(&fovi_ramp);
		STSEnableMeas(&fovi_ramp);
		STSAWGRunTriggerStop(&fovi_ramp, &fovi_ramp);

		int Trig_Point[SITE_NUM];
		SERIAL {
			Trig_Point[SITE] = (int) fovi_ramp.GetMeasResult(SITE, MIRET, TRIG_RESULT);
			if(((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < samples - 2)){
				//result[SITE] = start_point + (Trig_Point[SITE] - 2) * step;
				result[SITE] = fovi_ramp.GetMeasResult(SITE,MVRET,Trig_Point[SITE]-2);
			} else {
				result[SITE] = ERROR_RES;
			}
		}

		return TRUE;
	}



	// For debug only, to watch burn high voltage PIN I/V by AccoTest softview
	// The burn time is fixed to 20ms
	BOOL watch_burn(FOVI fovi_res, FOVI_VRNG v_range, FOVI_IRNG i_range, double burn_v, bool enable=false){
		if(!enable)	 return FALSE;

		int interval = 10; // us
		int samples;
		double pat[MAX_SAMPLES];
		samples = MAX_SAMPLES;
			
		for(int i=0; i<samples; ++i) pat[i]=burn_v;
		fovi_res.AwgClear();
		fovi_res.AwgLoader("awg", FV, v_range, i_range, pat, samples);
		fovi_res.AwgSelect("awg", 0, samples-1, samples-1, interval);

		fovi_res.Set(FV, burn_v, v_range, i_range, RELAY_ON);
		fovi_res.MeasureVI(samples, interval, MEAS_AWG);

		STSEnableAWG(&fovi_res);
		STSEnableMeas(&fovi_res);
		STSAWGRun();

		fovi_res.Set(FV, 0, v_range, i_range, RELAY_ON);

		return TRUE;
	}

	int where_at(double* cap, int samples, TRIG_MODE trig_mode, double trig_level, bool reverse=false){
		int start = 0;
		int stop = 0;

		if(reverse){
			start = samples;
			stop = 0;
		} else {
			start = 0;
			stop = samples;
		}

		for(int i = start; i < stop; ++i){
			if((trig_mode == TRIG_RISING) && (fabs(cap[i]) > trig_level))
				return i - 1;
			if((trig_mode == TRIG_FALLING) && (fabs(cap[i]) < trig_level))
				return i - 1;
		}

		return -1;
	}

	// use for open short test classify to different bin
	// pgs must include "OS_SHORT" "OS_SOME_OPEN" "OS_ALL_OPEN" "OS_LEAK"
	BOOL OS_Classify(short funcindex, string pin_str_array[], unsigned int OS_NUM, string leak_str_array[], unsigned int LEAK_NUM, double os_result[][SITE_NUM], double leak_result[][SITE_NUM], vector<string>& vec_exclude)
	{
		if (OS_NUM == 0) return FALSE;
		int open_count[SITE_NUM]= { 0 };
		int SHORT_FLAG[SITE_NUM] = { 0 };
		int SOME_OPEN_FLAG[SITE_NUM] = { 0 };
		int ALL_OPEN_FLAG[SITE_NUM] = { 0 };
		int LEAK_FLAG[SITE_NUM] = { 0 };
		CParam *OS_Param;

		for(unsigned int os_count = 0; os_count < OS_NUM; ++os_count){
			if(find(vec_exclude.begin(), vec_exclude.end(), pin_str_array[os_count]) != vec_exclude.end()) continue;
			OS_Param = StsGetParam(funcindex,pin_str_array[os_count].c_str());
			double spec_l = OS_Param->GetMinLimit();
			double spec_h = OS_Param->GetMaxLimit();
			SERIAL {
				if(spec_l > 0){
					if(os_result[os_count][SITE] < spec_l) 
						SHORT_FLAG[SITE] = 1;
					if(SHORT_FLAG[SITE] != 1 && (os_result[os_count][SITE] > spec_h)) 
						open_count[SITE]++;
				}
				if(spec_h < 0){
					if(os_result[os_count][SITE] >spec_h) 
						SHORT_FLAG[SITE] = 1;
					if(SHORT_FLAG[SITE] != 1 && (os_result[os_count][SITE] < spec_l)) 
						open_count[SITE]++;
				}
			}
		}

		for(unsigned int leak_count = 0; leak_count < LEAK_NUM; ++leak_count){
			OS_Param = StsGetParam(funcindex,leak_str_array[leak_count].c_str());
			double spec_l = OS_Param->GetMinLimit();
			double spec_h = OS_Param->GetMaxLimit();
			SERIAL {
				if (leak_result[leak_count][SITE] < spec_l || leak_result[leak_count][SITE] > spec_h) 
					LEAK_FLAG[SITE] = 1;
			}
		}

		SERIAL    //judge some open or all open 
		{
			if(SHORT_FLAG[SITE] != 1 && open_count[SITE] == (OS_NUM-vec_exclude.size()))   
				ALL_OPEN_FLAG[SITE] = 1;      
			else if(SHORT_FLAG[SITE] != 1 && open_count[SITE] < (int)(OS_NUM-vec_exclude.size()) && open_count[SITE] > 0)   
				SOME_OPEN_FLAG[SITE] = 1; 
		}

		SERIAL	StsGetParam(funcindex,"OS_SHORT")->SetTestResult(SITE, 0, SHORT_FLAG[SITE]);
		SERIAL	StsGetParam(funcindex,"OS_SOME_OPEN")->SetTestResult(SITE, 0, SOME_OPEN_FLAG[SITE]);
		SERIAL	StsGetParam(funcindex,"OS_ALL_OPEN")->SetTestResult(SITE, 0, ALL_OPEN_FLAG[SITE]);
		if(LEAK_NUM != 0) 
			SERIAL	StsGetParam(funcindex,"OS_LEAK")->SetTestResult(SITE, 0, LEAK_FLAG[SITE]);

		return TRUE;
	}
	BOOL REOS_Classify(short funcindex, string pin_str_array[], unsigned int OS_NUM, string leak_str_array[], unsigned int LEAK_NUM, double os_result[][SITE_NUM], double leak_result[][SITE_NUM], vector<string>& vec_exclude)
	{
		if (OS_NUM == 0) return FALSE;
		int open_count[SITE_NUM] = { 0 };
		int SHORT_FLAG[SITE_NUM] = { 0 };
		int SOME_OPEN_FLAG[SITE_NUM] = { 0 };
		int ALL_OPEN_FLAG[SITE_NUM] = { 0 };
		int LEAK_FLAG[SITE_NUM] = { 0 };
		CParam* OS_Param;

		for (unsigned int os_count = 0; os_count < OS_NUM; ++os_count) {
			if (find(vec_exclude.begin(), vec_exclude.end(), pin_str_array[os_count]) != vec_exclude.end()) continue;
			OS_Param = StsGetParam(funcindex, pin_str_array[os_count].c_str());
			double spec_l = OS_Param->GetMinLimit();
			double spec_h = OS_Param->GetMaxLimit();
			SERIAL{
				if (spec_l > 0) {
					if (os_result[os_count][SITE] < spec_l)
						SHORT_FLAG[SITE] = 1;
					if (SHORT_FLAG[SITE] != 1 && (os_result[os_count][SITE] > spec_h))
						open_count[SITE]++;
				}
				if (spec_h < 0) {
					if (os_result[os_count][SITE] > spec_h)
						SHORT_FLAG[SITE] = 1;
					if (SHORT_FLAG[SITE] != 1 && (os_result[os_count][SITE] < spec_l))
						open_count[SITE]++;
				}
			}
		}

		for (unsigned int leak_count = 0; leak_count < LEAK_NUM; ++leak_count) {
			OS_Param = StsGetParam(funcindex, leak_str_array[leak_count].c_str());
			double spec_l = OS_Param->GetMinLimit();
			double spec_h = OS_Param->GetMaxLimit();
			SERIAL{
				if (leak_result[leak_count][SITE] < spec_l || leak_result[leak_count][SITE] > spec_h)
					LEAK_FLAG[SITE] = 1;
			}
		}

		SERIAL    //judge some open or all open 
		{
			if (SHORT_FLAG[SITE] != 1 && open_count[SITE] == (OS_NUM - vec_exclude.size()))
				ALL_OPEN_FLAG[SITE] = 1;
			else if (SHORT_FLAG[SITE] != 1 && open_count[SITE] < (int)(OS_NUM - vec_exclude.size()) && open_count[SITE] > 0)
				SOME_OPEN_FLAG[SITE] = 1;
		}

		SERIAL	StsGetParam(funcindex, "REOS_SHORT")->SetTestResult(SITE, 0, SHORT_FLAG[SITE]);
		SERIAL	StsGetParam(funcindex, "REOS_SOME_OPEN")->SetTestResult(SITE, 0, SOME_OPEN_FLAG[SITE]);
		SERIAL	StsGetParam(funcindex, "REOS_ALL_OPEN")->SetTestResult(SITE, 0, ALL_OPEN_FLAG[SITE]);
		if (LEAK_NUM != 0)
			SERIAL	StsGetParam(funcindex, "REOS_LEAK")->SetTestResult(SITE, 0, LEAK_FLAG[SITE]);

		return TRUE;
	}
	
	
	BOOL ramp_2FPVI(FPVI10 fpvi_ramp, FPVI10 fpvi_ramp1, FPVI10_VRNG v_range, FPVI10_IRNG i_range, FOVI fovi_cap, double start_point, double stop_point, double step, int interval, double trig_level, TRIG_MODE trig_mode, double* result) {
		if (interval < 10)	return FALSE;
		if (step == 0)	return FALSE;

		GPFPVI10 fpvi_ramp_gp("ALL_FPVI", fpvi_ramp, fpvi_ramp1);

		int samples;
		double pat[MAX_SAMPLES];
		samples = int(fabs((stop_point - start_point) / step + 1));
		if ((samples <= 1) || (samples > MAX_SAMPLES)) {
			samples = MAX_SAMPLES;
		}

		fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

		fpvi_ramp.AwgClear();
		fpvi_ramp1.AwgClear();
		STSAWGCreateRampData(&pat[0], samples, 1, start_point / 2, stop_point / 2);
		fpvi_ramp.AwgLoader("awg", FI, v_range, i_range, pat, samples);
		fpvi_ramp1.AwgLoader("awg", FI, v_range, i_range, pat, samples);
		fpvi_ramp.AwgSelect("awg", 0, samples - 1, samples - 1, interval);
		fpvi_ramp1.AwgSelect("awg", 0, samples - 1, samples - 1, interval);
		fovi_cap.SetMeasVTrig(trig_level, trig_mode);

		fpvi_ramp_gp.Set(FI, start_point, v_range, i_range, RELAY_ON);
		if (!START_DELAY)
			delay_ms(START_DELAY);

		fpvi_ramp.MeasureVI(samples, interval, MEAS_AWG);
		fpvi_ramp1.MeasureVI(samples, interval, MEAS_AWG);
		fovi_cap.MeasureVI(samples, interval, MEAS_AWG);

		STSEnableAWG(&fpvi_ramp, &fpvi_ramp1);
		STSEnableMeas(&fovi_cap, &fpvi_ramp, &fpvi_ramp1);
		STSAWGRunTriggerStop(&fovi_cap, &fovi_cap, &fpvi_ramp, &fpvi_ramp1);

		int Trig_Point[SITE_NUM];
		SERIAL{
			Trig_Point[SITE] = (int)fovi_cap.GetMeasResult(SITE, TRIG_RESULT);
			if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < samples - 2)) {
				//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
				result[SITE] = fpvi_ramp.GetMeasResult(SITE, MIRET, Trig_Point[SITE] - 1) + fpvi_ramp1.GetMeasResult(SITE, MIRET, Trig_Point[SITE] - 1);
			}
 else
  result[SITE] = ERROR_RES;
		}

		fpvi_ramp_gp.Set(FI, 0, v_range, i_range, RELAY_ON);

		return TRUE;
	}
	BOOL ramp_2FPVI_ZCD(FPVI10 fpvi_ramp, FPVI10 fpvi_Meas, FPVI10_VRNG v_range, FPVI10_IRNG i_range, FOVI fovi_cap, double start_point, double stop_point, double step, int interval, double trig_level, TRIG_MODE trig_mode, double* result) {
		if (interval < 10)	return FALSE;
		if (step == 0)	return FALSE;

		int samples;
		double pat[MAX_SAMPLES];
		samples = int(fabs((stop_point - start_point) / step + 1));
		if ((samples <= 1) || (samples > MAX_SAMPLES)) {
			samples = MAX_SAMPLES;
		}

		fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);
		fpvi_Meas.Set(FI, 0, FPVI10_2V, FPVI10_10UA, RELAY_ON);

		fpvi_ramp.AwgClear();
		STSAWGCreateRampData(&pat[0], samples, 1, start_point, stop_point);
		fpvi_ramp.AwgLoader("awg", FI, v_range, i_range, pat, samples);
		fpvi_ramp.AwgSelect("awg", 0, samples - 1, samples - 1, interval);
		fovi_cap.SetMeasVTrig(trig_level, trig_mode);

		fpvi_ramp.Set(FI, start_point, v_range, i_range, RELAY_ON);
		if (!START_DELAY)
			delay_ms(START_DELAY);

		fpvi_ramp.MeasureVI(samples, interval, MEAS_AWG);
		fpvi_Meas.MeasureVI(samples, interval, MEAS_AWG);
		fovi_cap.MeasureVI(samples, interval, MEAS_AWG);

		STSEnableAWG(&fpvi_ramp);
		STSEnableMeas(&fovi_cap, &fpvi_ramp, &fpvi_Meas);
		STSAWGRunTriggerStop(&fovi_cap, &fovi_cap, &fpvi_ramp, &fpvi_Meas);

		int Trig_Point[SITE_NUM];
		SERIAL{
			Trig_Point[SITE] = (int)fovi_cap.GetMeasResult(SITE, TRIG_RESULT);
			if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < samples - 2)) {
				//result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
				result[SITE] = fpvi_Meas.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
			}
 else
  result[SITE] = ERROR_RES;
		}

		fpvi_ramp.Set(FI, 0, v_range, i_range, RELAY_ON);

		return TRUE;
	}
	// Use fpvi, ramp one pin current, capture another pin voltage, trig stop
	// Good for current limit measurement
	BOOL ramp(FPVI10 fpvi_ramp, FPVI10_VRNG v_range, FPVI10_IRNG i_range, FOVI fovi_cap, double start_point, double stop_point, double step, int interval, double trig_level, TRIG_MODE trig_mode, double* result, bool RET_TYPE = 0) {
		if (interval < 10)	return FALSE;
		if (step == 0)	return FALSE;

		int samples;
		double pat[MAX_SAMPLES];
		samples = int(fabs((stop_point - start_point) / step + 1));
		if ((samples <= 1) || (samples > MAX_SAMPLES)) {
			samples = MAX_SAMPLES;
		}

		fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

		fpvi_ramp.AwgClear();
		STSAWGCreateRampData(&pat[0], samples, 1, start_point, stop_point);
		fpvi_ramp.AwgLoader("awg", FI, v_range, i_range, pat, samples);
		fpvi_ramp.AwgSelect("awg", 0, samples - 1, samples - 1, interval);
		fovi_cap.SetMeasVTrig(trig_level, trig_mode);

		fpvi_ramp.Set(FI, start_point, v_range, i_range, RELAY_ON);
		if (!START_DELAY)
			delay_ms(START_DELAY);

		fpvi_ramp.MeasureVI(samples, interval, MEAS_AWG);
		fovi_cap.MeasureVI(samples, interval, MEAS_AWG);

		STSEnableAWG(&fpvi_ramp);
		STSEnableMeas(&fovi_cap, &fpvi_ramp);
		STSAWGRunTriggerStop(&fovi_cap, &fovi_cap, &fpvi_ramp);

		int Trig_Point[SITE_NUM];
		SERIAL{
			Trig_Point[SITE] = (int)fovi_cap.GetMeasResult(SITE, TRIG_RESULT);
			if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < samples - 2)) {
				result[SITE] = fpvi_ramp.GetMeasResult(SITE, MIRET, Trig_Point[SITE] - 1);
				if (RET_TYPE) result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			}
 else
  result[SITE] = ERROR_RES;
		}

		fpvi_ramp.Set(FI, 0, v_range, i_range, RELAY_ON);
		//fpvi_ramp.Set(FI, 0, v_range, i_range, RELAY_OFF);

		return TRUE;
	}

	BOOL ramp_v(FOVI fovi_ramp, FOVI_VRNG v_range, FOVI_IRNG i_range, FOVI fovi_cap, double start_point, double stop_point, double step, int interval, double trig_level, TRIG_MODE trig_mode, double* result, bool RET_TYPE = 0)
	{

		if (interval < 10)	return FALSE;
		if (step == 0)	return FALSE;

		int samples;
		double pat[MAX_SAMPLES];
		samples = int(fabs((stop_point - start_point) / step) + 1);
		if ((samples <= 1) || (samples > MAX_SAMPLES)) {
			samples = MAX_SAMPLES;
		}

		fovi_cap.Set(FI, 0, FOVI_10V, FOVI_10UA, RELAY_ON);

		STSAWGCreateRampData(&pat[0], samples, 1, start_point, stop_point);
		fovi_ramp.AwgClear();
		fovi_ramp.AwgLoader("awg", FV, v_range, i_range, pat, samples);
		fovi_ramp.AwgSelect("awg", 0, samples - 1, samples - 1, interval);
		fovi_cap.SetMeasVTrig(trig_level, trig_mode);

		fovi_ramp.Set(FV, start_point, v_range, i_range, RELAY_ON, 1);

		if (!START_DELAY)
			delay_ms(START_DELAY);

		fovi_ramp.MeasureVI(samples, interval, MEAS_AWG);
		fovi_cap.MeasureVI(samples, interval, MEAS_AWG);

		STSEnableAWG(&fovi_ramp, &fovi_cap);
		STSEnableMeas(&fovi_ramp, &fovi_cap);
		STSAWGRunTriggerStop(&fovi_cap, &fovi_ramp, &fovi_cap);

		int Trig_Point[SITE_NUM];
		SERIAL
		{
			Trig_Point[SITE] = (int)fovi_cap.GetMeasResult(SITE, TRIG_RESULT);
			if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < samples - 2))
			{
				result[SITE] = fovi_ramp.GetMeasResult(SITE,MVRET,Trig_Point[SITE]-1);
				if (RET_TYPE) result[SITE] = start_point + (Trig_Point[SITE] - 1) * step;
			}
			else
			{
				result[SITE] = ERROR_RES;
			}

		}

		return TRUE;
	
	
	}
};