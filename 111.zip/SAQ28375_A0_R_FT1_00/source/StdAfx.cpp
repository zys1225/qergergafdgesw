// stdafx.cpp : source file that includes just the standard includes
//	DUT.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


FOVI FOVI0(0, "FOVI0");
FOVI FOVI1(1, "FOVI1");
FOVI FOVI2(2, "FOVI2");
FOVI FOVI3(3, "FOVI3");
FOVI FOVI4(4, "FOVI4");
FOVI FOVI5(5, "FOVI5");
FOVI FOVI6(6, "FOVI6");
FOVI FOVI7(7, "FOVI7");
FOVI FOVI32(8, "FOVI32");
FOVI FOVI33(9, "FOVI33");
FOVI FOVI34(10, "FOVI34");
FOVI FOVI35(11, "FOVI35");

FOVI VBAT(0, "VBAT");//0                      
FOVI PVDD(1, "PVDD");//1						
FOVI DVDD(2, "DVDD");//2			
FOVI VLDO(3, "VLDO");//3			

FOVI SCL(4, "SCL");//4		
FOVI INTN(4, "INTN");//4		
FOVI BUF(4, "BUF");//4		
FOVI SCL_INTN(4, "SCL_INTN");//4		


FOVI SDA(5, "SDA");//5          
FOVI DATAI(5, "DATAI");//5          
FOVI SDA_DATAI(5, "SDA_DATAI");//5          


FOVI BCK(6, "BCK");//6			

FOVI WCK(7, "WCK");//7			
FOVI AD(7, "AD");//7			
FOVI WCK_AD(7, "WCK_AD");//7			

FOVI PWR_UP(8, "PWR_UP");//32	
FOVI SW(9, "SW");//33					
FOVI VOP(10, "VOP");//34               
FOVI VON(11, "VON");//35		


GPFOVI  ALL_FOVI("ALL_FOVI", FOVI0, FOVI1, FOVI2, FOVI3, FOVI4, FOVI5, FOVI6, FOVI7, FOVI32, FOVI33, FOVI34, FOVI35);
GPFOVI  ALL_PIN("ALL_PIN", FOVI0, FOVI1, FOVI2, FOVI3, FOVI4, FOVI5, FOVI6, FOVI7, FOVI33, FOVI34, FOVI35);

////////////////////////// FPVI /////////////////////////
FPVI10 FPVI0(0, "FPVI0");
FPVI10 FPVI1(1, "FPVI1");

GPFPVI10 ALL_FPVI("ALL_FPVI", FPVI0, FPVI1);
////////DIO resource////////////////
DIO_PLUS dio_plus;

DIO_PLUS_I2CSITE_DEF_REG(i2c_site0, 0, 0, 1); // name : i2c_stie0, No : 0, scl : 0, sda : 1
DIO_PLUS_I2CSITE_DEF_REG(i2c_site1, 1, 4, 5); // name : i2c_stie1, No : 1, scl : 2, sda : 3
DIO_PLUS_I2CSITE_DEF_REG(i2c_site2, 2, 8, 9); // name : i2c_stie1, No : 2, scl : 4, sda : 5
DIO_PLUS_I2CSITE_DEF_REG(i2c_site3, 3, 12, 13); // name : i2c_stie1, No : 3, scl : 6, sda : 7

DIO_PLUS::I2CSite* pI2CSites[] = { &i2c_site0, &i2c_site1, &i2c_site2, &i2c_site3 }; // I2C

////////QTMU resource////////////////
QTMU_PLUS qtmu0(0);

////////QVM resource////////////////
QVM qvm0(0);

////////CBIT resource////////////////
CBIT128 cbit;
