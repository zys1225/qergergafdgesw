/*****************************************************************************
*                                                                            *
*       Source title:   SPEC.h                                               *
*                       (Help treg execute feature in AccoTest)              *
*         Modify by:   SC TE                                                 *
*        Description:  Thx All Contributors                                  *
*                                                                            *
*   Revision History:                                                        *
*                                                                            *
*     mm/dd/yy  r.rr  - Original coding.                                     *
*                                                                            *
*****************************************************************************/

/*
 REVISION BLOCK:
 -Rev. -- Date --------------------------------------------------
  00		ready for upgraded treg for execute
  01		update get_step_str for not full steps delog need.		Alan	2018/12/18
 ----------------------------------------------------------------
*/

#pragma once
#include <map>
#include <vector>
#include <string>
#include <Windows.h>
#include <iostream>
using namespace std;


#define	BAD_POS 0xFFFFFFFF 
#define	SUCCESS 0

class CMapMemFile
{
private:
	HANDLE hFile;
	HANDLE hMapFile;
	DWORD size_low,size_high;	// no bigger than 4G
	DWORD error_code;
	const char* fileName;

	BOOL bMapOK;

	void* pvFile;
	unsigned char* p;

	//for load_data_to_db
	DWORD tab_ent_cnt;	// include '/t' and '/n'
	DWORD columns_of_one_row;
	DWORD column_no;
	DWORD row_no;

public:
	string error_str;

public:
	CMapMemFile(void){
		hFile = NULL;
		hMapFile = NULL;
		pvFile = NULL;
		p = NULL;
		size_low = 0;
		size_high = 0;
		error_code = 0;
		bMapOK = FALSE;
		tab_ent_cnt = 0;
		columns_of_one_row = 0;
		column_no = 0;
		row_no = 0;
	}

	// create for read only
	BOOL create(const char* file){
		fileName = file;
		hFile = CreateFile(
			fileName,
			GENERIC_READ,
			FILE_SHARE_READ,
			NULL,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			0);

		if (hFile == INVALID_HANDLE_VALUE) {
			bMapOK = false;
			error_code = GetLastError();
			error_str = "Fail CreateFile, hFile == INVALID_HANDLE_VALUE";
			//cout<<"create map file failure:"<<error_code<<endl;
			return FALSE;
		}else{
			size_low = GetFileSize(hFile, &size_high);
			if (size_low == BAD_POS && (error_code = GetLastError()) != SUCCESS) {
				bMapOK = false;
				CloseHandle(hFile);            
				error_str = "Fail GetFileSize";
				//cout<<"error :"<<error_code<<endl;
				return FALSE;
			}
			else{
				bMapOK = true;
				//cout<<"Create map file suceess"<<endl;
			}
		}

		hMapFile = CreateFileMapping(
			hFile,
			NULL,
			PAGE_READONLY,
			size_high,
			size_low,
			NULL
			);
		if(size_high > 0){
			bMapOK = FALSE;
			error_str = "Can't create file bigger than 4G.";
			//cout << "Can't create file bigger than 4G." << endl;
			CloseHandle(hFile);
			return FALSE;
		}
		if(hMapFile == INVALID_HANDLE_VALUE){
			bMapOK = FALSE;
			error_str = "Fail CreateFileMapping, hMapFile == INVALID_HANDLE_VALUE";
			//cout << "Can't create file mapping. Error: " << GetLastError() << endl;
			CloseHandle(hFile);
			return FALSE;
		} else {
			bMapOK = TRUE;
			//cout << "Create file mapping suceess!" << endl;
		}

		if(bMapOK){
			pvFile = MapViewOfFile(
				hMapFile,
				FILE_MAP_READ,
				0,
				0,
				0);
			if ((error_code = GetLastError()) != SUCCESS) {
				bMapOK = false;
				error_str = "Fail MapViewOfFile";
				//cout<<"error :"<<error_code<<endl;
				return FALSE;
			}
			p = (unsigned char*)pvFile;
		}

		return TRUE;
	}

	// over load create function for new file
	BOOL create(const char* file, DWORD size){
		fileName = file;
		hFile = CreateFile(
			fileName,
			GENERIC_READ | GENERIC_WRITE,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL,
			//CREATE_NEW,
			OPEN_ALWAYS,	// if no exist, create new
			FILE_ATTRIBUTE_NORMAL,
			0);

		if (hFile == INVALID_HANDLE_VALUE) {
			bMapOK = false;
			error_code = GetLastError();
			error_str = "Fail CreateFile, hFile == INVALID_HANDLE_VALUE";
			//cout << "create file fail: " << error_code << endl;
			//cout << "file name is: " << fileName << endl;
			return FALSE;
		}

		size_high = 0;
		size_low = size;
		hMapFile = CreateFileMapping(
			hFile,
			NULL,
			PAGE_READWRITE,
			size_high,
			size_low,
			NULL
			);
		if(size_high > 0){
			bMapOK = FALSE;
			error_str = "Can't create file bigger than 4G.";
			//cout << "Can't create file bigger than 4G." << endl;
			CloseHandle(hFile);
			return FALSE;
		}
		if(hMapFile == INVALID_HANDLE_VALUE){
			bMapOK = FALSE;
			error_str = "Fail CreateFileMapping, hMapFile == INVALID_HANDLE_VALUE";
			//cout << "can't create file mapping. Error: " << GetLastError() << endl;
			CloseHandle(hFile);
			return FALSE;
		} else {
			bMapOK = TRUE;
			//cout << "create file mapping suceess!" << endl;
		}

		if(bMapOK){
			pvFile = MapViewOfFile(
				hMapFile,
				FILE_MAP_READ | FILE_MAP_WRITE,
				0,
				0,
				0);
			if ((error_code = GetLastError()) != SUCCESS) {
				bMapOK = false;
				error_str = "Fail MapViewOfFile";
				return FALSE;
			}
			p = (unsigned char*)pvFile;
		}

		return TRUE;
	}

	DWORD find_a_word(string name, const unsigned char separator, const DWORD size){
		if(!bMapOK){
			cout << "Map fail, When find index name in file head." << endl;
			return BAD_POS;
		}

		if(p == NULL){
			cout << "Map point error, When find index name in file head." << endl;
			return BAD_POS;
		}

		if(size >= size_low){
			cout << "Size is over map file range, When find index name in file head." << endl;
			return BAD_POS;
		}

		if(name == ""){
			cout << "Name can't be blank, When find index name in file head." << endl;
		}

		// ignore '!' before name
		if(name[0] == '!'){
			string temp(name, 1, name.length() - 1);
			name = temp;
		}
		
		DWORD column = 0;
		DWORD first_pos_of_word = 0;
		//size_t size_name = 0; 

		DWORD start =0 ;
		if((p[0] < 33) || (p[0] > 126)){
			start = 3;
			first_pos_of_word = 3;
		}

		for(DWORD i = start; i < size; ++i){
			if((p[i] == separator) || (p[i] == '\n') || (p[i] == 13)){	// the last column, it maybe return key
				column++;
				//size_name = strlen(name);

				if((i - first_pos_of_word) == name.length()){	// compare only if the length is same
					for(DWORD j = 0; j < name.length(); ++j){
						if(p[first_pos_of_word + j] != name[j])
							break;
						else{
							if(j == name.length() -1)
								return column;
						}
					}
				}

				first_pos_of_word = i + 1;
			}
		}	

	
		//stringstream ss(p);
		//while(getline(ss,word,'\t')){
		//	if(word.compare(name) == 0){
		//		column++;
		//		return column;
		//	}
		//	else
		//		column++;
		//}

		return BAD_POS;
	}

	void CloseMapFile(void){
		if(pvFile != NULL){
			UnmapViewOfFile(pvFile);
			pvFile = NULL;
			p = NULL;
		}
		if(hMapFile != NULL){
			CloseHandle(hMapFile);
			hMapFile = NULL;
		}
		if(hFile != NULL){
			CloseHandle(hFile);
			hFile = NULL;
		}
	}

	BOOL IsMapOK(){
		return bMapOK;
	}

	DWORD GetSize(){
		return size_low;
	}

	unsigned char * GetPtr(){
		return p;
	}

	BOOL write(const char * words, DWORD len){
		if(!IsMapOK()){
			cout << "Map fail, When write words." << endl;
			return FALSE;
		}
		if(len > size_low){
			cout << "The size of the words is over range of mapped file, write fail." << endl;
			return FALSE;
		}

		try{
		for(DWORD i=0; i<len; ++i){
			p[i]=words[i];
		}
		}
		catch(exception & e){
			cout << "write file fail: " << endl;
			cout << e.what() << endl;
			return FALSE;
		}

		return TRUE;
	}

	////////// add by developer //////////////
	BOOL CsvReader(map<DWORD, map<DWORD, string>> &res_map);



public:
	~CMapMemFile(void){}
};

class LOG_TRIM{
public:
	vector<string> step_vec;
	string str_pre;
	string str_pre_bit;
	string str_post;
	string str_post_bit;
	string str_target;
	string str_guessed;
	string str_updated;

public:
	LOG_TRIM(void){}
	~LOG_TRIM(void){}
};


class SPEC{
private:
	unsigned int site_num;
	string path;

	vector<string> param_vec;
	map<string, string> func_map;	//map<func, param>
	map<string, string> lolim_map;	//map<param, lolim>
	map<string, string> hilim_map;	//map<param, hilim>
	map<string, string> unit_map;	//map<param, unit>

	map<string, LOG_TRIM> trim_map;	//map<func, trim_param>

public:
	bool init(string file);
	bool print(void);

	double get_low_limit(string param);
	double get_high_limit(string param);
	string get_unit(string param);

	string get_step_str(LPCTSTR funclabel, unsigned int step);
	string get_pre_str(LPCTSTR funclabel);
	string get_pre_bit_str(LPCTSTR funclabel);
	string get_post_str(LPCTSTR funclabel);
	string get_post_bit_str(LPCTSTR funclabel);
	string get_target_str(LPCTSTR funclabel);
	string get_guessed_str(LPCTSTR funclabel);
	string get_updated_str(LPCTSTR funclabel);

	string int2str(DWORD n);

public:
	SPEC(void){}
	~SPEC(void){}
};

class CFunc{
public:
	int bstr2int(string str);

public:
	CFunc(void){}
	~CFunc(void){}
};



class CBIT{
public:
	//map<param_name, param_bit_addr, absolute_bit_addr>
	//as map<"CSNS2_slope", map<0, 8>>
	//as map<"CSNS2_slope", map<1, 10>>
	//as map<"CSNS2_slope", map<2, 9>>
	//as map<"CSNS2_slope", map<3, 11>>
	map<string, map<int, int>> addr_map;

	//map<param_name, target> 
	//for option bit, target is "SEL"
	map<string, string> target_map;
	//map<param_name, default step>
	map<string, int> default_map;

	//map<param_name, map<step, value>>
	map<string, map<int, double>> step_map;
	map<string, map<int, double>> step_pcnt_map;


	string path;

public:
	bool init(string file);
	bool print(void);

public:
	CBIT(void){}
	~CBIT(void){}
};



class Csreg{
public:
	//map<param_name, map<type, value>>
	//as map<site, map<"CSNS2_slope", map<"work", value>>>
	//as map<site, map<"CSNS2_slope", map<"prog", value>>>
	//as map<site, map<"CSNS2_slope", map<"read", value>>>
	//as map<site, map<"CSNS2_slope", map<"save", value>>>
	//as map<site, map<"CSNS2_slope", map<"start", value>>>
	map<int, map<string, map<string, int>>> store_map;




public:
	Csreg(void);
	~Csreg(void);
};