#include "stdafx.h"
#include "stdarg.h"
//#include "list.h"
#include "Pin_Channel_define.h"
#include <map>
#include "part.h"
#include "lsi.h"
#include "sub.h"
#include "awg.h"
#include "cfg.h"
#include "part.h"
#include "cmd.h"

extern int wafer_id[SITE_NUM];
extern int x_coords[SITE_NUM];
extern int y_coords[SITE_NUM];
extern int xy_index[SITE_NUM];
extern float SPI_CLK;

extern bool burn_flag[SITE_NUM];
extern bool use_amux;

extern double PN_Posbk_Output;
extern int PN_Tracker_Num;
//extern bool PN_ASF;
extern bool PN_QST_Before_Prebk;
extern int PN_INIT_Timer;
//extern int PN_INIT_Counter;
extern double PN_Prebk_Output;
extern double PN_QST_Output;
extern double PN_QUC_Output;
extern double PN_QVR_Output;
extern double PN_QVR_Output_Target;
extern double PN_QT1_Output_Target;
extern double PN_QT2_Output_Target;
extern double PN_QT3_Output_Target;
extern double PN_QCO_Output;
extern double PN_QT1_Output;
extern double PN_QT2_Output;
extern double PN_QT3_Output;
extern bool PN_LOW_UV;
extern bool PN_SSD;
extern bool PN_EVS;
extern bool PN_SEC_Available;
extern bool PN_VCI_Available;
extern bool PN_AMUX_Available;
extern bool PN_Posbk_Available;
extern int PN_ECC;

extern bool use_lsi_dfi;
extern double lsi_dfi_gain;

extern AWG_FUNC awg;
extern int rdata[SITE_NUM];
extern bool  QC;
extern bool FLOW_CP;
extern bool DO_ABSN;
extern PinNode PINarray[PIN_Count];
extern int trimed_cp0[SITE_NUM];
extern int trimed_ft0[SITE_NUM];
extern int trimed_ftb0[SITE_NUM];
extern int trimed_cp1[SITE_NUM];
extern int trimed_ft1[SITE_NUM];
extern int trimed_ftb1[SITE_NUM];
extern int trimed_cp2[SITE_NUM];
extern int trimed_ft2[SITE_NUM];
extern int trimed_ftb2[SITE_NUM];
extern int burn_lock0[SITE_NUM];
extern int ecc_pass0[SITE_NUM];
extern int ecc_read0[SITE_NUM];
extern int ecc_calc0[SITE_NUM];
extern int burn_lock1[SITE_NUM];
extern int ecc_pass1[SITE_NUM];
extern int ecc_read1[SITE_NUM];
extern int ecc_calc1[SITE_NUM];
extern int burn_lock2[SITE_NUM];
extern int ecc_pass2[SITE_NUM];
extern int ecc_read2[SITE_NUM];
extern int ecc_calc2[SITE_NUM];
extern int crc_opt;
extern int crc_read[SITE_NUM];
extern int crc_pass[SITE_NUM];
extern double max_temp;

extern bool HW_QFN;

int REG_FS_R0[FBANK_NUM][SITE_NUM];
int REG_FS_R1[FBANK_NUM][SITE_NUM];
int REG_FS_R2[FBANK_NUM][SITE_NUM];
int REG_FS_W1[FBANK_NUM][SITE_NUM];
int REG_R0[BANK_NUM][SITE_NUM];
int REG_R1[BANK_NUM][SITE_NUM];
int REG_R2[BANK_NUM][SITE_NUM];
int REG_W1[BANK_NUM][SITE_NUM];

int REG_USR[64][SITE_NUM];

double PREBK_HSRDSON[SITE_NUM]={0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001};
double PREBK_LSRDSON[SITE_NUM]={0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001};
double POSBK_HSRDSON[SITE_NUM]={0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001};
double POSBK_LSRDSON[SITE_NUM]={0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001,0.0000000001};

extern double PREBK_LSRDSON_OS;
extern double PREBK_HSRDSON_OS;
extern double POSBK_LSRDSON_OS;
extern double POSBK_HSRDSON_OS;

double prebk_bv_ls[SITE_NUM];
double posbk_bv_ls[SITE_NUM];

double qt1_nleak[SITE_NUM];
double qt2_nleak[SITE_NUM];
double qt3_nleak[SITE_NUM];
double batsns1_nleak[SITE_NUM];
double batsns2_nleak[SITE_NUM];

double qt1_nleak_pre[SITE_NUM];
double qt2_nleak_pre[SITE_NUM];
double qt3_nleak_pre[SITE_NUM];

double qt1_nleak_pos[SITE_NUM];
double qt2_nleak_pos[SITE_NUM];
double qt3_nleak_pos[SITE_NUM];

double clk_chk[SITE_NUM];
double clk_chkl[SITE_NUM];
double clk_chkh[SITE_NUM];

extern double qt1_qvr_err[SITE_NUM];
extern double qt2_qvr_err[SITE_NUM];
extern double qt3_qvr_err[SITE_NUM];

extern bool DEBUG;

LARGE_INTEGER nFreq;
LARGE_INTEGER t1;
LARGE_INTEGER t2;
double dt;
double temp_temp;
time_t now;
tm *ltm;

double average(double a[], int n)
{
    // Find sum of array element
	if (n > 0)
	{
		int sum = 0;
		for (int i = 0; i < n; i++)
			sum += a[i];
		return (double)sum / n;
	}
	else
		return 0;
}

double calc_step(double start, double stop, int count)
{
	if(count<2){count=2;}
	double step = (stop-start)/(count-1);
	return step;
}

void dtime(int print)//Return time in us
{
	QueryPerformanceFrequency(&nFreq);
	QueryPerformanceCounter(&t2);
	dt = (t2.QuadPart - t1.QuadPart) / (double)nFreq.QuadPart*1e6;
	if (print){
		char chInput[128];
		sprintf(chInput, "duration :%.1f us\n", dt);
		OutputDebugString(chInput);
	}
	QueryPerformanceCounter(&t1);
}

double max_value(double value_1, double value_2)
{
	if (value_1 > value_2)
		return value_1;
	else
		return value_2;
}

void Copy_Array(double Dest[], double Source[])    
{
	SERIAL Dest[SITE] = Source[SITE];
}

void Copy_Array(int Dest[], int Source[])    
{
	SERIAL Dest[SITE] = Source[SITE];
}

void Unit_Convert(double Dest[], double Source[], double unit)
{
	SERIAL Dest[SITE] = Source[SITE] * unit;
}

void Get_Result(FPVIe resource, double *results, MeasRet retType, int sampleNumber)
{
	SERIAL results[SITE] = resource.GetMeasResult(SITE, retType, sampleNumber); 
}

void Get_Result(ACM resource, double *results, MeasRet retType, int sampleNumber)
{
	SERIAL results[SITE] = resource.GetMeasResult(SITE, retType, sampleNumber); 
}

void Get_Result(ACM200 resource, double *results, MeasRet retType, int sampleNumber)
{
	SERIAL results[SITE] = resource.GetMeasResult(SITE, retType, sampleNumber); 
}

void Get_Result(FOVIe resource, double *results, MeasRet retType, int sampleNumber)
{
	SERIAL results[SITE] = resource.GetMeasResult(SITE, retType, sampleNumber); 
}

void Get_Result(FXVIe_PLUS resource, double *results, MeasRet retType, int sampleNumber)
{
	SERIAL results[SITE] = resource.GetMeasResult(SITE, retType, sampleNumber); 
}

void Get_Result(const char* lpszPinName, double *results, int sampleNumber)
{
	SERIAL results[SITE] = dcm.GetPPMUMeasResult(lpszPinName, SITE, AVERAGE_RESULT);
}

//void Ms_LogData(CParam *Parm, double results[])
//{
//	SERIAL Parm->SetTestResult(SITE, 0, results[SITE]);
//}

void Ms_LogData(CParam *Parm, double *results)
{
	SERIAL Parm->SetTestResult(SITE, 0, results[SITE]);
}

void Ms_LogData(CParam *Parm, double results)
{
	SERIAL Parm->SetTestResult(SITE, 0, results);
}

void Ms_LogData(short funcindex, const char* Parm, double *results)
{
	CParam *ParmP = StsGetParam(funcindex, Parm);
	if(ParmP!=NULL) { Ms_LogData(ParmP, results); }
	else
	{
		string info = Parm;
		info = info + " not found";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void Ms_LogData(short funcindex, const char* Parm, double results)
{
	CParam *ParmP = StsGetParam(funcindex, Parm);
	if(ParmP!=NULL) { Ms_LogData(ParmP, results); }
	else
	{
		string info = Parm;
		info = info + " not found";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void Ms_LogData(short funcindex, string Parm, double *results)
{
	Ms_LogData(funcindex, Parm.c_str(), results);
}

void Ms_LogData(short funcindex, string Parm, double results)
{
	Ms_LogData(funcindex, Parm.c_str(), results);
}

//void Ms_LogData(CParam *Parm, int results[])
//{
//	SERIAL Parm->SetTestResult(SITE, 0, results[SITE]);
//}

void Ms_LogData(CParam *Parm, int *results)
{
	SERIAL Parm->SetTestResult(SITE, 0, results[SITE]);
}

void Ms_LogData(CParam *Parm, int results)
{
	SERIAL Parm->SetTestResult(SITE, 0, results);
}

void Ms_LogData(short funcindex, const char* Parm, int *results)
{
	CParam *ParmP = StsGetParam(funcindex, Parm);
	if(ParmP!=NULL) { Ms_LogData(ParmP, results); }
	else
	{
		string info = Parm;
		info = info + " not found";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void Ms_LogData(short funcindex, const char* Parm, int results)
{
	CParam *ParmP = StsGetParam(funcindex, Parm);
	if(ParmP!=NULL) { Ms_LogData(ParmP, results); }
	else
	{
		string info = Parm;
		info = info + " not found";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void Ms_LogData(short funcindex, string Parm, int *results)
{
	Ms_LogData(funcindex, Parm.c_str(), results);
}

void Ms_LogData(short funcindex, string Parm, int results)
{
	Ms_LogData(funcindex, Parm.c_str(), results);
}

//void Ms_LogData(CParam *Parm, bool results[])
//{
//	SERIAL Parm->SetTestResult(SITE, 0, results[SITE]);
//}

void Ms_LogData(CParam *Parm, bool *results)
{
	SERIAL Parm->SetTestResult(SITE, 0, results[SITE]);
}

void Ms_LogData(CParam *Parm, bool results)
{
	SERIAL Parm->SetTestResult(SITE, 0, results);
}

void Ms_LogData(short funcindex, const char* Parm, bool *results)
{
	CParam *ParmP = StsGetParam(funcindex, Parm);
	if(ParmP!=NULL) { Ms_LogData(ParmP, results); }
	else
	{
		string info = Parm;
		info = info + " not found";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void Ms_LogData(short funcindex, const char* Parm, bool results)
{
	CParam *ParmP = StsGetParam(funcindex, Parm);
	if(ParmP!=NULL) { Ms_LogData(ParmP, results); }
	else
	{
		string info = Parm;
		info = info + " not found";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void Ms_LogData(short funcindex, string Parm, bool *results)
{
	Ms_LogData(funcindex, Parm.c_str(), results);
}

void Ms_LogData(short funcindex, string Parm, bool results)
{
	Ms_LogData(funcindex, Parm.c_str(), results);
}

void Test_Contact_L(ACM200 &resource, double lowRes[])
{
	double highRes[SITE_NUM];
	//double lowRes[SITE_NUM];
	double result[SITE_NUM];
	resource.ContactCheck(ACM200_LOW_SIDE); 
	SERIAL result[SITE] = resource.GetContactCheckResult(SITE, highRes[SITE], lowRes[SITE]);  
}

void Test_Contact_L(FXVIe_PLUS &resource, double lowRes[])
{
	double highRes[SITE_NUM];
	//double lowRes[SITE_NUM];
	double result[SITE_NUM];
	resource.ContactCheck(FXVIe_PLUS_LOW_SIDE); 
	SERIAL result[SITE] = resource.GetContactCheckResult(SITE, highRes[SITE], lowRes[SITE]);  
}

void Test_Contact_L(FPVIe &resource, double result[])
{
	double highRes[SITE_NUM];
	double lowRes[SITE_NUM];
	//double result[SITE_NUM];
	resource.ContactCheck(FPVIe_LOW_SIDE); 
	SERIAL result[SITE] = resource.GetContactCheckResult(SITE);  
}

void Test_Contact(ACM200 &resource, double highRes[])
{
	//double highRes[SITE_NUM];
	double lowRes[SITE_NUM];
	double result[SITE_NUM];
	resource.ContactCheck(ACM200_HIGH_SIDE); 
	SERIAL result[SITE] = resource.GetContactCheckResult(SITE, highRes[SITE], lowRes[SITE]);  
}

void Test_Contact(FXVIe_PLUS &resource, double highRes[])
{
	//double highRes[SITE_NUM];
	double lowRes[SITE_NUM];
	double result[SITE_NUM];
	resource.ContactCheck(FXVIe_PLUS_HIGH_SIDE); 
	SERIAL result[SITE] = resource.GetContactCheckResult(SITE, highRes[SITE], lowRes[SITE]);  
}

void Test_Contact(FPVIe &resource, double result[])
{
	double highRes[SITE_NUM];
	double lowRes[SITE_NUM];
	//double result[SITE_NUM];
	resource.ContactCheck(FPVIe_HIGH_SIDE); 
	SERIAL result[SITE] = resource.GetContactCheckResult(SITE);  
}

void Test_Leak(FPVIe &resource, double value, double result[], FPVIe_VRNG vRange, FPVIe_IRNG iRangeNor, FPVIe_IRNG iRangeMeas, double ms)
{
	resource.Set(FV, 0, vRange, iRangeNor, FPVIe_RELAY_ON);
	resource.Set(FV, value, vRange, iRangeNor, FPVIe_RELAY_ON);
	delay_ms(ms);
	resource.Set(FV, value, vRange, iRangeMeas, FPVIe_RELAY_ON);
	delay_ms(ms);
	resource.MeasureVI(10, 10);
	Get_Result(resource, result, MIRET);
	resource.Set(FV, 0, vRange, iRangeNor, FPVIe_RELAY_ON);
	delay_ms(1);
	resource.Set(FV, 0, vRange, iRangeNor, FPVIe_RELAY_OFF);

	if (0)
	{
		double Vres[SITE_NUM];
		Get_Result(resource, Vres, MVRET);
		bool clamp = false;
		SERIAL if (Vres[SITE] < (value*0.9)){ clamp = true; }

		if (clamp)
		{
			string info = "current clamp !";
			MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
		}
	}
}

void Test_Leak(ACM200 &resource, double value, double result[], ACM200_VRNG vRange, ACM200_IRNG iRangeNor, ACM200_IRNG iRangeMeas, double ms)
{
	resource.Set(FV, 0, vRange, iRangeNor, ACM200_RELAY_ON);
	resource.Set(FV, value, vRange, iRangeNor, ACM200_RELAY_ON);
	delay_ms(ms);
	resource.Set(FV, value, vRange, iRangeMeas, ACM200_RELAY_ON);
	delay_ms(ms);
	resource.MeasureVI(10, 10);
	Get_Result(resource, result, MIRET);
	resource.Set(FV, 0, vRange, iRangeNor, ACM200_RELAY_ON);
	delay_ms(2);
	resource.Set(FV, 0, vRange, iRangeNor, ACM200_RELAY_OFF);

	if (0)
	{
		double Vres[SITE_NUM];
		Get_Result(resource, Vres, MVRET);
		bool clamp = false;
		SERIAL if (Vres[SITE] < (value*0.9)){ clamp = true; }

		if (clamp)
		{
			string info = "current clamp !";
			MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
		}
	}
}

void Test_Leak(FXVIe_PLUS &resource, double value, double result[], FXVIe_PLUS_VRNG vRange, FXVIe_PLUS_IRNG iRangeNor, FXVIe_PLUS_IRNG iRangeMeas, double ms)
{
	resource.Set(FV, 0, vRange, iRangeNor, FXVIe_PLUS_RELAY_ON);
	resource.Set(FV, value, vRange, iRangeNor, FXVIe_PLUS_RELAY_ON);
	delay_ms(ms);
	resource.Set(FV, value, vRange, iRangeMeas, FXVIe_PLUS_RELAY_ON);
	delay_ms(ms);
	resource.MeasureVI(10, 10);
	Get_Result(resource, result, MIRET);
	resource.Set(FV, 0, vRange, iRangeNor, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	resource.Set(FV, 0, vRange, iRangeNor, FXVIe_PLUS_RELAY_OFF);

	if (0)
	{
		double Vres[SITE_NUM];
		Get_Result(resource, Vres, MVRET);
		bool clamp = false;
		SERIAL if (Vres[SITE] < (value*0.9)){ clamp = true; }

		if (clamp)
		{
			string info = "current clamp !";
			MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
		}
	}
}

void Test_Leakf(FXVIe_PLUS &resource, double value, double result[], FXVIe_PLUS_VRNG vRange, FXVIe_PLUS_IRNG iRangeNor, FXVIe_PLUS_IRNG iRangeMeas, double ms)
{
	resource.Set(FV, 0, vRange, iRangeNor, FXVIe_PLUS_RELAY_FANOUT_ON);
	resource.Set(FV, value, vRange, iRangeNor, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(ms);
	resource.Set(FV, value, vRange, iRangeMeas, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(ms);
	resource.MeasureVI(10, 10);
	Get_Result(resource, result, MIRET);
	resource.Set(FV, 0, vRange, iRangeNor, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(1);
	resource.Set(FV, 0, vRange, iRangeNor, FXVIe_PLUS_RELAY_OFF);

	if (0)
	{
		double Vres[SITE_NUM];
		Get_Result(resource, Vres, MVRET);
		bool clamp = false;
		SERIAL if (Vres[SITE] < (value*0.9)){ clamp = true; }

		if (clamp)
		{
			string info = "current clamp !";
			MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
		}
	}
}

void Test_Leakf(const char* ch, double value, double result[], PPMUIRange iRangeNor, PPMUIRange iRangeMeas, double ms)
{
	int status = dcm.SetPPMU(ch, DCM_PPMU_FVMI, 0, iRangeNor);
	dcm.SetPPMU(ch, DCM_PPMU_FVMI, value, iRangeNor);
	delay_ms(ms);
	dcm.SetPPMU(ch, DCM_PPMU_FVMI, value, iRangeMeas);
	delay_ms(ms);
	dcm.PPMUMeasure(ch, 10, 10);
	Get_Result(ch, result);
	dcm.SetPPMU(ch, DCM_PPMU_FVMI, 0, iRangeNor);

	if (0)
	{
		double Vres[SITE_NUM];
		Get_Result(ch, Vres, MVRET);
		bool clamp = false;
		SERIAL if (Vres[SITE] < (value * 0.9)) { clamp = true; }

		if (clamp)
		{
			string info = "current clamp !";
			MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
		}
	}
	if (status!=0)
	{
		string info = "dcm error !";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void Test_Diode(FPVIe &resource, double value, double result[])
{
	resource.Set(FI, value, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);
	delay_us(100);
	resource.MeasureVI(10, 10);
	Get_Result(resource, result, MVRET);
	resource.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);
	resource.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
}

void Test_Diode(ACM200 &resource, double value, double result[])
{
	resource.Set(FI, value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	delay_us(100);
	resource.MeasureVI(10, 10);
	Get_Result(resource, result, MVRET);
	resource.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	resource.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
}

void Test_Diode(FXVIe_PLUS &resource, double value, double result[])
{
	resource.Set(FI, value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_us(100);
	resource.MeasureVI(10, 10);
	Get_Result(resource, result, MVRET);
	resource.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	resource.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
}

void Test_Diodef(FXVIe_PLUS &resource, double value, double result[])
{
	resource.Set(FI, value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_us(100);
	resource.MeasureVI(10, 10);
	Get_Result(resource, result, MVRET);
	resource.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	resource.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
}

void Test_Diode(const char* ch, double value, double result[])
{
	int status = dcm.SetPPMU(ch, DCM_PPMU_FIMV, value, DCM_PPMUIRANGE_2MA);
	delay_us(100);
	dcm.PPMUMeasure(ch, 10, 10);
	Get_Result(ch, result);
	dcm.SetPPMU(ch, DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
	if (status != 0)
	{
		string info = "dcm error !";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

//==============================================================
void AWG_volt_Debug(FOVIe force_res, FOVIe cap_res, FOVIe_VRNG v_range, FOVIe_IRNG i_range, double start_point, double stop_point, double step, int interval, double trig_level, TRIG_MODE trig_mode, double ret_result[SITE_NUM])
{
	const int MAX_samp = 2000;
	double volt_Ramp_pat[MAX_samp];
	int samples;
	samples = int(fabs((stop_point - start_point) / (step - 1E-12))) + 1;
	if ((samples <= 1) || (samples > MAX_samp))
		samples = MAX_samp;

	force_res.Set(FV, start_point, v_range, i_range, FOVIe_RELAY_ON);
	cap_res.Set(FI, 0, FOVIe_10V, FOVIe_100UA, FOVIe_RELAY_ON);

	STSAWGCreateRampData(&volt_Ramp_pat[0], samples, 1, start_point, stop_point);
	force_res.AwgClear();
	cap_res.AwgClear();
	force_res.AwgLoader("volt_Ramp_awg", FV, v_range, i_range, volt_Ramp_pat, samples);
	force_res.AwgSelect("volt_Ramp_awg", 0, samples - 1, samples - 1, interval);
	cap_res.SetMeasVTrig(trig_level, trig_mode);

	force_res.MeasureVI(samples, interval);
	cap_res.MeasureVI(samples, interval);

	STSEnableAWG(&force_res/*,&cap_res*/);
	STSEnableMeas(&force_res, &cap_res);
	if (1)
		StsAWGRun();
	else
		STSAWGRunTriggerStop(&cap_res, &force_res, &cap_res);
	//======================//
	force_res.Set(FV, stop_point, v_range, i_range, FOVIe_RELAY_ON, 0.5);

	double cap_awg_res[SITE_NUM][MAX_samp];
	if (1)
		SERIAL cap_res.BlockRead(SITE, 0, samples, cap_awg_res[SITE], MVRET);
	int Trig_Point[SITE_NUM];
	//SERIAL ret_result[SITE] = 1e12;
	//SERIAL
	//{
	//	Trig_Point[SITE] = (int)cap_res.GetMeasResult(SITE, TRIG_RESULT);

	//	if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < samples - 2))
	//	{
	//		ret_result[SITE] = volt_Ramp_pat[Trig_Point[SITE] - 2];
	//		//ret_result[SITE] = force_res.GetMeasResult(SITE,MVRET,Trig_Point[SITE]-1);
	//	}
	//	else
	//		ret_result[SITE] = 9999;
	//}
}

void all_resource_off(void)
{
	fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_OFF);
	fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi3.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	acm0.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm1.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm3.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm4.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	acm7.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm8.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm10.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
}

void set_vsx(double voltage)
{
	//cbitclose(K123);
	fxvi4.Set(FV, voltage, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	//delay_ms(1);
	if(voltage>20.0)
	{
		string info = "VSX voltage beyond range";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void set_vsx(bool on)
{
	if(! on)
	{
		fxvi4.Set(FV, 0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
		//C_VST_VS1_DisConnect;
	}
}

void set_vsx_hc(double voltage)
{
	//cbitclose(K123);
	fxvi4.Set(FV, voltage, FXVIe_PLUS_20V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_FANOUT_ON);
	//delay_ms(1);
	if (voltage > 20.0)
	{
		string info = "VSX voltage beyond range";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void set_vsx_hc(bool on)
{
	if (!on)
	{
		fxvi4.Set(FV, 0, FXVIe_PLUS_20V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_OFF);
		//C_VST_VS1_DisConnect;
	}
}

void set_vsx_hv(double voltage)
{
	//cbitclose(K123);
	fxvi4.Set(FV, voltage, FXVIe_PLUS_40V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_FANOUT_ON);
	//delay_ms(1);
	if(voltage>40.0)
	{
		string info = "VSX voltage beyond range";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void set_vsx_hv(bool on)
{
	if(! on)
	{
		fxvi4.Set(FV, 0, FXVIe_PLUS_40V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_OFF);
		//C_VST_VS1_DisConnect;
	}
}

void set_vs1(double voltage)
{
	fxvi4.Set(FV, voltage, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if (voltage > 10.0)
	{
		string info = "VS1 voltage beyond range";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void set_vs1(bool on)
{
	if(! on)
	{
		fxvi4.Set(FV, 0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	}
}

void set_vst(double voltage)
{
	//cbitclose(K123);
	fxvi4.Set(FV, voltage, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	//delay_ms(1);
	if (voltage > 10.0)
	{
		string info = "VST voltage beyond range";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

void set_vst(bool on)
{
	if(! on)
	{
		fxvi4.Set(FV, 0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	}
}

void set_fb(double voltage)
{
	//cbitclose(K213);
	A_FB1.Set(FV, voltage, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	//delay_ms(1);
	if (voltage > 10.0)
	{
		string info = "VFB voltage beyond range";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

double set_fb_plus_target(double voltage)
{
	double v = PN_Prebk_Output+voltage;
	set_fb(v);
	return v;
}

void set_fb(bool on)
{
	if(! on)
	{
		A_FB1.Set(FV, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_OFF);
		//C_ACM_FB1_DisConnect;
	}
}

void set_fb_hc(double voltage)
{
	F_FB.Set(FV, voltage, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	if (voltage > 10.0)
	{
		string info = "VFB voltage beyond range";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

double set_fb_plus_target_hc(double voltage)
{
	double v = PN_Prebk_Output+voltage;
	set_fb_hc(v);
	return v;
}

void set_fb_hc(bool on)
{
	if(! on)
	{
		F_FB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_OFF);
		//C_FXVI_FB_DisConnect;
	}
}

void set_qst(double voltage)
{
	A_QST.Set(FV, voltage, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	if (voltage > 10.0)
	{
		string info = "QST voltage beyond range";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

double set_qst_plus_target(double voltage)
{
	double v = PN_QST_Output+voltage;
	if(v<0){v=0;}
	set_qst(v);
	return v;
}

void set_qst(bool on)
{
	if(! on)
	{
		A_QST.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	}
}

void set_quc(double voltage)
{
	A_QUC.Set(FV, voltage, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	if (voltage > 10.0)
	{
		string info = "QUC voltage beyond range";
		MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
	}
}

double set_quc_target(void)
{
	set_quc(PN_QUC_Output);
	return PN_QUC_Output;
}

void set_quc(bool on)
{
	if(! on)
	{
		A_QUC.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	}
}

void set_qco(double voltage)
{
	A_QCO.Set(FV, voltage, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
}

void set_qco(bool on)
{
	if(! on)
	{
		A_QCO.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	}
}

void set_qvr(double voltage)
{
	A_QVR.Set(FV, voltage, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
}

void set_qvr(bool on)
{
	if(! on)
	{
		A_QVR.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	}
}

void set_qt1(double voltage)
{
	F_QT1.Set(FV, voltage, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
}

void set_qt1(bool on)
{
	if(! on)
	{
		F_QT1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	}
}

void set_qt2(double voltage)
{
	F_QT2.Set(FV, voltage, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
}

void set_qt2(bool on)
{
	if(! on)
	{
		F_QT2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	}
}

void set_qt3(double voltage)
{
	F_QT3.Set(FV, voltage, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
}

void set_qt3(bool on)
{
	if(! on)
	{
		F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	}
}

void set_posin(double voltage)
{
	A_POSIN.Set(FV, voltage, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
}

void set_posin(bool on)
{
	if(! on)
	{
		A_POSIN.Set(FV, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_OFF);
	}
}

void set_posfb(double voltage)
{
	A_POSFB.Set(FV, voltage, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
}

double set_posfb_plus_target(double voltage)
{
	double v = PN_Posbk_Output+voltage;
	if(v<0){v=0;}
	set_posfb(v);
	return v;
}

void set_posfb(bool on)
{
	if(! on)
	{
		A_POSFB.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	}
}

void set_stu(double voltage)
{
	A_STU.Set(FV, voltage, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
}

void set_stu(bool on)
{
	if(! on)
	{
		A_STU.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	}
}

void set_vci(double voltage)
{
	A_VCI.Set(FV, voltage, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
}

void set_vci(bool on)
{
	if(! on)
	{
		A_VCI.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	}
}

void set_sec_posfre(VIMode viMode, double setValue, ACM200_VRNG vRange, ACM200_IRNG iRange, ACM200_OUT_RELAY relayStatus, double risingTime)
{
	if(PN_SEC_Available)
	{
		A_SEC.Set(viMode, setValue, vRange, iRange, relayStatus, risingTime);
	}
	else
	{
		A_POSFRE.Set(viMode, setValue, vRange, iRange, relayStatus, risingTime);
	}
}

void setsync_sec_posfre(VIMode viMode, double setValue[], ACM200_VRNG vRange, ACM200_IRNG iRange, ACM200_OUT_RELAY relayStatus, double risingTime)
{
	if(PN_SEC_Available)
	{
		A_SEC.SetSyn(viMode, setValue, SITE_NUM, vRange, iRange, relayStatus, risingTime);
	}
	else
	{
		A_POSFRE.SetSyn(viMode, setValue, SITE_NUM, vRange, iRange, relayStatus, risingTime);
	}
}

void set_burn_voltage(double voltage)
{
	set_sec_posfre(FV, voltage, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON,1);
}

void set_burn_voltage(double voltage[])
{
	setsync_sec_posfre(FV, voltage, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON,1);
}

void set_burn_voltage(bool enable)
{
	if(!enable)
	{
		set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	}
	else
	{
		set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	}
}

void set_ena_pulse(void)
{
	if(0)
	{
		C_FXVI_ENA_Connect;
		F_ENA.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		F_ENA.Set(FV, 3.3, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
		F_ENA.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	}
	else
	{
		C_DCM_ENA_Connect;//dmc7
		dcm.Connect("DCM7");
		dcm.SetPPMU("DCM7", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("DCM7", DCM_PPMU_FVMV, 3.3, DCM_PPMUIRANGE_2MA);
		delay_ms(1);
		dcm.SetPPMU("DCM7", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	}
}

void set_ena_off(void)
{
	if(0)
	{
		F_ENA.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
		C_FXVI_ENA_DisConnect;
	}
	else
	{
		dcm.SetPPMU("DCM7", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
		delay_ms(1);
		dcm.Disconnect("DCM7");
		C_DCM_ENA_DisConnect;
	}
}

void set_wak(bool high)
{
	C_DCM_WAK_Connect;//dcm6
	if(high)
	{
		dcm.Connect("DCM6");
		dcm.SetPPMU("DCM6", DCM_PPMU_FVMV, 3.3, DCM_PPMUIRANGE_2MA);
	}
	else
	{
		dcm.SetPPMU("DCM6", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	}
}

void set_wak_off(void)
{
	dcm.SetPPMU("DCM6", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	delay_ms(1);
	dcm.Disconnect("DCM6");
	C_DCM_WAK_DisConnect;
}

void disconnect_posbk_resource(void)
{
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	A_POSFB.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	C_POSG_GND_DisConnect;
}

void prebk_load_connect(void)
{
	C_PREBK_LOAD1_Connect;
	C_LOAD1_RC_Connect;
	//C_LOAD1_1K_Connect;
	delay_ms(1);
}

void prebk_load_disconnect(void)
{
	C_PREBK_LOAD1_DisConnect;
	//C_LOAD1_RC_DisConnect;
	C_LOAD1_Discharge_Connect;
	delay_ms(3);
	C_LOAD1_Discharge_DisConnect;
}

void posbk_load_connect(void)
{
	C_POSBK_LOAD2_Connect;
	C_LOAD2_RC_Connect;
	//C_LOAD2_1K_Connect;
	delay_ms(1);
}

void posbk_load_disconnect(void)
{
	C_POSBK_LOAD2_DisConnect;
	//C_LOAD2_RC_DisConnect;
	C_LOAD2_Discharge_Connect;
	delay_ms(3);
	C_LOAD2_Discharge_DisConnect;
}

void Poweron_tm(void)
{
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	C_MPS_PU_Connect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	C_QT3_CAP_Connect;

	C_VST_VS1_Connect;
	C_ACM_FB1_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	set_vsx(4.0);
	set_fb(4.0);
	set_quc(4.0);
	delay_ms(2);
}

void Poweroff_tm(void)
{
	set_quc(false);
	set_vsx(0.0);
	delay_ms(2);
	set_quc(0.0);
	delay_ms(1);
	set_qst(false);
	set_vsx(false);
	set_quc(false);
	set_fb(false);
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	C_FB_CAP_DisConnect;
	C_QUC_CAP_DisConnect;
	C_QCO_CAP_DisConnect;
	C_QVR_CAP_DisConnect;
	C_QT1_CAP_DisConnect;
	C_QT2_CAP_DisConnect;
	C_QT3_CAP_DisConnect;
	C_VST_VS1_DisConnect;
	C_ACM_FB1_DisConnect;
	C_QUC_SQUC_DisConnect;
	C_QT1_SQT1_DisConnect;
	C_QT2_SQT2_DisConnect;
	C_MPS_PU_DisConnect;
	delay_ms(2);
}

void Poweron_tm_psrr(void)
{
	LSI_Connect();
	LSI_I2C_Connect();
	delay_ms(1);
	LSI_DC(true);
	PSRR_OutEna(false);
	C_FXVI_PSRR_Connect;
	C_LSI_DUTI_VST_Connect;
	//C_LSI_DUTO_PWRX_Connect;
	PSRR_Connect();
	PSRR_InitSignal();
	delay_ms(2);
	PSRR_OutEna(true);
	PSRR_SetDc(4.0);
	PSRR_SetAcOff();

	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	C_MPS_PU_Connect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	C_QT3_CAP_Connect;

	C_VST_VS1_Connect;
	C_FXVI_FB_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	F_VST.Set(FI, 0.0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//set_vsx(4.0);
	set_fb_hc(4.0);
	set_quc(4.0);
	delay_ms(2);
}

void Poweroff_tm_psrr(void)
{
	set_quc(false);
	//set_vsx(0.0);
	delay_ms(2);
	set_quc(0.0);
	set_qst(false);
	set_vsx(false);
	set_quc(false);
	set_fb_hc(false);
	PSRR_SetDcOff();
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	C_FB_CAP_DisConnect;
	C_QUC_CAP_DisConnect;
	C_QCO_CAP_DisConnect;
	C_QVR_CAP_DisConnect;
	C_QT1_CAP_DisConnect;
	C_QT2_CAP_DisConnect;
	C_QT3_CAP_DisConnect;
	C_VST_VS1_DisConnect;
	C_FXVI_FB_DisConnect;
	C_QUC_SQUC_DisConnect;
	C_QT1_SQT1_DisConnect;
	C_QT2_SQT2_DisConnect;
	C_MPS_PU_DisConnect;
	delay_ms(2);
}

void Poweron_tm_psrr_ldo(void)
{
	LSI_Connect();
	LSI_I2C_Connect();
	delay_ms(1);
	LSI_DC(true);
	PSRR_OutEna(false);
	C_FXVI_PSRR_Connect;
	C_LSI_DUTI_FB_Connect;
	C_LSI_DUTO_PWRX_Connect;
	PSRR_Connect();
	PSRR_InitSignal();
	delay_ms(2);
	PSRR_OutEna(true);
	PSRR_SetDc(0.0);
	PSRR_SetAcOff();

	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	C_MPS_PU_Connect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	C_QT3_CAP_Connect;

	C_VST_VS1_Connect;
	C_ACM_FB1_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	A_FB1.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);//
	delay_ms(2);
	set_vsx(4.0);
	PSRR_SetDc(4.0);
	set_quc(4.0);
	delay_ms(2);
}

void Poweroff_tm_psrr_ldo(void)
{
	set_quc(false);
	set_vsx(0.0);
	delay_ms(2);
	set_quc(0.0);
	set_qst(false);
	set_vsx(false);
	set_quc(false);
	set_fb(false);
	PSRR_SetDcOff();
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	C_FB_CAP_DisConnect;
	C_QUC_CAP_DisConnect;
	C_QCO_CAP_DisConnect;
	C_QVR_CAP_DisConnect;
	C_QT1_CAP_DisConnect;
	C_QT2_CAP_DisConnect;
	C_QT3_CAP_DisConnect;
	C_VST_VS1_DisConnect;
	C_ACM_FB1_DisConnect;
	C_QUC_SQUC_DisConnect;
	C_QT1_SQT1_DisConnect;
	C_QT2_SQT2_DisConnect;
	C_MPS_PU_DisConnect;
	delay_ms(2);
}

void Poweron_tm_hv(void)
{
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	C_MPS_PU_Connect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	C_QT3_CAP_Connect;

	C_VST_VS1_Connect;
	C_FXVI_FB_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	set_vsx_hv(4.0);
	set_fb_hc(4.0);
	set_quc(4.0);
	delay_ms(2);
}

void Poweroff_tm_hv(void)
{
	set_quc(false);
	set_vsx_hv(0.0);
	delay_ms(2);
	set_quc(0.0);
	set_qst(false);
	set_vsx_hv(false);
	set_quc(false);
	set_fb_hc(false);
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	C_FB_CAP_DisConnect;
	C_QUC_CAP_DisConnect;
	C_QCO_CAP_DisConnect;
	C_QVR_CAP_DisConnect;
	C_QT1_CAP_DisConnect;
	C_QT2_CAP_DisConnect;
	C_QT3_CAP_DisConnect;
	C_VST_VS1_DisConnect;
	C_FXVI_FB_DisConnect;
	C_QUC_SQUC_DisConnect;
	C_QT1_SQT1_DisConnect;
	C_QT2_SQT2_DisConnect;
	C_MPS_PU_DisConnect;
	delay_ms(2);
}

void Poweron_tm_hc(void)
{
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	C_MPS_PU_Connect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	C_QT3_CAP_Connect;

	C_VST_VS1_Connect;
	C_FXVI_FB_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	set_vsx(4.0);
	set_fb_hc(4.0);
	set_quc(4.0);
	delay_ms(2);
}

void Poweroff_tm_hc(void)
{
	set_quc(false);
	set_vsx(0.0);
	delay_ms(2);
	set_quc(0.0);
	set_qst(false);
	set_vsx(false);
	set_quc(false);
	set_fb_hc(false);
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	C_FB_CAP_DisConnect;
	C_QUC_CAP_DisConnect;
	C_QCO_CAP_DisConnect;
	C_QVR_CAP_DisConnect;
	C_QT1_CAP_DisConnect;
	C_QT2_CAP_DisConnect;
	C_QT3_CAP_DisConnect;
	C_VST_VS1_DisConnect;
	C_FXVI_FB_DisConnect;
	C_QUC_SQUC_DisConnect;
	C_QT1_SQT1_DisConnect;
	C_QT2_SQT2_DisConnect;
	C_MPS_PU_DisConnect;
	delay_ms(2);
}

void Poweron_slt(void)
{
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	if(PN_Posbk_Available){A_POSFB.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);}



	C_MPS_PU_Connect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	C_QT3_CAP_Connect;

	C_VST_VS1_Connect;
	C_FXVI_FB_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	set_vsx_hv(4.0);
	set_fb_hc(4.5);
	set_quc(4.5);
	delay_ms(2);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	set_vsx_hv(6.5);
	set_fb_hc(5.5);
	set_quc(5.0);
	set_ena_pulse();
	//delay_ms(2);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_FB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//prebk_load_connect();
	//if(PN_Posbk_Available){posbk_load_connect();}
}

void Poweroff_slt(void)
{
	set_vsx_hv(0.0);
	delay_ms(2);
	set_vsx_hv(false);
	prebk_load_disconnect();
	if(PN_Posbk_Available){posbk_load_disconnect();}
	delay_ms(2);
	set_posin(0.0);
	set_fb_hc(0.0);
	set_posfb(0.0);
	set_quc(0.0);
	delay_ms(5);
	set_posin(false);
	set_fb_hc(false);
	set_posfb(false);
	set_quc(false);
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	C_FB_CAP_DisConnect;
	C_QUC_CAP_DisConnect;
	C_QCO_CAP_DisConnect;
	C_QVR_CAP_DisConnect;
	C_QT1_CAP_DisConnect;
	C_QT2_CAP_DisConnect;
	C_QT3_CAP_DisConnect;
	C_VST_VS1_DisConnect;
	C_FXVI_FB_DisConnect;
	C_QUC_SQUC_DisConnect;
	C_QT1_SQT1_DisConnect;
	C_QT2_SQT2_DisConnect;
	C_MPS_PU_DisConnect;
	delay_ms(2);
	A_QST.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	if(PN_Posbk_Available){A_POSFB.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);}
	A_QST.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_QUC.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_QCO.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_QVR.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	F_QT1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	F_QT2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	if(PN_Tracker_Num==3){F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);}
	if(PN_Posbk_Available){A_POSFB.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);}
}

void Poweron_slt2(void)
{
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	C_ACM_STU_Connect;
	A_STU.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	if(PN_Posbk_Available){A_POSFB.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);}

	C_SW_PD_Connect;
	C_MPS_PU_Connect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	C_QT3_CAP_Connect;

	C_VST_VS1_Connect;
	C_FXVI_FB_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	set_vsx_hv(4.0);
	set_fb_hc(4.5);
	set_quc(4.5);
	delay_ms(2);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	set_vsx_hv(6.5);
	set_fb_hc(5.5);
	set_quc(5.0);
	set_ena_pulse();
	//delay_ms(2);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//F_FB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//prebk_load_connect();
	//if(PN_Posbk_Available){posbk_load_connect();}
}

void Poweroff_slt2(void)
{
	set_vsx_hv(0.0);
	delay_ms(2);
	set_vsx_hv(false);
	prebk_load_disconnect();
	if(PN_Posbk_Available){posbk_load_disconnect();}
	delay_ms(2);
	set_posin(0.0);
	set_fb_hc(0.0);
	set_posfb(0.0);
	set_quc(0.0);
	delay_ms(5);
	set_posin(false);
	set_fb_hc(false);
	set_posfb(false);
	//set_quc(false);
	delay_ms(2);
	A_QST.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	if(PN_Posbk_Available){A_POSFB.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);}
	delay_ms(2);
	A_QST.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_QUC.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_QCO.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_QVR.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	F_QT1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	F_QT2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	if(PN_Tracker_Num==3){F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);}
	if(PN_Posbk_Available){A_POSFB.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);}
	A_STU.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	C_SW_PD_DisConnect;
	C_VST_VS1_DisConnect;
	C_FXVI_FB_DisConnect;
	C_QUC_SQUC_DisConnect;
	C_QT1_SQT1_DisConnect;
	C_QT2_SQT2_DisConnect;
	C_MPS_PU_DisConnect;
	C_MPS_PD_DisConnect;
	C_ACM_STU_DisConnect;
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	C_FB_CAP_DisConnect;
	C_QUC_CAP_DisConnect;
	C_QCO_CAP_DisConnect;
	C_QVR_CAP_DisConnect;
	C_QT1_CAP_DisConnect;
	C_QT2_CAP_DisConnect;
	C_QT3_CAP_DisConnect;
}

void Poweron_nor(void)
{
	//C_FXVI_ACM_GND_Connect;
	//C_AGS_BSG_PG_GND_Connect;
	//A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	//A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	//C_VST_CAP_Connect;
	//C_VS1_CAP_Connect;
	//C_QST_CAP_Connect;
	//C_FB_CAP_Connect;
	//C_QUC_CAP_Connect;
	//C_QVR_CAP_Connect;
	//C_QCO_CAP_Connect;
	//C_QT1_CAP_Connect;
	//C_QT2_CAP_Connect;
	//C_QT3_CAP_Connect;

	//C_QUC_SQUC_Connect;
	//C_QT1_SQT1_Connect;
	//C_QT2_SQT2_Connect;

	//C_ACM_SEC_Connect;//K63, external post regulator is not used, then connect this pin to ground.
	////C_ACM_STU_Connect;//K78, pre-boost controller is not used, then connect this pin to ground.
	////C_FXVI_WAK_Connect;//not used, connect to ground.
	//C_VST_VS1_Connect;
	//C_ACM_FB1_Connect;
	//C_MPS_PU_Connect;
	////C_ACM_MPS_Connect;
	//delay_ms(2);
	//A_SEC.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//set_vsx(4.0);
	//set_fb(4.0);
	////A_STU.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	////F_FB.Set(FV, 5.8, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	////F_VST.Set(FV, 8.0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	////F_FB.Set(FV, 5.8, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//set_vsx(8.0);
	//set_fb(5.8);
	////A_MPS.Set(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	////F_WAK.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(2);
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	//C_FXVI_ACM_L_Connect;
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	C_MPS_PU_Connect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	C_QT3_CAP_Connect;

	C_VST_VS1_Connect;
	C_ACM_FB1_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	set_vsx(6.0);
	set_fb(6.0);////need to change do dynamic
	set_posfb(1.25*0.95);////need to change do dynamic
	set_quc(4.9);
	set_qst(5.1);
	//delay_ms(2);
	//set_vsx(6.0);
	//set_fb(5.5);
	//set_quc(5.0);

}

void Poweroff_nor(void)
{
	//F_WAK.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//A_MPS.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	F_VST.Set(FV, 0.0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	F_FB.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	C_MPS_PU_DisConnect;
	delay_ms(2);
	//F_VST.Set(FV, 0.0, FXVIe_PLUS_20V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	//F_FB.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	set_vsx(false);
	set_fb(false);
	//A_MPS.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	//F_WAK.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	//A_STU.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	C_All_Open;
	delay_ms(1);
}

void Poweron_nor_hv(void)
{
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	C_VST_CAP_Connect;
	//C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	//C_QT3_CAP_Connect;

	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;

	C_ACM_SECPOSFRE_Connect;//K63, external post regulator is not used, then connect this pin to ground.
	//C_ACM_STU_Connect;//K78, pre-boost controller is not used, then connect this pin to ground.
	//C_FXVI_WAK_Connect;//not used, connect to ground.
	C_VST_VS1_Connect;
	C_FXVI_FB_Connect;
	C_MPS_PU_Connect;
	//C_ACM_MPS_Connect;
	delay_ms(2);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//A_STU.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	F_FB.Set(FV, 5.8, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_VST.Set(FV, 8.0, FXVIe_PLUS_30V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	//A_MPS.Set(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//F_WAK.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
}

void Poweroff_nor_hv(void)
{
	//F_WAK.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//A_MPS.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	F_VST.Set(FV, 0.0, FXVIe_PLUS_30V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	F_FB.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	C_MPS_PU_DisConnect;
	delay_ms(2);
	F_VST.Set(FV, 0.0, FXVIe_PLUS_30V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	F_FB.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	//A_MPS.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	//F_WAK.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	//A_STU.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	C_All_Open;
	delay_ms(1);
}

void Setup_SleepState(void)
{
	int status[SITE_NUM];
	int sm[SITE_NUM];
	Cmd_En_Stb(false, false);
	Cmd_En_Com(false);
	Cmd_En_Ref(false);
	Cmd_En_Trk1(false);
	Cmd_En_Trk2(false);
	Cmd_En_Trk3(false);
	Cmd_AmuxEn(false);
	Cmd_Dis_WD();
	Cmd_Dis_ERR();
	//CmdReadData(0x27, status);
	//SERIAL sm[SITE] = status[SITE] & 0x07;
}

void Setup_StandbyState(void)
{
	int status[SITE_NUM];
	int sm[SITE_NUM];
	//Cmd_En_Stb(false, false);
	//Cmd_En_Com(false);
	//Cmd_En_Ref(false);
	//Cmd_En_Trk1(false);
	//Cmd_En_Trk2(false);
	//Cmd_En_Trk3(false);
	//Cmd_EnaAmux(false);
	//Cmd_Dis_WD();
	//Cmd_Dis_ERR();
	//CmdReadData(0x27, status);
	//SERIAL sm[SITE] = status[SITE] & 0x07;
}

void Test_Iq(bool first,double Iq_LFmin[],double Iq_LFmax[],double Iq_HF[], double Iq_Slp1[], double Iq_Slp2[], double Iq_Stb1[], double Iq_Stb2[], double Iq_Stb3[], double Iq_FS[], double VswSleep[])
{
	double result[SITE_NUM];
	int reg0[SITE_NUM];
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int reg3[SITE_NUM];
	int reg4[SITE_NUM];
	int reg5[SITE_NUM];
	int reg6[SITE_NUM];
	int reg7[SITE_NUM];
	int reg8[SITE_NUM];
	int reg9[SITE_NUM];
	int reg10[SITE_NUM];
	int reg11[SITE_NUM];
	int reg12[SITE_NUM];
	int reg13[SITE_NUM];
	int reg14[SITE_NUM];
	int reg15[SITE_NUM];

	C_FRE_PD_Connect;//Low Freq
	//C_FRE_PD_DisConnect;//High Freq
	Poweron_tm_hv();
	DUT_SPI_Connect(4.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	set_vsx_hv(6.0);
	set_fb_hc(5.5);
	set_quc(5.0);
	delay_ms(2);
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_ReadState(reg0);//1
	Cmd_Go2_Normal();
	Cmd_ReadState(reg1);//2
	set_vsx_hv(12.0);
	delay_ms(2);
	F_VST.MeasureVI(30,10);
	Get_Result(F_VST, result, MIRET);
	SERIAL Iq_LFmin[SITE] = result[SITE] * 1000.0;//mA
	set_vsx_hv(36.0);
	delay_ms(2);
	F_VST.MeasureVI(30, 10);
	Get_Result(F_VST, result, MIRET);
	SERIAL Iq_LFmax[SITE] = result[SITE] * 1000.0;//mA
	Poweroff_tm_hv();
	C_FRE_PD_DisConnect;

	if (first)
	{
		//C_FRE_PD_Connect;//Low Freq
		C_FRE_PD_DisConnect;//High Freq
		C_FXVI_ENA_Connect;
		Poweron_tm_hv();
		DUT_SPI_Connect(4.0);
		Cmd_Set_Freq();
		Cmd_TestMode(true);
		Cmd_Masksafe();
		set_vsx_hv(6.0);
		set_fb_hc(5.5);
		set_quc(5.0);
		delay_ms(2);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_ReadState(reg2);//1
		Cmd_Go2_Normal();
		Cmd_ReadState(reg3);//2
		set_vsx_hv(12.0);
		delay_ms(2);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_HF[SITE] = result[SITE] * 1000.0;//mA
		//F_VST.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON, 3);
		//delay_ms(2);


		//Sleep current
		Cmd_Bank1(true);
		Cmd_Forceoff(all_off);
		Cmd_Bank0(true);
		Setup_SleepState();
		delay_ms(2);
		Cmd_Go2_Sleep();
		delay_ms(1);
		Cmd_ReadState(reg4);//3
		//wake up timer disable
		Cmd_En_WakeupTimer(false);
		delay_ms(1);
		Cmd_ReadState(reg4);//3
		//F_VST.Set(FV, 6.0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(2);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Slp1[SITE] = result[SITE] * 1000000.0;//uA

		//wake up timer enable
		Cmd_En_WakeupTimer(true);
		delay_ms(2);
		//F_VST.Set(FV, 6.0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(2);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Slp2[SITE] = result[SITE] * 1000000.0;//uA


		//Standby current
		//Setup_StandbyState();
		//wake up timer disable
		Cmd_En_WakeupTimer(false);
		delay_ms(2);
		Cmd_Go2_Wake();
		delay_ms(1);
		Cmd_ReadState(reg5);//5
		delay_ms(1);
		//Cmd_Go2_Normal();
		//delay_ms(1);
		//Cmd_ReadState(reg6);//2
		//delay_ms(1);
		Cmd_Go2_Standby();
		delay_ms(1);
		Cmd_ReadState(reg7);//4?
		delay_ms(1);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Stb1[SITE] = result[SITE] * 1000000.0;//uA

		//wake up timer enable
		set_ena_pulse();
		Cmd_ReadState(reg8);//1
		delay_ms(5);
		Cmd_Dis_ERR_WD();
		delay_ms(1);
		Cmd_Go2_Normal();
		delay_ms(1);
		Cmd_ReadState(reg9);//2
		//Setup_StandbyState();
		Cmd_En_WakeupTimer(true);
		delay_ms(1);
		Cmd_Go2_Standby();
		delay_ms(1);
		Cmd_ReadState(reg10);//4?
		delay_ms(1);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Stb2[SITE] = result[SITE] * 1000000.0;//uA

		set_ena_pulse();
		Cmd_ReadState(reg11);//1
		delay_ms(5);
		Cmd_Dis_ERR_WD();
		delay_ms(1);
		Cmd_Go2_Normal();
		delay_ms(1);
		Cmd_ReadState(reg12);//2
		//Setup_StandbyState();
		delay_ms(1);
		//qst enable
		Cmd_Forceoff(except_qst);
		delay_ms(1);
		Cmd_Go2_Standby();
		delay_ms(1);
		Cmd_ReadState(reg13);//4?
		delay_ms(1);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Stb3[SITE] = result[SITE] * 1000000.0;//uA


		//Failsaft current
		set_ena_pulse();
		Cmd_ReadState(reg14);//1
		delay_ms(4);
		Cmd_Dis_ERR_WD();
		delay_ms(1);
		Cmd_Go2_Normal();
		delay_ms(1);
		Cmd_ReadState(reg15);//2
		//Setup_StandbyState();
		//fail safe state
		set_qst(6.0);//force qst ov to enter fs
		delay_ms(100);
		set_qst(false);
		set_fb(false);
		delay_ms(2);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_FS[SITE] = result[SITE] * 1000000.0;//uA
		set_ena_off();
		Poweroff_tm_hv();
		C_FXVI_ENA_DisConnect;
	}
	dcm.Disconnect("DCM_ALL");
}

void Test_Iq2(bool first,double Iq_LFmin[],double Iq_LFmax[],double Iq_HF[], double Iq_Slp1[], double Iq_Slp2[], double Iq_Stb1[], double Iq_Stb2[], double Iq_Stb3[], double Iq_FS[], double VswSleep[])
{
	double result[SITE_NUM];
	double ifb[SITE_NUM];
	double ivs[SITE_NUM];
	double vsw[SITE_NUM];
	int reg0[SITE_NUM];
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int reg3[SITE_NUM];
	int reg4[SITE_NUM];
	int reg5[SITE_NUM];
	int reg6[SITE_NUM];
	int reg7[SITE_NUM];
	int reg8[SITE_NUM];
	int reg9[SITE_NUM];
	int reg10[SITE_NUM];
	int reg11[SITE_NUM];
	int reg12[SITE_NUM];
	int reg13[SITE_NUM];
	int reg14[SITE_NUM];
	int reg15[SITE_NUM];

	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];
	int data5[SITE_NUM];
	int data6[SITE_NUM];
	int data7[SITE_NUM];

	double Vst = 14.0;
	double Vfb = PN_Prebk_Output+0.2;

	C_FRE_PD_Connect;//Low Freq
	//C_FRE_PD_DisConnect;//High Freq
	set_ena_off();
	set_wak(false);
	Poweron_slt2();
	set_fb_plus_target_hc(0.2);
	//prebk_load_connect();
	//if(PN_Posbk_Available){posbk_load_connect();}
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Forceoff(except_prebk_quc);
	delay_ms(10);
	Cmd_Bank0(true);
	Cmd_ReadState(reg0);//1
	Cmd_Go2_Normal();
	Cmd_ReadState(reg1);//2
	set_vsx_hv(Vst);	
	delay_ms(1);
	fxvi4.Set(FV, Vst, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(2);
	F_VST.MeasureVI(100,10);
	Get_Result(F_VST, result, MIRET);
	SERIAL Iq_LFmin[SITE] = result[SITE] * 1000.0;//mA
	set_vsx_hv(36.0);	
	delay_ms(1);
	fxvi4.Set(FV, 36.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(2);
	F_VST.MeasureVI(100, 10);
	Get_Result(F_VST, result, MIRET);
	SERIAL Iq_LFmax[SITE] = result[SITE] * 1000.0;//mA
	set_vsx_hv(6.0);
	delay_ms(2);
	Poweroff_slt2();
	set_ena_off();
	set_wak_off();
	C_FRE_PD_DisConnect;
	dcm.Disconnect("DCM_ALL");

	if (first)
	{
		fpvi0.Set(FI, 0, FPVIe_20V, FPVIe_10UA, FPVIe_RELAY_SENSE_ON);
		//fpvi0.Set(FV, 0, FPVIe_20V, FPVIe_1MA, FPVIe_RELAY_ON);
		delay_ms(2);
		C_FPVIH_SW_Connect;
		C_FPVIL_PG_Connect;
		//C_FRE_PD_Connect;//Low Freq
		C_FRE_PD_DisConnect;//High Freq
		set_ena_off();
		set_wak(false);
		Poweron_slt2();
		set_fb_plus_target_hc(0.2);
		//prebk_load_connect();
		//if(PN_Posbk_Available){posbk_load_connect();}
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Forceoff(except_prebk_quc);
		delay_ms(10);
		Cmd_Bank0(true);
		Cmd_ReadState(reg0);//1
		Cmd_Go2_Normal();
		Cmd_ReadState(reg1);//2
		set_vsx_hv(Vst);	
		delay_ms(1);
		fxvi4.Set(FV, Vst, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(2);
		F_VST.MeasureVI(100,10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_HF[SITE] = result[SITE] * 1000.0;//mA
		//F_VST.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON, 3);
		//delay_ms(2);

		C_VST_CAP_DisConnect;
		C_VS1_CAP_DisConnect;
		//set_fb_plus_target_hc(0.2);
		//Sleep current
		//Cmd_Bank1(true);
		//Cmd_Forceoff(except_prebk_quc);
		//set_quc(5.0);
		//Cmd_Bank0(true);
		//Cmd_Unlock();
		//CmdWriteData(0x05, 0);
		//CmdWriteData(0x06, 0);
		//Cmd_Lock();
		//wake up timer disable
		//Cmd_Go2_Normal();
		//Cmd_ReadState(data0);//2
		Cmd_En_WakeupTimer(false);
		CmdWriteData(WKTIMCFG2,0xFF);
		//CmdReadData(0x00,data1);
		Setup_SleepState();
		Cmd_Go2_Sleep();
		Cmd_ReadState(reg4);//3
		int data64[64][SITE_NUM];
		//for (int i = 0; i < 64; i++)
		//{
		//	CmdReadData(i, data64[i]);
		//}

		fxvi4.Set(FV, Vst, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		F_FB.Set(FV, Vfb, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(5);
		//C_VST_CAP_DisConnect;
		//C_VS1_CAP_DisConnect;
		//delay_ms(5);
		fpvi0.MeasureVI(50, 10);
		F_VST.MeasureVI(50, 10);
		F_FB.MeasureVI(50, 10);
		Get_Result(fpvi0, vsw, MVRET);
		Get_Result(F_VST, ivs, MIRET);
		Get_Result(F_FB, ifb, MIRET);
		SERIAL Iq_Slp1[SITE] = (ivs[SITE]+0.5*ifb[SITE]) * 1000000.0;//uA
		SERIAL VswSleep[SITE] = vsw[SITE];
		set_vsx_hv(Vst);
		set_fb_plus_target_hc(0.2);

		Cmd_Go2_Wake();
		Cmd_Go2_Normal();
		Cmd_ReadState(reg5);//2
		//wake up timer enable
		Cmd_En_WakeupTimer(true);
		CmdWriteData(WKTIMCFG2,0xFF);
		//CmdReadData(0x00,data2);
		Setup_SleepState();
		Cmd_Go2_Sleep();
		Cmd_ReadState(reg6);//3
		fxvi4.Set(FV, Vst, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		F_FB.Set(FV, Vfb, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(5);
		F_VST.MeasureVI(50, 10);
		F_FB.MeasureVI(50, 10);
		Get_Result(F_VST, ivs, MIRET);
		Get_Result(F_FB, ifb, MIRET);
		SERIAL Iq_Slp2[SITE] = (ivs[SITE]+0.5*ifb[SITE]) * 1000000.0;//uA
		set_vsx_hv(Vst);
		set_fb_plus_target_hc(0.2);

		//Standby current
		Cmd_Go2_Wake();
		Cmd_ReadState(reg6);//5
		Setup_StandbyState();
		//wake up timer disable
		Cmd_En_WakeupTimer(true);
		CmdWriteData(WKTIMCFG2,0xFF);
		CmdReadData(0x00,data3);
		Cmd_Go2_Normal();
		Cmd_ReadState(reg7);//2
		Cmd_Go2_Standby();
		Cmd_ReadState(reg7);//4?
		delay_ms(1);
		fxvi4.Set(FV, Vst, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(5);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Stb2[SITE] = result[SITE] * 1000000.0;//uA
		set_vsx_hv(Vst);
		set_fb_plus_target_hc(0.2);

		//wake up timer enable
		set_ena_pulse();
		Cmd_ReadState(reg8);//1
		delay_ms(5);
		//Cmd_Bank1(true);
		//Cmd_TestMode(false);
		//Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(reg9);//2
		//Cmd_Bank1(true);
		//Cmd_Forceoff(all_off);
		//Cmd_Bank0(true);
		Setup_StandbyState();
		Cmd_En_WakeupTimer(false);
		CmdWriteData(WKTIMCFG2,0xFF);
		CmdReadData(0x00,data4);
		Cmd_Go2_Standby();
		Cmd_ReadState(reg10);//4?
		delay_ms(1);
		fxvi4.Set(FV, Vst, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(6);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Stb1[SITE] = result[SITE] * 1000000.0;//uA
		set_vsx_hv(Vst);
		set_fb_plus_target_hc(0.2);

		set_ena_pulse();
		Cmd_ReadState(reg11);//1
		delay_ms(5);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(reg12);//2
		Setup_StandbyState();
		Cmd_En_WakeupTimer(false);
		CmdReadData(0x00,data5);
		//qst enable
		Cmd_Bank1(true);
		Cmd_Forceoff(except_qst);
		Cmd_Bank0(true);
		Cmd_Go2_Standby();
		Cmd_ReadState(reg13);//4?
		fxvi4.Set(FV, Vst, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(5);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Stb3[SITE] = result[SITE] * 1000000.0;//uA
		set_vsx_hv(Vst);
		set_fb_plus_target_hc(0.2);

		//Failsaft current
		set_ena_pulse();
		Cmd_ReadState(reg14);//1
		delay_ms(4);
		Cmd_Dis_ERR_WD();
		delay_ms(1);
		Cmd_Go2_Normal();
		delay_ms(1);
		Cmd_ReadState(reg15);//2
		//Setup_StandbyState();
		//fail safe state
		set_qst(6.0);//force qst ov to enter fs
		delay_ms(100);
		set_qst(false);
		delay_ms(2);
		fxvi4.Set(FV, Vst, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(5);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_FS[SITE] = result[SITE] * 1000000.0;//uA
		C_VST_CAP_Connect;
		C_VS1_CAP_Connect;
		Poweroff_slt2();
		set_ena_off();
		set_wak_off(); 
		fpvi0.Set(FI, 0, FPVIe_20V, FPVIe_10UA, FPVIe_RELAY_ON);
		C_FPVIH_SW_DisConnect;
		C_FPVIL_PG_DisConnect;
		fpvi0.Set(FV, 0, FPVIe_20V, FPVIe_10UA, FPVIe_RELAY_ON);
		delay_ms(2);
		fpvi0.Set(FV, 0, FPVIe_20V, FPVIe_10UA, FPVIe_RELAY_OFF);
	}
	//C_All_Open;
	//all_resource_off();
	dcm.Disconnect("DCM_ALL");
}

void Test_Iq3(bool first,double Iq_LFmin[],double Iq_LFmax[],double Iq_HF[], double Iq_Slp1[], double Iq_Slp2[], double Iq_Stb1[], double Iq_Stb2[], double Iq_Stb3[], double Iq_FS[], double VswSleep[])
{
	double result[SITE_NUM];
	int reg0[SITE_NUM];
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int reg3[SITE_NUM];
	int reg4[SITE_NUM];
	int reg5[SITE_NUM];
	int reg6[SITE_NUM];
	int reg7[SITE_NUM];
	int reg8[SITE_NUM];
	int reg9[SITE_NUM];
	int reg10[SITE_NUM];
	int reg11[SITE_NUM];
	int reg12[SITE_NUM];
	int reg13[SITE_NUM];
	int reg14[SITE_NUM];
	int reg15[SITE_NUM];

	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];
	int data5[SITE_NUM];
	int data6[SITE_NUM];
	int data7[SITE_NUM];

	C_FRE_PD_Connect;//Low Freq
	//C_FRE_PD_DisConnect;//High Freq
	set_ena_off();
	set_wak(false);
	Poweron_slt();
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_ReadState(reg0);//1
	Cmd_Go2_Normal();
	Cmd_ReadState(reg1);//2
	set_vsx_hv(12.0);
	delay_ms(1);
	F_VST.MeasureVI(300,10);
	Get_Result(F_VST, result, MIRET);
	SERIAL Iq_LFmin[SITE] = result[SITE] * 1000.0;//mA
	set_vsx_hv(36.0);
	delay_ms(1);
	F_VST.MeasureVI(300, 10);
	Get_Result(F_VST, result, MIRET);
	SERIAL Iq_LFmax[SITE] = result[SITE] * 1000.0;//mA
	set_vsx_hv(6.0);
	delay_ms(2);
	Poweroff_slt();
	set_ena_off();
	set_wak_off();
	C_FRE_PD_DisConnect;
	dcm.Disconnect("DCM_ALL");

	if (first)
	{
		C_ACM_STU_Connect;
		A_STU.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		//C_FRE_PD_Connect;//Low Freq
		C_FRE_PD_DisConnect;//High Freq
		set_ena_off();
		set_wak(false);
		Poweron_slt();
		A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		double vfb=PN_Prebk_Output*1.03;
		set_fb_hc(vfb);
		F_FB.MeasureVI(30, 10);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_ReadState(reg0);//1
		Cmd_Go2_Normal();
		Cmd_ReadState(reg1);//2
		set_vsx_hv(12.0);	
		delay_ms(1);
		F_VST.MeasureVI(300,10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_HF[SITE] = result[SITE] * 1000.0;//mA
		//F_VST.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON, 3);
		//delay_ms(2);

		C_VST_CAP_DisConnect;
		C_VS1_CAP_DisConnect;
		//set_fb_plus_target_hc(0.2);
		//Sleep current
		Cmd_Bank1(true);
		//Cmd_Forceoff(except_prebk_quc);
		//set_quc(5.0);
		//Cmd_Bank0(true);
		////wake up timer disable
		////CmdReadData(0x00,data0);
		//Cmd_En_WakeupTimer(false);
		//CmdReadData(0x00,data1);
		//Setup_SleepState();
		//Cmd_Go2_Sleep();
		//Cmd_ReadState(reg4);//3
		//fxvi4.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		//delay_ms(5);
		//F_VST.MeasureVI(3000, 10);
		//Get_Result(F_VST, result, MIRET);
		//SERIAL Iq_Slp1[SITE] = result[SITE] * 1000000.0;//uA
		//set_vsx_hv(12.0);

		//Cmd_Go2_Wake();
		//Cmd_Go2_Normal();
		//Cmd_ReadState(reg5);//2
		////wake up timer enable
		//Cmd_En_WakeupTimer(true);
		//CmdReadData(0x00,data2);
		//Setup_SleepState();
		//Cmd_Go2_Sleep();
		//Cmd_ReadState(reg6);//3
		//fxvi4.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		//delay_ms(5);
		//F_VST.MeasureVI(30, 10);
		//Get_Result(F_VST, result, MIRET);
		//SERIAL Iq_Slp2[SITE] = result[SITE] * 1000000.0;//uA
		set_vsx_hv(12.0);
		F_FB.MeasureVI(30, 10);
		double ifb[SITE_NUM];
		double ivsx[SITE_NUM];
		double iq[SITE_NUM];
		
		set_vsx_hv(14.0);
		//fxvi4.Set(FV, 14.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(5);
		Cmd_Bank1(true);
		//SS_HIGH
		int ssh = dut.sel("SS_HIGH").get_working(0);
		dut.sel("SS_HIGH").set_working(0);
		Nvm_PreviewFs(4);
		F_FB.MeasureVI(30, 10);
		Cmd_Bank1(true);
		Cmd_Forceoff(except_prebk_quc);
		F_FB.MeasureVI(30, 10);
		Cmd_Bank0(true);
		Cmd_En_Stb(false, false);
		Cmd_En_Posbk(false);
		//CmdWriteData(0x30,data6);
		Cmd_Bank0(true);
		Cmd_Go2_Sleep();
		Cmd_ReadState(reg4);//3
		Cmd_ReadState(reg5);//3
		CmdReadData(0x27,data6);//
		CmdReadData(0x33,data7);//
		Cmd_Bank0(true);
		//Cmd_En_Stb(false, false);
		fxvi4.Set(FV, 14.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		F_FB.Set(FV, vfb, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(5);
		F_VST.MeasureVI(30, 10);
		F_FB.MeasureVI(30, 10);
		Get_Result(F_VST, ivsx, MIRET);
		SERIAL ivsx[SITE] = ivsx[SITE] * 1000000.0;//uA
		Get_Result(F_FB, ifb, MIRET);
		SERIAL ifb[SITE] = ifb[SITE] * 1000000.0;//uA
		SERIAL iq[SITE] = ivsx[SITE]+0.6*ifb[SITE];
		C_ACM_STU_DisConnect;
		A_STU.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);

		//Standby current
		Cmd_Go2_Wake();
		Cmd_ReadState(reg6);//5
		Setup_StandbyState();
		//wake up timer disable
		Cmd_En_WakeupTimer(true);
		CmdWriteData(0x14,0xFF);
		CmdReadData(0x00,data3);
		Cmd_Go2_Normal();
		Cmd_ReadState(reg7);//2
		Cmd_Go2_Standby();
		Cmd_ReadState(reg7);//4?
		delay_ms(1);
		fxvi4.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(5);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Stb2[SITE] = result[SITE] * 1000000.0;//uA
		set_vsx_hv(12.0);

		//wake up timer enable
		set_ena_pulse();
		Cmd_ReadState(reg8);//1
		delay_ms(5);
		//Cmd_Bank1(true);
		//Cmd_TestMode(false);
		//Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(reg9);//2
		//Cmd_Bank1(true);
		//Cmd_Forceoff(all_off);
		//Cmd_Bank0(true);
		Setup_StandbyState();
		Cmd_En_WakeupTimer(false);
		CmdWriteData(0x14,0xFF);
		CmdReadData(0x00,data4);
		Cmd_Go2_Standby();
		Cmd_ReadState(reg10);//4?
		delay_ms(1);
		fxvi4.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(6);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Stb1[SITE] = result[SITE] * 1000000.0;//uA
		set_vsx_hv(12.0);

		set_ena_pulse();
		Cmd_ReadState(reg11);//1
		delay_ms(5);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(reg12);//2
		Setup_StandbyState();
		Cmd_En_WakeupTimer(false);
		CmdReadData(0x00,data5);
		//qst enable
		Cmd_Bank1(true);
		Cmd_Forceoff(except_qst);
		Cmd_Bank0(true);
		Cmd_Go2_Standby();
		Cmd_ReadState(reg13);//4?
		fxvi4.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(5);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_Stb3[SITE] = result[SITE] * 1000000.0;//uA
		set_vsx_hv(12.0);

		//Failsaft current
		set_ena_pulse();
		Cmd_ReadState(reg14);//1
		delay_ms(4);
		Cmd_Dis_ERR_WD();
		delay_ms(1);
		Cmd_Go2_Normal();
		delay_ms(1);
		Cmd_ReadState(reg15);//2
		//Setup_StandbyState();
		//fail safe state
		set_qst(6.0);//force qst ov to enter fs
		delay_ms(100);
		set_qst(false);
		delay_ms(2);
		fxvi4.Set(FV, 12.0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(5);
		F_VST.MeasureVI(30, 10);
		Get_Result(F_VST, result, MIRET);
		SERIAL Iq_FS[SITE] = result[SITE] * 1000000.0;//uA
		Poweroff_slt();
		set_ena_off();
		set_wak_off();
	}
	//C_All_Open;
	//all_resource_off();
	dcm.Disconnect("DCM_ALL");
}


void Get_HW_Temp(bool diode, bool sensor, double TempDiode[], double TempSensor[])
{
	if (diode)
	{
		double volt[SITE_NUM];
		//C_FXVI_ACM_GND_Connect;
		C_ACM_DIODE_Connect;
		delay_ms(1);
		temp_meas_board(volt, TempDiode);
		C_ACM_DIODE_DisConnect;
		delay_ms(1);
	}
	if (sensor)
	{
		C_ACM_FB1_Connect;
		set_fb(4.0);
		set_quc(4.0);
		Sensor_Connect();
		//Sensor_ReadID(id);
		Sensor_Start();
		delay_ms(5);
		Sensor_Read(TempSensor);
		Sensor_Stop();
		Sensor_DisConnect();
		set_quc(false);
		set_fb(false);
		C_ACM_FB1_DisConnect;
	}
}

void AT24C_Connect(void)
{
	C_I2C_Connect;
	delay_ms(1);
	double vdd = 5.0;
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.7 * vdd;
	double dVOL = 0.3 * vdd;
	int status1 = dcm.I2CSet(10000,SITE_NUM,DCM_REG8,"S24_6,S24_22,S24_46,S24_62,S24_14,S24_30,S24_38,S24_54","S24_5,S24_21,S24_45,S24_61,S24_13,S24_29,S24_37,S24_53");
	int status2 = dcm.I2CConnect();
	int status3 = dcm.I2CSetPinLevel(dVIH, dVIL, dVOH, dVOL);
}

void AT24C_DisConnect(void)
{
	dcm.I2CDisconnect();
	C_I2C_DisConnect;
	delay_ms(1);
}

void AT24C_Write(DWORD dwRegAddress, int nDataLength, DWORD dwDataArray[])
{
	BYTE AT24C = 0xA4;//8bit
	int status1 = dcm.I2CWriteData(AT24C, dwRegAddress, nDataLength, dwDataArray);
}

void AT24C_Read(DWORD dwRegAddress, DWORD dwDataArray[])
{
	BYTE AT24C = 0xA4;
	int status1 = dcm.I2CReadData(AT24C, dwRegAddress, 1);
	SERIAL dwDataArray[SITE] = dcm.I2CGetReadData(SITE, 0);
}

void DUT_SPI_Connect(double vdd)
{
	C_SPI_DUT;
	//double vdd = 5.0;
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	dcm.Connect("SPI_DUT");//Connect all channel's relay
	dcm.InitMCU("SPI_DUT");//Initialize MCU.
	dcm.SetPinLevel("SPI_DUT", dVIH, dVIL, dVOH, dVOL);
}

void Scan_Connect(double vdd)
{
	C_SCAN_Connect;
	//int vd = vdd*0.1;
	//double vdd = 5.0;
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	dcm.Connect("SCAN");//Connect all channel's relay
	dcm.InitMCU("SCAN");//Initialize MCU.
	dcm.SetPinLevel("SCAN", dVIH, dVIL, dVOH, dVOL);
}

void Prog_Clk_Connect(void)
{
	C_DCM_ERR_Connect;
	double vdd = 4.0;
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	dcm.Connect("DCM4");//Connect all channel's relay
	dcm.InitMCU("DCM4");//Initialize MCU.
	dcm.SetPinLevel("DCM4", dVIH, dVIL, dVOH, dVOL);
}

void Prog_Clk_Run(void)
{
	int status = dcm.RunVectorWithGroup("DCM4", "PROG_CLK_START", "PROG_CLK_STOP", TRUE);
}

void Prog_Clk_DisConnect(void)
{
	dcm.Disconnect("DCM4");//Connect all channel's relay
	C_DCM_ERR_DisConnect;
}

void Scan_SetLevle(double vdd)
{
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	dcm.SetPinLevel("SCAN", dVIH, dVIL, dVOH, dVOL);
}

void Scan_Run(const char* lpszPinGroup, const char* lpszStartLabel, const char* lpszStopLabel, int fail_flag[], int fail_count[])
{
	int sta[SITE_NUM];
	int flag[SITE_NUM];
	ULONG count[SITE_NUM];
	int status = dcm.RunVectorWithGroup(lpszPinGroup, lpszStartLabel, lpszStopLabel, TRUE);
	if (status != 0)
	{
		delay_us(1);
	}

	SERIAL 
	{
		flag[SITE] = dcm.GetMCUPinResult("D_SDO", SITE);
		if(flag[SITE]>0)
		{
			delay_us(1);
		}
	}

	SERIAL sta[SITE] = dcm.GetFailCount("D_SDO", SITE, count[SITE]);
	SERIAL fail_flag[SITE]=flag[SITE];
	SERIAL fail_count[SITE]=count[SITE];
	//int status2 = dcm.SaveFailMap(128);
}

void Iddq_Run(const string iddq_point[], int size, int fail_flag[], int fail_count[], double iddq[][SITE_NUM])
{
	//int fail_flag[SITE_NUM];
	//ULONG fail_count[SITE_NUM];
	int star_point = 0;
	int stop_point = 0;
	int flag[SITE_NUM];
	int count[SITE_NUM];
	string start;
	string stop;
	string paraname;
	string paradelta;
	double iddq_i[SITE_NUM];

	//int size = sizeof(iddq_point) / sizeof(iddq_point[0]);
	//int size = iddq_point.size();
	star_point = 0;
	stop_point = size - 2;

	for (int i = star_point; i <= stop_point; i++)
	{
		start = iddq_point[i];
		stop = iddq_point[i + 1];

		Scan_Run("SCAN", start.c_str(), stop.c_str(), flag, count);
		delay_us(100);
		A_SECPOSFRE.MeasureVI(20, 10);
		Get_Result(A_SECPOSFRE, iddq_i, MIRET);
		//if (1 == dio_plus.IsHasFailLine())
		//{
		//	dio_plus.SaveFailMap();
		//}
		SERIAL
		{
			if (i == star_point)
			{
				fail_flag[SITE] = flag[SITE];
				fail_count[SITE] = count[SITE];
			}
			else
			{
				fail_flag[SITE] += flag[SITE];
				fail_count[SITE] += count[SITE];
			}
			iddq[i][SITE] = iddq_i[SITE]*1000000.0;
		}
	}
}

void QVM_Init(void)
{
	qvm0.Init();
	qvm1.Init();
	qvm2.Init();
	qvm3.Init();
}

void QVM_Connect(void)
{
	qvm0.Connect();
	qvm1.Connect();
	qvm2.Connect();
	qvm3.Connect();
}

void QVM_DisConnect(void)
{
	qvm0.Disconnect();
	qvm1.Disconnect();
	qvm2.Disconnect();
	qvm3.Disconnect();
}

void QVM_Measure(UINT sampleTimes, double sampleInterval, QVMe_LADC_VRANG VRange, double result[])
{
	QVMe_LADC_FILTER Filter = QVMe_LADC_400KHz;
	FLOATMEASMODE measMode = MEAS_NORMAL;
	C_QVM_1357;
	delay_ms(2);
	qvm.MeasureLADC(sampleTimes, sampleInterval, QVMe_LADC_20V, Filter, measMode);
	QVM_GetResult1357(result);
	C_QVM_2468;
	delay_ms(2);
	qvm.MeasureLADC(sampleTimes, sampleInterval, QVMe_LADC_20V, Filter, measMode);
	QVM_GetResult2468(result);
}

void QVM_GetResult1357(double result[],int sampleNumber)
{
	result[0] = qvm0.GetMeasResult(-1, sampleNumber);
	result[2] = qvm1.GetMeasResult(-1, sampleNumber);
	result[4] = qvm2.GetMeasResult(-1, sampleNumber);
	result[6] = qvm3.GetMeasResult(-1, sampleNumber);
}

void QVM_GetResult2468(double result[], int sampleNumber)
{
	result[1] = qvm0.GetMeasResult(-1, sampleNumber);
	result[3] = qvm1.GetMeasResult(-1, sampleNumber);
	result[5] = qvm2.GetMeasResult(-1, sampleNumber);
	result[7] = qvm3.GetMeasResult(-1, sampleNumber);
}

void PSRR_TEST(unsigned char RELAY_DUTI, unsigned char RELAY_DUTO, double psrr[])
{
	F_LSI.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_SENSE_ON);
	//Connect PSRR IN
	C_FXVI_PSRR_Connect;
	//Connect PSRR DUTIN
	cbitclose(RELAY_DUTI);
	//Connect PSRR DUTO
	cbitclose(RELAY_DUTO);
	//Enable PSRR OUT
	LSI_LDO(true);
	C_LSI_DUTO_PWRX_Connect;
	delay_ms(2);

	//Connect PSRR DUTSI
	//Connect PSRR DUTSO
	F_LSI.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	PSRR_Test_LSI(A_ABUFO, 0.1, psrr);

	//Disable PSRR OUT
	LSI_LDO(false);
	C_LSI_DUTO_PWRX_DisConnect;
	//DisConnect PSRR DUTIN
	cbitopen(RELAY_DUTI);
	//DisConnect PSRR DUTO
	cbitopen(RELAY_DUTO);
	//DisConnect PSRR IN
	C_FXVI_PSRR_DisConnect;
	F_LSI.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	F_LSI.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
}

void conty_test(double Result[][SITE_NUM])
{
	double Value = -1.0 mA;
	double res_A[30][SITE_NUM] = { 0 };//18
	double res_B[30][SITE_NUM] = { 0 };//11
	double res_C[30][SITE_NUM] = { 0 };//8
	double res_D[30][SITE_NUM] = { 0 };//5
	double res_E[30][SITE_NUM] = { 0 };//4
	double res_F[30][SITE_NUM] = { 0 };//6
	double res_G[30][SITE_NUM] = { 0 };//1
	double res[SITE_NUM];

	//Analog,6group
	//A//VST,RSH,VS1,BATSNS1,QST,STU,POSIN,POSSW,POSFB,VCI,SEC,SQUC
	//B//RSL,BATSNS2,EVC,NC,FB2
	//C//FB1,QT1,SW2,QUC,MPS
	//D//SW1,QT2,SQT1,QVR,FB3
	//E//QT3,SQT2,QCO,FB4
	//F//AGS,PG
	//G//BSG,POSG
	//H//VS2
	//I//TPAD
	//Digital,4group
	/////DM7,DM6,DM5,DM4,DM3,DM2,DM1,DM0
	//A//DRG,SYN,ROT,SS1,SCS,SDO,   ,   
	//B//FRE,WAK,INT,ERR,   ,   ,SCL,SDI
	//C//ENA,WDI,SS2,

	C_All_Open;
	all_resource_off();
	dcm.Connect("DCM_ALL");
	delay_ms(1);
	C_FXVI_ACM_GND_Connect;
	//C_GND_Connect;

	////fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	////fxvi1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	////fxvi2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	////fxvi3.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	////fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	////fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	////acm0.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	////acm1.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	////acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	////acm3.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	////acm4.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	//acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	//acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	////acm7.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	////acm8.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	////acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	////acm10.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	////acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	//cbitclose(K214);
	//delay_ms(1);
	//acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//FB2,K214
	//acm11.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//acm11.MeasureVI(10, 10);
	//SERIAL
	//{
	//	res[SITE] = acm11.GetMeasResult(SITE, MVRET);
	//}
	//acm11.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	//acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	//cbitopen(K214);;
	//delay_ms(1);
	//cbitclose(K19);
	//delay_ms(1);
	//fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//FB1,K19
	//fxvi0.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//fxvi0.MeasureVI(10, 10);
	//SERIAL
	//{
	//	res[SITE] = fxvi0.GetMeasResult(SITE, MVRET);
	//}
	//fxvi0.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//cbitopen(K19);;
	//delay_ms(1);

	//cbitclose(K143);
	//cbitclose(K144);
	//cbitclose(K145);
	//cbitclose(K146);
	//cbitclose(K147);//posg need float
	//GroupA
	if(1)
	{
		C_Conty_GroupA_Connect;
		C_POSG_GND_Connect;
		C_AGS_GND_Connect;
		delay_ms(1);
		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);//VST,K8,K18
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//RSH,K21
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//VS1,
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//BATSNS1,K50
		acm0.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QST,
		acm1.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//STU,K78
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//POSIN,
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//POSSW,
		acm7.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//POSFB,
		acm8.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//VCI,K62
		acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//SEC,K63
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//SQUC,K218
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//DRG,K99
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//SYN,K105
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//ROT,K111
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//SS1,K114
		dcm.SetPPMU("CS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//SCS,
		dcm.SetPPMU("SDO", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//SDO,

		fpvi0.Set(FI, Value, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);
		fxvi0.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi4.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm0.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm1.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm5.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm6.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm7.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm8.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm9.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		dcm.SetPPMU("D6", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		dcm.SetPPMU("D5", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		dcm.SetPPMU("D4", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		dcm.SetPPMU("CS", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		dcm.SetPPMU("SDO", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		delay_ms(1);
		fpvi0.MeasureVI(10, 10);
		fxvi0.MeasureVI(10, 10);
		fxvi4.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		acm0.MeasureVI(10, 10);
		acm1.MeasureVI(10, 10);
		acm5.MeasureVI(10, 10);
		acm6.MeasureVI(10, 10);
		acm7.MeasureVI(10, 10);
		acm8.MeasureVI(10, 10);
		acm9.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		dcm.PPMUMeasure("D7", 10, 10);
		dcm.PPMUMeasure("D6", 10, 10);
		dcm.PPMUMeasure("D5", 10, 10);
		dcm.PPMUMeasure("D4", 10, 10);
		dcm.PPMUMeasure("CS", 10, 10);
		dcm.PPMUMeasure("SDO", 10, 10);
		SERIAL
		{
			res_A[0][SITE]=fpvi0.GetMeasResult(SITE, MVRET);
			res_A[1][SITE]=fxvi0.GetMeasResult(SITE, MVRET);
			res_A[2][SITE]=fxvi4.GetMeasResult(SITE, MVRET);
			res_A[3][SITE]=fxvi5.GetMeasResult(SITE, MVRET);
			res_A[4][SITE]=acm0.GetMeasResult(SITE, MVRET);
			res_A[5][SITE]=acm1.GetMeasResult(SITE, MVRET);
			res_A[6][SITE]=acm5.GetMeasResult(SITE, MVRET);
			res_A[7][SITE]=acm6.GetMeasResult(SITE, MVRET);
			res_A[8][SITE]=acm7.GetMeasResult(SITE, MVRET);
			res_A[9][SITE]=acm8.GetMeasResult(SITE, MVRET);
			res_A[10][SITE]=acm9.GetMeasResult(SITE, MVRET);
			res_A[11][SITE]=acm11.GetMeasResult(SITE, MVRET);
			res_A[12][SITE]=dcm.GetPPMUMeasResult("DCM7", SITE);
			res_A[13][SITE]=dcm.GetPPMUMeasResult("DCM6", SITE);
			res_A[14][SITE]=dcm.GetPPMUMeasResult("DCM5", SITE);
			res_A[15][SITE]=dcm.GetPPMUMeasResult("DCM4", SITE);
			res_A[16][SITE]=dcm.GetPPMUMeasResult("D_CS", SITE);
			res_A[17][SITE]=dcm.GetPPMUMeasResult("D_SDO", SITE);
		}
		fpvi0.Set(FI, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);
		fxvi0.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi4.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm0.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm1.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm5.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm6.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm7.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm8.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm9.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D4", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("CS", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SDO", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm0.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm1.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm7.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm8.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("CS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SDO", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		//ss1
		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);//VST
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//SS1,K114
		delay_ms(1);
		dcm.SetPPMU("D4", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		delay_ms(1);
		dcm.PPMUMeasure("D4", 10, 10);
		SERIAL
		{
			res_A[15][SITE] = dcm.GetPPMUMeasResult("DCM4", SITE);
		}
		dcm.SetPPMU("D4", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);

		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
		C_Conty_GroupA_DisConnect;
		C_POSG_GND_DisConnect;
		C_AGS_GND_DisConnect;
		delay_ms(1);
	}
	//GroupB
	if(1)
	{
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
		C_Conty_GroupB_Connect;
		C_AGS_GND_Connect;
		delay_ms(1);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//RSL,K22
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//BATSNS2,K51
		acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//EVC,K65
		acm10.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//NC,K72
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//FB2,K214
		
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//FRE,K103
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//WAK,K107
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//INT,K112
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//ERR,K115
		dcm.SetPPMU("SCK", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SCK,
		dcm.SetPPMU("SDI", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SDI,

		fxvi0.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm9.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm10.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D4", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SCK", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SDI", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_2MA);
		delay_ms(1);
		fxvi0.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		acm9.MeasureVI(10, 10);
		acm10.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		dcm.PPMUMeasure("D7", 10, 10);
		dcm.PPMUMeasure("D6", 10, 10);
		dcm.PPMUMeasure("D5", 10, 10);
		dcm.PPMUMeasure("D4", 10, 10);
		dcm.PPMUMeasure("SCK", 10, 10);
		dcm.PPMUMeasure("SDI", 10, 10);
		SERIAL
		{
			res_B[0][SITE]=fxvi0.GetMeasResult(SITE, MVRET);
			res_B[1][SITE]=fxvi5.GetMeasResult(SITE, MVRET);
			res_B[2][SITE]=acm9.GetMeasResult(SITE, MVRET);
			res_B[3][SITE]=acm10.GetMeasResult(SITE, MVRET);
			res_B[4][SITE]=acm11.GetMeasResult(SITE, MVRET);
			res_B[5][SITE]=dcm.GetPPMUMeasResult("DCM7", SITE);
			res_B[6][SITE]=dcm.GetPPMUMeasResult("DCM6", SITE);
			res_B[7][SITE]=dcm.GetPPMUMeasResult("DCM5", SITE);
			res_B[8][SITE]=dcm.GetPPMUMeasResult("DCM4", SITE);
			res_B[9][SITE]=dcm.GetPPMUMeasResult("D_SCK", SITE);
			res_B[10][SITE]=dcm.GetPPMUMeasResult("D_SDI", SITE);
		}
		fxvi0.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm9.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm10.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D4", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SCK", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SDI", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm10.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SCK", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SDI", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		C_Conty_GroupB_DisConnect;
		C_AGS_GND_DisConnect;
		delay_ms(1);
	}
	//GroupC
	if(1)
	{
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
		C_Conty_GroupC_Connect;
		C_PG_GND_Connect;
		C_AGS_GND_Connect;
		delay_ms(1);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//FB1,K19
		fxvi1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//QT1,
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//SW2,K54
		acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QUC,
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//MPS,K219
		
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//ENA,K106
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//WDI,K108
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SS2,K113

		fxvi0.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi1.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		//acm2.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_2MA);
		delay_ms(1);
		fxvi0.MeasureVI(10, 10);
		fxvi1.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		//acm2.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		dcm.PPMUMeasure("D7", 10, 10);
		dcm.PPMUMeasure("D6", 10, 10);
		dcm.PPMUMeasure("D5", 10, 10);
		SERIAL
		{
			res_C[0][SITE]=fxvi0.GetMeasResult(SITE, MVRET);
			res_C[1][SITE]=fxvi1.GetMeasResult(SITE, MVRET);
			res_C[2][SITE]=fxvi5.GetMeasResult(SITE, MVRET);
			//res_C[3][SITE]=acm2.GetMeasResult(SITE, MVRET);
			res_C[4][SITE]=acm11.GetMeasResult(SITE, MVRET);
			res_C[5][SITE]=dcm.GetPPMUMeasResult("DCM7", SITE);
			res_C[6][SITE]=dcm.GetPPMUMeasResult("DCM6", SITE);
			res_C[7][SITE]=dcm.GetPPMUMeasResult("DCM5", SITE);
		}
		fxvi0.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi1.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		//acm2.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);

		//quc
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QUC,
		acm2.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		acm2.MeasureVI(10, 10);
		SERIAL
		{
			res_C[3][SITE] = acm2.GetMeasResult(SITE, MVRET);
		}
		acm2.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);

		C_Conty_GroupC_DisConnect;
		C_PG_GND_DisConnect;
		C_AGS_GND_DisConnect;
		delay_ms(1);
	}
	//GroupD
	if(1)
	{
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
		C_Conty_GroupD_Connect;
		C_PG_GND_Connect;
		C_AGS_GND_Connect;
		delay_ms(1);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//SW1,K20
		fxvi2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//QT2,
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//SQT1,K53
		acm3.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QVR,
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//FB3,K215

		fxvi0.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi2.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm3.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi0.MeasureVI(10, 10);
		fxvi2.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		acm3.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		SERIAL
		{
			res_D[0][SITE]=fxvi0.GetMeasResult(SITE, MVRET);
			res_D[1][SITE]=fxvi2.GetMeasResult(SITE, MVRET);
			res_D[2][SITE]=fxvi5.GetMeasResult(SITE, MVRET);
			res_D[3][SITE]=acm3.GetMeasResult(SITE, MVRET);
			res_D[4][SITE]=acm11.GetMeasResult(SITE, MVRET);
		}
		fxvi0.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi2.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm3.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm3.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		C_Conty_GroupD_DisConnect;
		C_PG_GND_DisConnect;
		C_AGS_GND_DisConnect;
		delay_ms(1);
	}
	//GroupE
	if(1)
	{
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
		C_Conty_GroupE_Connect;
		C_AGS_GND_Connect;
		delay_ms(1);
		fxvi3.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//QT3,
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//SQT2,K52
		acm4.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QCO,
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//FB4,K216

		fxvi3.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm4.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi3.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		acm4.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		SERIAL
		{
			res_E[0][SITE]=fxvi3.GetMeasResult(SITE, MVRET);
			res_E[1][SITE]=fxvi5.GetMeasResult(SITE, MVRET);
			res_E[2][SITE]=acm4.GetMeasResult(SITE, MVRET);
			res_E[3][SITE]=acm11.GetMeasResult(SITE, MVRET);
		}
		fxvi3.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm4.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		fxvi3.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm4.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		C_Conty_GroupE_DisConnect;
		C_AGS_GND_DisConnect;
		delay_ms(1);
	}
	//GroupF,G,H,I
	if(1)
	{
		C_AGS_BSG_PG_GND_Connect;
		C_Conty_GroupH_Connect;
		delay_ms(1);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//VS2,K55

		fxvi5.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(1);
		fxvi5.MeasureVI(10, 10);
		SERIAL
		{
			res_F[4][SITE] = fxvi5.GetMeasResult(SITE, MVRET);
		}
		fxvi5.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		C_Conty_GroupH_DisConnect;
		delay_ms(1);
		C_AGS_BSG_PG_GND_DisConnect;
		C_Conty_GroupF_Connect;
		delay_ms(1);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//AGS,K57
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//PG,K212

		fxvi5.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi5.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		SERIAL
		{
			res_F[0][SITE]=fxvi5.GetMeasResult(SITE, MVRET);
			res_F[1][SITE]=acm11.GetMeasResult(SITE, MVRET);
		}
		fxvi5.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		C_Conty_GroupF_DisConnect;
		delay_ms(1);
		C_Conty_GroupG_Connect;
		delay_ms(1);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//BSG,K56
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//POSG,K217

		fxvi5.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FI, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi5.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		SERIAL
		{
			res_F[2][SITE]=fxvi5.GetMeasResult(SITE, MVRET);
			res_F[3][SITE]=acm11.GetMeasResult(SITE, MVRET);
		}
		fxvi5.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		C_Conty_GroupG_DisConnect;
		delay_ms(1);
		C_Conty_GroupI_Connect;
		delay_ms(1);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//TPAD,K145

		fxvi5.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(1);
		fxvi5.MeasureVI(10, 10);
		SERIAL
		{
			res_F[5][SITE]=fxvi5.GetMeasResult(SITE, MVRET);
		}
		fxvi5.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		C_Conty_GroupI_DisConnect;
		delay_ms(1);
	}

	//GroupG
	if (1)
	{
		C_FXVI_ACM_GND_Connect;
		C_AGS_BSG_PG_POSG_GND_Connect;
		C_FXVI_SW_Connect;
		delay_ms(2);
		F_SW.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);

		fxvi4.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
		fxvi4.MeasureVI(10, 10);
		SERIAL
		{
			res_G[0][SITE] = fxvi4.GetMeasResult(SITE, MVRET);
		}
		fxvi4.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		C_FXVI_ACM_GND_DisConnect;
		C_AGS_BSG_PG_POSG_GND_DisConnect;
		C_FXVI_SW_DisConnect;
		delay_ms(1);
	}

	//C_FXVI_SQT1_Connect;
	//C_FXVI_SQT2_Connect;
	//C_ACM_FB1_Connect;
	//delay_ms(1);
	//fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//force 0
	//A_FB1.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	//F_QT1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT3.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);

	//F_QT1.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT2.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT3.Set(FI, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_QT1.MeasureVI(10, 10);
	//F_QT2.MeasureVI(10, 10);
	//F_QT3.MeasureVI(10, 10);
	//SERIAL
	//{
	//	res_C[1][SITE] = fxvi1.GetMeasResult(SITE, MVRET);//qt1
	//	res_D[1][SITE] = fxvi2.GetMeasResult(SITE, MVRET);//qt2
	//	res_E[0][SITE] = fxvi3.GetMeasResult(SITE, MVRET);//qt3
	//}
	//F_QT1.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT2.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT3.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT3.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);

	//C_FXVI_SQT1_DisConnect;
	//C_FXVI_SQT2_DisConnect;
	//C_ACM_FB1_DisConnect;

	C_FXVI_ACM_GND_DisConnect;
	C_AGS_BSG_PG_GND_DisConnect;
	C_All_Open;
	all_resource_off();

	for (int i = 0; i < 18; i++) { SERIAL { Result[i][SITE] = res_A[i][SITE]; } }
	for (int i = 0; i < 11; i++) { SERIAL { Result[i+18][SITE] = res_B[i][SITE]; } }
	for (int i = 0; i < 8; i++) { SERIAL { Result[i+18+11][SITE] = res_C[i][SITE]; } }
	for (int i = 0; i < 5; i++) { SERIAL { Result[i+18+11+8][SITE] = res_D[i][SITE]; } }
	for (int i = 0; i < 4; i++) { SERIAL { Result[i+18+11+8+5][SITE] = res_E[i][SITE]; } }
	for (int i = 0; i < 6; i++) { SERIAL { Result[i+18+11+8+5+4][SITE] = res_F[i][SITE]; } }
	for (int i = 0; i < 1; i++) { SERIAL { Result[i+18+11+8+5+4+6][SITE] = res_G[i][SITE]; } }
}

void conty_getdata(double Result[][SITE_NUM])
{
	/////////0,		1,		2,		3,		4,		5,		6,		7,		8,		9
	//00-09//VST,	RSH,	VS1,	BATSNS1,QST,	STU,	POSIN,	POSSW,	POSFB,	VCI
	//10-19//SEC,	SQUC,	DRG,	SYN,	ROT,	SS1,	SCS,	SDO,	RSL,	BATSNS2
	//20-29//EVC,	NC,		FB2,	FRE,	WAK,	INT,	ERR,	SCL,	SDI,	FB1
	//30-39//QT1,	SW2,	QUC,	MPS,	ENA,	WDI,	SS2,	SW1,	QT2,	SQT1
	//40-49//QVR,	FB3,	QT3,	SQT2,	QCO,	FB4,	AGS,	PG,		BSG,	POSG
	//50-59//VS2,	TPAD

	//SYN/EVS/SSD
	//VCI/VMON
	//SEC/AMUX
	//EVC/POSFRE

	SERIAL
	{
		PINarray[0].pin_volt[SITE] = Result[50][SITE];//VS2
		PINarray[1].pin_volt[SITE] = Result[2][SITE];//VS1
		PINarray[2].pin_volt[SITE] = Result[37][SITE];//SW1
		PINarray[3].pin_volt[SITE] = Result[31][SITE];//SW2
		PINarray[4].pin_volt[SITE] = Result[3][SITE];//BATSNS1
		PINarray[5].pin_volt[SITE] = Result[19][SITE];//BATSNS2
		PINarray[6].pin_volt[SITE] = Result[12][SITE];//DRG
		PINarray[7].pin_volt[SITE] = Result[1][SITE];//RSH
		PINarray[8].pin_volt[SITE] = Result[18][SITE];//RSL
		PINarray[9].pin_volt[SITE] = Result[48][SITE];//BSG
		PINarray[10].pin_volt[SITE] = Result[0][SITE];//VST
		PINarray[11].pin_volt[SITE] = Result[34][SITE];//ENA
		PINarray[12].pin_volt[SITE] = Result[24][SITE];//WAK
		PINarray[13].pin_volt[SITE] = Result[4][SITE];//QST
		PINarray[14].pin_volt[SITE] = 0;//AG1
		PINarray[15].pin_volt[SITE] = 0;//AG2
		PINarray[16].pin_volt[SITE] = Result[46][SITE];//AGS1
		PINarray[17].pin_volt[SITE] = Result[46][SITE];//AGS2
		PINarray[18].pin_volt[SITE] = Result[36][SITE];//SS2
		PINarray[19].pin_volt[SITE] = Result[15][SITE];//SS1
		PINarray[20].pin_volt[SITE] = Result[28][SITE];//SDI
		PINarray[21].pin_volt[SITE] = Result[17][SITE];//SDO
		PINarray[22].pin_volt[SITE] = Result[27][SITE];//SCL
		PINarray[23].pin_volt[SITE] = Result[16][SITE];//SCS
		PINarray[24].pin_volt[SITE] = Result[35][SITE];//WDI
		PINarray[25].pin_volt[SITE] = Result[14][SITE];//ROT
		PINarray[26].pin_volt[SITE] = Result[25][SITE];//INT
		PINarray[27].pin_volt[SITE] = Result[13][SITE];//EVS
		PINarray[28].pin_volt[SITE] = Result[13][SITE];//SYN
		PINarray[29].pin_volt[SITE] = Result[13][SITE];//SSD
		PINarray[30].pin_volt[SITE] = Result[26][SITE];//ERR
		PINarray[31].pin_volt[SITE] = Result[20][SITE];//EVC
		PINarray[32].pin_volt[SITE] = Result[20][SITE];//POSFRE
		PINarray[33].pin_volt[SITE] = Result[23][SITE];//FRE
		PINarray[34].pin_volt[SITE] = Result[33][SITE];//MPS
		PINarray[35].pin_volt[SITE] = Result[10][SITE];//SEC
		PINarray[36].pin_volt[SITE] = Result[10][SITE];//AMUX
		PINarray[37].pin_volt[SITE] = Result[9][SITE];//VCI
		PINarray[38].pin_volt[SITE] = Result[9][SITE];//VMON
		PINarray[39].pin_volt[SITE] = Result[5][SITE];//STU
		PINarray[40].pin_volt[SITE] = 0;//AG3
		PINarray[41].pin_volt[SITE] = Result[40][SITE];//QVR
		PINarray[42].pin_volt[SITE] = Result[32][SITE];//QUC
		PINarray[43].pin_volt[SITE] = Result[11][SITE];//SQUC
		PINarray[44].pin_volt[SITE] = Result[44][SITE];//QCO
		PINarray[45].pin_volt[SITE] = Result[38][SITE];//QT2
		PINarray[46].pin_volt[SITE] = Result[43][SITE];//SQT2
		PINarray[47].pin_volt[SITE] = Result[30][SITE];//QT1
		PINarray[48].pin_volt[SITE] = Result[39][SITE];//SQT1
		PINarray[49].pin_volt[SITE] = Result[42][SITE];//QT3
		PINarray[50].pin_volt[SITE] = Result[49][SITE];//POSG
		PINarray[51].pin_volt[SITE] = Result[7][SITE];//POSSW
		PINarray[52].pin_volt[SITE] = Result[6][SITE];//POSIN
		PINarray[53].pin_volt[SITE] = Result[8][SITE];//POSFB
		PINarray[54].pin_volt[SITE] = Result[29][SITE];//FB1
		PINarray[55].pin_volt[SITE] = Result[22][SITE];//FB2
		PINarray[56].pin_volt[SITE] = Result[41][SITE];//FB3
		PINarray[57].pin_volt[SITE] = Result[45][SITE];//FB4
		PINarray[58].pin_volt[SITE] = 0;//AG4
		PINarray[59].pin_volt[SITE] = Result[47][SITE];//PG2
		PINarray[60].pin_volt[SITE] = Result[47][SITE];//PG1
		PINarray[61].pin_volt[SITE] = Result[51][SITE];//TP
		PINarray[62].pin_volt[SITE] = Result[21][SITE];//NC
		PINarray[63].pin_volt[SITE] = Result[0][SITE];//
		PINarray[64].pin_volt[SITE] = Result[0][SITE];//
		PINarray[65].pin_volt[SITE] = Result[0][SITE];//
		PINarray[66].pin_volt[SITE] = Result[0][SITE];//
		PINarray[67].pin_volt[SITE] = Result[0][SITE];//
		PINarray[68].pin_volt[SITE] = Result[0][SITE];//
		PINarray[69].pin_volt[SITE] = Result[0][SITE];//
		PINarray[70].pin_volt[SITE] = Result[0][SITE];//
		PINarray[71].pin_volt[SITE] = Result[0][SITE];//
		PINarray[72].pin_volt[SITE] = Result[0][SITE];//
		PINarray[73].pin_volt[SITE] = Result[0][SITE];//
		PINarray[74].pin_volt[SITE] = Result[0][SITE];//
		PINarray[75].pin_volt[SITE] = Result[0][SITE];//
		PINarray[76].pin_volt[SITE] = Result[0][SITE];//
		PINarray[77].pin_volt[SITE] = Result[0][SITE];//
		PINarray[78].pin_volt[SITE] = Result[0][SITE];//
		PINarray[79].pin_volt[SITE] = Result[0][SITE];//
		PINarray[80].pin_volt[SITE] = Result[0][SITE];//
		PINarray[81].pin_volt[SITE] = Result[0][SITE];//
		PINarray[82].pin_volt[SITE] = Result[0][SITE];//
		PINarray[83].pin_volt[SITE] = Result[0][SITE];//
		PINarray[84].pin_volt[SITE] = Result[0][SITE];//
		PINarray[85].pin_volt[SITE] = Result[0][SITE];//
		PINarray[86].pin_volt[SITE] = Result[0][SITE];//
		PINarray[87].pin_volt[SITE] = Result[0][SITE];//
		PINarray[88].pin_volt[SITE] = Result[0][SITE];//
		PINarray[89].pin_volt[SITE] = Result[0][SITE];//
		PINarray[80].pin_volt[SITE] = Result[0][SITE];//
		PINarray[91].pin_volt[SITE] = Result[0][SITE];//
		PINarray[92].pin_volt[SITE] = Result[0][SITE];//
		PINarray[93].pin_volt[SITE] = Result[0][SITE];//
		PINarray[94].pin_volt[SITE] = Result[0][SITE];//
		PINarray[95].pin_volt[SITE] = Result[0][SITE];//
		PINarray[96].pin_volt[SITE] = Result[0][SITE];//
		PINarray[97].pin_volt[SITE] = Result[0][SITE];//
		PINarray[98].pin_volt[SITE] = Result[52][SITE];//
	}
}

void conty_datalog(short funcindex, bool first)
{
	int Flag_all_open[SITE_NUM];
	int Flag_some_open[SITE_NUM];
	int Flag_short[SITE_NUM];
	int FailCount[SITE_NUM];
	int OpenCount[SITE_NUM];
	int ShortCount[SITE_NUM];
	//Check open and short flag
	double th_open = 0.9;
	double th_open2 = 1.5;
	double th_short = 0.2;

	//CParam *OS_SHORT = StsGetParam(funcindex, "OS_SHORT");
	//CParam *OS_SOME_OPEN = StsGetParam(funcindex, "OS_SOME_OPEN");
	//CParam *OS_ALL_OPEN = StsGetParam(funcindex, "OS_ALL_OPEN");

	SERIAL
	{
		Flag_all_open[SITE] = 1;
		Flag_some_open[SITE] = 0;
		Flag_short[SITE] = 0;
		FailCount[SITE] = 0;
		OpenCount[SITE] = 0;
		ShortCount[SITE] = 0;
	}
	bool debug_log = false;
	for (int i = 0; i < PIN_Count; i++)
	{
		if((debug_log && i<63) || ((PINarray[i].pin_valid)&&(PINarray[i].diode)))
		{
			SERIAL if (abs(PINarray[i].pin_volt[SITE]) < th_open){ Flag_all_open[SITE] = 0; }// Not all open if 1 pin not open
			SERIAL if ((abs(PINarray[i].pin_volt[SITE]) > th_open)&&(i != 61)&&(i != 62) && (i != 4) && (i != 5) && (i != 45) && (i != 47) && (i != 49)){ Flag_some_open[SITE] = 1; FailCount[SITE] ++; OpenCount[SITE] ++; }// Some open if 1 pin open
			//SERIAL if ((abs(PINarray[i].pin_volt[SITE]) > th_open2) && (i == 18) && (i == 19)) { Flag_some_open[SITE] = 1; FailCount[SITE]++; OpenCount[SITE]++; }// Some open if 1 pin open
			SERIAL if (abs(PINarray[i].pin_volt[SITE]) < th_short){ Flag_short[SITE] = 1; FailCount[SITE] ++; ShortCount[SITE] ++; }// Short if 1 pin short
			//SERIAL StsGetParam(funcindex, PINarray[i].name_os.c_str())->SetTestResult(SITE, 0, PINarray[i].pin_volt[SITE]);
			Ms_LogData(funcindex, PINarray[i].name_os.c_str(), PINarray[i].pin_volt);
			//if (first){ SERIAL StsGetParam(funcindex, PINarray[i].name_pre.c_str())->SetTestResult(SITE, 0, PINarray[i].pin_volt[SITE]); }
			//else      { SERIAL StsGetParam(funcindex, PINarray[i].name_post.c_str())->SetTestResult(SITE, 0, PINarray[i].pin_volt[SITE]); }
		}
	}
	if (first)
	{
		double DutTemp[SITE_NUM];
		int DutTempInt[SITE_NUM];
		double DutVolt[SITE_NUM];
		SERIAL DutVolt[SITE]=PINarray[34].pin_volt[SITE];//MPS
		ConvertTempDut(DutVolt, DutTemp);
		ConvertTempInt(DutTemp, DutTempInt);
		//SERIAL OS_ALL_OPEN->SetTestResult(SITE, 0, Flag_all_open[SITE]);
		//SERIAL OS_SOME_OPEN->SetTestResult(SITE, 0, Flag_some_open[SITE]);
		//SERIAL OS_SHORT->SetTestResult(SITE, 0, Flag_short[SITE]);
		Ms_LogData(funcindex, "DUT_Temp", DutTemp);
		Ms_LogData(funcindex, "DUT_TempInt", DutTempInt);
		Ms_LogData(funcindex, "OS_FailCount", FailCount);
		Ms_LogData(funcindex, "OS_OpenCount", OpenCount);
		Ms_LogData(funcindex, "OS_ShortCount", ShortCount);
		Ms_LogData(funcindex, "OS_ALL_OPEN", Flag_all_open);
		Ms_LogData(funcindex, "OS_SOME_OPEN", Flag_some_open);
		Ms_LogData(funcindex, "OS_SHORT", Flag_short);
	}
}

void lvl_test(double Result[][SITE_NUM], bool first)
{
	double Value = 0;
	if (first)
	{
		Value = 0.2;
	}
	else
	{
		Value = -0.2;
	}
	double res_A[30][SITE_NUM] = { 0 };//18
	double res_B[30][SITE_NUM] = { 0 };//11
	double res_C[30][SITE_NUM] = { 0 };//8
	double res_D[30][SITE_NUM] = { 0 };//5
	double res_E[30][SITE_NUM] = { 0 };//4
	double res_F[30][SITE_NUM] = { 0 };//6
	double res_G[30][SITE_NUM] = { 0 };//6

	//Analog,6group
	//A//VST,RSH,VS1,BATSNS1,QST,STU,POSIN,POSSW,POSFB,VCI,SEC,SQUC
	//B//RSL,BATSNS2,EVC,NC,FB2
	//C//FB1,QT1,SW2,QUC,MPS
	//D//SW1,QT2,SQT1,QVR,FB3
	//E//QT3,SQT2,QCO,FB4
	//F//AGS,PG
	//F//BSG,POSG
	//F//VS2
	//F//TPAD
	//Digital,4group
	/////DM7,DM6,DM5,DM4,DM3,DM2,DM1,DM0
	//A//DRG,SYN,ROT,SS1,SCS,SDO,   ,   
	//B//FRE,WAK,INT,ERR,   ,   ,SCL,SDI
	//C//ENA,WDI,SS2,

	C_All_Open;
	all_resource_off();
	dcm.Connect("DCM_ALL");
	delay_ms(1);
	C_FXVI_ACM_GND_Connect;

	//vicurve_v(A_QCO, ACM200_10V, ACM200_10MA, 0, 6);
	//GroupA
	if(1)
	{
		C_Conty_GroupA_Connect;
		C_POSG_GND_Connect;
		C_AGS_GND_Connect;
		delay_ms(1);
		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);//VST
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//RSH
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//VS1
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//BATSNS1
		acm0.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QST
		acm1.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//STU
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//POSIN
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//POSSW
		acm7.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//POSFB
		acm8.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//VCI
		acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//SEC
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//SQUC
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//DRG
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SYN
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//ROT
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SS1
		dcm.SetPPMU("CS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SCS
		dcm.SetPPMU("SDO", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SDO

		fpvi0.Set(FV, Value, FPVIe_2V, FPVIe_100UA, FPVIe_RELAY_ON);
		fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi4.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm0.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm1.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm5.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm6.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm7.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm8.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm9.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		fpvi0.Set(FV, Value, FPVIe_2V, FPVIe_10UA, FPVIe_RELAY_ON);
		fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
		fxvi4.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm0.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		acm1.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		acm5.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		acm6.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm7.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		acm8.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		acm9.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("CS", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("SDO", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		delay_ms(1);
		fpvi0.MeasureVI(10, 10);
		fxvi0.MeasureVI(10, 10);
		fxvi4.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		acm0.MeasureVI(10, 10);
		acm1.MeasureVI(10, 10);
		acm5.MeasureVI(10, 10);
		acm6.MeasureVI(10, 10);
		acm7.MeasureVI(10, 10);
		acm8.MeasureVI(10, 10);
		acm9.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		dcm.PPMUMeasure("D7", 10, 10);
		dcm.PPMUMeasure("D6", 10, 10);
		dcm.PPMUMeasure("D5", 10, 10);
		dcm.PPMUMeasure("D4", 10, 10);
		dcm.PPMUMeasure("CS", 10, 10);
		dcm.PPMUMeasure("SDO", 10, 10);
		SERIAL
		{
			res_A[0][SITE]=fpvi0.GetMeasResult(SITE, MIRET);
			res_A[1][SITE]=fxvi0.GetMeasResult(SITE, MIRET);
			res_A[2][SITE]=fxvi4.GetMeasResult(SITE, MIRET);
			res_A[3][SITE]=fxvi5.GetMeasResult(SITE, MIRET);
			res_A[4][SITE]=acm0.GetMeasResult(SITE, MIRET);
			res_A[5][SITE]=acm1.GetMeasResult(SITE, MIRET);
			res_A[6][SITE]=acm5.GetMeasResult(SITE, MIRET);
			res_A[7][SITE]=acm6.GetMeasResult(SITE, MIRET);
			res_A[8][SITE]=acm7.GetMeasResult(SITE, MIRET);
			res_A[9][SITE]=acm8.GetMeasResult(SITE, MIRET);
			res_A[10][SITE]=acm9.GetMeasResult(SITE, MIRET);
			res_A[11][SITE]=acm11.GetMeasResult(SITE, MIRET);
			res_A[12][SITE]=dcm.GetPPMUMeasResult("DCM7", SITE, AVERAGE_RESULT);
			res_A[13][SITE]=dcm.GetPPMUMeasResult("DCM6", SITE, AVERAGE_RESULT);
			res_A[14][SITE]=dcm.GetPPMUMeasResult("DCM5", SITE, AVERAGE_RESULT);
			res_A[15][SITE]=dcm.GetPPMUMeasResult("DCM4", SITE, AVERAGE_RESULT);
			res_A[16][SITE] = dcm.GetPPMUMeasResult("D_CS", SITE, AVERAGE_RESULT);
			res_A[17][SITE]=dcm.GetPPMUMeasResult("D_SDO", SITE, AVERAGE_RESULT);
		}
		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm0.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm1.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm7.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm8.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("CS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SDO", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		//ss1
		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);//VST
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SS1
		//fpvi0.Set(FV, Value, FPVIe_2V, FPVIe_100UA, FPVIe_RELAY_ON);
		delay_ms(1);
		//fpvi0.Set(FV, Value, FPVIe_2V, FPVIe_10UA, FPVIe_RELAY_ON);
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		delay_ms(1);
		dcm.PPMUMeasure("D4", 10, 10);
		SERIAL
		{
			res_A[15][SITE] = dcm.GetPPMUMeasResult("DCM4", SITE, AVERAGE_RESULT);
		}
		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_ON);
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		//possw
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//POSSW

		acm6.Set(FV, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		//acm6.Set(FV, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		acm6.MeasureVI(10, 10);
		SERIAL
		{
			res_A[7][SITE] = acm6.GetMeasResult(SITE, MIRET);
		}
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);

		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_1MA, FPVIe_RELAY_OFF);
		C_Conty_GroupA_DisConnect;
		C_POSG_GND_DisConnect;
		C_AGS_GND_DisConnect;
		delay_ms(1);
	}
	//GroupB
	if(1)
	{
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
		C_Conty_GroupB_Connect;
		C_AGS_GND_Connect;
		delay_ms(1);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//RSL
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//BATSNS2
		acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//EVC
		acm10.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//NC
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//FB2
		
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//FRE
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//WAK
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//INT
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//ERR
		dcm.SetPPMU("SCK", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SCK
		dcm.SetPPMU("SDI", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//SDI

		fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm9.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm10.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm9.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		acm10.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("SCK", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("SDI", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		delay_ms(1);
		fxvi0.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		acm9.MeasureVI(10, 10);
		acm10.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		dcm.PPMUMeasure("D7", 10, 10);
		dcm.PPMUMeasure("D6", 10, 10);
		dcm.PPMUMeasure("D5", 10, 10);
		dcm.PPMUMeasure("D4", 10, 10);
		dcm.PPMUMeasure("SCK", 10, 10);
		dcm.PPMUMeasure("SDI", 10, 10);
		SERIAL
		{
			res_B[0][SITE]=fxvi0.GetMeasResult(SITE, MIRET);
			res_B[1][SITE]=fxvi5.GetMeasResult(SITE, MIRET);
			res_B[2][SITE]=acm9.GetMeasResult(SITE, MIRET);
			res_B[3][SITE]=acm10.GetMeasResult(SITE, MIRET);
			res_B[4][SITE]=acm11.GetMeasResult(SITE, MIRET);
			res_B[5][SITE]=dcm.GetPPMUMeasResult("DCM7", SITE, AVERAGE_RESULT);
			res_B[6][SITE]=dcm.GetPPMUMeasResult("DCM6", SITE, AVERAGE_RESULT);
			res_B[7][SITE]=dcm.GetPPMUMeasResult("DCM5", SITE, AVERAGE_RESULT);
			res_B[8][SITE]=dcm.GetPPMUMeasResult("DCM4", SITE, AVERAGE_RESULT);
			res_B[9][SITE]=dcm.GetPPMUMeasResult("D_SCK", SITE, AVERAGE_RESULT);
			res_B[10][SITE]=dcm.GetPPMUMeasResult("D_SDI", SITE, AVERAGE_RESULT);
		}
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm10.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SCK", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("SDI", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		C_Conty_GroupB_DisConnect;
		C_AGS_GND_DisConnect;
		delay_ms(1);
	}
	//GroupC
	if(1)
	{
		fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
		C_Conty_GroupC_Connect;
		C_PG_GND_Connect;
		C_AGS_GND_Connect;
		delay_ms(1);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//FB1
		fxvi1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//QT1
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//SW2
		acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QUC
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//MPS
		
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//FRE
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//WAK
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);//INT

		fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi1.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		//acm2.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi1.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		//acm2.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, Value, DCM_PPMUIRANGE_20UA);
		delay_ms(1);
		fxvi0.MeasureVI(10, 10);
		fxvi1.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		//acm2.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		dcm.PPMUMeasure("D7", 10, 10);
		dcm.PPMUMeasure("D6", 10, 10);
		dcm.PPMUMeasure("D5", 10, 10);
		SERIAL
		{
			res_C[0][SITE]=fxvi0.GetMeasResult(SITE, MIRET);
			res_C[1][SITE]=fxvi1.GetMeasResult(SITE, MIRET);
			res_C[2][SITE]=fxvi5.GetMeasResult(SITE, MIRET);
			//res_C[3][SITE]=acm2.GetMeasResult(SITE, MIRET);
			res_C[4][SITE]=acm11.GetMeasResult(SITE, MIRET);
			res_C[5][SITE]=dcm.GetPPMUMeasResult("DCM7", SITE, AVERAGE_RESULT);
			res_C[6][SITE]=dcm.GetPPMUMeasResult("DCM6", SITE, AVERAGE_RESULT);
			res_C[7][SITE]=dcm.GetPPMUMeasResult("DCM5", SITE, AVERAGE_RESULT);
		}
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		//acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		dcm.SetPPMU("D7", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D6", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D5", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);

		//quc
		acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QUC
		acm2.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		acm2.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(2);
		acm2.MeasureVI(10, 10);
		SERIAL
		{
			res_C[3][SITE]=acm2.GetMeasResult(SITE, MIRET);
		}
		acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);

		C_PG_GND_DisConnect;
		C_AGS_GND_DisConnect;
		C_Conty_GroupC_DisConnect;
		delay_ms(1);
	}
	//GroupD
	if(1)
	{
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
		C_Conty_GroupD_Connect;
		C_PG_GND_Connect;
		C_AGS_GND_Connect;
		delay_ms(1);
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//SW1
		fxvi2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//QT2
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//SQT1
		acm3.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QVR
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//FB3

		fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi2.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm3.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
		fxvi2.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm3.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi0.MeasureVI(10, 10);
		fxvi2.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		acm3.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		SERIAL
		{
			res_D[0][SITE]=fxvi0.GetMeasResult(SITE, MIRET);
			res_D[1][SITE]=fxvi2.GetMeasResult(SITE, MIRET);
			res_D[2][SITE]=fxvi5.GetMeasResult(SITE, MIRET);
			res_D[3][SITE]=acm3.GetMeasResult(SITE, MIRET);
			res_D[4][SITE]=acm11.GetMeasResult(SITE, MIRET);
		}
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm3.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);

		//sw
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//SW1

		fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
		//fxvi0.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
		fxvi0.MeasureVI(10, 10);
		SERIAL
		{
			res_D[0][SITE] = fxvi0.GetMeasResult(SITE, MIRET);
		}
		fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);


		C_Conty_GroupD_DisConnect;
		C_PG_GND_DisConnect;
		C_AGS_GND_DisConnect;
		delay_ms(1);
	}
	//GroupE
	if(1)
	{
		acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
		acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
		C_Conty_GroupE_Connect;
		delay_ms(1);
		fxvi3.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//QT3
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//SQT2
		acm4.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//QCO
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//FB4

		fxvi3.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm4.Set(FV, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi3.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm4.Set(FV, Value, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi3.MeasureVI(10, 10);
		fxvi5.MeasureVI(10, 10);
		acm4.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		SERIAL
		{
			res_E[0][SITE]=fxvi3.GetMeasResult(SITE, MIRET);
			res_E[1][SITE]=fxvi5.GetMeasResult(SITE, MIRET);
			res_E[2][SITE]=acm4.GetMeasResult(SITE, MIRET);
			res_E[3][SITE]=acm11.GetMeasResult(SITE, MIRET);
		}
		fxvi3.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm4.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		C_Conty_GroupE_DisConnect;
		C_AGS_GND_DisConnect;
		delay_ms(1);
	}
	//GroupF,G,H,I
	if(1)
	{
		C_AGS_BSG_PG_GND_Connect;
		C_Conty_GroupH_Connect;
		delay_ms(1);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//VS2
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(1);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(1);
		fxvi5.MeasureVI(10, 10);
		SERIAL
		{
			res_F[4][SITE] = fxvi5.GetMeasResult(SITE, MIRET);
		}
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		C_Conty_GroupH_DisConnect;
		delay_ms(1);
		C_AGS_BSG_PG_GND_DisConnect;
		C_Conty_GroupF_Connect;
		delay_ms(1);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//AGS
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//PG
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);//29uA
		delay_ms(1);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);//29uA
		delay_ms(1);
		fxvi5.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		SERIAL
		{
			res_F[0][SITE]=fxvi5.GetMeasResult(SITE, MIRET);
			res_F[1][SITE]=acm11.GetMeasResult(SITE, MIRET);
		}
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		C_Conty_GroupF_DisConnect;
		delay_ms(1);
		C_Conty_GroupG_Connect;
		delay_ms(1);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//BSG
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);//POSG
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FV, Value, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
		delay_ms(1);
		fxvi5.MeasureVI(10, 10);
		acm11.MeasureVI(10, 10);
		SERIAL
		{
			res_F[2][SITE]=fxvi5.GetMeasResult(SITE, MIRET);
			res_F[3][SITE]=acm11.GetMeasResult(SITE, MIRET);
		}
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		C_Conty_GroupG_DisConnect;
		delay_ms(1);
		C_Conty_GroupI_Connect;
		delay_ms(1);
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);//TPAD
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(1);
		fxvi5.Set(FV, Value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(1);
		fxvi5.MeasureVI(10, 10);
		SERIAL
		{
			res_F[5][SITE]=fxvi5.GetMeasResult(SITE, MIRET);
		}
		fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		C_Conty_GroupI_DisConnect;
		delay_ms(1);
	}
	C_FXVI_ACM_GND_DisConnect;
	C_AGS_BSG_PG_GND_DisConnect;
	C_All_Open;
	all_resource_off();

	for (int i = 0; i < 18; i++) { SERIAL { Result[i][SITE] = res_A[i][SITE]; } }
	for (int i = 0; i < 11; i++) { SERIAL { Result[i+18][SITE] = res_B[i][SITE]; } }
	for (int i = 0; i < 8; i++) { SERIAL { Result[i+18+11][SITE] = res_C[i][SITE]; } }
	for (int i = 0; i < 5; i++) { SERIAL { Result[i+18+11+8][SITE] = res_D[i][SITE]; } }
	for (int i = 0; i < 4; i++) { SERIAL { Result[i+18+11+8+5][SITE] = res_E[i][SITE]; } }
	for (int i = 0; i < 6; i++) { SERIAL { Result[i+18+11+8+5+4][SITE] = res_F[i][SITE]; } }
}

void lvl_getdata(double Result[][SITE_NUM])
{
	/////////0,		1,		2,		3,		4,		5,		6,		7,		8,		9
	//00-09//VST,	RSH,	VS1,	BATSNS1,QST,	STU,	POSIN,	POSSW,	POSFB,	VCI
	//10-19//SEC,	SQUC,	DRG,	SYN,	ROT,	SS1,	SCS,	SDO,	RSL,	BATSNS2
	//20-29//EVC,	NC,		FB2,	FRE,	WAK,	INT,	ERR,	SCL,	SDI,	FB1
	//30-39//QT1,	SW2,	QUC,	MPS,	ENA,	WDI,	SS2,	SW1,	QT2,	SQT1
	//40-49//QVR,	FB3,	QT3,	SQT2,	QCO,	FB4,	AGS,	PG,		BSG,	POSG
	//50-59//VS2,	TPAD

	//SYN/EVS/SSD
	//VCI/VMON
	//SEC/AMUX
	//EVC/POSFRE

	SERIAL
	{
		PINarray[0].pin_lvl[SITE] = Result[50][SITE];//VS2
		PINarray[1].pin_lvl[SITE] = Result[2][SITE];//VS1
		PINarray[2].pin_lvl[SITE] = Result[37][SITE];//SW1
		PINarray[3].pin_lvl[SITE] = Result[31][SITE];//SW2
		PINarray[4].pin_lvl[SITE] = Result[3][SITE];//BATSNS1
		PINarray[5].pin_lvl[SITE] = Result[19][SITE];//BATSNS2
		PINarray[6].pin_lvl[SITE] = Result[12][SITE];//DRG
		PINarray[7].pin_lvl[SITE] = Result[1][SITE];//RSH
		PINarray[8].pin_lvl[SITE] = Result[18][SITE];//RSL
		PINarray[9].pin_lvl[SITE] = Result[48][SITE];//BSG
		PINarray[10].pin_lvl[SITE] = Result[0][SITE];//VST
		PINarray[11].pin_lvl[SITE] = Result[34][SITE];//ENA
		PINarray[12].pin_lvl[SITE] = Result[24][SITE];//WAK
		PINarray[13].pin_lvl[SITE] = Result[4][SITE];//QST
		PINarray[14].pin_lvl[SITE] = 0;//AG1
		PINarray[15].pin_lvl[SITE] = 0;//AG2
		PINarray[16].pin_lvl[SITE] = Result[46][SITE];//AGS1
		PINarray[17].pin_lvl[SITE] = Result[46][SITE];//AGS2
		PINarray[18].pin_lvl[SITE] = Result[36][SITE];//SS2
		PINarray[19].pin_lvl[SITE] = Result[15][SITE];//SS1
		PINarray[20].pin_lvl[SITE] = Result[28][SITE];//SDI
		PINarray[21].pin_lvl[SITE] = Result[17][SITE];//SDO
		PINarray[22].pin_lvl[SITE] = Result[27][SITE];//SCL
		PINarray[23].pin_lvl[SITE] = Result[16][SITE];//SCS
		PINarray[24].pin_lvl[SITE] = Result[35][SITE];//WDI
		PINarray[25].pin_lvl[SITE] = Result[14][SITE];//ROT
		PINarray[26].pin_lvl[SITE] = Result[25][SITE];//INT
		PINarray[27].pin_lvl[SITE] = Result[13][SITE];//EVS
		PINarray[28].pin_lvl[SITE] = Result[13][SITE];//SYN
		PINarray[29].pin_lvl[SITE] = Result[13][SITE];//SSD
		PINarray[30].pin_lvl[SITE] = Result[26][SITE];//ERR
		PINarray[31].pin_lvl[SITE] = Result[20][SITE];//EVC
		PINarray[32].pin_lvl[SITE] = Result[20][SITE];//POSFRE
		PINarray[33].pin_lvl[SITE] = Result[23][SITE];//FRE
		PINarray[34].pin_lvl[SITE] = Result[33][SITE];//MPS
		PINarray[35].pin_lvl[SITE] = Result[10][SITE];//SEC
		PINarray[36].pin_lvl[SITE] = Result[10][SITE];//AMUX
		PINarray[37].pin_lvl[SITE] = Result[9][SITE];//VCI
		PINarray[38].pin_lvl[SITE] = Result[9][SITE];//VMON
		PINarray[39].pin_lvl[SITE] = Result[5][SITE];//STU
		PINarray[40].pin_lvl[SITE] = 0;//AG3
		PINarray[41].pin_lvl[SITE] = Result[40][SITE];//QVR
		PINarray[42].pin_lvl[SITE] = Result[32][SITE];//QUC
		PINarray[43].pin_lvl[SITE] = Result[11][SITE];//SQUC
		PINarray[44].pin_lvl[SITE] = Result[44][SITE];//QCO
		PINarray[45].pin_lvl[SITE] = Result[38][SITE];//QT2
		PINarray[46].pin_lvl[SITE] = Result[43][SITE];//SQT2
		PINarray[47].pin_lvl[SITE] = Result[30][SITE];//QT1
		PINarray[48].pin_lvl[SITE] = Result[39][SITE];//SQT1
		PINarray[49].pin_lvl[SITE] = Result[42][SITE];//QT3
		PINarray[50].pin_lvl[SITE] = Result[49][SITE];//POSG
		PINarray[51].pin_lvl[SITE] = Result[7][SITE];//POSSW
		PINarray[52].pin_lvl[SITE] = Result[6][SITE];//POSIN
		PINarray[53].pin_lvl[SITE] = Result[8][SITE];//POSFB
		PINarray[54].pin_lvl[SITE] = Result[29][SITE];//FB1
		PINarray[55].pin_lvl[SITE] = Result[22][SITE];//FB2
		PINarray[56].pin_lvl[SITE] = Result[41][SITE];//FB3
		PINarray[57].pin_lvl[SITE] = Result[45][SITE];//FB4
		PINarray[58].pin_lvl[SITE] = 0;//AG4
		PINarray[59].pin_lvl[SITE] = Result[47][SITE];//PG2
		PINarray[60].pin_lvl[SITE] = Result[47][SITE];//PG1
		PINarray[61].pin_lvl[SITE] = Result[51][SITE];//TP
		PINarray[62].pin_lvl[SITE] = Result[21][SITE];//NC
		PINarray[63].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[64].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[65].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[66].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[67].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[68].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[69].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[70].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[71].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[72].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[73].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[74].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[75].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[76].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[77].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[78].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[79].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[80].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[81].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[82].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[83].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[84].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[85].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[86].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[87].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[88].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[89].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[80].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[91].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[92].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[93].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[94].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[95].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[96].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[97].pin_lvl[SITE] = Result[0][SITE];//
		PINarray[98].pin_lvl[SITE] = Result[52][SITE];//
	}
	for (int i = 0; i < PIN_Count; i++)
	{
		SERIAL PINarray[i].pin_lvl[SITE] = PINarray[i].pin_lvl[SITE] * 1000000.0;
	}
}

void lvl_datalog(short funcindex, bool first)
{
	for (int i = 0; i < PIN_Count-1; i++)
	{
		if ((PINarray[i].pin_valid)&&(PINarray[i].diode))
		{
			//SERIAL StsGetParam(funcindex, PINarray[i].name_lvl.c_str())->SetTestResult(SITE, 0, PINarray[i].pin_lvl[SITE]*1000000.0);
			Ms_LogData(funcindex, PINarray[i].name_lvl.c_str(), PINarray[i].pin_lvl);
		}
	}
}

void leak_test0(double Result[][SITE_NUM])
{
	double res_A[8][SITE_NUM] = { 0 };//8
	double res_B[14][SITE_NUM] = { 0 };//14
	double res_C[24][SITE_NUM] = { 0 };//25
	double res_D[7][SITE_NUM] = { 0 };//6

	C_All_Open;
	all_resource_off();
	dcm.Disconnect("DCM_ALL");
	delay_ms(1);
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_POSG_GND_Connect;
	if (1)
	{
		F_VST.Set(FV, 3, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);

		//C_SW1_SW2_Connect;
		//C_FPVIH_SW_Connect;
		//C_FPVIH_VS1_Connect;
		//C_FPVIL_AG_Connect;
		//delay_ms(1);
		//Test_Leak(fpvi0, 8, res_B[1], FPVIe_10V, FPVIe_1MA);
		//Copy_Array(res_B[2], res_B[1]);//sw2
		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
		//C_SW1_SW2_DisConnect;
		//C_FPVIH_SW_DisConnect;
		//C_FPVIH_VS1_DisConnect;
		//C_FPVIL_AG_DisConnect;
		//delay_ms(1);
	}
	C_AGS_BSG_PG_POSG_GND_Connect;
}

void leak_test(double Result[][SITE_NUM])
{
	double V_BATSNS1	= 5;//BATSNS1
	double V_BATSNS2	= 5;//BATSNS2
	double V_QT1		= 5;//QT1
	double V_SQT1		= 5;//SQT1
	double V_QT2		= 5;//QT2
	double V_SQT2		= 5;//SQT2
	double V_QT3		= 5;//QT3
	double V_VS1		= 8;//VS1
	double V_VS2		= 8;//VS2
	double V_VST		= 8;//VST
	double V_SW1		= 8;//SW1
	double V_SW2		= 8;//SW2
	double V_DRG		= 5;//DRG
	double V_RSH		= 5;//RSH
	double V_WAK		= 5;//WAK
	double V_ENA		= 5;//ENA
	double V_ERR		= 5;//ERR
	double V_INT		= 5;//INT
	double V_ROT		= 5;//ROT
	double V_WDI		= 5;//WDI
	double V_SCS		= 5;//SCS
	double V_SCL		= 5;//SCL
	double V_SDI		= 5;//SDI
	double V_SDO		= 5;//SDO
	double V_SS1		= 5;//SS1
	double V_SS2		= 5;//SS2
	double V_SSD		= 5;//SSD
	double V_EVS		= 5;//EVS

	double V_FB1		= 5;//FB1
	double V_FB2		= 5;//FB2
	double V_FB3		= 5;//FB3
	double V_FB4		= 5;//FB4
	double V_POSIN		= 5;//POSIN
	double V_POSSW		= 5;//POSSW

	double V_POSFB		= 5;//POSFB
	double V_QUC		= 5;//QUC
	double V_SQUC		= 5;//SQUC
	double V_QCO		= 5;//QCO
	double V_QVR		= 5;//QVR
	double V_QST		= 5;//QST
	double V_RSL		= 5;//RSL
	double V_MPS		= 5;//MPS
	double V_STU		= 5;//STU
	double V_FRE		= 5;//FRE
	double V_SEC		= 5;//SEC
	double V_SYN		= 5;//SYN
	double V_EVC		= 5;//EVC
	double V_VCI		= 5;//VCI
	double V_VMON		= 5;//VMON
	double V_AMUX		= 5;//AMUX
	double V_POSFRE		= 5;//POSFRE

	double V_BSG		= 0;//BSG----------
	double V_AGS1		= 0;//AGS1----------
	double V_AGS2		= 0;//AGS2----------
	double V_PG1		= 0;//PG1----------
	double V_PG2		= 0;//PG2----------
	double V_POSG		= 0;//POSG----------

	double V_AG1		= 0;//AG1----------
	double V_AG2		= 0;//AG2----------
	double V_AG3		= 0;//AG3----------
	double V_AG4		= 0;//AG4----------

	double V_TP			= 5;//TP
	double V_NC			= 5;//NC

	double res_A[8][SITE_NUM] = { 0 };//8
	double res_B[14][SITE_NUM] = { 0 };//14
	double res_C[24][SITE_NUM] = { 0 };//25
	double res_D[7][SITE_NUM] = { 0 };//6

	C_All_Open;
	all_resource_off();
	dcm.Disconnect("DCM_ALL");
	delay_ms(1);
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_POSG_GND_Connect;
	delay_ms(2);
	F_VST.Set(FV, 2.5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(2);
	F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(1);
	F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	//A,VST,VS1,VS2,FB1,FB2,FB3,FB4,POSIN
	//B,QST,SW1,SW2,POSSW,POSFB,SQUC,QUC,QVR,QCO,SQT1,QT1,SQT2,QT2,QT3
	//C,BATSNS1,BATSNS2,RSH,RSL,VCI/VMON,NC,SEC/AMUX,FRE,EVC/POSFRE,SYN/EVS/SSD,ENA,WAK,WDI,STU,INT,ERR,SCS,SCL,SDI,MPS
	//D,DRG,ROT,INT,SS1,SS2,SDO,TP

	//C_ACM_FB1_Connect;
	//delay_ms(1);
	////fpvi0.Set(FV, 0, FPVIe_10V, FPVIe_10MA, FPVIe_RELAY_ON);
	//Test_Leak(A_FB1, V_FB1, res_A[3], ACM200_10V, ACM200_100MA, ACM200_100MA);
	//C_ACM_FB1_DisConnect;
	//delay_ms(1);
	//C_ACM_FB2_Connect;
	//delay_ms(1);
	//Test_Leak(A_FB2, V_FB2, res_A[4], ACM200_10V, ACM200_100MA, ACM200_100MA);
	//C_ACM_FB2_DisConnect;
	//delay_ms(1);
	//C_ACM_FB3_Connect;
	//delay_ms(1);
	//Test_Leak(A_FB3, V_FB3, res_A[5], ACM200_10V, ACM200_100MA, ACM200_100MA);
	//C_ACM_FB3_DisConnect;
	//delay_ms(1);
	//C_ACM_FB4_Connect;
	//delay_ms(1);
	//Test_Leak(A_FB4, V_FB4, res_A[6], ACM200_10V, ACM200_100MA, ACM200_100MA);
	//fpvi0.Set(FV, 0, FPVIe_10V, FPVIe_10MA, FPVIe_RELAY_OFF);
	//C_ACM_FB4_DisConnect;
	//delay_ms(1);

	//GroupA
	if (1)
	{
		C_FXVI_DRG_Connect;//44k,
		delay_ms(1);
		//vicurve_v(F_DRG, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, -1, 35);
		Test_Leak(F_DRG, V_DRG, res_D[0], FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_1MA);
		C_FXVI_DRG_DisConnect;
		delay_ms(1);

		C_FPVIL_AG_Connect;
		C_FPVIH_VST_Connect;
		delay_ms(1);
		Test_Leak(fpvi0, V_VST, res_A[0], FPVIe_10V, FPVIe_10MA, FPVIe_10MA);
		C_FPVIH_VST_DisConnect;
		delay_ms(1);
		C_FPVIH_VS1_Connect;
		//C_FPVIH_SW_Connect;
		delay_ms(1);
		F_VST.Set(FV, 5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		Test_Leak(fpvi0, V_VS1, res_A[1], FPVIe_10V, FPVIe_1MA);
		//fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_10MA, FPVIe_RELAY_ON);
		//fpvi0.Set(FV, V_VS1, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_ON);
		//delay_ms(2);
		//fpvi0.Set(FV, V_VS1, FPVIe_100V, FPVIe_100UA, FPVIe_RELAY_ON);
		//delay_ms(3);
		//fpvi0.MeasureVI(100, 10);
		//Get_Result(fpvi0, res_A[1], MIRET);
		//fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_10MA, FPVIe_RELAY_ON);
		//delay_ms(1);
		//fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_10MA, FPVIe_RELAY_OFF);
		C_FPVIH_VS1_DisConnect;
		//C_FPVIH_SW_DisConnect;
		C_FPVIL_AG_DisConnect;
		delay_ms(1);
		C_FXVI_VS2_Connect;
		Test_Leakf(F_VS2, V_VS2, res_A[2], FXVIe_PLUS_10V, FXVIe_PLUS_1MA);
		C_FXVI_VS2_DisConnect;
		delay_ms(1);
		//C_ACM_FB1_Connect;
		//C_FPVIH_VST_Connect;
		//C_FPVIL_AG_Connect;
		//delay_ms(1);
		//fpvi0.Set(FV, 0, FPVIe_10V, FPVIe_10MA, FPVIe_RELAY_ON);
		//Test_Leak(A_FB1, V_FB1, res_A[3], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//C_ACM_FB1_DisConnect;
		//delay_ms(1);
		//C_ACM_FB2_Connect;
		//delay_ms(1);
		//Test_Leak(A_FB2, V_FB2, res_A[4], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//C_ACM_FB2_DisConnect;
		//delay_ms(1);
		//C_ACM_FB3_Connect;
		//delay_ms(1);
		//Test_Leak(A_FB3, V_FB3, res_A[5], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//C_ACM_FB3_DisConnect;
		//delay_ms(1);
		//C_ACM_FB4_Connect;
		//delay_ms(1);
		//Test_Leak(A_FB4, V_FB4, res_A[6], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//fpvi0.Set(FV, 0, FPVIe_10V, FPVIe_10MA, FPVIe_RELAY_OFF);
		//C_ACM_FB4_DisConnect;
		//delay_ms(1);
		//C_ACM_FB1_Connect;
		//delay_ms(1);
		//C_FPVIH_VST_DisConnect;
		C_FPVIL_AG_DisConnect;
		delay_ms(1);
		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	}
	//GroupB
	if (1)
	{
		//C_VST_VS1_Connect;
		//delay_ms(1);
		F_VST.Set(FV, 3, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		//Test_Leak(A_QST, V_QST, res_B[0], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//SERIAL res_B[0][SITE]=0;
		//C_VST_VS1_DisConnect;
		C_SW1_SW2_Connect;
		C_FPVIH_SW_Connect;
		C_FPVIH_VS1_Connect;
		C_FPVIL_AG_Connect;
		delay_ms(1);
		Test_Leak(fpvi0, V_SW1, res_B[1], FPVIe_10V, FPVIe_1MA);
		Copy_Array(res_B[2], res_B[1]);//sw2
		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		delay_ms(2);
		//F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
		C_SW1_SW2_DisConnect;
		C_FPVIH_SW_DisConnect;
		C_FPVIH_VS1_DisConnect;
		C_FPVIL_AG_DisConnect;
		delay_ms(1);
		if(PN_Posbk_Available)
		{
			if (max_temp < 0){ F_VST.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON); }
			A_POSSW.Set(FV, V_POSIN, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON,2);
			Test_Leak(A_POSIN, V_POSIN, res_A[7], ACM200_10V, ACM200_1MA);
			A_POSIN.Set(FV, V_POSSW, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
			Test_Leak(A_POSSW, V_POSSW, res_B[3], ACM200_10V, ACM200_1MA);
			Test_Leak(A_POSFB, V_POSFB, res_B[4], ACM200_10V, ACM200_1MA);
			A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
			A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
			F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
			delay_ms(2);
		}
		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
		//C_QUC_SQUC_Connect;
		//C_FXVI_FB_Connect;
		//delay_ms(1);
		//F_FB.Set(FV, V_QUC, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		//delay_ms(1);
		//Test_Leak(A_QUC, V_QUC, res_B[6], ACM200_10V, ACM200_1MA, ACM200_1MA);
		//Copy_Array(res_B[5], res_B[6]);//squc
		//C_QUC_SQUC_DisConnect;
		//delay_ms(1);
		//F_FB.Set(FV, V_QVR, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		//Test_Leak(A_QVR, V_QVR, res_B[7], ACM200_10V, ACM200_10MA, ACM200_10MA);//acm3
		//F_FB.Set(FV, V_QCO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		//Test_Leak(A_QCO, V_QCO, res_B[8], ACM200_10V, ACM200_1MA, ACM200_1MA);
		//F_FB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		//F_FB.Set(FV, V_QCO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
		//C_FXVI_FB_DisConnect;
		//delay_ms(1);
		C_QT1_SQT1_Connect;
		delay_ms(1);
		Test_Leak(F_QT1, V_QT1, res_B[10], FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_1MA);
		Copy_Array(res_B[9], res_B[10]);//sqt1
		//vicurve_v(F_QT1, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, 0, -3);
		Test_Leak(F_QT1, -2, qt1_nleak, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_1MA);
		C_QT1_SQT1_DisConnect;
		C_QT2_SQT2_Connect;
		delay_ms(1);
		Test_Leak(F_QT2, V_QT2, res_B[12], FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_1MA);
		Test_Leak(F_QT2, -2, qt2_nleak, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_1MA);
		Copy_Array(res_B[11], res_B[12]);//sqt2
		C_QT2_SQT2_DisConnect;
		Test_Leak(F_QT3, V_QT3, res_B[13], FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_1MA);
		Test_Leak(F_QT3, -2, qt3_nleak, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_1MA);
	}
	//GroupC
	if (1)
	{
		C_FXVI_BATSNS1_Connect;
		delay_ms(1);
		Test_Leakf(F_BATS1, V_BATSNS1, res_C[0], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		Test_Leakf(F_BATS1, -2, batsns1_nleak, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_BATSNS1_DisConnect;
		delay_ms(1);
		C_FXVI_BATSNS2_Connect;
		delay_ms(1);
		Test_Leakf(F_BATS2, V_BATSNS2, res_C[1], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		Test_Leakf(F_BATS2, -2, batsns2_nleak, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_BATSNS2_DisConnect;
		delay_ms(1);
		C_FXVI_RSH_Connect;
		delay_ms(1);
		Test_Leak(F_RSH, V_RSH, res_C[2], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_RSH_DisConnect;
		delay_ms(1);
		C_FXVI_RSL_Connect;
		delay_ms(1);
		Test_Leak(F_RSL, V_RSL, res_C[3], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_RSL_DisConnect;
		delay_ms(1);
		if(PN_VCI_Available)//vci/vmon
		{
			C_ACM_VCI_Connect;
			delay_ms(1);
			Test_Leak(A_VCI, V_VCI, res_C[4], ACM200_10V, ACM200_1MA);
			C_ACM_VCI_DisConnect;
			delay_ms(1);
		}
		else
		{
			C_ACM_VMON_Connect;
			delay_ms(1);
			Test_Leak(A_VMON, V_VMON, res_C[5], ACM200_10V, ACM200_1MA);
			C_ACM_VMON_DisConnect;
			delay_ms(1);
		}
		C_ACM_NC_Connect;
		delay_ms(1);
		Test_Leak(A_NC, V_NC, res_C[6], ACM200_10V, ACM200_1MA, ACM200_10UA);
		C_ACM_NC_DisConnect;
		delay_ms(1);
		if(PN_SEC_Available)//sec,amux
		{
			C_ACM_SEC_Connect;
			delay_ms(1);
			Test_Leak(A_SEC, V_SEC, res_C[7], ACM200_10V, ACM200_1MA, ACM200_1MA);
			C_ACM_SEC_DisConnect;
			delay_ms(1);
		}
		else
		{
			C_ACM_AMUX_Connect;
			delay_ms(1);
			Test_Leak(A_AMUX, V_AMUX, res_C[8], ACM200_10V, ACM200_10MA, ACM200_10MA);
			C_ACM_AMUX_DisConnect;
			delay_ms(1);
		}
		C_DBUFI_FRE;
		C_ACM_DBUFO_Connect;
		delay_ms(1);
		Test_Leak(A_DBUFO, V_FRE, res_C[9], ACM200_10V, ACM200_1MA, ACM200_10UA);
		C_DBUFI_DisConnect;
		C_ACM_DBUFO_DisConnect;
		delay_ms(1);
		if (PINarray[28].pin_valid)//syn
		{
			//C_ACM_SYN_Connect;
			//delay_ms(1);
			//Test_Leak(A_SYN, V_SYN, res_C[12], ACM200_10V, ACM200_1MA);
			//C_ACM_SYN_DisConnect;
			//delay_ms(1);
		}
		if (PINarray[27].pin_valid)//evs
		{
			C_ACM_EVS_Connect;
			delay_ms(1);
			Test_Leak(A_EVS, V_EVS, res_C[13], ACM200_10V, ACM200_1MA, ACM200_10UA);
			C_ACM_EVS_DisConnect;
			delay_ms(1);
		}
		if (PINarray[29].pin_valid)//ssd
		{
			C_ACM_SSD_Connect;
			delay_ms(1);
			Test_Leak(A_SSD, V_SSD, res_C[14], ACM200_10V, ACM200_1MA);
			C_ACM_SSD_DisConnect;
			delay_ms(1);
		}
		if(PN_SEC_Available)//no posfre, has evc
		{
			//C_ACM_EVC_Connect;
			//delay_ms(1);
			//Test_Leak(A_EVC, V_EVC, res_C[10], ACM200_10V, ACM200_100MA, ACM200_100MA);
			//C_ACM_EVC_DisConnect;
			//delay_ms(1);
		}
		else//posfre
		{
			C_ACM_POSFRE_Connect;
			delay_ms(1);
			Test_Leak(A_POSFRE, V_POSFRE, res_C[11], ACM200_10V, ACM200_1MA, ACM200_10UA);
			C_ACM_POSFRE_DisConnect;
			delay_ms(1);
		}
		C_FXVI_ENA_Connect;
		delay_ms(1);
		Test_Leak(F_ENA, V_ENA, res_C[15], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_ENA_DisConnect;
		delay_ms(1);
		C_FXVI_WAK_Connect;
		delay_ms(1);
		Test_Leak(F_WAK, V_WAK, res_C[16], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_WAK_DisConnect;
		delay_ms(1);
		C_FXVI_WDI_Connect;
		delay_ms(1);
		Test_Leak(F_WDI, V_WDI, res_C[17], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_WDI_DisConnect;
		delay_ms(1);
		C_ACM_STU_Connect;
		delay_ms(1);
		Test_Leak(A_STU, V_STU, res_C[18], ACM200_10V, ACM200_1MA, ACM200_10UA);
		C_ACM_STU_DisConnect;
		delay_ms(1);
		C_FXVI_ERR_Connect;
		delay_ms(1);
		Test_Leak(F_ERR, V_ERR, res_C[19], FXVIe_PLUS_10V, FXVIe_PLUS_1MA);
		C_FXVI_ERR_DisConnect;
		delay_ms(1);
		C_FXVI_SCS_Connect;
		delay_ms(1);
		Test_Leak(F_SCS, V_SCS, res_C[20], FXVIe_PLUS_10V, FXVIe_PLUS_1MA);
		C_FXVI_SCS_DisConnect;
		delay_ms(1);
		C_FXVI_SCL_Connect;
		delay_ms(1);
		Test_Leak(F_SCL, V_SCL, res_C[21], FXVIe_PLUS_10V, FXVIe_PLUS_1MA);
		C_FXVI_SCL_DisConnect;
		delay_ms(1);
		C_FXVI_SDI_Connect;
		delay_ms(1);
		Test_Leak(F_SDI, V_SDI, res_C[22], FXVIe_PLUS_10V, FXVIe_PLUS_10MA);
		C_FXVI_SDI_DisConnect;
		delay_ms(1);
		C_ACM_MPS_Connect;
		delay_ms(1);
		Test_Leak(A_MPS, V_MPS, res_C[23], ACM200_10V, ACM200_1MA, ACM200_1MA);
		C_ACM_MPS_DisConnect;
		delay_ms(1);
	}
	//GroupD
	if (1)
	{
		C_FXVI_ROT_Connect;
		delay_ms(1);
		Test_Leak(F_ROT, V_ROT, res_D[1], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_1MA);
		C_FXVI_ROT_DisConnect;
		delay_ms(1);
		C_FXVI_INT_Connect;
		C_ACM_FB1_Connect;
		delay_ms(1);
		A_FB1.Set(FV, 3.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		Test_Leak(F_INT, V_INT, res_D[2], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_1MA);//fb=0,current clamp
		A_FB1.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		C_FXVI_INT_DisConnect;
		C_ACM_FB1_DisConnect;
		delay_ms(1);
		C_FXVI_SS1_Connect;
		delay_ms(1);
		A_QUC.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		Test_Leak(F_SS1, V_SS1, res_D[3], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_1MA);
		C_FXVI_SS1_DisConnect;
		delay_ms(1);
		C_FXVI_SS2_Connect;
		delay_ms(1);
		Test_Leak(F_SS2, V_SS2, res_D[4], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_1MA);
		A_QUC.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		C_FXVI_SS2_DisConnect;
		delay_ms(1);
		C_FXVI_SDO_Connect;
		C_ACM_FB1_Connect;
		delay_ms(1);
		A_FB1.Set(FV, 3.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		Test_Leak(F_SDO, V_SDO, res_D[5], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_1MA);//fb=0,current clamp
		A_FB1.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		C_FXVI_SDO_DisConnect;
		C_ACM_FB1_DisConnect;
		delay_ms(1);
		C_FXVI_TPAD_Connect;
		C_TP_GND_DisConnect;
		delay_ms(1);
		Test_Leak(F_TPAD, V_TP, res_D[6], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_TPAD_DisConnect;
		C_TP_GND_Connect;
		delay_ms(1);
	}
	C_AGS_BSG_PG_POSG_GND_Connect;
	C_All_Open;
	all_resource_off();
	for (int i = 0; i < 8; i++) { SERIAL{ Result[i][SITE] = res_A[i][SITE]; } }
	for (int i = 0; i < 14; i++) { SERIAL{ Result[i + 8][SITE] = res_B[i][SITE]; } }
	for (int i = 0; i < 24; i++) { SERIAL{ Result[i + 8 + 14][SITE] = res_C[i][SITE]; } }
	for (int i = 0; i < 7; i++) { SERIAL{ Result[i + 8 + 14 + 24][SITE] = res_D[i][SITE]; } }
}

void leak_getdata(double Result[][SITE_NUM], bool first)
{
	/////////0,		1,		2,		3,		4,		5,		6,		7,		8,		9
	//00-09//VST,	VS1,	VS2,	FB1,	FB2,	FB3,	FB4,	POSIN,	QST,	SW1
	//10-19//SW2,	POSSW,	POSFB,	SQUC,	QUC,	QVR,	QCO,	SQT1,	QT1,	SQT2
	//20-29//QT2,	QT3,	BATSNS1,BATSNS2,RSH,	RSL,	VCI,	VMON,	NC,		SEC
	//30-39//AMUX,	FRE,	EVC,	POSFRE,	SYN,	EVS,	SSD,	ENA,	WAK,	WDI
	//40-49//STU,	ERR,	SCS,	SCL,	SDI,	MPS,	DRG,	ROT,	INT,	SS1
	//50-59//SS2,	SDO,	TP

	//A,VST,VS1,VS2,FB1,FB2,FB3,FB4,POSIN
	//B,QST,SW1,SW2,POSSW,POSFB,SQUC,QUC,QVR,QCO,SQT1,QT1,SQT2,QT2,QT3
	//C,BATSNS1,BATSNS2,RSH,RSL,VCI/VMON,NC,SEC/AMUX,FRE,EVC/POSFRE,SYN/EVS/SSD,ENA,WAK,WDI,STU,INT,ERR,SCS,SCL,SDI,MPS
	//D,DRG,ROT,SS1,SS2,SDO

	//SYN/EVS/SSD
	//VCI/VMON
	//SEC/AMUX
	//EVC/POSFRE

	SERIAL
	{
		PINarray[0].pin_leak[SITE] = Result[2][SITE];//VS2
		PINarray[1].pin_leak[SITE] = Result[1][SITE];//VS1
		PINarray[2].pin_leak[SITE] = Result[9][SITE];//SW1
		PINarray[3].pin_leak[SITE] = Result[10][SITE];//SW2
		PINarray[4].pin_leak[SITE] = Result[22][SITE];//BATSNS1
		PINarray[5].pin_leak[SITE] = Result[23][SITE];//BATSNS2
		PINarray[6].pin_leak[SITE] = Result[46][SITE];//DRG
		PINarray[7].pin_leak[SITE] = Result[24][SITE];//RSH
		PINarray[8].pin_leak[SITE] = Result[25][SITE];//RSL
		PINarray[9].pin_leak[SITE] = 0;//BSG
		PINarray[10].pin_leak[SITE] = Result[0][SITE]/1000.0;//VST
		PINarray[11].pin_leak[SITE] = Result[37][SITE];//ENA
		PINarray[12].pin_leak[SITE] = Result[38][SITE];//WAK
		PINarray[13].pin_leak[SITE] = Result[8][SITE];//QST
		PINarray[14].pin_leak[SITE] = 0;//AG1
		PINarray[15].pin_leak[SITE] = 0;//AG2
		PINarray[16].pin_leak[SITE] = 0;//AGS1
		PINarray[17].pin_leak[SITE] = 0;//AGS2
		PINarray[18].pin_leak[SITE] = Result[50][SITE];//SS2
		PINarray[19].pin_leak[SITE] = Result[49][SITE];//SS1
		PINarray[20].pin_leak[SITE] = Result[44][SITE];//SDI
		PINarray[21].pin_leak[SITE] = Result[51][SITE];//SDO
		PINarray[22].pin_leak[SITE] = Result[43][SITE];//SCL
		PINarray[23].pin_leak[SITE] = Result[42][SITE];//SCS
		PINarray[24].pin_leak[SITE] = Result[39][SITE];//WDI
		PINarray[25].pin_leak[SITE] = Result[47][SITE];//ROT
		PINarray[26].pin_leak[SITE] = Result[48][SITE];//INT
		PINarray[27].pin_leak[SITE] = Result[35][SITE];//EVS
		PINarray[28].pin_leak[SITE] = Result[34][SITE];//SYN
		PINarray[29].pin_leak[SITE] = Result[36][SITE];//SSD
		PINarray[30].pin_leak[SITE] = Result[41][SITE];//ERR
		PINarray[31].pin_leak[SITE] = Result[32][SITE];//EVC
		PINarray[32].pin_leak[SITE] = Result[33][SITE];//POSFRE
		PINarray[33].pin_leak[SITE] = Result[31][SITE];//FRE
		PINarray[34].pin_leak[SITE] = Result[45][SITE];//MPS
		PINarray[35].pin_leak[SITE] = Result[29][SITE];//SEC
		PINarray[36].pin_leak[SITE] = Result[30][SITE]/1000.0;//AMUX
		PINarray[37].pin_leak[SITE] = Result[26][SITE];//VCI
		PINarray[38].pin_leak[SITE] = Result[27][SITE];//VMON
		PINarray[39].pin_leak[SITE] = Result[40][SITE];//STU
		PINarray[40].pin_leak[SITE] = 0;//AG3
		PINarray[41].pin_leak[SITE] = Result[15][SITE];//QVR
		PINarray[42].pin_leak[SITE] = Result[14][SITE];//QUC
		PINarray[43].pin_leak[SITE] = Result[13][SITE];//SQUC
		PINarray[44].pin_leak[SITE] = Result[16][SITE];//QCO
		PINarray[45].pin_leak[SITE] = Result[20][SITE];//QT2
		PINarray[46].pin_leak[SITE] = Result[19][SITE];//SQT2
		PINarray[47].pin_leak[SITE] = Result[18][SITE];//QT1
		PINarray[48].pin_leak[SITE] = Result[17][SITE];//SQT1
		PINarray[49].pin_leak[SITE] = Result[21][SITE];//QT3
		PINarray[50].pin_leak[SITE] = 0;//POSG
		PINarray[51].pin_leak[SITE] = Result[11][SITE];//POSSW
		PINarray[52].pin_leak[SITE] = Result[7][SITE];//POSIN
		PINarray[53].pin_leak[SITE] = Result[12][SITE];//POSFB
		PINarray[54].pin_leak[SITE] = Result[3][SITE];//FB1
		PINarray[55].pin_leak[SITE] = Result[4][SITE];//FB2
		PINarray[56].pin_leak[SITE] = Result[5][SITE];//FB3
		PINarray[57].pin_leak[SITE] = Result[6][SITE];//FB4
		PINarray[58].pin_leak[SITE] = 0;//AG4
		PINarray[59].pin_leak[SITE] = 0;//PG2
		PINarray[60].pin_leak[SITE] = 0;//PG1
		PINarray[61].pin_leak[SITE] = Result[52][SITE];//TP
		PINarray[62].pin_leak[SITE] = Result[28][SITE];//NC
		PINarray[63].pin_leak[SITE] = Result[0][SITE];//
		PINarray[64].pin_leak[SITE] = Result[0][SITE];//
		PINarray[65].pin_leak[SITE] = Result[0][SITE];//
		PINarray[66].pin_leak[SITE] = Result[0][SITE];//
		PINarray[67].pin_leak[SITE] = Result[0][SITE];//
		PINarray[68].pin_leak[SITE] = Result[0][SITE];//
		PINarray[69].pin_leak[SITE] = Result[0][SITE];//
		PINarray[70].pin_leak[SITE] = Result[0][SITE];//
		PINarray[71].pin_leak[SITE] = Result[0][SITE];//
		PINarray[72].pin_leak[SITE] = Result[0][SITE];//
		PINarray[73].pin_leak[SITE] = Result[0][SITE];//
		PINarray[74].pin_leak[SITE] = Result[0][SITE];//
		PINarray[75].pin_leak[SITE] = Result[0][SITE];//
		PINarray[76].pin_leak[SITE] = Result[0][SITE];//
		PINarray[77].pin_leak[SITE] = Result[0][SITE];//
		PINarray[78].pin_leak[SITE] = Result[0][SITE];//
		PINarray[79].pin_leak[SITE] = Result[0][SITE];//
		PINarray[80].pin_leak[SITE] = Result[0][SITE];//
		PINarray[81].pin_leak[SITE] = Result[0][SITE];//
		PINarray[82].pin_leak[SITE] = Result[0][SITE];//
		PINarray[83].pin_leak[SITE] = Result[0][SITE];//
		PINarray[84].pin_leak[SITE] = Result[0][SITE];//
		PINarray[85].pin_leak[SITE] = Result[0][SITE];//
		PINarray[86].pin_leak[SITE] = Result[0][SITE];//
		PINarray[87].pin_leak[SITE] = Result[0][SITE];//
		PINarray[88].pin_leak[SITE] = Result[0][SITE];//
		PINarray[89].pin_leak[SITE] = Result[0][SITE];//
		PINarray[80].pin_leak[SITE] = Result[0][SITE];//
		PINarray[91].pin_leak[SITE] = Result[0][SITE];//
		PINarray[92].pin_leak[SITE] = Result[0][SITE];//
		PINarray[93].pin_leak[SITE] = Result[0][SITE];//
		PINarray[94].pin_leak[SITE] = Result[0][SITE];//
		PINarray[95].pin_leak[SITE] = Result[0][SITE];//
		PINarray[96].pin_leak[SITE] = Result[0][SITE];//
		PINarray[97].pin_leak[SITE] = Result[0][SITE];//
	}
	for (int i = 0; i < PIN_Count; i++)
	{
		if(first) 
		{ 
			SERIAL PINarray[i].pin_leak_pre[SITE] = PINarray[i].pin_leak[SITE] * 1000000.0; 
		}
		else
		{ 
			SERIAL PINarray[i].pin_leak_post[SITE] = PINarray[i].pin_leak[SITE] * 1000000.0; 
			SERIAL PINarray[i].pin_leak_delt[SITE] = PINarray[i].pin_leak_post[SITE] - PINarray[i].pin_leak_pre[SITE]; 
		}
	}
}

void leak_datalog(short funcindex, bool first)
{
	//bypass pin list
	//qst,13
	//fb,54,55,56,57
	//quc,42,43
	//qvr,41,
	//qco,44
	//evc,31
	//syn,28
	for (int i = 0; i < PIN_Count-1; i++)
	{
		if ((PINarray[i].pin_valid)&&(PINarray[i].diode))
		{
			if(first)
			{
				//SERIAL StsGetParam(funcindex, PINarray[i].name_leak.c_str())->SetTestResult(SITE, 0, PINarray[i].pin_leak_pre[SITE]);
				Ms_LogData(funcindex, PINarray[i].name_leak.c_str(), PINarray[i].pin_leak_pre);
			}
			else
			{
				//SERIAL StsGetParam(funcindex, PINarray[i].name_leak.c_str())->SetTestResult(SITE, 0, PINarray[i].pin_leak_post[SITE]);
				//SERIAL StsGetParam(funcindex, PINarray[i].name_leak_delt.c_str())->SetTestResult(SITE, 0, PINarray[i].pin_leak_delt[SITE]);
				Ms_LogData(funcindex, PINarray[i].name_leak.c_str(), PINarray[i].pin_leak_post);
				Ms_LogData(funcindex, PINarray[i].name_leak_delt.c_str(), PINarray[i].pin_leak_delt);
			}
		}
	}
	SERIAL qt1_nleak[SITE] = qt1_nleak[SITE] * 1000000.0; 
	SERIAL qt2_nleak[SITE] = qt2_nleak[SITE] * 1000000.0; 
	SERIAL qt3_nleak[SITE] = qt3_nleak[SITE] * 1000000.0; 
	SERIAL batsns1_nleak[SITE] = batsns1_nleak[SITE] * 1000000.0; 
	SERIAL batsns2_nleak[SITE] = batsns2_nleak[SITE] * 1000000.0; 
	if(first)
	{
		Ms_LogData(funcindex, "LEAK_QT1N", qt1_nleak);
		Ms_LogData(funcindex, "LEAK_QT2N", qt2_nleak);
		if(PN_Tracker_Num==3){Ms_LogData(funcindex, "LEAK_QT3N", qt3_nleak);}
		Ms_LogData(funcindex, "LEAK_BATSNS1N", batsns1_nleak);
		Ms_LogData(funcindex, "LEAK_BATSNS2N", batsns2_nleak);
	}
	else
	{
		Ms_LogData(funcindex, "LEAK_QT1N", qt1_nleak);
		Ms_LogData(funcindex, "LEAK_QT2N", qt2_nleak);
		if(PN_Tracker_Num==3){Ms_LogData(funcindex, "LEAK_QT3N", qt3_nleak);}
		Ms_LogData(funcindex, "LEAK_BATSNS1N", batsns1_nleak);
		Ms_LogData(funcindex, "LEAK_BATSNS2N", batsns2_nleak);
	}
}

void abs_test(double Result[][SITE_NUM])
{
	bool use_ldo = true;
	double vldo = 4.8;

	//42V
	double DefaultN18V = -18;
	double DefaultN5V = -5;
	double VN18=DefaultN18V;
	double VN5=DefaultN5V;
	double Default42V = 42;
	double V42=Default42V;
	if(use_ldo)
	{
		V42=Default42V-vldo;
		VN18=DefaultN18V-vldo;
		VN5=DefaultN5V-vldo;
	}
	double V_BATSNS1	= V42;//BATSNS1
	double V_BATSNS2	= V42;//BATSNS2
	double V_QT1		= V42;//QT1
	double V_SQT1		= V42;//SQT1
	double V_QT2		= V42;//QT2
	double V_SQT2		= V42;//SQT2
	double V_QT3		= V42;//QT3
	double V_VS1		= V42;//VS1
	double V_VS2		= V42;//VS2
	double V_VST		= V42;//VST
	double V_SW1		= V42;//SW1
	double V_SW2		= V42;//SW2
	double V_DRG		= V42;//DRG
	double V_RSH		= V42;//RSH
	double V_WAK		= V42;//WAK
	double V_ENA		= V42;//ENA
	double V_ERR		= V42;//ERR
	double V_INT		= V42;//INT
	double V_ROT		= V42;//ROT
	double V_WDI		= V42;//WDI
	double V_SCS		= V42;//SCS
	double V_SCL		= V42;//SCL
	double V_SDI		= V42;//SDI
	double V_SDO		= V42;//SDO
	double V_SS1		= V42;//SS1
	double V_SS2		= V42;//SS2
	double V_SSD		= V42;//SSD,share with SYN
	double V_EVS		= V42;//EVS,share with SYN
	//8V
	double Default8V = 8;
	double V8=Default8V;
	if(use_ldo){V8=Default8V-vldo;}
	double V_FB1		= V8;//FB1
	double V_FB2		= V8;//FB2
	double V_FB3		= V8;//FB3
	double V_FB4		= V8;//FB4
	double V_POSIN		= V8;//POSIN
	double V_POSSW		= V8;//POSSW
	//6V
	double V6=6;
	if(use_ldo){V6=6-vldo;}
	double V_POSFB		= V6;//POSFB
	double V_QUC		= V6;//QUC
	double V_SQUC		= V6;//SQUC
	double V_QCO		= V6;//QCO
	double V_QVR		= V6;//QVR
	double V_QST		= V6;//QST
	double V_RSL		= V6;//RSL
	double V_MPS		= V6;//MPS
	double V_STU		= V6;//STU
	double V_FRE		= V6;//FRE
	double V_SEC		= V6;//SEC
	double V_SYN		= V6;//SYN share with EVS,SSD
	double V_EVC		= V6;//EVC
	double V_VCI		= V6;//VCI
	double V_VMON		= V6;//VMON
	double V_AMUX		= V6;//AMUX
	double V_POSFRE		= V6;//POSFRE
	//
	double V0=0;
	if(use_ldo){V0=0-vldo;}
	double V_BSG		= V0;//BSG----------
	double V_AGS1		= V0;//AGS1----------
	double V_AGS2		= V0;//AGS2----------
	double V_PG1		= V0;//PG1----------
	double V_PG2		= V0;//PG2----------
	double V_POSG		= V0;//POSG----------

	double V_AG1		= 0;//AG1----------
	double V_AG2		= 0;//AG2----------
	double V_AG3		= 0;//AG3----------
	double V_AG4		= 0;//AG4----------

	double V5=5;
	if(use_ldo){V5=5-vldo;}
	double V_TP			= V5;//TP
	double V_NC			= V5;//NC

	double res_A[8][SITE_NUM] = { 0 };//8
	double res_B[14][SITE_NUM] = { 0 };//14
	double res_C[24][SITE_NUM] = { 0 };//25
	double res_D[7][SITE_NUM] = { 0 };//6

	double result[SITE_NUM];

	C_All_Open;
	all_resource_off();
	dcm.Disconnect("DCM_ALL");
	delay_ms(1);
	if(use_ldo){C_FXVI_ACM_LDO_Connect;delay_ms(2);LSI_LDO(true);}
	else{C_FXVI_ACM_GND_Connect;}
	C_AGS_BSG_PG_POSG_GND_Connect;
	//A,VST,VS1,VS2,FB1,FB2,FB3,FB4,POSIN
	//B,QST,SW1,SW2,POSSW,POSFB,SQUC,QUC,QVR,QCO,SQT1,QT1,SQT2,QT2,QT3
	//C,BATSNS1,BATSNS2,RSH,RSL,VCI/VMON,NC,SEC/AMUX,FRE,EVC/POSFRE,SYN/EVS/SSD,ENA,WAK,WDI,STU,INT,ERR,SCS,SCL,SDI,MPS
	//D,DRG,ROT,INT,SS1,SS2,SDO,TP

	F_VST.Set(FV, 3, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(2);
	F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	//GroupA
	if (1)
	{
		C_FXVI_DRG_Connect;//44k,
		delay_ms(1);
		Test_Leak(F_DRG, V_DRG, res_D[0], FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);
		C_FXVI_DRG_DisConnect;
		delay_ms(1);

		C_ACM_FB1_Connect;
		delay_ms(1);
		Test_Leak(A_FB1, V_FB1, res_A[3], ACM200_10V, ACM200_100MA, ACM200_100MA);
		Test_Leak(A_FB1, V_FB1, res_A[3], ACM200_10V, ACM200_100MA, ACM200_100MA);
		delay_ms(1);
		//fpvi0.Set(FV, 0, FPVIe_10V, FPVIe_10MA, FPVIe_RELAY_ON);
		Test_Leak(A_FB1, V_FB1, res_A[3], ACM200_10V, ACM200_100MA, ACM200_100MA);
		C_ACM_FB1_DisConnect;
		delay_ms(1);
		C_ACM_FB2_Connect;
		delay_ms(1);
		Test_Leak(A_FB2, V_FB2, res_A[4], ACM200_10V, ACM200_100MA, ACM200_100MA);
		C_ACM_FB2_DisConnect;
		delay_ms(1);
		C_ACM_FB3_Connect;
		delay_ms(1);
		Test_Leak(A_FB3, V_FB3, res_A[5], ACM200_10V, ACM200_100MA, ACM200_100MA);
		C_ACM_FB3_DisConnect;
		delay_ms(1);
		C_ACM_FB4_Connect;
		delay_ms(1);
		Test_Leak(A_FB4, V_FB4, res_A[6], ACM200_10V, ACM200_100MA, ACM200_100MA);
		fpvi0.Set(FV, 0, FPVIe_10V, FPVIe_10MA, FPVIe_RELAY_OFF);
		C_ACM_FB4_DisConnect;
		delay_ms(1);

		C_FPVIL_AG_Connect;
		C_FPVIH_VST_Connect;
		delay_ms(1);
		V_VST = Default42V;
		Test_Leak(fpvi0, V_VST, res_A[0], FPVIe_100V, FPVIe_10MA, FPVIe_10MA);
		C_FPVIH_VST_DisConnect;
		delay_ms(1);
		C_FPVIH_VS1_Connect;
		//C_FPVIH_SW_Connect;
		delay_ms(1);
		V_VS1 = Default42V;
		F_VST.Set(FV, 5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		Test_Leak(fpvi0, V_VS1, res_A[1], FPVIe_100V, FPVIe_1MA);
		//fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_10MA, FPVIe_RELAY_ON);
		//fpvi0.Set(FV, V_VS1, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_ON);
		//delay_ms(2);
		//fpvi0.Set(FV, V_VS1, FPVIe_100V, FPVIe_100UA, FPVIe_RELAY_ON);
		//delay_ms(3);
		//fpvi0.MeasureVI(100, 10);
		//Get_Result(fpvi0, res_A[1], MIRET);
		//fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_10MA, FPVIe_RELAY_ON);
		//delay_ms(1);
		//fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_10MA, FPVIe_RELAY_OFF);
		C_FPVIH_VS1_DisConnect;
		//C_FPVIH_SW_DisConnect;
		C_FPVIL_AG_DisConnect;
		delay_ms(1);
		C_FXVI_VS2_Connect;
		Test_Leakf(F_VS2, V_VS2, res_A[2], FXVIe_PLUS_40V, FXVIe_PLUS_1MA);
		C_FXVI_VS2_DisConnect;
		delay_ms(1);
		//C_ACM_FB1_Connect;
		//C_FPVIH_VST_Connect;
		//C_FPVIL_AG_Connect;
		//delay_ms(1);
		//fpvi0.Set(FV, 0, FPVIe_10V, FPVIe_10MA, FPVIe_RELAY_ON);
		//Test_Leak(A_FB1, V_FB1, res_A[3], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//C_ACM_FB1_DisConnect;
		//delay_ms(1);
		//C_ACM_FB2_Connect;
		//delay_ms(1);
		//Test_Leak(A_FB2, V_FB2, res_A[4], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//C_ACM_FB2_DisConnect;
		//delay_ms(1);
		//C_ACM_FB3_Connect;
		//delay_ms(1);
		//Test_Leak(A_FB3, V_FB3, res_A[5], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//C_ACM_FB3_DisConnect;
		//delay_ms(1);
		//C_ACM_FB4_Connect;
		//delay_ms(1);
		//Test_Leak(A_FB4, V_FB4, res_A[6], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//fpvi0.Set(FV, 0, FPVIe_10V, FPVIe_10MA, FPVIe_RELAY_OFF);
		//C_ACM_FB4_DisConnect;
		//delay_ms(1);
		//C_ACM_FB1_Connect;
		//delay_ms(1);
		//C_FPVIH_VST_DisConnect;
		C_FPVIL_AG_DisConnect;
		delay_ms(1);
		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	}
	//GroupB
	if (1)
	{
		//C_VST_VS1_Connect;
		//delay_ms(1);
		F_VST.Set(FV, 3, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		//Test_Leak(A_QST, V_QST, res_B[0], ACM200_10V, ACM200_100MA, ACM200_100MA);
		//SERIAL res_B[0][SITE]=0;
		//C_VST_VS1_DisConnect;
		C_SW1_SW2_Connect;
		C_FPVIH_SW_Connect;
		C_FPVIH_VS1_Connect;
		C_FPVIL_AG_Connect;
		delay_ms(1);
		V_SW1 = Default42V;
		Test_Leak(fpvi0, V_SW1, res_B[1], FPVIe_100V, FPVIe_1MA);
		Copy_Array(res_B[2], res_B[1]);//sw2

		//SW1 BV
		double bv_sw1[SITE_NUM];
		fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_ON);
		//vicurve_v(fpvi0, FPVIe_100V, FPVIe_10MA, 0, 65);
		fpvi0.Set(FI, 1 mA, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_ON);
		delay_ms(1);
		fpvi0.MeasureVI(20,10);
		Get_Result(fpvi0, prebk_bv_ls, MVRET);
		fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_ON);
		fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_OFF);

		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
		F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
		C_SW1_SW2_DisConnect;
		C_FPVIH_SW_DisConnect;
		C_FPVIH_VS1_DisConnect;
		C_FPVIL_AG_DisConnect;
		delay_ms(1);
		if(PN_Posbk_Available)
		{
			C_FPVIH_POSIN_Connect;
			C_FPVIL_AG_Connect;
			delay_ms(1);
			V_POSIN = Default8V;
			Test_Leak(fpvi0, V_POSIN, res_A[7], FPVIe_10V, FPVIe_1MA);
			C_FPVIH_POSSW_Connect;
			delay_ms(1);
			V_POSSW = Default8V;
			Test_Leak(fpvi0, V_POSSW, res_B[3], FPVIe_10V, FPVIe_1MA);

			//POSSW BV
			double bv_sw1[SITE_NUM];
			fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_ON);
			//vicurve_v(fpvi0, FPVIe_100V, FPVIe_10MA, 0, 15);
			fpvi0.Set(FI, 1 mA, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_ON);
			delay_ms(1);
			fpvi0.MeasureVI(20,10);
			Get_Result(fpvi0, posbk_bv_ls, MVRET);
			fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_ON);
			fpvi0.Set(FV, 0, FPVIe_100V, FPVIe_1MA, FPVIe_RELAY_OFF);

			C_FPVIH_POSSW_DisConnect;
			C_FPVIH_POSIN_DisConnect;
			C_FPVIL_AG_DisConnect;
			delay_ms(1);
			Test_Leak(A_POSFB, V_POSFB, res_B[4], ACM200_10V, ACM200_1MA);
		}
		//C_QUC_SQUC_Connect;
		//C_FXVI_FB_Connect;
		//delay_ms(1);
		//F_FB.Set(FV, V_QUC, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		//delay_ms(1);
		//Test_Leak(A_QUC, V_QUC, res_B[6], ACM200_10V, ACM200_1MA, ACM200_1MA);
		//Copy_Array(res_B[5], res_B[6]);//squc
		//C_QUC_SQUC_DisConnect;
		//delay_ms(1);
		//F_FB.Set(FV, V_QVR, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		//Test_Leak(A_QVR, V_QVR, res_B[7], ACM200_10V, ACM200_10MA, ACM200_10MA);//acm3
		//F_FB.Set(FV, V_QCO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		//Test_Leak(A_QCO, V_QCO, res_B[8], ACM200_10V, ACM200_1MA, ACM200_1MA);
		//F_FB.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		//F_FB.Set(FV, V_QCO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);+
		//C_FXVI_FB_DisConnect;
		//delay_ms(1);
		C_QT1_SQT1_Connect;
		delay_ms(1);
		Test_Leak(F_QT1, V_QT1, res_B[10], FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);
		Copy_Array(res_B[9], res_B[10]);//sqt1
		if(DO_ABSN){Test_Leak(F_QT1, VN18, qt1_nleak, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);}
		C_QT1_SQT1_DisConnect;
		C_QT2_SQT2_Connect;
		delay_ms(1);
		Test_Leak(F_QT2, V_QT2, res_B[12], FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);
		if(DO_ABSN){Test_Leak(F_QT2, VN18, qt2_nleak, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);}
		Copy_Array(res_B[11], res_B[12]);//sqt2
		C_QT2_SQT2_DisConnect;
		Test_Leak(F_QT3, V_QT3, res_B[13], FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);
		if(DO_ABSN){Test_Leak(F_QT3, VN18, qt3_nleak, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);}
	}
	//GroupC
	if (1)
	{
		C_FXVI_BATSNS1_Connect;
		delay_ms(1);
		Test_Leakf(F_BATS1, V_BATSNS1, res_C[0], FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		if(DO_ABSN){Test_Leakf(F_BATS1, VN18, batsns1_nleak, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_100UA);}
		C_FXVI_BATSNS1_DisConnect;
		delay_ms(1);
		C_FXVI_BATSNS2_Connect;
		delay_ms(1);
		Test_Leakf(F_BATS2, V_BATSNS2, res_C[1], FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		if(DO_ABSN){Test_Leakf(F_BATS1, VN18, batsns2_nleak, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_100UA);}
		C_FXVI_BATSNS2_DisConnect;
		delay_ms(1);
		C_FXVI_RSH_Connect;
		delay_ms(1);
		Test_Leak(F_RSH, V_RSH, res_C[2], FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_RSH_DisConnect;
		delay_ms(1);
		C_FXVI_RSL_Connect;
		delay_ms(1);
		Test_Leak(F_RSL, V_RSL, res_C[3], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_RSL_DisConnect;
		delay_ms(1);
		if(PN_VCI_Available)//vci/vmon
		{
			C_ACM_VCI_Connect;
			delay_ms(1);
			Test_Leak(A_VCI, V_VCI, res_C[4], ACM200_10V, ACM200_1MA);
			C_ACM_VCI_DisConnect;
			delay_ms(1);
		}
		else
		{
			C_ACM_VMON_Connect;
			delay_ms(1);
			Test_Leak(A_VMON, V_VMON, res_C[5], ACM200_10V, ACM200_1MA);
			C_ACM_VMON_DisConnect;
			delay_ms(1);
		}
		C_ACM_NC_Connect;
		delay_ms(1);
		Test_Leak(A_NC, V_NC, res_C[6], ACM200_10V, ACM200_1MA, ACM200_10UA);
		C_ACM_NC_DisConnect;
		delay_ms(1);
		if(PN_SEC_Available)//sec,amux
		{
			C_ACM_SEC_Connect;
			delay_ms(1);
			Test_Leak(A_SEC, V_SEC, res_C[7], ACM200_10V, ACM200_1MA, ACM200_1MA);
			C_ACM_SEC_DisConnect;
			delay_ms(1);
		}
		else
		{
			C_ACM_AMUX_Connect;
			delay_ms(2);
			Test_Leak(A_AMUX, V_AMUX, res_C[8], ACM200_10V, ACM200_10MA, ACM200_10MA);
			C_ACM_AMUX_DisConnect;
			delay_ms(1);
		}
		C_DBUFI_FRE;
		C_ACM_DBUFO_Connect;
		delay_ms(1);
		Test_Leak(A_DBUFO, V_FRE, res_C[9], ACM200_10V, ACM200_1MA);
		C_DBUFI_DisConnect;
		C_ACM_DBUFO_DisConnect;
		delay_ms(1);
		if (PINarray[28].pin_valid)//syn
		{
			//C_ACM_SYN_Connect;
			//delay_ms(1);
			//Test_Leak(A_SYN, V_SYN, res_C[12], ACM200_10V, ACM200_1MA);
			//C_ACM_SYN_DisConnect;
			//delay_ms(1);
		}
		if (PINarray[27].pin_valid)//evs
		{
			C_ACM_EVS_Connect;
			delay_ms(1);
			Test_Leak(A_EVS, V_EVS, res_C[13], ACM200_40V, ACM200_1MA);
			C_ACM_EVS_DisConnect;
			delay_ms(1);
		}
		if (PINarray[29].pin_valid)//ssd
		{
			C_ACM_SSD_Connect;
			delay_ms(1);
			Test_Leak(A_SSD, V_SSD, res_C[14], ACM200_40V, ACM200_1MA);
			C_ACM_SSD_DisConnect;
			delay_ms(1);
		}
		if(PN_SEC_Available)//no posfre, has evc
		{
			//C_ACM_EVC_Connect;
			//delay_ms(1);
			//Test_Leak(A_EVC, V_EVC, res_C[10], ACM200_10V, ACM200_100MA, ACM200_100MA);
			//C_ACM_EVC_DisConnect;
			//delay_ms(1);
		}
		else//posfre
		{
			C_ACM_POSFRE_Connect;
			delay_ms(1);
			Test_Leak(A_POSFRE, V_POSFRE, res_C[11], ACM200_10V, ACM200_1MA);
			C_ACM_POSFRE_DisConnect;
			delay_ms(1);
		}
		C_FXVI_ENA_Connect;
		delay_ms(1);
		Test_Leak(F_ENA, V_ENA, res_C[15], FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_ENA_DisConnect;
		delay_ms(1);
		C_FXVI_WAK_Connect;
		delay_ms(1);
		Test_Leak(F_WAK, V_WAK, res_C[16], FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_WAK_DisConnect;
		delay_ms(1);
		C_FXVI_WDI_Connect;
		delay_ms(1);
		Test_Leak(F_WDI, V_WDI, res_C[17], FXVIe_PLUS_40V, FXVIe_PLUS_1MA);
		C_FXVI_WDI_DisConnect;
		delay_ms(1);
		C_ACM_STU_Connect;
		delay_ms(1);
		Test_Leak(A_STU, V_STU, res_C[18], ACM200_10V, ACM200_1MA, ACM200_10UA);
		C_ACM_STU_DisConnect;
		delay_ms(1);
		C_FXVI_ERR_Connect;
		delay_ms(1);
		Test_Leak(F_ERR, V_ERR, res_C[19], FXVIe_PLUS_40V, FXVIe_PLUS_1MA);
		C_FXVI_ERR_DisConnect;
		delay_ms(1);
		C_FXVI_SCS_Connect;
		delay_ms(1);
		Test_Leak(F_SCS, V_SCS, res_C[20], FXVIe_PLUS_40V, FXVIe_PLUS_1MA);
		C_FXVI_SCS_DisConnect;
		delay_ms(1);
		C_FXVI_SCL_Connect;
		delay_ms(1);
		Test_Leak(F_SCL, V_SCL, res_C[21], FXVIe_PLUS_40V, FXVIe_PLUS_1MA);
		C_FXVI_SCL_DisConnect;
		delay_ms(1);
		C_FXVI_SDI_Connect;
		delay_ms(1);
		Test_Leak(F_SDI, V_SDI, res_C[22], FXVIe_PLUS_40V, FXVIe_PLUS_1MA);
		C_FXVI_SDI_DisConnect;
		delay_ms(1);
		C_ACM_MPS_Connect;
		delay_ms(1);
		Test_Leak(A_MPS, V_MPS, res_C[23], ACM200_10V, ACM200_1MA, ACM200_1MA);
		C_ACM_MPS_DisConnect;
		delay_ms(1);
	}
	//GroupD
	if (1)
	{
		C_FXVI_ROT_Connect;
		delay_ms(1);
		Test_Leak(F_ROT, V_ROT, res_D[1], FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_1MA);
		C_FXVI_ROT_DisConnect;
		delay_ms(1);
		C_FXVI_INT_Connect;
		C_ACM_FB1_Connect;
		delay_ms(1);
		A_FB1.Set(FV, 3.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		Test_Leak(F_INT, V_INT, res_D[2], FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_1MA);//fb=0,current clamp
		A_FB1.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		C_FXVI_INT_DisConnect;
		C_ACM_FB1_DisConnect;
		delay_ms(1);
		//set_vst(5.0);
		//set_quc(5.0);
		C_FXVI_SS1_Connect;
		delay_ms(1);
		A_QUC.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		Test_Leak(F_SS1, V_SS1, res_D[3], FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);
		C_FXVI_SS1_DisConnect;
		delay_ms(1);
		C_FXVI_SS2_Connect;
		delay_ms(1);
		Test_Leak(F_SS2, V_SS2, res_D[4], FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);
		A_QUC.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		C_FXVI_SS2_DisConnect;
		//set_vst(false);
		//set_quc(false);
		delay_ms(1);
		C_FXVI_SDO_Connect;//42k
		C_ACM_FB1_Connect;
		delay_ms(1);
		A_FB1.Set(FV, 3.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		Test_Leak(F_SDO, V_SDO, res_D[5], FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_10MA);//fb=0,current clamp
		A_FB1.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		C_FXVI_SDO_DisConnect;
		C_ACM_FB1_DisConnect;
		delay_ms(1);
		C_FXVI_TPAD_Connect;
		C_TP_GND_DisConnect;
		delay_ms(1);
		Test_Leak(F_TPAD, V_TP, res_D[6], FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_10UA);
		C_FXVI_TPAD_DisConnect;
		C_TP_GND_Connect;
		delay_ms(1);
	}
	C_AGS_BSG_PG_POSG_GND_Connect;
	if(use_ldo){LSI_LDO(false);delay_ms(2);C_FXVI_ACM_LDO_DisConnect;}
	else{C_FXVI_ACM_GND_DisConnect;}
	for (int i = 0; i < 8; i++) { SERIAL{ Result[i][SITE] = res_A[i][SITE]; } }
	for (int i = 0; i < 14; i++) { SERIAL{ Result[i + 8][SITE] = res_B[i][SITE]; } }
	for (int i = 0; i < 24; i++) { SERIAL{ Result[i + 8 + 14][SITE] = res_C[i][SITE]; } }
	for (int i = 0; i < 7; i++) { SERIAL{ Result[i + 8 + 14 + 24][SITE] = res_D[i][SITE]; } }
}

void abs_getdata(double Result[][SITE_NUM])
{
	/////////0,		1,		2,		3,		4,		5,		6,		7,		8,		9
	//00-09//VST,	VS1,	VS2,	FB1,	FB2,	FB3,	FB4,	POSIN,	QST,	SW1
	//10-19//SW2,	POSSW,	POSFB,	SQUC,	QUC,	QVR,	QCO,	SQT1,	QT1,	SQT2
	//20-29//QT2,	QT3,	BATSNS1,BATSNS2,RSH,	RSL,	VCI,	VMON,	NC,		SEC
	//30-39//AMUX,	FRE,	EVC,	POSFRE,	SYN,	EVS,	SSD,	ENA,	WAK,	WDI
	//40-49//STU,	ERR,	SCS,	SCL,	SDI,	MPS,	DRG,	ROT,	INT,	SS1
	//50-59//SS2,	SDO,	TP

	//A,VST,VS1,VS2,FB1,FB2,FB3,FB4,POSIN
	//B,QST,SW1,SW2,POSSW,POSFB,SQUC,QUC,QVR,QCO,SQT1,QT1,SQT2,QT2,QT3
	//C,BATSNS1,BATSNS2,RSH,RSL,VCI/VMON,NC,SEC/AMUX,FRE,EVC/POSFRE,SYN/EVS/SSD,ENA,WAK,WDI,STU,INT,ERR,SCS,SCL,SDI,MPS
	//D,DRG,ROT,SS1,SS2,SDO

	//SYN/EVS/SSD
	//VCI/VMON
	//SEC/AMUX
	//EVC/POSFRE

	SERIAL
	{
		PINarray[0].pin_abs[SITE] = Result[2][SITE];//VS2
		PINarray[1].pin_abs[SITE] = Result[1][SITE];//VS1
		PINarray[2].pin_abs[SITE] = Result[9][SITE];//SW1
		PINarray[3].pin_abs[SITE] = Result[10][SITE];//SW2
		PINarray[4].pin_abs[SITE] = Result[22][SITE];//BATSNS1
		PINarray[5].pin_abs[SITE] = Result[23][SITE];//BATSNS2
		PINarray[6].pin_abs[SITE] = Result[46][SITE]/1000.0;//DRG
		PINarray[7].pin_abs[SITE] = Result[24][SITE];//RSH
		PINarray[8].pin_abs[SITE] = Result[25][SITE];//RSL
		PINarray[9].pin_abs[SITE] = 0;//BSG
		PINarray[10].pin_abs[SITE] = Result[0][SITE]/1000.0;//VST
		PINarray[11].pin_abs[SITE] = Result[37][SITE];//ENA
		PINarray[12].pin_abs[SITE] = Result[38][SITE];//WAK
		PINarray[13].pin_abs[SITE] = Result[8][SITE];//QST
		PINarray[14].pin_abs[SITE] = 0;//AG1
		PINarray[15].pin_abs[SITE] = 0;//AG2
		PINarray[16].pin_abs[SITE] = 0;//AGS1
		PINarray[17].pin_abs[SITE] = 0;//AGS2
		PINarray[18].pin_abs[SITE] = Result[50][SITE]/1000.0;//SS2
		PINarray[19].pin_abs[SITE] = Result[49][SITE]/1000.0;//SS1
		PINarray[20].pin_abs[SITE] = Result[44][SITE];//SDI
		PINarray[21].pin_abs[SITE] = Result[51][SITE]/1000.0;//SDO
		PINarray[22].pin_abs[SITE] = Result[43][SITE];//SCL
		PINarray[23].pin_abs[SITE] = Result[42][SITE];//SCS
		PINarray[24].pin_abs[SITE] = Result[39][SITE];//WDI
		PINarray[25].pin_abs[SITE] = Result[47][SITE]/1000.0;//ROT
		PINarray[26].pin_abs[SITE] = Result[48][SITE]/1000.0;//INT
		PINarray[27].pin_abs[SITE] = Result[35][SITE];//EVS
		PINarray[28].pin_abs[SITE] = Result[34][SITE];//SYN
		PINarray[29].pin_abs[SITE] = Result[36][SITE];//SSD
		PINarray[30].pin_abs[SITE] = Result[41][SITE];//ERR
		PINarray[31].pin_abs[SITE] = Result[32][SITE];//EVC
		PINarray[32].pin_abs[SITE] = Result[33][SITE];//POSFRE
		PINarray[33].pin_abs[SITE] = Result[31][SITE];//FRE
		PINarray[34].pin_abs[SITE] = Result[45][SITE];//MPS
		PINarray[35].pin_abs[SITE] = Result[29][SITE];//SEC
		PINarray[36].pin_abs[SITE] = Result[30][SITE]/1000.0;//AMUX
		PINarray[37].pin_abs[SITE] = Result[26][SITE];//VCI
		PINarray[38].pin_abs[SITE] = Result[27][SITE];//VMON
		PINarray[39].pin_abs[SITE] = Result[40][SITE];//STU
		PINarray[40].pin_abs[SITE] = 0;//AG3
		PINarray[41].pin_abs[SITE] = Result[15][SITE];//QVR
		PINarray[42].pin_abs[SITE] = Result[14][SITE];//QUC
		PINarray[43].pin_abs[SITE] = Result[13][SITE];//SQUC
		PINarray[44].pin_abs[SITE] = Result[16][SITE];//QCO
		PINarray[45].pin_abs[SITE] = Result[20][SITE]/1000.0;//QT2
		PINarray[46].pin_abs[SITE] = Result[19][SITE]/1000.0;//SQT2
		PINarray[47].pin_abs[SITE] = Result[18][SITE]/1000.0;//QT1
		PINarray[48].pin_abs[SITE] = Result[17][SITE]/1000.0;//SQT1
		PINarray[49].pin_abs[SITE] = Result[21][SITE]/1000.0;//QT3
		PINarray[50].pin_abs[SITE] = 0;//POSG
		PINarray[51].pin_abs[SITE] = Result[11][SITE];//POSSW
		PINarray[52].pin_abs[SITE] = Result[7][SITE];//POSIN
		PINarray[53].pin_abs[SITE] = Result[12][SITE];//POSFB
		PINarray[54].pin_abs[SITE] = Result[3][SITE]/1000.0;//FB1
		PINarray[55].pin_abs[SITE] = Result[4][SITE]/1000.0;//FB2
		PINarray[56].pin_abs[SITE] = Result[5][SITE]/1000.0;//FB3
		PINarray[57].pin_abs[SITE] = Result[6][SITE]/1000.0;//FB4
		PINarray[58].pin_abs[SITE] = 0;//AG4
		PINarray[59].pin_abs[SITE] = 0;//PG2
		PINarray[60].pin_abs[SITE] = 0;//PG1
		PINarray[61].pin_abs[SITE] = Result[52][SITE];//TP
		PINarray[62].pin_abs[SITE] = Result[28][SITE];//NC
		PINarray[63].pin_abs[SITE] = Result[0][SITE];//
		PINarray[64].pin_abs[SITE] = Result[0][SITE];//
		PINarray[65].pin_abs[SITE] = Result[0][SITE];//
		PINarray[66].pin_abs[SITE] = Result[0][SITE];//
		PINarray[67].pin_abs[SITE] = Result[0][SITE];//
		PINarray[68].pin_abs[SITE] = Result[0][SITE];//
		PINarray[69].pin_abs[SITE] = Result[0][SITE];//
		PINarray[70].pin_abs[SITE] = Result[0][SITE];//
		PINarray[71].pin_abs[SITE] = Result[0][SITE];//
		PINarray[72].pin_abs[SITE] = Result[0][SITE];//
		PINarray[73].pin_abs[SITE] = Result[0][SITE];//
		PINarray[74].pin_abs[SITE] = Result[0][SITE];//
		PINarray[75].pin_abs[SITE] = Result[0][SITE];//
		PINarray[76].pin_abs[SITE] = Result[0][SITE];//
		PINarray[77].pin_abs[SITE] = Result[0][SITE];//
		PINarray[78].pin_abs[SITE] = Result[0][SITE];//
		PINarray[79].pin_abs[SITE] = Result[0][SITE];//
		PINarray[80].pin_abs[SITE] = Result[0][SITE];//
		PINarray[81].pin_abs[SITE] = Result[0][SITE];//
		PINarray[82].pin_abs[SITE] = Result[0][SITE];//
		PINarray[83].pin_abs[SITE] = Result[0][SITE];//
		PINarray[84].pin_abs[SITE] = Result[0][SITE];//
		PINarray[85].pin_abs[SITE] = Result[0][SITE];//
		PINarray[86].pin_abs[SITE] = Result[0][SITE];//
		PINarray[87].pin_abs[SITE] = Result[0][SITE];//
		PINarray[88].pin_abs[SITE] = Result[0][SITE];//
		PINarray[89].pin_abs[SITE] = Result[0][SITE];//
		PINarray[80].pin_abs[SITE] = Result[0][SITE];//
		PINarray[91].pin_abs[SITE] = Result[0][SITE];//
		PINarray[92].pin_abs[SITE] = Result[0][SITE];//
		PINarray[93].pin_abs[SITE] = Result[0][SITE];//
		PINarray[94].pin_abs[SITE] = Result[0][SITE];//
		PINarray[95].pin_abs[SITE] = Result[0][SITE];//
		PINarray[96].pin_abs[SITE] = Result[0][SITE];//
		PINarray[97].pin_abs[SITE] = Result[0][SITE];//
	}
	for (int i = 0; i < PIN_Count; i++)
	{
		SERIAL PINarray[i].pin_abs[SITE] = PINarray[i].pin_abs[SITE] * 1000000.0;
	}
}

void abs_datalog(short funcindex)
{
	for (int i = 0; i < PIN_Count-1; i++)
	{
		if ((PINarray[i].pin_valid)&&(PINarray[i].diode))
		{
			//SERIAL StsGetParam(funcindex, PINarray[i].name_abs.c_str())->SetTestResult(SITE, 0, PINarray[i].pin_abs[SITE] * 1000000.0);
			Ms_LogData(funcindex, PINarray[i].name_abs.c_str(), PINarray[i].pin_abs);
		}
	}
	Ms_LogData(funcindex, "BV_PreBK_LS", prebk_bv_ls);
	if(PN_Posbk_Available) {Ms_LogData(funcindex, "BV_PosBK_LS", posbk_bv_ls);}
	SERIAL qt1_nleak[SITE] = qt1_nleak[SITE] * 1000.0; 
	SERIAL qt2_nleak[SITE] = qt2_nleak[SITE] * 1000.0; 
	SERIAL qt3_nleak[SITE] = qt3_nleak[SITE] * 1000.0; 
	SERIAL batsns1_nleak[SITE] = batsns1_nleak[SITE] * 1000000.0; 
	SERIAL batsns2_nleak[SITE] = batsns2_nleak[SITE] * 1000000.0; 
	if(DO_ABSN)
	{
		Ms_LogData(funcindex, "ABS_QT1N", qt1_nleak);
		Ms_LogData(funcindex, "ABS_QT2N", qt2_nleak);
		if(PN_Tracker_Num==3){Ms_LogData(funcindex, "ABS_QT3N", qt3_nleak);}
		if (PINarray[4].pin_valid){Ms_LogData(funcindex, "ABS_BATSNS1N", batsns1_nleak);}
		if (PINarray[5].pin_valid){Ms_LogData(funcindex, "ABS_BATSNS2N", batsns2_nleak);}
	}
}

void ConvertTempBoard(double *Volt, double Temp[])
{
	for (int i = 0; i<SITE_NUM; i++)
	{
		if (abs(Volt[i]) > 2.0){ Temp[i] = 9999; }
		else { Temp[i] = -804.75 * abs(Volt[i]) + 503.14; }
	}
}

void ConvertTempDut(double *Volt, double Temp[])
{
	max_temp = -999;
	double k=0;
	double b=0;
	int pn=PART_NUM();
	if(pn==62583)	{k=-1265.6;b=777.50;}//qfp64
	if(pn==62585)	{k=-1232.4;b=761.98;}//qfp48,tbd
	else			{k=-1232.4;b=761.98;}//qfn48
	
	for (int i = 0; i<SITE_NUM; i++)
	{
		if (abs(Volt[i]) > 2.0){ Temp[i] = 9999; }
		else { Temp[i] = k * abs(Volt[i]) + b; }
	}
	SERIAL 
	{
		if(Temp[SITE]>max_temp){max_temp=Temp[SITE];}
	}
}

void ConvertTempInt(double Temp[], int TempInt[])
{
	for (int i = 0; i<SITE_NUM; i++)
	{
		if (Temp[i] > 140){ TempInt[i] = 150; }
		else if (Temp[i] > 110){ TempInt[i] = 125; }
		else if (Temp[i] > 90){ TempInt[i] = 100; }
		else if (Temp[i] > 70){ TempInt[i] = 85; }
		else if (Temp[i] > 40){ TempInt[i] = 50; }
		else if (Temp[i] > 10){ TempInt[i] = 25; }
		else if (Temp[i] > -5){ TempInt[i] = 0; }
		else if (Temp[i] > -15){ TempInt[i] = -10; }
		else if (Temp[i] > -25){ TempInt[i] = -20; }
		else if (Temp[i] > -50){ TempInt[i] = -40; }
		else if (Temp[i] > -60){ TempInt[i] = -50; }
		else if (Temp[i] > -70){ TempInt[i] = -60; }
		else if (Temp[i] > -80){ TempInt[i] = -70; }
		else if (Temp[i] > -90){ TempInt[i] = -80; }
		else { TempInt[i] = 999; }
	}
}

void temp_meas_board(double Volt[], double Temp[])
{
	double result[SITE_NUM];
	A_DIODE.Set(FI, -1 mA, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_DIODE.MeasureVI(20, 10);
	for (int i = 0; i < SITE_NUM; i++)
	{
		result[i] = abs(A_DIODE.GetMeasResult(i, MVRET));
		Volt[i] = abs(result[i]);
	}
	ConvertTempBoard(Volt, Temp);
	A_DIODE.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	A_DIODE.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
}

//CRC
int Invert_Bit8(int Data, bool DoInvert)
{
	int x;
	int y = 7;
	int datain[8];
	int DataOut = 0;
	if (DoInvert)
	{
		for (x = 0; x < 8; x++)
		{
			datain[y] = (Data >> x) & 0x01;
			DataOut = DataOut + (datain[y] << y);
			y--;
		}
	}
	else DataOut = Data;
	DataOut = DataOut & 0xFF;
	return DataOut;
}

int Invert_Bit16(int Data, bool DoInvert)
{
	int x;
	int y = 15;
	int datain[16];
	int DataOut = 0;
	if (DoInvert)
	{
		for (x = 0; x < 16; x++)
		{
			datain[y] = (Data >> x) & 0x0001;
			DataOut = DataOut + (datain[y] << y);
			y--;
		}
	}
	else DataOut = Data;
	DataOut = DataOut & 0xFFFF;
	return DataOut;
}

int CRC_8_ROHC(int data[],int count)
{
	int CRC = 0;                                 // CRC Result
	int nArgvalue;

	int POLY = 0x07;	 //X^8+X^2+X^1+1
	int IniVal = 0xFF;
	int CheckSumTotal;
	int RegisterValue;

	CheckSumTotal = IniVal;

	for(int j=0;j< count;j++)
	{
		nArgvalue = data[j];
		RegisterValue = Invert_Bit8(nArgvalue, true);
		CheckSumTotal = CheckSumTotal ^ (RegisterValue);		/* Fetch byte from memory, XOR into CRC top byte*/
		for (int i = 0; i < 8; i++)								/* Prepare to rotate 8 bits */
		{
			if (CheckSumTotal & 0x80)							/* b7 is 1 */
			{
				CheckSumTotal = (CheckSumTotal << 1) ^ POLY;    /* rotate and XOR with polynomic */
			}
			else												/* b7 is 0 */
				CheckSumTotal <<= 1;							/* just rotate */
		}														/* Loop for 8 bits */
		CheckSumTotal &= 0xFF;									/* Ensure CRC remains 8-bit value */
	} 
	CRC = Invert_Bit8(CheckSumTotal, true);
	return CRC;
}

int CRC_16_CCITT_FALSE(int data[],int count)
{
	int CRC = 0;                                 // CRC Result
	int nArgvalue;

	int POLY = 0x1021;	 //X^16+X^12+X^5+1
	int IniVal = 0xFFFF;
	int CheckSumTotal;
	int RegisterValue;

	CheckSumTotal = IniVal;

	for(int j=0;j< count;j++)
	{
		nArgvalue = data[j];
		RegisterValue = Invert_Bit16(nArgvalue, false);
		CheckSumTotal = CheckSumTotal ^ (RegisterValue);		/* Fetch byte from memory, XOR into CRC top byte*/
		for (int i = 0; i < 16; i++)								/* Prepare to rotate 16 bits */
		{
			if (CheckSumTotal & 0x8000)							/* b15 is 1 */
			{
				CheckSumTotal = (CheckSumTotal << 1) ^ POLY;    /* rotate and XOR with polynomic */
			}
			else												/* b7 is 0 */
				CheckSumTotal <<= 1;							/* just rotate */
		}														/* Loop for 16 bits */
		CheckSumTotal &= 0xFFFF;									/* Ensure CRC remains 8-bit value */
	}
	CRC = Invert_Bit16(CheckSumTotal, false);
	return CRC;
}

int check_valid_cp_trim_item(string node_name)
{
	int find = 0;
	int size = 3;
	string ignore_opt[] =
	{
		"DIE_ID_X",
		"DIE_ID_Y",
		"Wafer_ID"
	};
	for(int i=0;i<size;i++)
	{
		if(node_name.compare(ignore_opt[i])==0){find=1;}
	}
	return find;
}

int check_valid_sel_opt(string node_name)
{
	int find = 0;
	int size = 5;
	string ignore_opt[] =
	{
		"DIE_ID_X",
		"DIE_ID_Y",
		"Wafer_ID",
		"ECC_Code",
		"Burn_lock"
	};
	for(int i=0;i<size;i++)
	{
		if(node_name.compare(ignore_opt[i])==0){find=1;}
	}
	return find;
}

int check_valid_trim_opt(string node_name)
{
	int find = 0;
	int size = 2;
	string checked_opt[] =
	{
		"bg1_tc",
		"bg2_tc"
	};
	for(int i=0;i<size;i++)
	{
		if(node_name.compare(checked_opt[i])==0){find=1;}
	}
	return find;
}

void Setup_CP_Trim_Item(void)
{
	SEL_NODE *sel_node;
	string sel_name;
	TRIM_NODE *trim_node;
	string trim_name;
	for (unsigned ntrim = 0; ntrim < dut.sel.count(); ntrim++)
	{
		sel_node = &dut.sel[ntrim];
		sel_name = sel_node->get_node_name();
		if(check_valid_cp_trim_item(sel_name)==0)
		{
			dut.sel(sel_name.c_str()).set_working(0);
		}
		else
		{
			//delay_us(1);
		}	
	}
	for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++)
	{
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		if(check_valid_cp_trim_item(trim_name)==0)
		{
			dut.trim(trim_name.c_str()).set_working(0);
		}
		else
		{
			//delay_us(1);
		}	
	}
}

int NVM_OPTION_CACL_TREG(void)
{
	int CRC = 0;
	int option_array_treg[512];
	int option_array_size = 0;

	SEL_NODE *sel_node;
	string sel_name;
	TRIM_NODE *trim_node;
	string trim_name;
	option_array_size = 0;
	for (unsigned ntrim = 0; ntrim < dut.sel.count(); ntrim++)
	{
		sel_node = &dut.sel[ntrim];
		sel_name = sel_node->get_node_name();
		if(check_valid_sel_opt(sel_name)==0)
		{
			option_array_treg[option_array_size] = dut.sel(sel_name.c_str()).get_working(0);
			option_array_size++;
		}
		else
		{
			//delay_us(1);
		}	
	}
	for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++)
	{
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		if(check_valid_trim_opt(trim_name)==1)
		{
			//option_array_treg[option_array_size] = dut.trim(trim_name.c_str()).get_working(0);
			//option_array_size++;
		}
		else
		{
			//delay_us(1);
		}	
	}
	CRC = CRC_16_CCITT_FALSE(option_array_treg, option_array_size);
	return CRC;
}

void NVM_OPTION_CACL_WORKING(int CRC[])
{
	int option_array_treg[SITE_NUM][512];
	int option_array_size;

	SEL_NODE *sel_node;
	string sel_name;
	TRIM_NODE *trim_node;
	string trim_name;
	SERIAL
	{
		option_array_size = 0;
		for (unsigned ntrim = 0; ntrim < dut.sel.count(); ntrim++)
		{
			sel_node = &dut.sel[ntrim];
			sel_name = sel_node->get_node_name();
			if(check_valid_sel_opt(sel_name)==0)
			{
				option_array_treg[SITE][option_array_size] = dut.sel(sel_name.c_str()).get_working(SITE);
				option_array_size++;
			}
			else
			{
				//delay_us(1);
			}
		}
		for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++)
		{
			trim_node = &dut.trim[ntrim];
			trim_name = trim_node->get_node_name();
			if(check_valid_trim_opt(trim_name)==1)
			{
				//option_array_treg[SITE][option_array_size] = dut.trim(trim_name.c_str()).get_working(SITE);
				//option_array_size++;
			}
			else
			{
				//delay_us(1);
			}	
		}
		CRC[SITE] = CRC_16_CCITT_FALSE(option_array_treg[SITE], option_array_size);
	}
}

void NVM_OPTION_CACL_READBACK(int CRC[])
{
	int option_array_treg[SITE_NUM][512];
	int option_array_size;

	SEL_NODE *sel_node;
	string sel_name;
	TRIM_NODE *trim_node;
	string trim_name;
	SERIAL
	{
		option_array_size = 0;
		for (unsigned ntrim = 0; ntrim < dut.sel.count(); ntrim++)
		{
			sel_node = &dut.sel[ntrim];
			sel_name = sel_node->get_node_name();
			if(check_valid_sel_opt(sel_name)==0)
			{
				option_array_treg[SITE][option_array_size] = dut.sel(sel_name.c_str()).get_read_back(SITE);
				option_array_size++;
			}
			else
			{
				//delay_us(1);
			}
		}
		for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++)
		{
			trim_node = &dut.trim[ntrim];
			trim_name = trim_node->get_node_name();
			if(check_valid_trim_opt(trim_name)==1)
			{
				//option_array_treg[SITE][option_array_size] = dut.trim(trim_name.c_str()).get_read_back(SITE);
				//option_array_size++;
			}
			else
			{
				//delay_us(1);
			}	
		}
		CRC[SITE] = CRC_16_CCITT_FALSE(option_array_treg[SITE], option_array_size);
	}
}

void User_Read(short funcindex, bool post)
{
	int reg[64][SITE_NUM];
	int reg0[SITE_NUM];
	int reg4_pass[SITE_NUM] = {0};
	int reg28_pass[SITE_NUM] = {0};
	int reg31_pass[SITE_NUM] = {0};
	int reg53_pass[SITE_NUM] = {0};
	int reg56_pass[SITE_NUM] = {0};
	int reg57_pass[SITE_NUM] = {0};
	int reg4_dft[SITE_NUM] = { 0 };
	int reg28_dft[SITE_NUM] = { 0 };
	int reg31_dft[SITE_NUM] = { 0 };
	int reg53_dft[SITE_NUM] = { 0 };
	int reg56_dft[SITE_NUM] = { 0 };
	int reg57_dft[SITE_NUM] = { 0 };
	int lmt_prebk[SITE_NUM] = { 0 };
	int lmt_posbk[SITE_NUM] = { 0 };
	int lmt_quc[SITE_NUM] = { 0 };
	int lmt_qco[SITE_NUM] = { 0 };
	int posbk_dis[SITE_NUM] = { 0 };

	SERIAL
	{
		lmt_prebk[SITE] = dut.sel("PREBK_LMT").get_working(SITE);
		lmt_posbk[SITE] = dut.sel("POSTBK_LMT").get_working(SITE);
		lmt_quc[SITE] = dut.sel("QUC_LMT").get_working(SITE);
		lmt_qco[SITE] = dut.sel("QCO_LMT").get_working(SITE);
		posbk_dis[SITE] = dut.sel("POSBK_DIS").get_working(SITE);
		reg57_dft[SITE] = (lmt_posbk[SITE] << 7) + (lmt_prebk[SITE] << 6) + (lmt_qco[SITE] << 5) + (lmt_quc[SITE] << 4);

		if (dut.sel("QSTOS_DIS").get_working(SITE) == 0) { reg4_dft[SITE] = 254; }
		else { reg4_dft[SITE] = 126; }

		if (DIE_VER() == 0)
		{
			if (posbk_dis[SITE] == 0) { reg53_dft[SITE] = 254; }
			else { reg53_dft[SITE] = 255; }
			reg56_dft[SITE] = 0;
		}
		else
		{
			//252
			if (posbk_dis[SITE] == 0) { reg53_dft[SITE] = 252; }
			else { reg53_dft[SITE] = 255; }
			reg56_dft[SITE] = 0;
			//reg53_dft=reg53_dft&0xFD;
			//reg56_dft = reg56_dft|0x02;

			reg56_dft[SITE] = 2;
		}
	}

	Cmd_Bank0();
	//Cmd_Unlock();
	for (int i = 0; i < 64; i++)
	{
		CmdReadData(i, reg[i]);
	}
	//Cmd_Lock();
	string Parm = "";
	for (int i = 0; i < 64; i++)
	{
		Copy_Array(reg0, reg[i]);
		if(!post){Parm = "REG" + to_string(i) + "_R0";}
		else{Parm = "REG" + to_string(i) + "_R2";}
		Ms_LogData(funcindex, Parm, reg0);
	}

	SERIAL
	{
		if((trimed_ft0[SITE]!=0)||(post))
		{
			if(reg[4][SITE]==reg4_dft[SITE]){reg4_pass[SITE]=1;}
			else{reg4_pass[SITE]=0;}
			if(reg[53][SITE]==reg53_dft[SITE]){reg53_pass[SITE]=1;}
			else{reg53_pass[SITE]=0;}
			if(reg[56][SITE]==reg56_dft[SITE]){reg56_pass[SITE]=1;}
			else{reg56_pass[SITE]=0;}
			if(reg[57][SITE]==reg57_dft[SITE]){reg57_pass[SITE]=1;}
			else{reg57_pass[SITE]=0;}
		}
		else
		{
			reg4_pass[SITE]=1;
			reg53_pass[SITE]=1;
			reg56_pass[SITE]=1;
			reg57_pass[SITE]=1;
		}
		
		if((reg[28][SITE]==0)||(reg[28][SITE]==4)){reg28_pass[SITE]=1;}
		else{reg28_pass[SITE]=0;}
		if((reg[31][SITE]==0)||(reg[31][SITE]==2)){reg31_pass[SITE]=1;}
		else{reg31_pass[SITE]=0;}
	}
	if(!post)
	{
		Ms_LogData(funcindex, "REG4_DFT_R0", reg4_dft);
		Ms_LogData(funcindex, "REG53_DFT_R0", reg53_dft);
		Ms_LogData(funcindex, "REG56_DFT_R0", reg56_dft);
		Ms_LogData(funcindex, "REG57_DFT_R0", reg57_dft);

		Ms_LogData(funcindex, "REG4_PASS_R0", reg4_pass);
		Ms_LogData(funcindex, "REG28_PASS_R0", reg28_pass);
		Ms_LogData(funcindex, "REG31_PASS_R0", reg31_pass);
		Ms_LogData(funcindex, "REG53_PASS_R0", reg53_pass);//
		Ms_LogData(funcindex, "REG56_PASS_R0", reg56_pass);
		Ms_LogData(funcindex, "REG57_PASS_R0", reg57_pass);
	}
	else
	{
		Ms_LogData(funcindex, "REG4_DFT_R2", reg4_dft);
		Ms_LogData(funcindex, "REG53_DFT_R2", reg53_dft);
		Ms_LogData(funcindex, "REG56_DFT_R2", reg56_dft);
		Ms_LogData(funcindex, "REG57_DFT_R2", reg57_dft);

		Ms_LogData(funcindex, "REG4_PASS_R2", reg4_pass);
		Ms_LogData(funcindex, "REG28_PASS_R2", reg28_pass);
		Ms_LogData(funcindex, "REG31_PASS_R2", reg31_pass);
		Ms_LogData(funcindex, "REG53_PASS_R2", reg53_pass);//
		Ms_LogData(funcindex, "REG56_PASS_R2", reg56_pass);
		Ms_LogData(funcindex, "REG57_PASS_R2", reg57_pass);
	}
}

void NVM_Read0(void)
{
	crc_opt = NVM_OPTION_CACL_TREG();
	Cmd_Bank1(true);
	Nvm_ReadFs(REG_FS_R0);
	Nvm_Read(REG_R0);

	string EE_str;
	int data[SITE_NUM] = { 0 };
	int sum[SITE_NUM] = { 0 };
	SERIAL
	{
		for (int addr = 0; addr < FBANK_NUM; addr ++)//All bank
		{
			data[SITE] = REG_FS_R0[addr][SITE];
			EE_str = "FBANK" + to_string(addr);
			dut.assy(EE_str.c_str()).set_read_back((data[SITE]), SITE);
	    	dut.assy(EE_str.c_str()).copy_read_to_prog();
		}
	}
	SERIAL
	{
		sum[SITE]=0;
		for (int addr = 0; addr < BANK_NUM; addr++)//All bank
		{
			data[SITE] = REG_R0[addr][SITE];
			EE_str = "BANK" + to_string(addr);
			dut.assy(EE_str.c_str()).set_read_back((data[SITE]), SITE);
	    	dut.assy(EE_str.c_str()).copy_read_to_prog();
			sum[SITE]=sum[SITE]+data[SITE];
		}
	}
    //check device trimmed
    SERIAL{
        if ((dut.sel("DIE_ID_X").get_read_back(SITE) != 0)||(dut.sel("DIE_ID_Y").get_read_back(SITE) != 0)||(dut.sel("Wafer_ID").get_read_back(SITE) != 0))
            trimed_cp0[SITE] = 1;
        else
            trimed_cp0[SITE] = 0;
    }
	SERIAL{
        if ((dut.sel("ECC_Code").get_read_back(SITE) != 0))
            trimed_ft0[SITE] = 1;
        else
            trimed_ft0[SITE] = 0;
    }
	SERIAL{
        if (sum[SITE] !=0)
            trimed_ftb0[SITE] = 1;
        else
            trimed_ftb0[SITE] = 0;
    }

	SERIAL
	{
		burn_lock0[SITE] = dut.sel("Burn_lock").get_read_back(SITE);
		ecc_calc0[SITE] = calc_ecc(REG_FS_R0[0][SITE], REG_FS_R0[1][SITE], REG_FS_R0[2][SITE], REG_FS_R0[3][SITE], REG_FS_R0[4][SITE], REG_FS_R0[5][SITE]);
		ecc_read0[SITE] = dut.sel("ECC_Code").get_read_back(SITE);
		if(ecc_calc0[SITE] == ecc_read0[SITE]){ecc_pass0[SITE] = 1;}
		else {ecc_pass0[SITE] = 0;}
	}

	Burn_Flag_Ctl(DO_TRIM, trimed_cp0, trimed_ft0, trimed_ftb0, burn_lock0, burn_flag);

	SERIAL
	{
		for (int addr = 0; addr < BANK_NUM; addr++)//All bank
		{
			EE_str = "BANK" + to_string(addr);
			for (unsigned int node_no = 0; node_no<dut.assy(EE_str.c_str()).count(); ++node_no){
				string node_name(dut.assy(EE_str.c_str())[node_no].get_node_name());

				if (dut.find(node_name.c_str()) == FOUND_TRIM)									// judge if it is trim node, not sel node
				{
					dut.trim(node_name.c_str()).set_trim_allowed(burn_flag[SITE], SITE);	// if burn_flag is false, disable trim allow, else enable
				}
			}
		}
	}

	SERIAL
	{
		if(trimed_cp0[SITE] == 1)
		{
			dut.sel("DIE_ID_X").set_working(dut.sel("DIE_ID_X").get_read_back(SITE), SITE);
			dut.sel("DIE_ID_Y").set_working(dut.sel("DIE_ID_Y").get_read_back(SITE), SITE);
			dut.sel("Wafer_ID").set_working(dut.sel("Wafer_ID").get_read_back(SITE), SITE);
		}
		else
		{
			dut.sel("DIE_ID_X").set_working(x_coords[SITE], SITE);
			dut.sel("DIE_ID_Y").set_working(y_coords[SITE], SITE);
			dut.sel("Wafer_ID").set_working(wafer_id[SITE], SITE);
		}
	}
	SERIAL
	{
		if(trimed_ft0[SITE] == 1)
		{
			for (int addr = 0; addr < FBANK_NUM; ++addr)
			{
				EE_str = "FBANK" + to_string(addr);
				dut.assy(EE_str.c_str()).copy_read_to_work(SITE);
			}
		}
	}
	SERIAL
	{
		if(trimed_ftb0[SITE] == 1)
		{
			for (int addr = 0; addr < BANK_NUM; ++addr)
			{
				EE_str = "BANK" + to_string(addr);
				dut.assy(EE_str.c_str()).copy_read_to_work(SITE);
			}
		}
	}
}

void NVM_Read1(int pvr_f[], int pvr[])
{
	Cmd_Bank1(true);
	Nvm_ReadFs(REG_FS_R1);
	Nvm_Read(REG_R1);

	//int data0[50];
	//for (int reg = 0; reg < dut.assy.count(); reg++)
	//{
	//	data0[reg] = dut.assy[reg].get_programmed(0);
	//}

	string EE_str;
	int data[SITE_NUM] = { 0 };
	int count[SITE_NUM] = { 0 };
	int sum[SITE_NUM] = { 0 };
	SERIAL pvr_f[SITE] = 0;//1 for same data
	SERIAL pvr[SITE] = 0;//1 for same data
	SERIAL count[SITE] = 0;
	SERIAL
	{
		count[SITE] = 0;
		for (int addr = 0; addr < FBANK_NUM; addr++)//All bank
		{
			data[SITE] = REG_FS_R1[addr][SITE];
			EE_str = "FBANK" + to_string(addr);
			dut.assy(EE_str.c_str()).set_read_back((data[SITE]), SITE);
			count[SITE] += dut.assy(EE_str.c_str()).comp_prog_to_read(SITE);
	    	//dut.assy(EE_str.c_str()).copy_read_to_prog();
		}
		pvr_f[SITE] = count[SITE];
	}
	SERIAL
	{
		count[SITE] = 0;
		sum[SITE]=0;
		for (int addr = 0; addr < BANK_NUM; addr++)//All bank
		{
			data[SITE] = REG_R1[addr][SITE];
			EE_str = "BANK" + to_string(addr);
			dut.assy(EE_str.c_str()).set_read_back((data[SITE]), SITE);
			count[SITE] += dut.assy(EE_str.c_str()).comp_prog_to_read(SITE);
	    	//dut.assy(EE_str.c_str()).copy_read_to_prog();
			sum[SITE]=sum[SITE]+data[SITE];
		}
		pvr[SITE] = count[SITE];
	}
	//check device trimmed
	SERIAL{
		if ((dut.sel("DIE_ID_X").get_read_back(SITE) != 0) || (dut.sel("DIE_ID_Y").get_read_back(SITE) != 0) || (dut.sel("Wafer_ID").get_read_back(SITE) != 0))
			trimed_cp1[SITE] = 1;
		else
			trimed_cp1[SITE] = 0;
	}
	SERIAL{
		if ((dut.sel("ECC_Code").get_read_back(SITE) != 0))
			trimed_ft1[SITE] = 1;
		else
			trimed_ft1[SITE] = 0;
	}
	SERIAL{
        if (sum[SITE] !=0)
            trimed_ftb1[SITE] = 1;
        else
            trimed_ftb1[SITE] = 0;
    }

	SERIAL
	{
		burn_lock1[SITE] = dut.sel("Burn_lock").get_read_back(SITE);
		ecc_calc1[SITE] = calc_ecc(REG_FS_R1[0][SITE], REG_FS_R1[1][SITE], REG_FS_R1[2][SITE], REG_FS_R1[3][SITE], REG_FS_R1[4][SITE], REG_FS_R1[5][SITE]);
		ecc_read1[SITE] = dut.sel("ECC_Code").get_read_back(SITE);
		if(ecc_calc1[SITE] == ecc_read1[SITE]){ecc_pass1[SITE] = 1;}
		else {ecc_pass1[SITE] = 0;}
	}
}

void NVM_Read2(int wvr_f[], int wvr[])
{
	Cmd_Bank1(true);
	Nvm_ReadFs(REG_FS_R2);
	Nvm_Read(REG_R2);
	
	string EE_str;
	int data[SITE_NUM] = { 0 };
	int count[SITE_NUM] = { 0 };
	int sum[SITE_NUM] = { 0 };
	SERIAL wvr_f[SITE] = 0;//1 for same data
	SERIAL wvr[SITE] = 0;//1 for same data
	SERIAL count[SITE] = 0;
	SERIAL
	{
		count[SITE] = 0;
		for (int addr = 0; addr < FBANK_NUM; addr++)//All bank
		{
			data[SITE] = REG_FS_R2[addr][SITE];
			EE_str = "FBANK" + to_string(addr);
			dut.assy(EE_str.c_str()).set_read_back((data[SITE]), SITE);
			count[SITE] += dut.assy(EE_str.c_str()).comp_read_to_work(SITE);
	    	//dut.assy(EE_str.c_str()).copy_read_to_prog();
		}
		wvr_f[SITE] = count[SITE];
	}
	SERIAL
	{
		count[SITE] = 0;
		sum[SITE]=0;
		for (int addr = 0; addr < BANK_NUM; addr++)//All bank
		{
			data[SITE] = REG_R2[addr][SITE];
			EE_str = "BANK" + to_string(addr);
			dut.assy(EE_str.c_str()).set_read_back((data[SITE]), SITE);
			count[SITE] += dut.assy(EE_str.c_str()).comp_read_to_work(SITE);
	    	//dut.assy(EE_str.c_str()).copy_read_to_prog();
			sum[SITE]=sum[SITE]+data[SITE];
		}
		wvr[SITE] = count[SITE];
	}
	//check device trimmed
	SERIAL{
		if ((dut.sel("DIE_ID_X").get_read_back(SITE) != 0) || (dut.sel("DIE_ID_Y").get_read_back(SITE) != 0) || (dut.sel("Wafer_ID").get_read_back(SITE) != 0))
			trimed_cp2[SITE] = 1;
		else
			trimed_cp2[SITE] = 0;
	}
	SERIAL{
		if ((dut.sel("ECC_Code").get_read_back(SITE) != 0))
			trimed_ft2[SITE] = 1;
		else
			trimed_ft2[SITE] = 0;
	}
	SERIAL{
        if (sum[SITE] !=0)
            trimed_ftb2[SITE] = 1;
        else
            trimed_ftb2[SITE] = 0;
    }

	SERIAL
	{
		burn_lock2[SITE] = dut.sel("Burn_lock").get_read_back(SITE);
		ecc_calc2[SITE] = calc_ecc(REG_FS_R2[0][SITE], REG_FS_R2[1][SITE], REG_FS_R2[2][SITE], REG_FS_R2[3][SITE], REG_FS_R2[4][SITE], REG_FS_R2[5][SITE]);
		ecc_read2[SITE] = dut.sel("ECC_Code").get_read_back(SITE);
		if(ecc_calc2[SITE] == ecc_read2[SITE]){ecc_pass2[SITE] = 1;}
		else {ecc_pass2[SITE] = 0;}
	}
	//NVM_OPTION_CACL_WORKING(crc_read);
	NVM_OPTION_CACL_READBACK(crc_read);
	SERIAL
	{
		if (crc_read[SITE] == crc_opt) { crc_pass[SITE] = 1; }
		else { crc_pass[SITE] = 0; }
	}
}

void NVM_Read0_datalog(short funcindex)
{
	int ecc_match[SITE_NUM];
	SERIAL 
	{
		if((ecc_read0[SITE]==0)&&(ecc_calc0[SITE]==0)){ecc_match[SITE]=1;}
		else
		{
			if(ecc_read0[SITE]==PN_ECC)
			{ecc_match[SITE]=1;}else{ecc_match[SITE]=0;}
		}
	}
	Ms_LogData(funcindex, "Flag_Trimed_CP0", trimed_cp0);
	Ms_LogData(funcindex, "Flag_Trimed_FTA0", trimed_ft0);
	Ms_LogData(funcindex, "Flag_Trimed_FTB0", trimed_ftb0);
	Ms_LogData(funcindex, "Burn_Lock_R0", burn_lock0);
	Ms_LogData(funcindex, "Ecc_Pass_R0", ecc_pass0);
	Ms_LogData(funcindex, "Ecc_Read_R0", ecc_read0);
	Ms_LogData(funcindex, "Ecc_Calc_R0", ecc_calc0);
	Ms_LogData(funcindex, "Ecc_Treg", PN_ECC);
	Ms_LogData(funcindex, "Ecc_Match_R0", ecc_match);
	//string test_name;
	//for (int i = 0; i < FBANK_NUM; i++)
	//{
	//	test_name = "FBANK" + int2str(i) + "_R0";
	//	SERIAL StsGetParam(funcindex, test_name.c_str())->SetTestResult(SITE, 0, REG_FS_R0[i][SITE]);
	//}
	//for (int i = 0; i < BANK_NUM; i++)
	//{
	//	test_name = "BANK" + int2str(i) + "_R0";
	//	SERIAL StsGetParam(funcindex, test_name.c_str())->SetTestResult(SITE, 0, REG_R0[i][SITE]);
	//}

	//Bank READ
	for (int reg = 0; reg < dut.assy.count(); reg++)
    {
        string EE_str = string(dut.assy[reg].get_name()) + "_R0";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].get_read_back(SITE));
    }

    //TRIM PRE
	for (int reg = 0; reg < dut.trim.count(); reg++)
	{
        string EE_str = string(dut.trim[reg].get_name()) + "_R0";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.trim[reg].get_read_back(SITE));
    }

    //SEL PRE
	for (int reg = 0; reg < dut.sel.count(); reg++)
	{
        string EE_str = string(dut.sel[reg].get_name()) + "_R0";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.sel[reg].get_read_back(SITE));
	}
}

void NVM_Read1_datalog(short funcindex)
{
	//Ms_LogData(funcindex, "Flag_Trimed_CP1", trimed_cp1);
	//Ms_LogData(funcindex, "Flag_Trimed_FT1", trimed_ft1);
	//Ms_LogData(funcindex, "Flag_Trimed_FTB1", trimed_ftb1);
	Ms_LogData(funcindex, "Burn_Lock_R1", burn_lock1);
	Ms_LogData(funcindex, "Ecc_Pass_R1", ecc_pass1);
	Ms_LogData(funcindex, "Ecc_Read_R1", ecc_read1);
	Ms_LogData(funcindex, "Ecc_Calc_R1", ecc_calc1);
	//string test_name;
	//for (int i = 0; i < FBANK_NUM; i++)
	//{
	//	test_name = "FBANK" + int2str(i) + "_R1";
	//	SERIAL StsGetParam(funcindex, test_name.c_str())->SetTestResult(SITE, 0, REG_FS_R1[i][SITE]);
	//}
	//for (int i = 0; i < BANK_NUM; i++)
	//{
	//	test_name = "BANK" + int2str(i) + "_R1";
	//	SERIAL StsGetParam(funcindex, test_name.c_str())->SetTestResult(SITE, 0, REG_R1[i][SITE]);
	//}

	//Bank READ
	for (int reg = 0; reg < dut.assy.count(); reg++)
    {
        string EE_str = string(dut.assy[reg].get_name()) + "_R1";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].get_read_back(SITE));
    }

    //TRIM PRE
	for (int reg = 0; reg < dut.trim.count(); reg++)
	{
        string EE_str = string(dut.trim[reg].get_name()) + "_R1";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.trim[reg].get_read_back(SITE));
    }

    //SEL PRE
	for (int reg = 0; reg < dut.sel.count(); reg++)
	{
        string EE_str = string(dut.sel[reg].get_name()) + "_R1";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.sel[reg].get_read_back(SITE));
    }
}

void NVM_Read2_datalog(short funcindex)
{
	Ms_LogData(funcindex, "Flag_Trimed_CP2", trimed_cp2);
	Ms_LogData(funcindex, "Flag_Trimed_FTA2", trimed_ft2);
	Ms_LogData(funcindex, "Flag_Trimed_FTB2", trimed_ftb2);
	Ms_LogData(funcindex, "Burn_Lock_R2", burn_lock2);
	Ms_LogData(funcindex, "Ecc_Pass_R2", ecc_pass2);
	Ms_LogData(funcindex, "Ecc_Read_R2", ecc_read2);
	Ms_LogData(funcindex, "Ecc_Calc_R2", ecc_calc2);
	//string test_name;
	//for (int i = 0; i < FBANK_NUM; i++)
	//{
	//	test_name = "FBANK" + int2str(i) + "_R2";
	//	SERIAL StsGetParam(funcindex, test_name.c_str())->SetTestResult(SITE, 0, REG_FS_R2[i][SITE]);
	//}
	//for (int i = 0; i < BANK_NUM; i++)
	//{
	//	test_name = "BANK" + int2str(i) + "_R2";
	//	SERIAL StsGetParam(funcindex, test_name.c_str())->SetTestResult(SITE, 0, REG_R2[i][SITE]);
	//}

	//Bank FINAL
	for (int reg = 0; reg < dut.assy.count(); reg++)
    {
        string EE_str = string(dut.assy[reg].get_name()) + "_R2";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].get_read_back(SITE));

        EE_str = string(dut.assy[reg].get_name()) + "_COMP";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].comp_read_to_work(SITE));
    }

    //TRIM FINAL
	for (int reg = 0; reg < dut.trim.count(); reg++)
	{
        string EE_str = string(dut.trim[reg].get_name()) + "_R2";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.trim[reg].get_read_back(SITE));
    }

    //SEL FINAL
	for (int reg = 0; reg < dut.sel.count(); reg++)
	{
        string EE_str = string(dut.sel[reg].get_name()) + "_R2";
        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.sel[reg].get_read_back(SITE));
    }
}

void NVM_Pgm_datalog(short funcindex)
{
	//Bank READ
	int data[SITE_NUM];
	//int data0[50];
	//for (int reg = 0; reg < dut.assy.count(); reg++)
	//{
	//	data0[reg] = dut.assy[reg].get_programmed(0);
	//}
	int N = dut.assy.count();
    for (int reg = 0; reg < N; reg++)
    {
        string EE_str = string(dut.assy[reg].get_name()) + "_PGM";
		SERIAL data[SITE] = dut.assy[reg].get_programmed(SITE);
		//SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, data[SITE]);
		Ms_LogData(funcindex, EE_str.c_str(), data);
    }
}

void Nvm_PreviewFs(int index)
{
	int data[SITE_NUM];
	Cmd_Bank1();
	if (index == -1)
	{
		for (int reg = 0; reg<FBANK_NUM; reg++)
		{
			string EE_str;
			EE_str = "FBANK" + int2str(reg);
			SERIAL data[SITE] = dut.assy(EE_str.c_str()).get_working(SITE);
			Cmd_Nvm_WriteFs(reg, data);
		}
	}
	else
	{
		int reg = index;
		string EE_str;
		EE_str = "FBANK" + int2str(reg);
		SERIAL data[SITE] = dut.assy(EE_str.c_str()).get_working(SITE);
		Cmd_Nvm_WriteFs(reg, data);
	}
}

void Nvm_Preview(int index)
{
	int data[SITE_NUM];
	Cmd_Bank1();
	if (index == -1)
	{
		for (int reg = 0; reg<BANK_NUM; reg++)
		{
			string EE_str;
			EE_str = "BANK" + int2str(reg);
			SERIAL data[SITE] = dut.assy(EE_str.c_str()).get_working(SITE);
			Cmd_Nvm_Write(reg, data);
		}
	}
	else
	{
		int reg = index;
		string EE_str;
		EE_str = "BANK" + int2str(reg);
		SERIAL data[SITE] = dut.assy(EE_str.c_str()).get_working(SITE);
		Cmd_Nvm_Write(reg, data);
	}
}

void Nvm_Burn(bool globalen, bool siteen[])
{
	int N = dut.assy.count();
	for (int reg = 0; reg < N; reg++)
    {
        string EE_str = string(dut.assy[reg].get_name());
        SERIAL
		{
			if (siteen[SITE] == true)
			{
				dut.assy(EE_str.c_str()).copy_work_to_prog(SITE);//untrimmed,copy work to prog
			}
		}
    }
	Cmd_Bank1();
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data1r[SITE_NUM];
	int data2r[SITE_NUM];
	int rdata0[SITE_NUM];
	int rdata1[SITE_NUM];
	int finish[SITE_NUM];
	for (int site = 0; site<SITE_NUM; site++)
	{
		if (siteen){ data1[site] = 0x01; data2[site] = 0x01; }
		else{ data1[site] = 0x00; data2[site] = 0x00; }
	}
	if (globalen)
	{
		CmdReadData(0x35, rdata0);
		CmdWriteData(0x21, data1);
		CmdReadData(0x21, data1r);
		delay_us(100);//100us
		CmdWriteData(0x20, data2);
		CmdReadData(0x20, data2r);
		Prog_Clk_Connect();
		Prog_Clk_Run();//7.7ms+600us
		Prog_Clk_DisConnect();
		CmdReadData(0x35, rdata1);
		SERIAL 
		{
			if (rdata1[SITE] == 0){ finish[SITE] = 1; }
			else{ finish[SITE] = 0; }
		}
	}
}

void Burn_Flag_Ctl(bool globalen, int trimed_cp[], int trimed_ft[], int trimed_ftb[], int locked[], bool siteen[])
{
	//for ft flow
	if (globalen)
	{
		SERIAL 
		{
			if(locked[SITE]){ siteen[SITE] = false; }
			else
			{
				if(FLOW_CP)
				{
					if (trimed_cp[SITE]) { siteen[SITE] = false; }
					else { siteen[SITE] = true; }
				}
				else//FT
				{
					if ((trimed_cp[SITE])&&(trimed_ft[SITE])&&(trimed_ftb[SITE])) { siteen[SITE] = false; }
					else { siteen[SITE] = true; }
				}
			}
		}
	}
	else
	{
		SERIAL siteen[SITE] = false;
	}
}

void measure_freq_duty_set(const char* PIN, double vdd, CHANNEL_STATUS ChannelStatus)
{
	int status;
	dcm.Connect(PIN);
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	status = dcm.SetPinLevel(PIN, dVIH, dVIL, dVOH, dVOL);
	status = dcm.SetChannelStatus(PIN, ChannelStatus);///<Ensure the waveform is ran from low
	//status = dcm.SetTMUMatrix(PIN, DCM_ALLSITE, DCM_ALL_TMU);///<Connect pin OUT1 to TMU unit1 of its controller
	status = dcm.SetTMUMatrix(PIN, SITE_1, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_5, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_2, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_6, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_7, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_3, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_8, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_4, DCM_TMU2);
	status = dcm.SetTMUParam(PIN, DCM_POS, 4, 0);
}

void measure_freq_duty_set(const char* PIN, double vdd)
{
	int status;
	dcm.Connect(PIN);
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	status = dcm.SetPinLevel(PIN, dVIH, dVIL, dVOH, dVOL);
	status = dcm.SetChannelStatus(PIN, DCM_HIGH_IMPEDANCE);///<Ensure the waveform is ran from low
	//status = dcm.SetTMUMatrix(PIN, DCM_ALLSITE, DCM_ALL_TMU);///<Connect pin OUT1 to TMU unit1 of its controller
	status = dcm.SetTMUMatrix(PIN, SITE_1, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_5, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_2, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_6, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_7, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_3, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_8, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_4, DCM_TMU2);
	status = dcm.SetTMUParam(PIN, DCM_POS, 4, 0);
}

void measure_edge_set1(const char* PIN, double vdd, DCM_SLOPE Slope)
{
	int status;
	dcm.Connect(PIN);
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.95 * vdd;
	double dVOL = 0.05 * vdd;
	status = dcm.SetPinLevel(PIN, dVIH, dVIL, dVOH, dVOL);
	status = dcm.SetChannelStatus(PIN, DCM_HIGH_IMPEDANCE);///<Ensure the waveform is ran from low
	status = dcm.SetTMUMatrix(PIN, SITE_1, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_1, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_2, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_2, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_3, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_3, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_4, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_4, DCM_TMU2);
	status = dcm.SetTMUParam(PIN, Slope, 3, 5);
}

void measure_edge_set2(const char* PIN, double vdd, DCM_SLOPE Slope)
{
	int status;
	dcm.Connect(PIN);
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.95 * vdd;
	double dVOL = 0.05 * vdd;
	status = dcm.SetPinLevel(PIN, dVIH, dVIL, dVOH, dVOL);
	status = dcm.SetChannelStatus(PIN, DCM_HIGH_IMPEDANCE);///<Ensure the waveform is ran from low
	status = dcm.SetTMUMatrix(PIN, SITE_5, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_5, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_6, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_6, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_7, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_7, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_8, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_8, DCM_TMU2);
	status = dcm.SetTMUParam(PIN, Slope, 3, 0);
}

void measure_tblank_set(const char* PIN)
{
	int status;
	dcm.Connect(PIN);
	double dVIH = 5.0;
	double dVIL = 0.0;
	//double dVOH = 3.0;//329
	double dVOH = 3.6;//311
	double dVOL = 0.0;
	status = dcm.SetPinLevel(PIN, dVIH, dVIL, dVOH, dVOL);
	status = dcm.SetChannelStatus(PIN, DCM_HIGH_IMPEDANCE);///<Ensure the waveform is ran from low
	//status = dcm.SetTMUMatrix(PIN, DCM_ALLSITE, DCM_ALL_TMU);///<Connect pin OUT1 to TMU unit1 of its controller
	status = dcm.SetTMUMatrix(PIN, SITE_1, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_5, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_2, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_6, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_7, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_3, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_8, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_4, DCM_TMU2);
	status = dcm.SetTMUParam(PIN, DCM_POS, 4, 0);
}

void measure_edge_get1(const char* PIN, double edge[])
{
	dcm.TMUMeasure(PIN, DCM_MEAS_EDGE, 1, 10);
	SERIAL
	{
		if((SITE%2)==0)
		{
			edge[SITE] = dcm.GetTMUMeasureResult("DCM6", SITE, DCM_EDGE);//us
			edge[SITE]=edge[SITE]*1000.0;
		}
	}
}

void measure_edge_get2(const char* PIN, double edge[])
{
	dcm.TMUMeasure(PIN, DCM_MEAS_EDGE, 1, 10);
	SERIAL
	{
		if((SITE%2)==1)
		{
			edge[SITE] = dcm.GetTMUMeasureResult("DCM6", SITE, DCM_EDGE);//us
			edge[SITE]=edge[SITE]*1000.0;
		}
	}
}

void measure_freq_duty_set(double vdd)
{
	int status;
	//int vdd = 3.3;
	const char* PIN = "DCM7";
	dcm.Connect(PIN);
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	dcm.SetPinLevel(PIN, dVIH, dVIL, dVOH, dVOL);
	dcm.SetChannelStatus(PIN, DCM_HIGH_IMPEDANCE);///<Ensure the waveform is ran from low
	//status = dcm.SetTMUMatrix(PIN, DCM_ALLSITE, DCM_ALL_TMU);///<Connect pin OUT1 to TMU unit1 of its controller
	status = dcm.SetTMUMatrix(PIN, SITE_1, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_5, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_2, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_6, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_7, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_3, DCM_TMU2);
	status = dcm.SetTMUMatrix(PIN, SITE_8, DCM_TMU1);
	status = dcm.SetTMUMatrix(PIN, SITE_4, DCM_TMU2);
	status = dcm.SetTMUParam(PIN, DCM_POS, 4, 0);
}

void measure_freq_get(const char* PIN, double freq[])
{
	double frequency[SITE_NUM];
	dcm.TMUMeasure(PIN, DCM_MEAS_FREQ_DUTY, 50, 20);
	SERIAL
	{
		frequency[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_FREQ);//KHz
		freq[SITE]=frequency[SITE];
	}
}

void measure_freq_get(double res[])
{
	const char* PIN = "DCM7";
	dcm.TMUMeasure(PIN, DCM_MEAS_FREQ_DUTY, 50, 20);
	SERIAL
	{
		res[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_FREQ);//KHz
	}
}

void measure_duty_get(const char* PIN, double freq[], double duty[])
{
	double th[SITE_NUM];
	//double tl[SITE_NUM];
	dcm.TMUMeasure(PIN, DCM_MEAS_FREQ_DUTY, 50, 20);
	SERIAL
	{
		freq[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_FREQ);//KHz
		th[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_HIGH_DUTY);
		//tl[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_LOW_DUTY);
		duty[SITE] = th[SITE];
	}
}

void measure_ton_get(const char* PIN, double freq[], double ton[])
{
	double th[SITE_NUM];
	//double tl[SITE_NUM];
	double tfreq[SITE_NUM];
	dcm.TMUMeasure(PIN, DCM_MEAS_FREQ_DUTY, 50, 20);
	SERIAL
	{
		th[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_HIGH_DUTY);
		tfreq[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_FREQ);
		//tl[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_LOW_DUTY);
		ton[SITE] = (1000000.0/tfreq[SITE])*(th[SITE]/100.0);//ns
		freq[SITE] = tfreq[SITE];
	}
}

void measure_toff_get(const char* PIN, double freq[], double toff[])
{
	//double th[SITE_NUM];
	double tl[SITE_NUM];
	double tfreq[SITE_NUM];
	dcm.TMUMeasure(PIN, DCM_MEAS_FREQ_DUTY, 50, 20);
	SERIAL
	{
		//th[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_HIGH_DUTY);
		tfreq[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_FREQ);
		tl[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_LOW_DUTY);
		toff[SITE] = (1000000.0/tfreq[SITE])*(tl[SITE]/100.0);//ns
		freq[SITE] = tfreq[SITE];
	}
}

void measure_t_get(const char* PIN, double freq[], double duty[], double ton[], double toff[])
{
	double th[SITE_NUM];
	double tl[SITE_NUM];
	double edge[SITE_NUM];
	double tfreq[SITE_NUM];
	dcm.TMUMeasure(PIN, DCM_MEAS_FREQ_DUTY, 50, 20);
	SERIAL
	{
		th[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_HIGH_DUTY);
		tfreq[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_FREQ);
		tl[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_LOW_DUTY);
		edge[SITE] = dcm.GetTMUMeasureResult(PIN, SITE, DCM_EDGE);
		ton[SITE] = (1000000.0/tfreq[SITE])*(th[SITE]/100.0);//ns
		toff[SITE] = (1000000.0/tfreq[SITE])*(tl[SITE]/100.0);//ns
		freq[SITE] = tfreq[SITE];
		duty[SITE] = th[SITE];
	}
}

void measure_rising(const char* lpszPinGroup, double rising[])
{
	///<Edge measurement, can't measure the edge time of DCM for the edge is too sharp for TMU unit
	dcm.SetChannelStatus("OUT1", DCM_HIGH_IMPEDANCE);///<Ensure the waveform is ran from low
 	dcm.SetTMUMatrix("OUT1", DCM_ALLSITE, DCM_TMU1);///<Connect pin OUT1 to TMU unit1 of its controller
	dcm.SetTMUMatrix("OUT1", DCM_ALLSITE, DCM_TMU2);///<Connect pin OUT1 to TMU unit2 of its controller
	dcm.SetTMUParam("OUT1", DCM_POS, 4, 0);
	dcm.TMUMeasure("OUT1", DCM_MEAS_EDGE, 1, 10);///<Start edge measurement
	SERIAL
	{
		rising[SITE] = dcm.GetTMUMeasureResult("OUT1", SITE, DCM_EDGE);
	}
}

void measure_delay(const char* lpszPinGroupA, const char* lpszPinGroupB, double delay[])
{
	///<Delay measurement, the waveform should input to channels which connect to TMU unit 1 and unit 2 
	dcm.SetTMUMatrix("OUT1", DCM_ALLSITE, DCM_TMU1);///<Connect pin OUT1 to TMU unit1 of its controller
	dcm.SetTMUMatrix("OUT2", DCM_ALLSITE, DCM_TMU2);///<Connect pin OUT2 to TMU unit2 of its controller
	dcm.SetTMUParam("G_TMU", DCM_POS, 0, 0);///<The trigger edge is positive

	///<Delay measurement
	dcm.TMUMeasure("G_TMU", DCM_MEAS_DELAY, 1, 20);///<Start delay measurement
	dcm.RunVectorWithGroup("G_TMU_IN", "TMU_ST", "TMU_SP");
	SERIAL
	{
		delay[SITE] = dcm.GetTMUMeasureResult("OUT2", SITE, DCM_DELAY);
	}
}


//void measure_CLK_CHECK(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
//	double freqslow[SITE_NUM];
//	double freqfast[SITE_NUM];
//
//	OTP_M_Preview(0, 2);
//	delay_ms(1);
//
//	//will search different range with different code
//	CLK_SWEEP(freqslow, freqfast,  80, 320, 10);
//	SERIAL{
//		g_freq_slow[SITE] = freqslow[SITE];
//		g_freq_fast[SITE] = freqfast[SITE];
//		results[SITE] = (freqslow[SITE] + freqfast[SITE]) / 2.0;
//	}
//}

void clk_sweep(double *freq_slow, double *freq_fast,  double range_min, double range_max, double range_step)
{
	double out_flip[200][SITE_NUM];
	ULONG failcount[SITE_NUM];
	double period;
	int count=0;
	count = (int)((range_max - range_min) / (range_step+1e-30)+1);
	SERIAL_ALL
	{
		freq_slow[SITE] = 0;
		freq_fast[SITE] = 0;

	}
	if (count <= 0)
	{
		return;
	}
	else
	{
		if (count > 200)count = 200;
		for (int i = 0; i < count; i++)
		{
			period = 1.0 / (range_min + range_step*i + 1e-30)*1e6;//scale to ns
			dcm.SetPeriod("CLK_SWEEP", period);
			dcm.SetEdge("FIN_WAKE2", "CLK_SWEEP", DCM_DTFT_RZ,DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);
			dcm.SetEdge("FOUT_INTB", "CLK_SWEEP", DCM_DTFT_RZ, DCM_IO_NRZ, period*0.25, period*0.75, period*0.25, period*0.75, period*0.5);

			int nRetVal = dcm.RunVectorWithGroup("CLK_CHK_G", "CLK_SWEEP_START", "CLK_SWEEP_STOP", true);

			SERIAL
			{
				dcm.GetFailCount("FOUT_INTB_D", SITE, failcount[SITE]);
				out_flip[i][SITE] = failcount[SITE];
			}
		}
		for (int i = 0; i < count; i++)
		{
			SERIAL
			{
				if (out_flip[i][SITE]>0)freq_slow[SITE] = range_min + range_step*i;

			}
			
		}
		for (int i = count-1; i > -1; i--)
		{
			SERIAL
			{
				if (out_flip[i][SITE]>0)freq_fast[SITE] = range_min + range_step*i;

			}
		}	
	}
}


///////////////////////////////////////
void measure_bg1_ref(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results)
{
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	Nvm_Preview(0);
	delay_ms(1);
	if (0)
	{
		A_STU.MeasureVI(10, 10);
		Get_Result(A_STU, results, MVRET);
	}
	else
	{
		A_ABUFO.MeasureVI(10, 10);
		Get_Result(A_ABUFO, results, MVRET);
	}
}

void measure_bg1_tc(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results)
{
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	Nvm_Preview(1);
	delay_ms(1);
	if (0)
	{
		A_STU.MeasureVI(10, 10);
		Get_Result(A_STU, results, MVRET);
	}
	else
	{
		A_ABUFO.MeasureVI(10, 10);
		Get_Result(A_ABUFO, results, MVRET);
	}
}

void measure_bg2_ref(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results)
{
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	Nvm_Preview(2);
	Nvm_Preview(3);
	delay_ms(1);
	if (0)
	{
		A_STU.MeasureVI(10, 10);
		Get_Result(A_STU, results, MVRET);
	}
	else
	{
		A_ABUFO.MeasureVI(10, 10);
		Get_Result(A_ABUFO, results, MVRET);
	}
}

void measure_bg2_tc(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results)
{
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	Nvm_Preview(4);
	delay_ms(1);
	if (0)
	{
		A_STU.MeasureVI(10, 10);
		Get_Result(A_STU, results, MVRET);
	}
	else
	{
		A_ABUFO.MeasureVI(10, 10);
		Get_Result(A_ABUFO, results, MVRET);
	}
}

void measure_ldo_ibias(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(2);
	delay_ms(1);
	A_STU.MeasureVI(10, 10);
	Get_Result(A_STU, results, MIRET);
    //awg.rampimv(A_QUC, A_DBUFO, ACM200_3p6V, ACM200_100MA, "ldo_ibias", 0 mA, 120 mA, 0.5 mA, 20, 2.5 V, TRIG_RISING, results);
    SERIAL results[SITE] = -(results[SITE]*1000000.0);//uA
}

void measure_qst_vref1(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(21);
	delay_ms(1);
	A_QST.MeasureVI(10, 10);
	Get_Result(A_QST, results, MVRET);
}

void measure_qst_vref2(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double vqst[SITE_NUM];
	double vquc[SITE_NUM];
    Nvm_Preview(21);
	delay_ms(1);
	A_QST.MeasureVI(10, 10);
	A_QUC.MeasureVI(10, 10);
	Get_Result(A_QST, vqst, MVRET);
	Get_Result(A_QUC, vquc, MVRET);
	SERIAL  results[SITE] = (vqst[SITE] - vquc[SITE])*1000.0;
}

void measure_qst_oc(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double v_qst = dut.trim("qst_vref1").get_target(0);
	//double v_qst = 5.0;//3.3V
	Nvm_Preview(20);
    Nvm_Preview(21);
	delay_ms(1);
	A_QST.Set(FV, v_qst*0.9, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON,1);
	//delay_ms(1);
	A_QST.MeasureVI(10, 10);
	Get_Result(A_QST, results, MIRET);
	SERIAL results[SITE] = -(results[SITE] * 1000.0);//mA
}

void measure_qvr_vref(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(18);
	delay_ms(1);
	A_QVR.MeasureVI(10, 10);
	Get_Result(A_QVR, results, MVRET);
}

void measure_quc_buf(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(3);
	Nvm_Preview(4);
	delay_ms(1);
	if (0)
	{
		A_STU.MeasureVI(10, 10);
		Get_Result(A_STU, results, MVRET);
	}
	else
	{
		A_ABUFO.MeasureVI(10, 10);
		Get_Result(A_ABUFO, results, MVRET);
	}
}

void measure_vmon_buf(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(5);
	delay_ms(1);
	if (0)
	{
		A_STU.MeasureVI(20, 10);
		Get_Result(A_STU, results, MVRET);
	}
	else
	{
		A_ABUFO.MeasureVI(20, 10);
		Get_Result(A_ABUFO, results, MVRET);
	}
}

void measure_qco_ea(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(9);
	delay_ms(1);
	A_QCO.MeasureVI(10, 10);
	Get_Result(A_QCO, results, MVRET);
}

void measure_qt1_vref(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	Cmd_Bank1(true);
    Nvm_Preview(22);
	delay_ms(1);
	double vqtx[SITE_NUM];
	double vos[SITE_NUM];
	double vqtx_post[SITE_NUM];
	bool track = false;
	if(dut.sel("QT1_VOUT").get_working(0)==0){track=true;}else{track=false;}
	if(track)
	{
		//delay_ms(5);
		qt1_qvr_os(vqtx, vos);
		SERIAL vqtx_post[SITE]=vos[SITE]/1000.0+PN_QVR_Output_Target;
	}
	else
	{
		//F_QT1.MeasureVI(10, 10);
		//Get_Result(F_QT1, vqtx_post, MVRET);
		qt1_measure(vqtx_post);
	}
	SERIAL results[SITE]=vqtx_post[SITE];
}

void measure_qt2_vref(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	Cmd_Bank1(true);
    Nvm_Preview(22);
	delay_ms(1);
	double vqtx[SITE_NUM];
	double vos[SITE_NUM];
	double vqtx_post[SITE_NUM];
	bool track = false;
	if(dut.sel("QT2_VOUT").get_working(0)==0){track=true;}else{track=false;}
	if(track)
	{
		//delay_ms(5);
		qt2_qvr_os(vqtx, vos);
		SERIAL vqtx_post[SITE]=vos[SITE]/1000.0+PN_QVR_Output_Target;
	}
	else
	{
		//F_QT2.MeasureVI(10, 10);
		//Get_Result(F_QT2, vqtx_post, MVRET);
		qt2_measure(vqtx_post);
	}
	SERIAL results[SITE]=vqtx_post[SITE];
}

void measure_qt3_vref(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy\_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	Cmd_Bank1(true);
    Nvm_Preview(5);
	delay_ms(1);
	double vqtx[SITE_NUM];
	double vos[SITE_NUM];
	double vqtx_post[SITE_NUM];
	bool track = false;
	if(dut.sel("QT3_VOUT").get_working(0)==0){track=true;}else{track=false;}
	if(track)
	{
		//delay_ms(5);
		qt3_qvr_os(vqtx, vos);
		SERIAL vqtx_post[SITE]=vos[SITE]/1000.0+PN_QVR_Output_Target;
	}
	else
	{
		//F_QT3.MeasureVI(10, 10);
		//Get_Result(F_QT3, vqtx_post, MVRET);
		qt3_measure(vqtx_post);
	}
	SERIAL results[SITE]=vqtx_post[SITE];
}

void measure_lfo12_100k(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(2);
	delay_ms(1);
	measure_freq_get("DCM7", results);//kHz
}

void measure_lfo12(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	Nvm_Preview(2);
	delay_us(500);
	if(PN_SEC_Available){measure_freq_get("DCM7", results);}//kHz
	else {measure_freq_get("DCM6", results);}//kHz
}

void measure_lfo1(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(2);
	delay_ms(2);
	measure_freq_get("DCM7", results);//kHz
}

void measure_lfo2(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(4);
	Nvm_Preview(12);
	Nvm_Preview(13);
	Nvm_Preview(20);
	delay_ms(1);
	if(PN_SEC_Available){measure_freq_get("DCM7", results);}//kHz
	else {measure_freq_get("DCM6", results);}//kHz
}

void measure_hfo12(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
	int working = trim_node->get_working(0);
#endif
	if (treg_measure_flag == TREG_MEASURE_CHAR) {}
	if (treg_measure_flag == TREG_MEASURE_PRE) {}
	if (treg_measure_flag == TREG_MEASURE_POST) {
		SERIAL{
			//if (device_trimmed[SITE])
			//trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
		}
	}
	Nvm_Preview(0);
	delay_us(500);
	if(PN_SEC_Available){measure_freq_get("DCM7", results);}//kHz
	else {measure_freq_get("DCM6", results);}//kHz
	SERIAL results[SITE] = results[SITE] / 1000.0;//MHz
}

void sweep_clk(int start, int stop, int step, double freq[])
{
	int pt[SITE_NUM];
	int trig[SITE_NUM];
	double vsec0[SITE_NUM];
	double vsec[SITE_NUM];
	int j = 0;

	DDS_Connect();
	delay_ms(1);
	DDS_SetFreq(start);
	delay_us(100);
	A_SECPOSFRE.MeasureVI(10, 1);
	Get_Result(A_SECPOSFRE, vsec0, MIRET);
	SERIAL pt[SITE] = 0;
	SERIAL trig[SITE] = 0;
	if(start<stop)
	{
		for (int i = start; i < stop; i = i + step)
		{
			DDS_SetFreq(i);
			delay_us(100);
			A_SECPOSFRE.MeasureVI(10, 1);
			Get_Result(A_SECPOSFRE, vsec, MIRET);
			SERIAL 
			{
				if (((vsec0[SITE] > 5 mA) && (vsec[SITE] < 5 mA) && (trig[SITE] == 0)) || ((vsec0[SITE] < 5 mA) && (vsec[SITE] > 5 mA) && (trig[SITE] == 0)))
				{ 
					trig[SITE] = 1; pt[SITE] = j; 
				}
			}
			j++;
		}
	}
	else
	{
		for (int i = stop; i > start; i = i - step)
		{
			DDS_SetFreq(i);
			delay_us(100);
			A_SECPOSFRE.MeasureVI(10, 1);
			Get_Result(A_SECPOSFRE, vsec, MIRET);
			SERIAL 
			{
				if (((vsec0[SITE] > 5 mA) && (vsec[SITE] < 5 mA) && (trig[SITE] == 0)) || ((vsec0[SITE] < 5 mA) && (vsec[SITE] > 5 mA) && (trig[SITE] == 0)))
				{ 
					trig[SITE] = 1; pt[SITE] = j; 
				}
			}
			j++;
		}
	}
	DDS_SetFreq(start);
	if(stop>start){SERIAL freq[SITE] = (start + pt[SITE] * step)/1000.0;}
	else{SERIAL freq[SITE] = (start - pt[SITE] * step)/1000.0;}
	//kHz
}

void sweep_clk_ss(int start, int stop, int step, double freq[])
{
	int pt[SITE_NUM];
	int trig[SITE_NUM];
	double vsec0[SITE_NUM];
	double vsec[SITE_NUM];
	int j = 0;

	DDS_Connect();
	delay_ms(1);
	DDS_SetFreq(start);
	delay_us(100);
	F_SS1.MeasureVI(10, 1);
	Get_Result(F_SS1, vsec0, MVRET);
	SERIAL pt[SITE] = 0;
	SERIAL trig[SITE] = 0;
	if(start<stop)
	{
		for (int i = start; i < stop; i = i + step)
		{
			DDS_SetFreq(i);
			delay_us(100);
			F_SS1.MeasureVI(10, 1);
			Get_Result(F_SS1, vsec, MVRET);
			SERIAL 
			{
				if (((vsec0[SITE] > 2) && (vsec[SITE] < 1) && (trig[SITE] == 0)) || ((vsec0[SITE] < 1) && (vsec[SITE] > 2) && (trig[SITE] == 0)))
				{ 
					trig[SITE] = 1; pt[SITE] = j; 
				}
			}
			j++;
		}
	}
	else
	{
		for (int i = start; i > stop; i = i - step)
		{
			DDS_SetFreq(i);
			delay_us(100);
			F_SS1.MeasureVI(10, 1);
			Get_Result(F_SS1, vsec, MVRET);
			SERIAL 
			{
				if (((vsec0[SITE] > 2) && (vsec[SITE] < 1) && (trig[SITE] == 0)) || ((vsec0[SITE] < 1) && (vsec[SITE] > 2) && (trig[SITE] == 0)))
				{ 
					trig[SITE] = 1; pt[SITE] = j; 
				}
			}
			j++;
		}
	}
	DDS_SetFreq(start);
	if(stop>start){SERIAL freq[SITE] = (start + pt[SITE] * step)/1000.0;}
	else{SERIAL freq[SITE] = (start - pt[SITE] * step)/1000.0;}
	//kHz
}

void sweep_clk_ss_onetime(int start, int stop, int step, double freql[], double freqh[], double freq[])
{
	int ptl[SITE_NUM];
	int trigl[SITE_NUM];
	int pth[SITE_NUM];
	int trigh[SITE_NUM];
	double vsec[SITE_NUM];
	int j = 0;

	DDS_Connect();
	delay_ms(1);
	DDS_SetFreq(start);
	SERIAL ptl[SITE] = 0;
	SERIAL trigl[SITE] = 0;
	SERIAL pth[SITE] = 0;
	SERIAL trigh[SITE] = 0;
	SERIAL freql[SITE] = 0;
	SERIAL freqh[SITE] = 0;
	if(start<stop)
	{
		for (int i = start; i < stop; i = i + step)
		{
			DDS_SetFreq(i);
			delay_us(100);
			F_SS1.MeasureVI(10, 1);
			Get_Result(F_SS1, vsec, MVRET);
			SERIAL 
			{
				if ((vsec[SITE] > 2) && (trigl[SITE] == 0))
				{ 
					trigl[SITE] = 1; ptl[SITE] = j; 
				}
				if ((vsec[SITE] < 1) && (trigl[SITE] == 1) && (trigh[SITE] == 0))
				{ 
					trigh[SITE] = 1; pth[SITE] = j; 
				}
			}
			j++;
		}
	}
	else
	{
		for (int i = start; i > stop; i = i - step)
		{
			DDS_SetFreq(i);
			delay_us(100);
			F_SS1.MeasureVI(10, 1);
			Get_Result(F_SS1, vsec, MVRET);
			SERIAL 
			{
				if ((vsec[SITE] > 2) && (trigl[SITE] == 0))
				{ 
					trigl[SITE] = 1; ptl[SITE] = j; 
				}
				if ((vsec[SITE] < 1) && (trigl[SITE] == 1) && (trigh[SITE] == 0))
				{ 
					trigh[SITE] = 1; pth[SITE] = j; 
				}
			}
			j++;
		}
	}
	DDS_SetFreq(start);
	SERIAL
	{
		if(stop>start)
		{
			freql[SITE] = (start + ptl[SITE] * step)/1000.0;
			freqh[SITE] = (start + pth[SITE] * step)/1000.0;
		}
		else
		{
			freql[SITE] = (start - ptl[SITE] * step)/1000.0;
			freqh[SITE] = (start - pth[SITE] * step)/1000.0;
		}
		freq[SITE] = (freql[SITE] + freqh[SITE])/2.0;//kHz
	}

}

void sweep_clk2(int start, int stop, int step, double freq[])
{
	int dir[SITE_NUM];
	int freq0[SITE_NUM];
	double freql[SITE_NUM];
	double freqh[SITE_NUM];
	double range[SITE_NUM];
	double freqtmp[SITE_NUM];
	double vsec0[SITE_NUM];
	double vsec[SITE_NUM];
	int N = 10;
	//N = step;

	SERIAL freql[SITE]=start;
	SERIAL freqh[SITE]=stop;

	DDS_Connect();
	delay_ms(1);
	DDS_SetFreq(start);
	delay_us(100);
	A_SECPOSFRE.MeasureVI(10, 1);
	Get_Result(A_SECPOSFRE, vsec0, MVRET);
	SERIAL dir[SITE] = 0;//less
	for (int i = 0; i < N; i++)
	{
		SERIAL freq0[SITE]=(freql[SITE]+freqh[SITE])/2;
		DDS_SetFreq(freq0);
		delay_us(100);
		A_SECPOSFRE.MeasureVI(10, 1);
		Get_Result(A_SECPOSFRE, vsec, MVRET);
		SERIAL 
		{
			if (((vsec0[SITE] > 2) && (vsec[SITE] < 1)) || ((vsec0[SITE] < 1) && (vsec[SITE] > 2)))
			{ 
				dir[SITE] = 1; 
				//freq0[SITE]=freql[SITE];
			}
			else{dir[SITE] = 0; }
		}
		//DDS_SetFreq(freq0);
		SERIAL
		{
			range[SITE]=freqh[SITE]-freql[SITE];
			if(dir[SITE]==0){freql[SITE]=freq0[SITE]-range[SITE]*0.1;}
			else{freqh[SITE]=freq0[SITE]+range[SITE]*0.1;}
		}
	}
	DDS_SetFreq(start);
	SERIAL freq[SITE] = freql[SITE]/1000.0;
	//kHz
}

void sweep_clk2_ss(int start, int stop, int step, double freq[])
{
	int dir[SITE_NUM];
	int freq0[SITE_NUM];
	double freql[SITE_NUM];
	double freqh[SITE_NUM];
	double range[SITE_NUM];
	double freqtmp[SITE_NUM];
	double vsec0[SITE_NUM];
	double vsec[SITE_NUM];
	int N = 10;
	//N = step;

	SERIAL freql[SITE]=start;
	SERIAL freqh[SITE]=stop;

	DDS_Connect();
	delay_ms(1);
	DDS_SetFreq(start);
	delay_us(100);
	F_SS1.MeasureVI(10, 1);
	Get_Result(F_SS1, vsec0, MVRET);
	SERIAL dir[SITE] = 0;//less
	for (int i = 0; i < N; i++)
	{
		SERIAL freq0[SITE]=(freql[SITE]+freqh[SITE])/2;
		DDS_SetFreq(freq0);
		delay_us(100);
		F_SS1.MeasureVI(10, 1);
		Get_Result(F_SS1, vsec, MVRET);
		SERIAL 
		{
			if (((vsec0[SITE] > 2) && (vsec[SITE] < 1)) || ((vsec0[SITE] < 1) && (vsec[SITE] > 2)))
			{ 
				dir[SITE] = 1; 
				//freq0[SITE]=freql[SITE];
			}
			else{dir[SITE] = 0; }
		}
		//DDS_SetFreq(freq0);
		SERIAL
		{
			range[SITE]=freqh[SITE]-freql[SITE];
			if(dir[SITE]==0){freql[SITE]=freq0[SITE]-range[SITE]*0.1;}
			else{freqh[SITE]=freq0[SITE]+range[SITE]*0.1;}
		}
	}
	DDS_SetFreq(start);
	SERIAL freq[SITE] = freql[SITE]/1000.0;
	//kHz
}

void measure_lfo_check(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	DUT_SPI_Connect(4.0);
    Nvm_Preview(3);
	
	double freql[SITE_NUM];
	double freqh[SITE_NUM];
	int pt[SITE_NUM];
	int trig[SITE_NUM];
	double vsec[SITE_NUM];
	
	int start = 90 KHz;
	int stop = 300 KHz;
	int step = 5 KHz;
	int j = 0;

	Cmd_Dmuxset_Fs0(8);//slow
	start = 90 KHz;
	stop = 350 KHz;
	step = 10 KHz;
	sweep_clk(start, stop, step, freql);

	DUT_SPI_Connect(4.0);
	Cmd_Dmuxset_Fs0(7);//fast
	start = 180 KHz;
	stop = 650 KHz;
	step = 10 KHz;
	sweep_clk(start, stop, step, freqh);

	SERIAL results[SITE] = (freql[SITE]+freqh[SITE])/2.0;
	//SERIAL results[SITE] = freql[SITE];
	//SERIAL results[SITE] = freqh[SITE];
	//measure_freq_get("DCM4", results);
}

void measure_lfo_check_ss(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	DUT_SPI_Connect(4.0);
    Nvm_Preview(3);
	
	double freql[SITE_NUM];
	double freqh[SITE_NUM];
	int pt[SITE_NUM];
	int trig[SITE_NUM];
	double vsec[SITE_NUM];
	
	int start = 90 KHz;
	int stop = 300 KHz;
	int step = 5 KHz;
	int j = 0;

	//Cmd_Dmuxset_Fs0(8);//slow
	start = 90 KHz;
	stop = 350 KHz;
	step = 10 KHz;
	sweep_clk_ss(start, stop, step, freql);

	DUT_SPI_Connect(4.0);
	//Cmd_Dmuxset_Fs0(7);//fast
	start = 650 KHz;
	stop = 180 KHz;
	step = 10 KHz;
	sweep_clk_ss(start, stop, step, freqh);

	SERIAL results[SITE] = (freql[SITE]+freqh[SITE])/2.0;
	//SERIAL results[SITE] = freql[SITE];
	//SERIAL results[SITE] = freqh[SITE];
	//measure_freq_get("DCM4", results);
}

void measure_lfo_check_ss_onetime(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	DUT_SPI_Connect(4.0);
    Nvm_Preview(3);
	int start_freq[16]={140 KHz, 130 KHz, 120 KHz, 110 KHz, 105 KHz, 100 KHz, 95 KHz, 90 KHz, 320 KHz, 280 KHz, 240 KHz, 220 KHz, 200 KHz, 180 KHz, 160 KHz, 150 KHz};
	int stop_freq[16]={350 KHz, 330 KHz, 310 KHz, 300 KHz, 290 KHz, 280 KHz, 270 KHz, 260 KHz, 640 KHz, 580 KHz, 530 KHz, 480 KHz, 450 KHz, 420 KHz, 390 KHz, 370 KHz};
	
	int code = trim_node->get_working(0);
	int start = start_freq[code];
	int stop = stop_freq[code];
	int step = abs((stop-start)/20);
	sweep_clk_ss_onetime(start, stop, step, clk_chkl, clk_chkh, clk_chk);

	SERIAL results[SITE] = clk_chk[SITE];
}

void datalog_clk_chk(short funcindex)
{
	Ms_LogData(funcindex, "lfo_check_cen", clk_chk);
	Ms_LogData(funcindex, "lfo_check_low", clk_chkl);
	Ms_LogData(funcindex, "lfo_check_high", clk_chkh);
}

void measure_lfo_check2(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	DUT_SPI_Connect(4.0);
    Nvm_Preview(3);
	
	double freql[SITE_NUM];
	double freqh[SITE_NUM];
	int pt[SITE_NUM];
	int trig[SITE_NUM];
	double vsec[SITE_NUM];
	
	int start = 90 KHz;
	int stop = 300 KHz;
	int step = 5 KHz;
	int j = 0;

	Cmd_Dmuxset_Fs0(8);//slow
	start = 90 KHz;
	stop = 350 KHz;
	step = 10 KHz;
	sweep_clk2(start, stop, step, freql);

	DUT_SPI_Connect(4.0);
	Cmd_Dmuxset_Fs0(7);//fast
	start = 180 KHz;
	stop = 650 KHz;
	step = 10 KHz;
	sweep_clk2(start, stop, step, freqh);

	SERIAL results[SITE] = (freql[SITE]+freqh[SITE])/2.0;
	//SERIAL results[SITE] = freql[SITE];
	//SERIAL results[SITE] = freqh[SITE];
	//measure_freq_get("DCM4", results);
}

void measure_lfo_check2_ss(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	DUT_SPI_Connect(4.0);
    Nvm_Preview(3);
	

	double freql[SITE_NUM];
	double freqh[SITE_NUM];
	int pt[SITE_NUM];
	int trig[SITE_NUM];
	double vsec[SITE_NUM];
	
	int start = 90 KHz;
	int stop = 300 KHz;
	int step = 5 KHz;
	int j = 0;

	Cmd_Dmuxset_Fs0(8);//slow
	start = 90 KHz;
	stop = 350 KHz;
	step = 10 KHz;
	sweep_clk2_ss(start, stop, step, freql);

	DUT_SPI_Connect(4.0);
	Cmd_Dmuxset_Fs0(7);//fast
	start = 180 KHz;
	stop = 650 KHz;
	step = 10 KHz;
	sweep_clk2_ss(start, stop, step, freqh);

	SERIAL results[SITE] = (freql[SITE]+freqh[SITE])/2.0;
	//SERIAL results[SITE] = freql[SITE];
	//SERIAL results[SITE] = freqh[SITE];
	//measure_freq_get("DCM4", results);
}

void measure_bst_osc(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(10);
	delay_ms(2);
	measure_freq_get("DCM7", results);
}

void measure_bst_ea(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double val1[SITE_NUM];
	double val2[SITE_NUM];
	double start = 8.4;
	double stop = 6.2;
	double step = calc_step(start,stop,100);
    Nvm_Preview(6);
	delay_ms(2);//acm9
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "bst_ea", start, stop, step, 50, 0.5 mA, TRIG_FALLING, val1);
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "bst_ea", stop, start, step, 50, 0.5 mA, TRIG_RISING, val2);
	SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
}

void measure_bst_ea2(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results) {
#ifdef _DEBUG
	int working = trim_node->get_working(0);
#endif
	if (treg_measure_flag == TREG_MEASURE_CHAR) {}
	if (treg_measure_flag == TREG_MEASURE_PRE) {}
	if (treg_measure_flag == TREG_MEASURE_POST) {
		SERIAL{
			//if (device_trimmed[SITE])
			//trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
		}
	}
	double val1[SITE_NUM];
	double val2[SITE_NUM];
	double start = 8.6;
	double stop = 6.5;
	double step = calc_step(start, stop, 100);
	Nvm_Preview(1);
	delay_ms(2);//acm9
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "bst_ea", start, stop, step, 50, 0.5 mA, TRIG_FALLING, val1);
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "bst_ea", stop, start, step, 50, 0.5 mA, TRIG_RISING, val2);
	SERIAL results[SITE] = (val1[SITE] + val2[SITE]) / 2.0;
}

void measure_bst_uv(TRIM_NODE* trim_node, TREG_MEASURE_FLAG treg_measure_flag, double* results) {
#ifdef _DEBUG
	int working = trim_node->get_working(0);
#endif
	if (treg_measure_flag == TREG_MEASURE_CHAR) {}
	if (treg_measure_flag == TREG_MEASURE_PRE) {}
	if (treg_measure_flag == TREG_MEASURE_POST) {
		SERIAL{
			//if (device_trimmed[SITE])
			//trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
		}
	}
	double val1[SITE_NUM];
	double val2[SITE_NUM];
	double start = 7.2;
	double stop = 9.2;
	double step = calc_step(start, stop, 100);
	Nvm_Preview(6);//preiview bst ea
	delay_ms(2);//acm9
	//awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_UV1", start, stop, step, 30, 2.5 mA, TRIG_RISING, val1);
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_UV2", stop, start, step, 30, 2.5 mA, TRIG_FALLING, val2);
	SERIAL results[SITE] = val2[SITE];
}

void measure_bst_gain(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double val1[SITE_NUM];
	double val2[SITE_NUM];
	double current = 0;
	double voltage = 0.17;//V
	double voltage1 = 0.05;//V
	double voltage2 = 0.10;//V
    Nvm_Preview(6);
	delay_ms(2);
	if(use_lsi_dfi)
	{
		if(DIE_VER()==0)
		{
			current = voltage/lsi_dfi_gain;//8.5mA
			fpvi0.Set(FI, current, FPVIe_2V, FPVIe_10MA, FPVIe_RELAY_ON);
			delay_ms(2);
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val1, MIRET);
		}
		else
		{
			current = voltage1/lsi_dfi_gain;//8.5mA
			fpvi0.Set(FI, current, FPVIe_2V, FPVIe_10MA, FPVIe_RELAY_ON);
			delay_ms(2);
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val1, MVRET);
			current = voltage2/lsi_dfi_gain;//8.5mA
			fpvi0.Set(FI, current, FPVIe_2V, FPVIe_10MA, FPVIe_RELAY_ON);
			delay_ms(2);
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val2, MVRET);
		}
	}
	else
	{
		if(DIE_VER()==0)
		{
			fpvi0.Set(FV, voltage, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
			delay_ms(2);
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val1, MIRET);
		}
		else
		{
			fpvi0.Set(FV, voltage1, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
			delay_ms(2);
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val1, MVRET);
			fpvi0.Set(FV, voltage2, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
			delay_ms(2);
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val2, MVRET);
		}
	}
	
	if(DIE_VER()==0)
	{
		SERIAL val1[SITE] = -val1[SITE];
		SERIAL  results[SITE] = ((val1[SITE]*1000000.0*32*31.97)/24.0)/(voltage*1000.0);
	}
	else
	{
		SERIAL  results[SITE] = (val2[SITE]-val1[SITE])/(voltage2-voltage1);
		//SERIAL  results[SITE] = (val1[SITE])/(voltage1);
	}
}

void measure_bst_ilos(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double val1[SITE_NUM];
	double current = 0;
	double voltage = 0;
	if(DIE_VER()==0) {voltage = 0.0;}
	else {voltage = 0.1;}
    Nvm_Preview(7);
	delay_ms(2);
	if(use_lsi_dfi)
	{
		current = voltage/lsi_dfi_gain;//8.5mA
		fpvi0.Set(FI, current, FPVIe_2V, FPVIe_10MA, FPVIe_RELAY_ON);
		delay_ms(2);
		if(DIE_VER()==0)
		{
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val1, MIRET);
		}
		else
		{
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val1, MVRET);
		}
	}
	else
	{
		fpvi0.Set(FV, voltage, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
		delay_ms(2);
		if(DIE_VER()==0)
		{
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val1, MIRET);
		}
		else
		{
			A_STU.MeasureVI(50, 10);
			Get_Result(A_STU, val1, MVRET);
		}
	}
	if(DIE_VER()==0)
	{
		SERIAL val1[SITE] = -val1[SITE];
		SERIAL  results[SITE] = val1[SITE]*1000000.0;//uA
		//SERIAL  results[SITE] = ((val1[SITE]*1000000.0*32*31.97)/24.0)/5.27;
	}
	else
	{
		SERIAL  results[SITE] = (val1[SITE]-(voltage*dut.trim("bst_gain").get_pre_reading(SITE)))*1000.0;//mV
	}
}

void measure_bst_minpk(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(8);
	delay_ms(1);//acm9
	double current1 = 0;
	double current2 = 0;
	double voltage1 = -0.05;
	double voltage2 = 0.10;
	if(use_lsi_dfi)
	{
		current1 = voltage1/lsi_dfi_gain;
		current2 = voltage2/lsi_dfi_gain;
		double step = calc_step(current1,current2,100);
		awg.rampimi(fpvi0, A_SECPOSFRE, FPVIe_2V, FPVIe_10MA, "bst_minpk", current1, current2, step, 20, 0.5 mA, TRIG_RISING, results);
		SERIAL results[SITE]=results[SITE]*lsi_dfi_gain;
	}
	else
	{
		double step = calc_step(voltage1,voltage2,100);
		awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_1V, FPVIe_10MA, "bst_minpk", voltage1, voltage2, step, 20, 0.5 mA, TRIG_RISING, results);
	}
	SERIAL  results[SITE] = results[SITE] * 1000.0; 
}

void measure_bst_maxpk(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(8);
	delay_ms(1);
	double current = 0;
	double voltage = 0.4;
	if(use_lsi_dfi)
	{
		current = voltage/lsi_dfi_gain;
		double step = calc_step(0,current,100);
		awg.rampimi(fpvi0, A_SECPOSFRE, FPVIe_5V, FPVIe_100MA, "bst_maxpk", 0, current, step, 20, 5 mA, TRIG_RISING, results);
		SERIAL results[SITE]=results[SITE]*lsi_dfi_gain;
	}
	else
	{
		double step = calc_step(0,voltage,100);
		awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_1V, FPVIe_1MA, "bst_maxpk", 0, voltage, step, 20, 5 mA, TRIG_RISING, results);
	}
	SERIAL  results[SITE] = results[SITE] * 1000.0; 
}

void measure_bst_lmtos(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double val_tm24[SITE_NUM];
	SERIAL val_tm24[SITE]=dut.trim("bst_ocp_stg_war").get_post_reading(SITE);
    Nvm_Preview(8);
	delay_ms(1);
	double current = 0;
	double voltage = 0.4;
	if(use_lsi_dfi)
	{
		current = voltage/lsi_dfi_gain;
		double step = calc_step(0,current,120);
		awg.rampimi(fpvi0, A_SECPOSFRE, FPVIe_5V, FPVIe_100MA, "bst_maxpk", 0, current, step, 20, 5 mA, TRIG_RISING, results);
		SERIAL results[SITE]=results[SITE]*lsi_dfi_gain;
	}
	else
	{
		double step = calc_step(0,voltage,120);
		awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_1V, FPVIe_1MA, "bst_maxpk", 0, voltage, step, 20, 5 mA, TRIG_RISING, results);
	}
	SERIAL  results[SITE] = results[SITE] * 1000.0 - val_tm24[SITE];
}

void measure_bst_ocp_stg_war(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(9);
	delay_ms(1);
	double current = 0;
	double voltage = 0.5;
	if(use_lsi_dfi)
	{
		current = voltage/lsi_dfi_gain;
		double step = calc_step(0,current,100);
		awg.rampimi(fpvi0, A_SECPOSFRE, FPVIe_5V, FPVIe_100MA, "bst_ocp_stg_war", 0, current, step, 20, 5 mA, TRIG_RISING, results);
		SERIAL results[SITE]=results[SITE]*lsi_dfi_gain;
	}
	else
	{
		double step = calc_step(0,voltage,100);
		awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_1V, FPVIe_1MA, "bst_ocp_stg_war", 0, voltage, step, 20, 5 mA, TRIG_RISING, results);
	}
	SERIAL  results[SITE] = results[SITE] * 1000.0; 
}

void measure_prebk_pvss_f(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    double val1[SITE_NUM];
    Nvm_Preview(13);
	delay_ms(1);
	A_STU.MeasureVI(30, 10);
	Get_Result(A_STU, val1, MVRET);
	SERIAL  results[SITE] = val1[SITE];
}

void measure_prebk_ea(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double val1[SITE_NUM];
	double val2[SITE_NUM];
	double start = PN_Prebk_Output-0.5;
	double stop = PN_Prebk_Output+0.6;
	if(start<0){start=0;}
	double step = calc_step(start,stop,100);
    Nvm_Preview(10);
	delay_us(100);
	int interval = 100;
	if(DIE_VER()==0){interval = 100;}
	else{interval = 50;}
	//awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", start, stop, step, 200, 2.5 V, TRIG_RISING, results);
	//awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", start, stop, step, 2000, 2.5 V, TRIG_RISING, results);
	awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", start, stop, step, interval, 2.5 V, TRIG_RISING, val1);
	awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", stop, start, step, interval, 2.5 V, TRIG_FALLING, val2);
	SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
}

void measure_prebk_osc(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double frequency[SITE_NUM];
    Nvm_Preview(13);
	delay_ms(2);
	measure_freq_get("DCM5",frequency);
	SERIAL  results[SITE] = frequency[SITE]*2.0;
}

void measure_prebk_minpk(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double value[SITE_NUM];
    Nvm_Preview(12);
	delay_ms(1);
	//awg.rampvmi_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_minpk", -0.2 V, 1.5 V, 0.01 V, 20, 8.8 mA, TRIG_RISING, value);
	prebk_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_minpk", -0.2 V, 1.6 V, value);
    //awg.rampvmi(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_minpk", 0 V, 1.5 V, 0.01 V, 20, 8.8 mA, TRIG_RISING, value);
	//awg.rampvmi(fpvi0, fxvi5, FPVIe_2V, FPVIe_100MA, "prebk_minpk", 0 V, 1 V, 0.01 V, 20, 7.0 mA, TRIG_RISING, value);
	SERIAL  results[SITE] = value[SITE]/(PREBK_HSRDSON[SITE]/1000.0); 
	SERIAL
	{
		if (results[SITE] > 100)
		{
			delay_us(1);
		}
		if (results[SITE] < 0.1)
		{
			delay_us(1);
		}
	}
}

void measure_prebk_minpk2(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double value[SITE_NUM];
	double start = -0.5;
	double stop = 1.5;
	double step = calc_step(start,stop,100);
	//Cmd_Forceoff(except_dcdc);
	//fpvi0.Set(FI, 0, FPVIe_10V, FPVIe_100MA, FPVIe_RELAY_ON);
	fpvi0.Set(FI, start, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON, 1);
	Cmd_TMSel(0x00);
	Cmd_TMSel(0x0000000000900100);
	//delay_ms(2);
	//dut.trim("prebk_minpk").set_working(0);
	//Nvm_Preview(12);
	//dut.trim("prebk_minpk").set_working(6);
    Nvm_Preview(12);
	delay_ms(2);
	//awg.rampvmi_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_minpk", -0.2 V, 1.5 V, 0.01 V, 20, 8.8 mA, TRIG_RISING, value);
	//test_prebk(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_minpk", -0.2 V, 1.6 V, value);
	fpvi0.Set(FI, start, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
    //awg.rampimv(fpvi0, A_DBUFO, FPVIe_10V, FPVIe_2A, "prebk_minpk", start, stop, step, 20, 5.0, TRIG_FALLING, results);
	prebk_minipk2(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_2A, "prebk_minpk", start, stop, results);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	//delay_ms(2);
	//fpvi0.Set(FI, 0, FPVIe_10V, FPVIe_2A, FPVIe_RELAY_ON,1);
	//fpvi0.Set(FI, 0, FPVIe_10V, FPVIe_100MA, FPVIe_RELAY_ON,1);
	//awg.rampvmi(fpvi0, fxvi5, FPVIe_2V, FPVIe_100MA, "prebk_minpk", 0 V, 1 V, 0.01 V, 20, 7.0 mA, TRIG_RISING, value);
	//Cmd_Forceoff(except_quc);
	//SERIAL  results[SITE] = value[SITE]/(PREBK_HSRDSON[SITE]/1000.0); 
	SERIAL
	{
		if (results[SITE] > 100)
		{
			delay_us(1);
		}
		if (results[SITE] < 0.1)
		{
			delay_us(1);
		}
	}
}

void measure_prebk_hscl(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double value[SITE_NUM];
    Nvm_Preview(11);
	delay_ms(1);
	double start = -0.3;
	double stop = 2.4;
	//awg.rampvmi_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_hscl", -0.2 V, 2.0 V,step, 20, 13.8 mA, TRIG_RISING, value);
	prebk_hscl(fpvi0, fxvi4, FPVIe_5V, FPVIe_100MA, "prebk_hscl", start, stop, value);
    //awg.rampvmi(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_hscl", 0 V, 1.5 V, 0.01 V, 20, 13.8 mA, TRIG_RISING, value);
	//awg.rampvmi(fpvi0, fxvi5, FPVIe_2V, FPVIe_100MA, "prebk_hscl", 0 V, 1.5 V, 0.01 V, 20, 12.2 mA, TRIG_RISING, value);
	SERIAL  results[SITE] = value[SITE]/(PREBK_HSRDSON[SITE]/1000.0); 
	SERIAL
	{
		if (results[SITE] > 100)
		{
			results[SITE] = 10.9999;
			delay_us(1);
		}
		if (results[SITE] < 0.1)
		{
			delay_us(1);
		}
	}
}

void measure_prebk_hscl2(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double value[SITE_NUM];
	Cmd_TMSel(0x0000000000900100);
	Cmd_TMSel(0x0048000000B00100);
    Nvm_Preview(11);
	delay_ms(1);
	double start = -1;
	double stop = 6.5;
	double step = calc_step(start,stop, 100);
	prebk_hscl(fpvi0, FPVIe_5V, FPVIe_10A, "prebk_hscl2", start, stop, value);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL  results[SITE] = value[SITE]; 
	SERIAL
	{
		if (results[SITE] > 100)
		{
			results[SITE] = 10.9999;
			delay_us(1);
		}
		if (results[SITE] < 0.1)
		{
			delay_us(1);
		}
	}
}

void measure_prebk_lscl(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double value[SITE_NUM];
    Nvm_Preview(12);
	delay_ms(1);//acm10
	double start = 0.6;
	double stop = -1.2;
	double step=calc_step(start,stop,100);
    awg.rampvmv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_2A, "prebk_lscl", start, stop, step, 20, 2.5, TRIG_FALLING, value);
	//awg.rampvmi(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_hscl", -1 V, 1 V, 0.05 V, 20, 13.5 mA, TRIG_RISING, results);
	//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	SERIAL  results[SITE] = -value[SITE]/(PREBK_LSRDSON[SITE]/1000.0); //A
	SERIAL
	{
		if (results[SITE] > 9)
		{
			results[SITE] = 8.9999;
			delay_us(1);
		}
	}
}

void measure_prebk_lscl2(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double value[SITE_NUM];
    Nvm_Preview(12);
	delay_ms(1);//acm10
	double start = 0.6;
	double stop = -8.0;
	double step=calc_step(start,stop,100);
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_10A, "prebk_lscl", start, stop, step, 10, 2.5, TRIG_FALLING, value);
	//awg.rampvmi(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_hscl", -1 V, 1 V, 0.05 V, 20, 13.5 mA, TRIG_RISING, results);
	fpvi0.Set(FI, 0, FPVIe_2V, FPVIe_10A, FPVIe_RELAY_ON);
	SERIAL  results[SITE] = -value[SITE]; //A
	SERIAL
	{
		if ((results[SITE] > 9)|| (results[SITE] < -9))
		{
			results[SITE] = 99;
			delay_us(1);
		}
	}
	delay_us(1);
}

void measure_prebk_zc(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double value[SITE_NUM];
    Nvm_Preview(14);
	delay_ms(1);
	if(DIE_VER()==0)
	{
		double start = 0.05;
		double stop = -0.05;
		double step=calc_step(start,stop,120);
		awg.rampvmv(fpvi0, A_DBUFO, FPVIe_100MV, FPVIe_100MA, "prebk_zc", start, stop, step, 20, 2.5 V, TRIG_RISING, value);
		//SERIAL  results[SITE] = (value[SITE]/(PREBK_LSRDSON[SITE]/1000.0))*1000.0; //mA
		SERIAL  results[SITE] = -(value[SITE]/(PREBK_LSRDSON[SITE]/1000.0))*1000.0; //mA
	}
	else
	{
		double start = 0.3;
		double stop = -0.3;
		double step=calc_step(start,stop,120);
		fpvi0.Set(FV, start, FPVIe_100MV, FPVIe_1A, FPVIe_RELAY_ON);
		awg.rampimv(fpvi0, A_DBUFO, FPVIe_100MV, FPVIe_1A, "prebk_zc", start, stop, step, 20, 2.5 V, TRIG_RISING, value);
		//SERIAL  results[SITE] = (value[SITE]/(PREBK_LSRDSON[SITE]/1000.0))*1000.0; //mA
		SERIAL  results[SITE] = -value[SITE]*1000.0; //mA
	}
}

void measure_postbk_ea(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double val1[SITE_NUM];
	double val2[SITE_NUM];
	double start = PN_Posbk_Output-0.2;
	double stop = PN_Posbk_Output+0.2;
	if(start<0){start=0;}
	double step = calc_step(start,stop,150);
    Nvm_Preview(15);
	delay_ms(1);//acm7,acm10
	//awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", start, stop, step, 20, 2.5 V, TRIG_FALLING, results);
    //awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", start, stop, step, 200, 2.5 V, TRIG_FALLING, results);
	awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", start, stop, step, 20, 2.5 V, TRIG_FALLING, val1);
	awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", stop, start, step, 20, 2.5 V, TRIG_RISING, val2);
	SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
	//set_posfb(0.0);
	//set_posfb(2.0);
}

void measure_postbk_osc_fh(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(16);
	Nvm_Preview(17);
	delay_ms(1);
	measure_freq_get("DCM5", results);
	SERIAL  results[SITE] = results[SITE]/1000.0;
}

void measure_postbk_osc_fl(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(17);
	delay_ms(1);
	measure_freq_get("DCM5", results);
}

void measure_postbk_vy_negcl(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double step = calc_step(0,2.2,100);
    Nvm_Preview(18);
	delay_ms(5);//acm10
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_vy_negcl", 0 A, 2.2 A, step, 30, 2.5 V, TRIG_FALLING, results);
	SERIAL results[SITE]=-results[SITE];
}

void measure_postbk_negcl(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double step = calc_step(0,2,100);
    Nvm_Preview(16);
	delay_ms(5);
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_2A, "postbk_negcl", 0 A, 2 A, step, 30, 2.5 V, TRIG_FALLING, results);
	SERIAL results[SITE]=-2.0*results[SITE];
}

void posbk_vymax_convert(double data_measure[],double data_vynecl[],double data_out[])
{
	double results[SITE_NUM];
	double vy_negcl[SITE_NUM];
	SERIAL  results[SITE] = data_measure[SITE];
	SERIAL  vy_negcl[SITE] = data_vynecl[SITE];
	if (DIE_VER() == 0)
	{
		SERIAL  results[SITE] = results[SITE] * 7.0 - vy_negcl[SITE];//need - tm82 value(abs), abs down
	}
	else
	{
		SERIAL  results[SITE] = results[SITE] * (17 / 5) - vy_negcl[SITE];//need - tm82 value(abs), abs down
		SERIAL  results[SITE] = results[SITE] - 0.25;//2026_2_6 by correlation
	}
	SERIAL  data_out[SITE] = results[SITE];
}

void measure_postbk_vymax(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double vy_negcl[SITE_NUM];
	double result[SITE_NUM];
	SERIAL vy_negcl[SITE]=dut.trim("postbk_vy_negcl").get_post_reading(SITE);
	double start = 0.0;
	double stop = -3.2;
	double step = calc_step(start,stop,100);
    Nvm_Preview(19);
	delay_ms(1);//acm10
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_vymax", start, stop, step, 20, 2.5 V, TRIG_RISING, result);
	posbk_vymax_convert(result, vy_negcl, results);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
}

void measure_postbk_vymax2(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	int posbk_limit = dut.sel("POSTBK_LMT").get_working(0);
	double vy_negcl[SITE_NUM];
	SERIAL vy_negcl[SITE]=dut.trim("postbk_vy_negcl").get_post_reading(SITE);
	double start = -2.2;
	double stop = -6.5;
	if(posbk_limit==0){start = -0.2;stop = -4.0;}
	else{start = -2.2;stop = -6.5;}
	double step = calc_step(start,stop,120);
	fpvi0.Set(FI, start, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
	//dut.trim("postbk_vymax").set_working(7);
	int code[SITE_NUM];
	int reg[SITE_NUM];
	//SERIAL code[SITE]= dut.trim("postbk_vymax").get_working(SITE);
    Nvm_Preview(19);
	delay_ms(1);//acm10
	//Cmd_Nvm_Read(19, reg);
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_vymax", start, stop, step, 20, 2.5 V, TRIG_RISING, results);
	//SERIAL  results[SITE]=results[SITE]*7.0-vy_negcl[SITE];//need - tm82 value(abs), abs down
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
}

void measure_postbk_pkmin(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double step = calc_step(-0.3,0.3,100);
    Nvm_Preview(19);
	delay_ms(1);
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_1A, "postbk_pkmin", -0.3 A, 0.3 A, step, 30, 2.5 V, TRIG_FALLING, results);
	SERIAL  results[SITE]=-results[SITE]*8.0;
}

void measure_postbk_pkmin2(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double step = calc_step(-1.0,2.0,100);
    Nvm_Preview(19);
	delay_ms(1);
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_2A, "postbk_pkmin", -1 A, 2 A, step, 30, 2.5 V, TRIG_FALLING, results);
	SERIAL  results[SITE]=results[SITE]*1.0;
}

void measure_postbk_pkmax(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(18);
	Nvm_Preview(19);
	delay_ms(1);//acm10
	double start = -0.1;
	double stop = 1;
	double step = calc_step(start,stop,100);
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_1A, "postbk_pkmax", start, stop, step, 20, 2.5 V, TRIG_FALLING, results);
	SERIAL  results[SITE]=results[SITE]*8.0;
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON,1);
}

void measure_postbk_pkmax2(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
    Nvm_Preview(18);
	Nvm_Preview(19);
	delay_ms(1);//acm10
	double start = 1.0;
	double stop = 7.6;
	if (dut.sel("POSTBK_LMT").get_working(0) == 0){start = 1.0;stop=5.0;}
	else{start = 3.5;stop=7.6;}
	double step = calc_step(start,stop,100);
	//fpvi0.Set(FI, start, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_pkmax", start, stop, step, 30, 2.5 V, TRIG_FALLING, results);
	//SERIAL  results[SITE]=results[SITE]*8.0;
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
}

void measure_postbk_zcd(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double step = calc_step(-1,1,100);
	Nvm_Preview(20);
	delay_ms(1);
    awg.rampimv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_1A, "postbk_zcd", -1 A, 1 A, step, 20, 2.5 V, TRIG_FALLING, results);
	SERIAL
	{
		results[SITE] = -results[SITE]*1000.0; 
		if(results[SITE]>1000.0){results[SITE] = 999.99;}
		if (results[SITE]<-1000.0) { results[SITE] = -999.99; }
	}
}

void measure_postbk_ss(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){
#ifdef _DEBUG
    int working = trim_node->get_working(0);
#endif
    if (treg_measure_flag == TREG_MEASURE_CHAR) {}
    if (treg_measure_flag == TREG_MEASURE_PRE) {}
    if (treg_measure_flag == TREG_MEASURE_POST) {
        SERIAL {
            //if (device_trimmed[SITE])
            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device
        }
    }
	double res_ss[SITE_NUM];
	int sample = 0;
	Nvm_Preview(20);
	delay_ms(1);
	int tss = dut.sel("POSTBK_SS").get_working(0);
	if(DIE_VER()==0)
	{
		sample=3500;
	}
	else
	{
		if(tss==0){sample=1000;}
		else{sample=3500;}
	}

	//Cmd_TMSel(0x2C48000003000100);
	CmdWriteData(0x28, 0x00);
	CmdWriteData(0x29, 0x01);
	CmdWriteData(0x2A, 0x00);
	CmdWriteData(0x2C, 0x00);
	CmdWriteData(0x2D, 0x00);
	CmdWriteData(0x2E, 0x48);
	CmdWriteData(0x2F, 0x2C);
	//CmdWriteData(0x2B, 0xC3);//0xD787
	//ULONG wdata = 0xD787;
	//int state1 = dcm.WriteWaveData("D_SDI", "CMD_Data", DCM_ALLSITE, 0, 16, wdata);
	Cmd_Set_Freq(100 KHz);
	int state2 = dcm.RunVectorWithGroup("SPI_DUT", "CMD1_Start", "CMD1_Stop", false);
	test_ss(F_SCS, A_DBUFO, sample, 1, results);//fxvi5,acm10
	SERIAL results[SITE]=results[SITE]+0.0232;
	//CmdWriteData(0x2B, 0x82);//ena posbk test, hs on
	//delay_ms(1);
	//CmdWriteData(0x2B, 0x83);
	//if(tss==0){A_DBUFO.MeasureVI(3500,1);}//0.2ms,acm10
	//else{A_DBUFO.MeasureVI(3500,1);}//2ms
	//calc_ss(A_DBUFO, 3500, 1, 0.1, res_ss);
	//SERIAL results[SITE] = res_ss[SITE];
	Cmd_Set_Freq();
	Cmd_TMSel(0x2C480000C2000100);//rst
}

//DWORD delaytime;
//vector <AWG_PATTERN> pattern_store;
//vector <RES_PATTERN> res_store;
//AWG_PATTERN temp_pattern;
//RES_PATTERN temp_res;
//double awgPatStart;
//double awgPatStop;
//
//int scanSampleSize;
//int scanSampleSize1;
//int scanSampleSize2;
//int smooth_size;
//int patSamplesize;
//int startpoint;
//int sts_first_load;//only valid for first time load at release mode
//int id;
//int pat_unload;
//int validsites[SITE_NUM];
//int pat_loadfailed;
//double pat[MAX_SAMPLES];
//double pat2[MAX_SAMPLES];
//double cap[SITE_NUM][MAX_SAMPLES];
//
//bool pattern_unloaded(char *patname)
//{
//	string ptname = patname;
//	string ptname_o;
//	int cmp_rst=1;
//	transform(ptname.begin(), ptname.end(), ptname.begin(), towupper);//same case
//	
//
//	for (unsigned int i = 0; i < pattern_store.size(); i++)
//	{
//		ptname_o = pattern_store[i].pattern_name;
//		transform(ptname_o.begin(), ptname_o.end(), ptname_o.begin(), towupper);//same case
//		cmp_rst = ptname_o.compare(ptname);
//		if (cmp_rst == 0) 
//			return false;
//	}
//	id++;
//	return true;
//}

void ramp2vmv(FXVIe_PLUS fovi_ramp1, ACM200 fovi_ramp2, ACM200 fovi_cap, FXVIe_PLUS_VRNG v_range1, FXVIe_PLUS_IRNG i_range1, ACM200_VRNG v_range2, ACM200_IRNG i_range2, char* reg_str, double scanStartValue1, double scanStopValue1, double scanStartValue2, double scanStopValue2, double trig_level, TRIG_MODE trig_mode, double *result1, double *result2)
{
	double pat1[1024];
	double pat2[1024];
	int interval = 30;
	int patSamplesize = 100;
	double step1 = calc_step(scanStartValue1,scanStopValue1,patSamplesize);
	double step2 = calc_step(scanStartValue2,scanStopValue2,patSamplesize);

	fovi_ramp1.Set(FV, scanStartValue1, v_range1, i_range1, FXVIe_PLUS_RELAY_FANOUT_ON, 1);
	fovi_ramp2.Set(FV, scanStartValue2, v_range2, i_range2, ACM200_RELAY_ON, 1);
	fovi_cap.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	fovi_ramp1.AwgClear();
	fovi_ramp2.AwgClear();

	STSAWGCreateRampData(&pat1[0], patSamplesize, 1, scanStartValue1, scanStopValue1);
	STSAWGCreateRampData(&pat2[0], patSamplesize, 1, scanStartValue2, scanStopValue2);

	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE);
		fovi_ramp2.SetAlarmMask(SITE);
	}
	fovi_ramp1.AwgLoader(reg_str, FV, v_range1, i_range1, pat1, patSamplesize);
	fovi_ramp2.AwgLoader(reg_str, FV, v_range2, i_range2, pat2, patSamplesize);
	SERIAL
	{
		fovi_ramp1.SetAlarmMask(SITE, false);
		fovi_ramp2.SetAlarmMask(SITE, false);
	}
	fovi_ramp1.AwgSelect(reg_str, 0, patSamplesize - 1, patSamplesize - 1, interval);
	fovi_ramp2.AwgSelect(reg_str, 0, patSamplesize - 1, patSamplesize - 1, interval);
	fovi_cap.SetMeasVTrig(trig_level, trig_mode);

	fovi_ramp1.MeasureVI(patSamplesize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	fovi_ramp2.MeasureVI(patSamplesize, interval, MEAS_AWG);
	fovi_cap.MeasureVI(patSamplesize, interval, MEAS_AWG);

	STSEnableAWG(&fovi_ramp1, &fovi_ramp2);
	STSEnableMeas(&fovi_ramp1, &fovi_ramp2, &fovi_cap);
	StsAWGRun();
	
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)fovi_cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(1);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < patSamplesize - 2)) 
		{
			result1[SITE] = fovi_ramp1.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
			result2[SITE] = fovi_ramp2.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else 
		{
			result1[SITE] = 999999;
			result2[SITE] = 999999;
		}
	}
}

void prebk_hscl(FPVIe ramp, FXVIe_PLUS cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double *result)
{
	double pat[1024];
	int interval = 25;
	int patSamplesize = 100;
	double step = calc_step(scanStartValue,scanStopValue,patSamplesize);
	ramp.Set(FV, scanStartValue, v_range, i_range, FPVIe_RELAY_ON);
	ramp.AwgClear();
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, scanStartValue, scanStopValue);
	SERIAL ramp.SetAlarmMask(SITE);

	ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL ramp.SetAlarmMask(SITE, false);


	ramp.AwgSelect(reg_str, 0, patSamplesize - 1, patSamplesize - 1, interval);

	ramp.MeasureVI(patSamplesize, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);
	cap.MeasureVI(patSamplesize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp, &cap);
	STSAWGRun();

	int Trig_Point[SITE_NUM];
	//SERIAL Trig_Point[SITE] = (int)cap.GetMeasResult(SITE, MIRET, TRIG_RESULT);

	double vs_i[SITE_NUM][4096];
	double sw_i[SITE_NUM][4096];
	double det_i[SITE_NUM][4096];
	double slop[SITE_NUM][4096];
	int find[SITE_NUM];
	double value_start[SITE_NUM];
	double value_stop[SITE_NUM];
	double value_trigger[SITE_NUM];

	SERIAL
	{
		find[SITE] = 0;
		cap.BlockRead(SITE, 0, patSamplesize, vs_i[SITE],MIRET);
		ramp.BlockRead(SITE, 0, patSamplesize, sw_i[SITE],MIRET);
		for(int i =0;i<patSamplesize;i++)
		{
			det_i[SITE][i] = vs_i[SITE][i]+sw_i[SITE][i];
		}
	}

	SERIAL
	{
		value_start[SITE]=(det_i[SITE][0]+det_i[SITE][1])/2.0;
		value_stop[SITE]=(det_i[SITE][patSamplesize-1]+det_i[SITE][patSamplesize-2])/2.0;
		//value_trigger[SITE]=value_start[SITE]+0.5 mA;
		value_trigger[SITE]=(value_start[SITE]+value_stop[SITE])/2.0;
		for(int i =1;i<patSamplesize;i++)
		{
			if(find[SITE]==0)
			{
				if(det_i[SITE][i]>value_trigger[SITE])
				{
					find[SITE]=1;
					Trig_Point[SITE] = i;
				}
			}
		}
	}
	delay_us(1);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < patSamplesize - 2)){
			result[SITE] = ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}
	//SERIAL
	//{
	//	if(result[SITE]<0.1)
	//	{
	//		delay_us(1);
	//	}
	//}
}

void prebk_hscl2(FPVIe ramp, FXVIe_PLUS cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double *result)
{
	double pat[1024];
	int interval = 25;
	int patSamplesize = 100;
	double step = calc_step(scanStartValue,scanStopValue,patSamplesize);
	ramp.Set(FV, scanStartValue, v_range, i_range, FPVIe_RELAY_ON);
	ramp.AwgClear();
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, scanStartValue, scanStopValue);
	SERIAL ramp.SetAlarmMask(SITE);

	ramp.AwgLoader(reg_str, FV, v_range, i_range, pat, patSamplesize);
	SERIAL ramp.SetAlarmMask(SITE, false);


	ramp.AwgSelect(reg_str, 0, patSamplesize - 1, patSamplesize - 1, interval);

	ramp.MeasureVI(patSamplesize, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);
	cap.MeasureVI(patSamplesize, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp, &cap);
	STSAWGRun();

	int Trig_Point[SITE_NUM];
	//SERIAL Trig_Point[SITE] = (int)cap.GetMeasResult(SITE, MIRET, TRIG_RESULT);

	double vs_i[SITE_NUM][4096];
	double sw_i[SITE_NUM][4096];
	double det_i[SITE_NUM][4096];
	double slop[SITE_NUM][4096];
	int find[SITE_NUM];
	double value_start[SITE_NUM];
	double value_stop[SITE_NUM];
	double value_trigger[SITE_NUM];

	SERIAL
	{
		find[SITE] = 0;
		cap.BlockRead(SITE, 0, patSamplesize, vs_i[SITE],MIRET);
		ramp.BlockRead(SITE, 0, patSamplesize, sw_i[SITE],MIRET);
		for(int i =0;i<patSamplesize;i++)
		{
			det_i[SITE][i] = vs_i[SITE][i];
		}
	}

	SERIAL
	{
		value_start[SITE]=(det_i[SITE][0]+det_i[SITE][1])/2.0;
		value_stop[SITE]=(det_i[SITE][patSamplesize-1]+det_i[SITE][patSamplesize-2])/2.0;
		//value_trigger[SITE]=value_start[SITE]+0.5 mA;
		value_trigger[SITE]=(value_start[SITE]+value_stop[SITE])/2.0;
		for(int i =1;i<patSamplesize;i++)
		{
			if(find[SITE]==0)
			{
				if(det_i[SITE][i]>value_trigger[SITE])
				{
					find[SITE]=1;
					Trig_Point[SITE] = i;
				}
			}
		}
	}
	delay_us(1);
	SERIAL{

		if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < patSamplesize - 2)){
			result[SITE] = ramp.GetMeasResult(SITE, MVRET, Trig_Point[SITE] - 1);
		}
		else {
			result[SITE] = 999999;
		}
	}
	//SERIAL
	//{
	//	if(result[SITE]<0.1)
	//	{
	//		delay_us(1);
	//	}
	//}
}

void prebk_minipk(FPVIe ramp, ACM200 cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double *result)
{
	double trig_level = 5.0;
	double pat[1024];
	int interval = 25;
	int patSamplesize = 100;
	double step = calc_step(scanStartValue,scanStopValue,patSamplesize);
	ramp.Set(FI, scanStartValue, v_range, i_range, FPVIe_RELAY_ON);
	ramp.AwgClear();
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, scanStartValue, scanStopValue);
	SERIAL ramp.SetAlarmMask(SITE);

	ramp.AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
	SERIAL ramp.SetAlarmMask(SITE, false);


	ramp.AwgSelect(reg_str, 0, patSamplesize - 1, patSamplesize - 1, interval);
	cap.SetMeasVTrig(trig_level, TRIG_FALLING);

	ramp.MeasureVI(patSamplesize, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);
	cap.MeasureVI(patSamplesize, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp, &cap);
	STSAWGRun();
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(10);
	SERIAL{

		//if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < patSamplesize - 2)){
		//	result[SITE] = ramp.GetMeasResult(SITE, MIRET, Trig_Point[SITE] - 1);
		//}
		//else {
		//	result[SITE] = 999999;
		//}
		result[SITE]=ramp.GetMeasResult(SITE, MIRET, MAX_RESULT);
	}
}

void prebk_minipk2(FPVIe ramp, ACM200 cap, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double* result)
{
	double trig_level = 5.0;
	double pat[1024];
	double capdata[SITE_NUM][256];
	int interval = 25;
	int patSamplesize = 100;
	double step = calc_step(scanStartValue, scanStopValue, patSamplesize);
	ramp.Set(FI, scanStartValue, v_range, i_range, FPVIe_RELAY_ON);
	ramp.AwgClear();
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, scanStartValue, scanStopValue);
	SERIAL ramp.SetAlarmMask(SITE);

	ramp.AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
	SERIAL ramp.SetAlarmMask(SITE, false);


	ramp.AwgSelect(reg_str, 0, patSamplesize - 1, patSamplesize - 1, interval);
	cap.SetMeasVTrig(trig_level, TRIG_FALLING);

	ramp.MeasureVI(patSamplesize, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);
	cap.MeasureVI(patSamplesize, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp, &cap);
	STSAWGRun();
	int Trig_Point[SITE_NUM];
	int Find[SITE_NUM];
	//SERIAL Trig_Point[SITE] = (int)cap.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(10);
	SERIAL
	{
		Find[SITE]=0;
		Trig_Point[SITE] = 0;
		ramp.BlockRead(SITE, 0, patSamplesize, capdata[SITE],MIRET);
		for (int i = 0; i < patSamplesize-1; i++)
		{
			if ((capdata[SITE][i] > capdata[SITE][i + 1]) &&(Find[SITE] ==0))
			{
				Find[SITE] = 1;
				Trig_Point[SITE] = i;
			}
		}
		result[SITE] = capdata[SITE][Trig_Point[SITE]];
	}
}

void prebk_hscl(FPVIe ramp, FPVIe_VRNG v_range, FPVIe_IRNG i_range, char* reg_str, double scanStartValue, double scanStopValue, double *result)
{
	double trig_level = 5.0;
	double pat[1024];
	int interval = 25;
	int patSamplesize = 50;
	double step = calc_step(scanStartValue,scanStopValue,patSamplesize);
	ramp.Set(FI, scanStartValue, v_range, i_range, FPVIe_RELAY_ON);
	ramp.AwgClear();
	STSAWGCreateRampData(&pat[0], patSamplesize, 1, scanStartValue, scanStopValue);
	SERIAL ramp.SetAlarmMask(SITE);

	ramp.AwgLoader(reg_str, FI, v_range, i_range, pat, patSamplesize);
	SERIAL ramp.SetAlarmMask(SITE, false);


	ramp.AwgSelect(reg_str, 0, patSamplesize - 1, patSamplesize - 1, interval);
	ramp.SetMeasVTrig(trig_level, TRIG_FALLING);

	ramp.MeasureVI(patSamplesize, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp);
	STSAWGRun();
	int Trig_Point[SITE_NUM];
	SERIAL Trig_Point[SITE] = (int)ramp.GetMeasResult(SITE, MVRET, TRIG_RESULT);
	delay_us(10);
	SERIAL{

		//if (((Trig_Point[SITE]) > 2) && ((Trig_Point[SITE]) < patSamplesize - 2)){
		//	result[SITE] = ramp.GetMeasResult(SITE, MIRET, Trig_Point[SITE] - 1);
		//}
		//else {
		//	result[SITE] = 999999;
		//}
		result[SITE]=ramp.GetMeasResult(SITE, MIRET, MAX_RESULT);
	}
}

void ldo_load_test(FXVIe_PLUS ramp, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double start, double stop, double value1, double value2, double result1[], double result2[], double loadreg[])
{
	double pat1[1024];
	double pat2[1024];
	int scanSample = 500; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.SetClamp(100,2);
	ramp.Set(FI, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FI, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	//F_FB.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);//fxvi0
	acm10.MeasureVI(scanSample, interval, MEAS_AWG);
	acm10.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);

	A_AMUX.MeasureVI(scanSample, interval, MEAS_AWG);//acm9	
	A_AMUX.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);

	STSEnableAWG(&ramp);
	//STSEnableMeas(&ramp,&acm10,&F_FB);
	STSEnableMeas(&ramp,&acm10,&A_AMUX);
	//STSEnableMeas(&ramp,&A_AMUX);
	STSAWGRun();
	//ramp.Set(FI, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	//double CapV0[SITE_NUM][1024];
	double CapV[SITE_NUM][1024];
	//double CapI[SITE_NUM][1024];
	int point1[SITE_NUM];
	int point2[SITE_NUM];
	//double result1a[SITE_NUM];
	//double result2a[SITE_NUM];
	//double delt[SITE_NUM];
	SERIAL
	{
		//F_FB.BlockRead(SITE, 0, scanSample, CapV0[SITE],MVRET);
		A_AMUX.BlockRead(SITE, 0, scanSample, CapV[SITE],MVRET);
		//ramp.BlockRead(SITE, 0, scanSample, CapI[SITE],MIRET);
	}
	SERIAL
	{
		point1[SITE] = (value1-start)/step;
		point2[SITE] = (value2-start)/step;
		result1[SITE] = (CapV[SITE][point1[SITE]]+CapV[SITE][point1[SITE]+1]+CapV[SITE][point1[SITE]+2]+CapV[SITE][point1[SITE]+3]+CapV[SITE][point1[SITE]+4])/5;
		result2[SITE] = (CapV[SITE][point2[SITE]]+CapV[SITE][point2[SITE]-1]+CapV[SITE][point2[SITE]-2]+CapV[SITE][point2[SITE]-3]+CapV[SITE][point2[SITE]-4])/5;

		//result1a[SITE] = (CapV0[SITE][point1[SITE]]+CapV0[SITE][point1[SITE]+1]+CapV0[SITE][point1[SITE]+2]+CapV0[SITE][point1[SITE]+3]+CapV0[SITE][point1[SITE]+4])/5;
		//result2a[SITE] = (CapV0[SITE][point2[SITE]]+CapV0[SITE][point2[SITE]-1]+CapV0[SITE][point2[SITE]-2]+CapV0[SITE][point2[SITE]-3]+CapV0[SITE][point2[SITE]-4])/5;

		////loadreg[SITE] = abs(result1[SITE] - result2[SITE])*1000.0;
		//delt[SITE] = (result2a[SITE] - result1a[SITE])*1000.0;
		result1[SITE] = result1[SITE]*2.5;
		result2[SITE] = result2[SITE]*2.5;
		loadreg[SITE] = abs(result1[SITE] - result2[SITE])*1000.0;
		//loadreg[SITE] = ((result2a[SITE] - result2[SITE])-(result1a[SITE] - result1[SITE]))*1000.0;
	}
	//STSAWGCreateRampData(&pat2[0], scanSample, 1, stop, start);
	//ramp.Set(FI, stop, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	//ramp.AwgClear();
	//SERIAL ramp.SetAlarmMask(SITE);
	//ramp.AwgLoader(reg_str, FI, v_range, i_range, pat2, scanSample);
	//SERIAL ramp.SetAlarmMask(SITE, false);

	//ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	//ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	//STSEnableAWG(&ramp);
	//STSEnableMeas(&ramp);
	//STSAWGRun();
	ramp.Set(FI, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.SetClamp(100,100);
}

void ldo_load_test_qvm(FXVIe_PLUS ramp, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double start, double stop, double value1, double value2, double result1[], double result2[], double loadreg[])
{
	double pat1[1024];
	double pat2[1024];
	int scanSample = 500; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.SetClamp(100,2);
	ramp.Set(FI, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FI, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	//F_FB.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	acm10.MeasureVI(scanSample, interval, MEAS_AWG);
	acm10.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	qvm0.MeasureLADC(scanSample, interval, QVMe_LADC_10V, QVMe_LADC_40KHz, MEAS_AWG);
	qvm1.MeasureLADC(scanSample, interval, QVMe_LADC_10V, QVMe_LADC_40KHz, MEAS_AWG);
	qvm2.MeasureLADC(scanSample, interval, QVMe_LADC_10V, QVMe_LADC_40KHz, MEAS_AWG);
	qvm3.MeasureLADC(scanSample, interval, QVMe_LADC_10V, QVMe_LADC_40KHz, MEAS_AWG);

	A_AMUX.MeasureVI(scanSample, interval, MEAS_AWG);
	A_AMUX.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp,&acm10,&qvm0,&qvm1,&qvm2,&qvm3,&A_AMUX);
	STSAWGRun();
	double CapV[SITE_NUM][1024];
	int point1[SITE_NUM];
	int point2[SITE_NUM];
	qvm0.BlockRead(SITE, 0, scanSample, CapV[0]);
	qvm1.BlockRead(SITE, 0, scanSample, CapV[1]);
	qvm2.BlockRead(SITE, 0, scanSample, CapV[2]);
	qvm3.BlockRead(SITE, 0, scanSample, CapV[3]);
	StsGetSiteStatus(sitesta, SITE_NUM); for(globalsite=0;globalsite<4;globalsite++)  if(sitesta[globalsite])
	{
		point1[SITE] = (value1-start)/step;
		point2[SITE] = (value2-start)/step;
		result1[SITE] = (CapV[SITE][point1[SITE]]+CapV[SITE][point1[SITE]+1]+CapV[SITE][point1[SITE]+2]+CapV[SITE][point1[SITE]+3]+CapV[SITE][point1[SITE]+4])/5;
		result2[SITE] = (CapV[SITE][point2[SITE]]+CapV[SITE][point2[SITE]-1]+CapV[SITE][point2[SITE]-2]+CapV[SITE][point2[SITE]-3]+CapV[SITE][point2[SITE]-4])/5;
		result1[SITE] = result1[SITE]*2.5;
		result2[SITE] = result2[SITE]*2.5;
		loadreg[SITE] = abs(result1[SITE] - result2[SITE])*1000.0;
		loadreg[SITE] = loadreg[SITE];
	}
	ramp.Set(FI, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.SetClamp(100,100);
}

void ldo_load_test2(FXVIe_PLUS ramp, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double start, double stop, double value1, double value2, double result1[], double result2[], double loadreg[])
{
	double res1a[SITE_NUM];
	double res2a[SITE_NUM];
	double res3a[SITE_NUM];
	double res1b[SITE_NUM];
	double res2b[SITE_NUM];
	double res3b[SITE_NUM];
	C_QVM_1357;
	ldo_load_test_qvm(ramp, v_range, i_range, reg_str, start, stop, value1, value2, res1a, res2a, res3a);
	C_QVM_2468;
	ldo_load_test_qvm(ramp, v_range, i_range, reg_str, start, stop, value1, value2, res1b, res2b, res3b);
	result1[0]=res1a[0];result1[1]=res1b[0];
	result1[2]=res1a[1];result1[3]=res1b[1];
	result1[4]=res1a[2];result1[5]=res1b[2];
	result1[6]=res1a[3];result1[7]=res1b[3];
	result2[0]=res2a[0];result2[1]=res2b[0];
	result2[2]=res2a[1];result2[3]=res2b[1];
	result2[4]=res2a[2];result2[5]=res2b[2];
	result2[6]=res2a[3];result2[7]=res2b[3];
	loadreg[0]=res3a[0];loadreg[1]=res1b[0];
	loadreg[2]=res3a[1];loadreg[3]=res3b[1];
	loadreg[4]=res3a[2];loadreg[5]=res3b[2];
	loadreg[6]=res3a[3];loadreg[7]=res3b[3];
}

void ldo_load_test(ACM200 ramp, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double start, double stop, double value1, double value2, double result1[], double result2[], double loadreg[])
{
	double pat1[1024];
	double pat2[1024];
	int scanSample = 500; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.SetClamp(100,2);
	ramp.Set(FI, start, v_range, i_range, ACM200_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FI, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, MEAS_AWG);

	A_AMUX.MeasureVI(scanSample, interval, MEAS_AWG);//acm9	
	A_AMUX.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp,&A_AMUX);
	STSAWGRun();
	//ramp.Set(FI, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	double CapV[SITE_NUM][1024];
	//double CapI[SITE_NUM][1024];
	int point1[SITE_NUM];
	int point2[SITE_NUM];
	
	SERIAL
	{
		//ramp.BlockRead(SITE, 0, scanSample, CapV[SITE],MVRET);
		A_AMUX.BlockRead(SITE, 0, scanSample, CapV[SITE],MVRET);
		//ramp.BlockRead(SITE, 0, scanSample, CapI[SITE],MIRET);
	}
	SERIAL
	{
		point1[SITE] = (value1-start)/step;
		point2[SITE] = (value2-start)/step;
		result1[SITE] = (CapV[SITE][point1[SITE]]+CapV[SITE][point1[SITE]+1]+CapV[SITE][point1[SITE]+2]+CapV[SITE][point1[SITE]+3]+CapV[SITE][point1[SITE]+4])/5;
		result2[SITE] = (CapV[SITE][point2[SITE]]+CapV[SITE][point2[SITE]-1]+CapV[SITE][point2[SITE]-2]+CapV[SITE][point2[SITE]-3]+CapV[SITE][point2[SITE]-4])/5;
		result1[SITE] = result1[SITE]*2.5;
		result2[SITE] = result2[SITE]*2.5;
		loadreg[SITE] = abs(result1[SITE] - result2[SITE])*1000.0;
	}
	//STSAWGCreateRampData(&pat2[0], scanSample, 1, stop, start);
	//ramp.Set(FI, stop, v_range, i_range, ACM200_RELAY_ON);
	//ramp.AwgClear();
	//SERIAL ramp.SetAlarmMask(SITE);
	//ramp.AwgLoader(reg_str, FI, v_range, i_range, pat2, scanSample);
	//SERIAL ramp.SetAlarmMask(SITE, false);

	//ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	//ramp.MeasureVI(scanSample, interval, MEAS_AWG);

	//STSEnableAWG(&ramp);
	//STSEnableMeas(&ramp);
	//STSAWGRun();
	ramp.Set(FI, start, v_range, i_range, ACM200_RELAY_ON);
	ramp.SetClamp(100,100);
}

void ldo_drop_test(FXVIe_PLUS ramp, FXVIe_PLUS cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double start, double stop, double result1[])
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 500; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.Set(FV, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FV, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	cap.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp, &cap);
	STSAWGRun();
	double RampV[SITE_NUM][1024];
	double CapV[SITE_NUM][1024];
	int point1[SITE_NUM];
	double differ=999;
	double Vnor[SITE_NUM];
	double Sum=0;
	
	SERIAL
	{
		ramp.BlockRead(SITE, 0, scanSample, RampV[SITE],MVRET);
		cap.BlockRead(SITE, 0, scanSample, CapV[SITE],MVRET);
	}
	//SERIAL
	//{
	//	point1[SITE] = 0;
	//	Sum=0;
	//	differ=999;
	//	for(int i=0;i<10;i++)
	//	{	
	//		Sum=Sum+CapV[SITE][i];
	//	}
	//	Vnor[SITE] = Sum/10;
	//	dropV[SITE] = Vnor[SITE]*0.95;
	//	for(int i=0;i<scanSample;i++)
	//	{
	//		if(abs(CapV[SITE][i]-dropV[SITE])<differ)
	//		{
	//			point1[SITE] = i;
	//			differ = abs(CapV[SITE][i]-dropV[SITE]);
	//		}
	//	}
	//	result1[SITE] = (RampV[SITE][point1[SITE]] - dropV[SITE])*1000.0;
	//	if(result1[SITE]>500)
	//	{
	//		delay_us(1);
	//	}
	//}
	SERIAL
	{
		point1[SITE] = 0;
		Sum=0;
		differ=999;
		//for(int i=0;i<10;i++)
		//{	
		//	Sum=Sum+CapV[SITE][i];
		//}
		//Vnor[SITE] = Sum/10;
		//dropV[SITE] = Vnor[SITE]*0.95;
		for(int i=0;i<scanSample;i++)
		{
			if(abs(RampV[SITE][i]-CapV[SITE][i])<differ)
			{
				point1[SITE] = i;
				differ = abs(RampV[SITE][i]-CapV[SITE][i]);
			}
		}
		result1[SITE] = (RampV[SITE][point1[SITE]] - CapV[SITE][point1[SITE]])*1000.0;
		if(result1[SITE]>500)
		{
			delay_us(1);
		}
	}
	//ramp.MeasureVI(1000, 10, FXVIe_PLUS_MI_X1, MEAS_NORMAL);
	//interval = 1;
	scanSample = 200; 
	STSAWGCreateRampData(&pat2[0], scanSample, 1, stop, start);
	ramp.Set(FV, stop, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FV, v_range, i_range, pat2, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	//ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	//cap.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&ramp);
	//STSEnableMeas(&ramp, &cap);
	STSAWGRun();
	//ramp.Set(FV, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
}

void ldo_drop_test(FXVIe_PLUS ramp, ACM200 cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double start, double stop, double result1[])
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 500; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.Set(FV, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FV, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	cap.MeasureVI(scanSample, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp, &cap);
	STSAWGRun();
	double RampV[SITE_NUM][1024];
	double CapV[SITE_NUM][1024];
	int point1[SITE_NUM];
	double differ=999;
	double Vnor[SITE_NUM];
	double Sum=0;
	
	SERIAL
	{
		ramp.BlockRead(SITE, 0, scanSample, RampV[SITE],MVRET);
		cap.BlockRead(SITE, 0, scanSample, CapV[SITE],MVRET);
	}
	//SERIAL
	//{
	//	point1[SITE] = 0;
	//	Sum=0;
	//	differ=999;
	//	for(int i=0;i<10;i++)
	//	{	
	//		Sum=Sum+CapV[SITE][i];
	//	}
	//	Vnor[SITE] = Sum/10;
	//	dropV[SITE] = Vnor[SITE]*0.95;
	//	for(int i=0;i<scanSample;i++)
	//	{
	//		if(abs(CapV[SITE][i]-dropV[SITE])<differ)
	//		{
	//			point1[SITE] = i;
	//			differ = abs(CapV[SITE][i]-dropV[SITE]);
	//		}
	//	}
	//	result1[SITE] = (RampV[SITE][point1[SITE]] - dropV[SITE])*1000.0;
	//	if(result1[SITE]>500)
	//	{
	//		delay_us(1);
	//	}
	//}
	SERIAL
	{
		point1[SITE] = 0;
		Sum=0;
		differ=999;
		//for(int i=0;i<10;i++)
		//{	
		//	Sum=Sum+CapV[SITE][i];
		//}
		//Vnor[SITE] = Sum/10;
		//dropV[SITE] = Vnor[SITE]*0.95;
		for(int i=0;i<scanSample;i++)
		{
			if(abs(RampV[SITE][i]-CapV[SITE][i])<differ)
			{
				point1[SITE] = i;
				differ = abs(RampV[SITE][i]-CapV[SITE][i]);
			}
		}
		result1[SITE] = (RampV[SITE][point1[SITE]] - CapV[SITE][point1[SITE]])*1000.0;
		if(result1[SITE]>500)
		{
			delay_us(1);
		}
	}
	//interval = 1;
	scanSample = 200; 
	STSAWGCreateRampData(&pat2[0], scanSample, 1, stop, start);
	ramp.Set(FV, stop, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FV, v_range, i_range, pat2, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	//ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	//cap.MeasureVI(scanSample, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	//STSEnableMeas(&ramp, &cap);
	STSAWGRun();
	//ramp.Set(FV, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
}

void ldo_drop_testf(FXVIe_PLUS ramp, ACM200 cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, double start, double stop, double result1[])
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 500; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.Set(FV, start, v_range, i_range, FXVIe_PLUS_RELAY_FANOUT_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FV, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	cap.MeasureVI(scanSample, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp, &cap);
	STSAWGRun();
	double RampV[SITE_NUM][1024];
	double CapV[SITE_NUM][1024];
	int point1[SITE_NUM];
	double differ=999;
	double Vnor[SITE_NUM];
	double Sum=0;
	
	SERIAL
	{
		ramp.BlockRead(SITE, 0, scanSample, RampV[SITE],MVRET);
		cap.BlockRead(SITE, 0, scanSample, CapV[SITE],MVRET);
	}
	//SERIAL
	//{
	//	point1[SITE] = 0;
	//	Sum=0;
	//	differ=999;
	//	for(int i=0;i<10;i++)
	//	{	
	//		Sum=Sum+CapV[SITE][i];
	//	}
	//	Vnor[SITE] = Sum/10;
	//	dropV[SITE] = Vnor[SITE]*0.95;
	//	for(int i=0;i<scanSample;i++)
	//	{
	//		if(abs(CapV[SITE][i]-dropV[SITE])<differ)
	//		{
	//			point1[SITE] = i;
	//			differ = abs(CapV[SITE][i]-dropV[SITE]);
	//		}
	//	}
	//	result1[SITE] = (RampV[SITE][point1[SITE]] - dropV[SITE])*1000.0;
	//	if(result1[SITE]>500)
	//	{
	//		delay_us(1);
	//	}
	//}
	SERIAL
	{
		point1[SITE] = 0;
		Sum=0;
		differ=999;
		//for(int i=0;i<10;i++)
		//{	
		//	Sum=Sum+CapV[SITE][i];
		//}
		//Vnor[SITE] = Sum/10;
		//dropV[SITE] = Vnor[SITE]*0.95;
		for(int i=0;i<scanSample;i++)
		{
			if(abs(RampV[SITE][i]-CapV[SITE][i])<differ)
			{
				point1[SITE] = i;
				differ = abs(RampV[SITE][i]-CapV[SITE][i]);
			}
		}
		result1[SITE] = (RampV[SITE][point1[SITE]] - CapV[SITE][point1[SITE]])*1000.0;
		if(result1[SITE]>500)
		{
			delay_us(1);
		}
	}
	//interval = 1;
	scanSample = 200; 
	STSAWGCreateRampData(&pat2[0], scanSample, 1, stop, start);
	ramp.Set(FV, stop, v_range, i_range, FXVIe_PLUS_RELAY_FANOUT_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FV, v_range, i_range, pat2, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	//ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	//cap.MeasureVI(scanSample, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	//STSEnableMeas(&ramp, &cap);
	STSAWGRun();
	//ramp.Set(FV, start, v_range, i_range, FXVIe_PLUS_RELAY_FANOUT_ON);
}

void ldo_ilimit_test(FXVIe_PLUS ramp, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, double value, double result1[])
{
	double Vlimit = value*0.9;
	ramp.Set(FV, Vlimit, v_range, i_range, FXVIe_PLUS_RELAY_ON,1);
	//delay_ms(1);
	ramp.MeasureVI(20,10);
	Get_Result(ramp, result1, MIRET);
	SERIAL result1[SITE] = -result1[SITE]*1000.0;
}

void ldo_ilimit_test(ACM200 ramp, ACM200_VRNG v_range, ACM200_IRNG i_range, double value, double result1[])
{
	double Vlimit = value*0.9;
	ramp.Set(FV, Vlimit, v_range, i_range, ACM200_RELAY_ON,1);
	//delay_ms(1);
	ramp.MeasureVI(20,10);
	Get_Result(ramp, result1, MIRET);
	SERIAL result1[SITE] = -result1[SITE]*1000.0;
}

void ldo_ilimit_test(FPVIe ramp, FPVIe_VRNG v_range, FPVIe_IRNG i_range, double vref, double value, double result1[])
{
	double Vlimit = value*0.9;
	double Vforce = Vlimit-vref;
	ramp.Set(FV, Vforce, v_range, i_range, FPVIe_RELAY_ON);
	delay_ms(1);
	ramp.MeasureVI(20,10);
	Get_Result(ramp, result1, MIRET);
	SERIAL result1[SITE] = -result1[SITE]*1000.0;


	//fpvi0.Set(FV, Vforce, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON);
	//delay_ms(1);
	//fpvi0.MeasureVI(20,10);
	//Get_Result(fpvi0, result1, MIRET);
	//SERIAL result1[SITE] = -result1[SITE]*1000.0;
}

void calc_ss(ACM200 cap, int sample, double interval, double os, double result1[])
{
	double value2[SITE_NUM][4000];
	int find[SITE_NUM];
	int trigger[SITE_NUM];
	double value[SITE_NUM];
	SERIAL
	{
		find[SITE] = 0;
		trigger[SITE]=0;
		cap.BlockRead(SITE, 0, sample, value2[SITE],MVRET);
		for(int i=0;i<sample;i++)
		{
			if(find[SITE]==0)
			{
				if (((value2[SITE][0] > 1) && (value2[SITE][i] < 1)) || ((value2[SITE][0] < 1) && (value2[SITE][i] > 1)))
				{
					trigger[SITE]=i;
					find[SITE]=1;
				}
			}
		}
	}
	//double tss_os = 0.2;
	SERIAL trigger[SITE] = trigger[SITE] * interval;
	SERIAL value[SITE] = trigger[SITE]/1000.0+os;
	SERIAL if ((value[SITE] > 10000) || (value[SITE] < -10000)) { value[SITE] = 99999; }
	SERIAL result1[SITE]=value[SITE];//ms
}

void Calc_MinMaxF(double tx[512][SITE_NUM], double f_cen[SITE_NUM], double f_min[SITE_NUM], double f_max[SITE_NUM], double f_dther[SITE_NUM], double f_dther_range[SITE_NUM], double f_dther_ratio[SITE_NUM])
{
	double tcycle[512];
	//vector<int> data;
	double tcycle_min[SITE_NUM];
	double tcycle_max[SITE_NUM];
	double tcycle_avg[SITE_NUM];
	double tcycle_dther[SITE_NUM];

	int t1[SITE_NUM];
	int t2[SITE_NUM];
	int t3[SITE_NUM];
	int t4[SITE_NUM];

	int t_position[512][SITE_NUM];
	int t_peak[512][SITE_NUM];
	int t_vely[512][SITE_NUM];
	double f_peak[512];
	double f_vely[512];
	double t_position_det[512];
	int up[SITE_NUM];
	double cmp_value[SITE_NUM];

	SERIAL
	{
		//cc.sample_freq = 1;
		for (int i = 0; i <= 254; i++)
		{
			tcycle[i] = tx[i * 2 + 2][SITE] - tx[i * 2][SITE];
			//data.push_back(i) = tcycle[i] * 1000;
		}
		//cc.CycleCheck(data);
		tcycle_min[SITE] = *min_element(tcycle, tcycle + 254)+0.0000000001;
		tcycle_max[SITE] = *max_element(tcycle, tcycle + 254)+0.0000000001;
		tcycle_avg[SITE] = (tcycle_min[SITE] + tcycle_max[SITE]) / 2;
		f_min[SITE] = 1000000 / tcycle_max[SITE];
		f_max[SITE] = 1000000 / tcycle_min[SITE];
		f_cen[SITE] = 1000000 / tcycle_avg[SITE];
		
		t1[SITE] = 0;
		t2[SITE] = 0;
		cmp_value[SITE] = 0;
		
		if (1)
		{
			cmp_value[SITE] = tcycle_avg[SITE];
			if (tcycle[0] < cmp_value[SITE]){ up[SITE] = 1; }
			int n = 0;
			for (int i = 0; i <= 254; i++)
			{
				if (up[SITE] > 0)
				{
					if (tcycle[i] > cmp_value[SITE]){ t_position[n][SITE] = i; n++;  up[SITE] = 0; }
				}
				else
				{
					if (tcycle[i] < cmp_value[SITE]){ t_position[n][SITE] = i; n++;  up[SITE] = 1; }
				}
				if (t_position[n][SITE] > 254){ t_position[n][SITE] = 254; }
				if (t_position[n][SITE] < 0){ t_position[n][SITE] = 0; }
			}
			int index = 0;
			for (int i = 0; i < n; i++)
			{
				if (t_position[i+1][SITE] > 0)
				{ 
					t_position_det[index] = (tx[t_position[index+1][SITE] * 2 + 1][SITE] - tx[t_position[index][SITE] * 2 + 1][SITE])*2;
					index++; 
				}
			}
			tcycle_dther[SITE] = average(t_position_det, index);

		}

		f_dther[SITE] = 1000000 / (tcycle_dther[SITE]+0.0000000001);
		f_dther_ratio[SITE]=f_cen[SITE]/f_dther[SITE];
		f_dther_range[SITE]=((f_max[SITE] - f_min[SITE])/f_cen[SITE]/2)*100;
	}
}

void check_rdson_valid(bool enable)
{
	if(enable)
	{
		double rdson_na = 0.0000000001;
		int prebk_tested=0;
		int posbk_tested=0;
		SERIAL
		{
			if((PREBK_HSRDSON[SITE]!=rdson_na)&&(PREBK_LSRDSON[SITE]!=rdson_na))
			{
				prebk_tested=1;
			}
			if((POSBK_HSRDSON[SITE]!=rdson_na)&&(POSBK_LSRDSON[SITE]!=rdson_na))
			{
				posbk_tested=1;
			}
		}
		if(prebk_tested==0)
		{
			string info = "PreBK_Rdson haven't test !";
			MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
		}
		if(posbk_tested==0)
		{
			string info = "PosBK_Rdson haven't test !";
			MessageBoxA(NULL, info.c_str(), "Error Message", MB_OK);
		}
	}
}

void qst_dgl(ACM200 ramp, ACM200 cap, ACM200_VRNG v_range, ACM200_IRNG i_range, char* reg_str, double start, double stop, double result1[])
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 100; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateSquareData(&pat1[0], scanSample, 1, -44 mA, -22 mA ,0);
	ramp.Set(FI, start, v_range, i_range, ACM200_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FI, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, MEAS_AWG);
	cap.MeasureVI(scanSample, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp, &cap);
	STSAWGRun();
	double RampV[SITE_NUM][1024];
	double CapV[SITE_NUM][1024];
	int point1[SITE_NUM];
	double differ=999;
	double Vnor[SITE_NUM];
	double Sum=0;
	
	SERIAL
	{
		ramp.BlockRead(SITE, 0, scanSample, RampV[SITE],MIRET);
		cap.BlockRead(SITE, 0, scanSample, CapV[SITE],MIRET);
	}
	SERIAL
	{
		point1[SITE] = 0;
		Sum=0;
		differ=999;
		for(int i=0;i<10;i++)
		{	
			Sum=Sum+CapV[SITE][i];
		}
		Vnor[SITE] = Sum/10;
		dropV[SITE] = Vnor[SITE]*0.95;
		for(int i=0;i<scanSample;i++)
		{
			if(abs(CapV[SITE][i]-dropV[SITE])<differ)
			{
				point1[SITE] = i;
				differ = abs(CapV[SITE][i]-dropV[SITE]);
			}
		}
		result1[SITE] = (RampV[SITE][point1[SITE]] - dropV[SITE])*1000.0;
		if(result1[SITE]>500)
		{
			delay_us(1);
		}
	}
	//STSAWGCreateRampData(&pat2[0], scanSample, 1, stop, start);
	//ramp.Set(FV, stop, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	//ramp.AwgClear();
	//SERIAL ramp.SetAlarmMask(SITE);
	//ramp.AwgLoader(reg_str, FV, v_range, i_range, pat2, scanSample);
	//SERIAL ramp.SetAlarmMask(SITE, false);

	//ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	//ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	//cap.MeasureVI(scanSample, interval, MEAS_AWG);

	//STSEnableAWG(&ramp);
	//STSEnableMeas(&ramp, &cap);
	//STSAWGRun();
	ramp.Set(FI, 0, v_range, i_range, ACM200_RELAY_ON);
}

void vicurve_v(ACM200 ramp, ACM200_VRNG v_range, ACM200_IRNG i_range, double start, double stop)
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 100; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.Set(FV, start, v_range, i_range, ACM200_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader("vicurve_v", FV, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect("vicurve_v", 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp);
	STSAWGRun();
}

void vicurve_v(FXVIe_PLUS ramp, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, double start, double stop)
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 100; 
	int interval = 10000;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.Set(FV, start, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader("vicurve_v", FV, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect("vicurve_v", 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp);
	STSAWGRun();
}

void vicurve_v(FPVIe ramp, FPVIe_VRNG v_range, FPVIe_IRNG i_range, double start, double stop)
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 100; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.Set(FV, start, v_range, i_range, FPVIe_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader("vicurve_v", FV, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect("vicurve_v", 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp);
	STSAWGRun();
}

void vicurve_i(FPVIe ramp, FPVIe_VRNG v_range, FPVIe_IRNG i_range, double start, double stop)
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 100; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.Set(FI, start, v_range, i_range, FPVIe_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader("vicurve_v", FI, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect("vicurve_v", 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp);
	STSAWGRun();
}

void vicurve_i(ACM200 ramp, ACM200_VRNG v_range, ACM200_IRNG i_range, double start, double stop)
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 100; 
	int interval = 10;
	double step = (stop-start)/(scanSample-1);

	STSAWGCreateRampData(&pat1[0], scanSample, 1, start, stop);
	ramp.Set(FI, start, v_range, i_range, ACM200_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader("vicurve_i", FI, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect("vicurve_i", 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp);
	STSAWGRun();
}

void ramp_sine(ACM200 ramp, ACM200_VRNG v_range, ACM200_IRNG i_range, double dc, double vpp)
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 100; 
	int interval = 10;
	//double step = (stop-start)/(scanSample-1);

	STSAWGCreateSineData(&pat1[0], scanSample, 1, vpp, dc);
	ramp.Set(FI, dc, v_range, i_range, ACM200_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader("sine", FI, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect("sine", 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp);
	STSAWGRun();
}

void ramp_sine(FXVIe_PLUS ramp, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, double dc, double vpp)
{
	double dropV[SITE_NUM];
	double pat1[1024];
	double pat2[1024];
	int scanSample = 1024; 
	int interval = 1;
	//double step = (stop-start)/(scanSample-1);

	STSAWGCreateSineData(&pat1[0], scanSample, 200, vpp, dc, 0);
	ramp.Set(FV, dc, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader("sine", FV, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect("sine", 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp);
	STSAWGRun();
}

void check_hw(void)
{
	DWORD data[64][SITE_NUM];
	string bname_read = "";
	string brev_read = "";
	string bnumber_read = "";
	int find = 0;
	char c1[1];
	AT24C_Connect();
	for(int i=0;i<64;i++)
	{
		AT24C_Read(i, data[i]);
		c1[0] = (char)data[i][0];
		if (data[i][0] == 124)  find++;
		else if (find == 0)	bname_read = bname_read + c1[0];
		else if (find == 1)	brev_read = brev_read + c1[0];
		else if (find == 2)	bnumber_read = bnumber_read + c1[0];
	}
	if(bname_read=="SC6258XN48"){HW_QFN = true;}
	else {HW_QFN = false;}
	AT24C_DisConnect();
}

void check_software(int* MainVer, float* SubVer)
{
	char pcVer[100];
	STSGetSystemVersion(pcVer, 50);
	int num1;
	float num2;
	sscanf(pcVer, "2.2.0.0.%d _r p1.0.%f", &num1, &num2);
	string PcVer = pcVer;
	*MainVer = num1;
	*SubVer = num2;
}

void check_chip(int chip[])
{
	double Ival = -1 mA;
	double v_quc[SITE_NUM];
	double v_posin[SITE_NUM];
	double v_qt3[SITE_NUM];
	double v_fb3[SITE_NUM];
	double v_evs[SITE_NUM];
	double i_evs[SITE_NUM];
	double v_ssd[SITE_NUM];

	C_ACM_FB3_Connect;
	C_ACM_SYNEVSSSD_Connect;
	delay_ms(1);
	Test_Diode(A_QUC, Ival, v_quc);
	Test_Diode(A_POSIN, Ival, v_posin);
	//Test_Diode(F_QT3, Ival, v_qt3);
	Test_Diode(A_FB3, Ival, v_fb3);
	//Test_Diode(A_EVS, Ival, v_evs);
	//Test_Diode(A_SSD, Ival, v_ssd);

	A_EVS.Set(FV, 1.0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(1);
	A_EVS.MeasureVI(20, 10);
	Get_Result(A_EVS, i_evs, MIRET);
	A_EVS.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	A_EVS.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);

	C_ACM_FB3_DisConnect;
	C_ACM_SYNEVSSSD_DisConnect;
	delay_ms(1);
	SERIAL chip[SITE]=0;
	SERIAL
	{
		if(v_quc[SITE]>-1.0)//has chip
		{
			if(v_fb3[SITE]>-1.0)//if has fb3, 83
			{
				chip[SITE]=62583;
			}
			else//84,85,86,87
			{
				if(v_posin[SITE]<-1.0)//if no posin, 84,85
				{
					if(HW_QFN){chip[SITE]=62584;}
					else chip[SITE]=62585;
				}
				else//86,87
				{
					if(i_evs[SITE]>0.3 uA) {chip[SITE]=62587;}//ssd
					else {chip[SITE]=62586;}//evs
				}
			}
		}
		else
		{chip[SITE]=62580;}
	}
}

void rdson_hs_prebk(double rdson[])
{
	bool method2 = false;
	if ((PINarray[0].pin_valid)&&(PINarray[3].pin_valid)){method2=true;}
	double rdson_i = 500 mA;
	double rdson_v[SITE_NUM];
	double rdson_r[SITE_NUM];
	double v_h[SITE_NUM];
	double v_l[SITE_NUM];
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(1);
	fpvi0.Set(FI, rdson_i, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(1);
	//method2 = false;
	if(method2)
	{
		F_VS2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		C_FXVI_VS2_Connect;
		delay_ms(1);
		F_VS2.MeasureVI(50,10);
		Get_Result(F_VS2, v_h, MVRET);
		C_FXVI_VS2_DisConnect;
		delay_ms(1);
		C_FXVI_SW2_Connect;
		delay_ms(1);
		F_SW2.MeasureVI(50,10);
		Get_Result(F_SW2, v_l, MVRET);
		SERIAL rdson_v[SITE]=v_h[SITE]-v_l[SITE];
		C_FXVI_SW2_DisConnect;
		delay_ms(1);
		F_SW2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	}
	else
	{
		fpvi0.MeasureVI(50,10);
		Get_Result(fpvi0, rdson_v, MVRET);
	}
	SERIAL rdson_r[SITE]=(rdson_v[SITE]/rdson_i)*1000.0;
	SERIAL PREBK_HSRDSON[SITE]=rdson_r[SITE]-PREBK_HSRDSON_OS;
	SERIAL rdson[SITE]=PREBK_HSRDSON[SITE];
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
}

void rdson_ls_prebk(double rdson[])
{
	bool method2 = false;
	if ((PINarray[0].pin_valid)&&(PINarray[3].pin_valid)){method2=true;}
	double rdson_i = 500 mA;
	double rdson_v[SITE_NUM];
	double rdson_r[SITE_NUM];
	double v_h[SITE_NUM];
	double v_l[SITE_NUM];
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(1);
	fpvi0.Set(FI, rdson_i, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(1);
	//method2 = false;
	if(method2)
	{
		//A_PG.Set(FV, 0.0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
		F_SW2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
		C_FXVI_SW2_Connect;
		//C_ACM_PG_Connect;
		delay_ms(1);
		F_SW2.MeasureVI(50,10);
		//A_PG.MeasureVI(30,10);
		Get_Result(F_SW2, v_h, MVRET);
		//Get_Result(A_PG, v_l, MVRET);
		//SERIAL rdson_v[SITE]=v_h[SITE]-v_l[SITE];
		SERIAL rdson_v[SITE]=v_h[SITE];
		C_FXVI_SW2_DisConnect;
		//C_ACM_PG_DisConnect;
		delay_ms(1);
		F_SW2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
		//A_PG.Set(FV, 0.0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);
	}
	else
	{
		fpvi0.MeasureVI(50,10);
		Get_Result(fpvi0, rdson_v, MVRET);
	}
	SERIAL rdson_r[SITE]=(rdson_v[SITE]/rdson_i)*1000.0;
	SERIAL PREBK_LSRDSON[SITE]=rdson_r[SITE]-PREBK_LSRDSON_OS;
	SERIAL rdson[SITE]=PREBK_LSRDSON[SITE];
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON);
}

void rdson_hs_posbk(double rdson[])
{
	double rdson_i = 500 mA;
	double rdson_v[SITE_NUM];
	double rdson_r[SITE_NUM];
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(1);
	fpvi0.Set(FI, rdson_i, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(1);
	fpvi0.MeasureVI(50,10);
	Get_Result(fpvi0, rdson_v, MVRET);
	SERIAL rdson_r[SITE]=(rdson_v[SITE]/rdson_i)*1000.0;
	SERIAL POSBK_HSRDSON[SITE]=rdson_r[SITE]-POSBK_HSRDSON_OS;
	SERIAL rdson[SITE]=POSBK_HSRDSON[SITE];
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON,1);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
}

void rdson_ls_posbk(double rdson[])
{
	double rdson_i = 500 mA;
	double rdson_v[SITE_NUM];
	double rdson_r[SITE_NUM];
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(1);
	fpvi0.Set(FI, rdson_i, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(1);
	fpvi0.MeasureVI(50,10);
	Get_Result(fpvi0, rdson_v, MVRET);
	SERIAL rdson_r[SITE]=(rdson_v[SITE]/rdson_i)*1000.0;
	SERIAL POSBK_LSRDSON[SITE]=rdson_r[SITE]-POSBK_LSRDSON_OS;
	SERIAL rdson[SITE]=POSBK_LSRDSON[SITE];
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON,1);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
}

void test_ss(FXVIe_PLUS cap1, ACM200 cap2, int scanSample, int interval, double result1[])
{
	cap1.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);
	cap2.MeasureVI(scanSample, interval, MEAS_AWG);

	STSEnableMeas(&cap1, &cap2);
	STSAWGRun();

	double cap_start[SITE_NUM][4000];
	double cap_stop[SITE_NUM][4000];
	int pt_start[SITE_NUM];
	int pt_stop[SITE_NUM];
	int find[SITE_NUM];
	double value[SITE_NUM];
	SERIAL cap1.BlockRead(SITE, 0, scanSample, cap_start[SITE],MVRET);
	SERIAL cap2.BlockRead(SITE, 0, scanSample, cap_stop[SITE],MVRET);
	SERIAL
	{
		find[SITE] = 0;
		pt_start[SITE]=0;
		for(int i=0;i<scanSample;i++)
		{
			if(find[SITE]==0)
			{
				if (cap_start[SITE][i] > 2.0)
				{
					pt_start[SITE]=i;
					find[SITE]=1;
				}
			}
		}
	}
	SERIAL
	{
		find[SITE] = 0;
		pt_stop[SITE]=0;
		for(int i=scanSample-1;i>=0;i--)
		{
			if(find[SITE]==0)
			{
				if (((cap_stop[SITE][scanSample-1] < 2.0)&&(cap_stop[SITE][i] > 2.0))||((cap_stop[SITE][scanSample-1] > 2.0)&&(cap_stop[SITE][i] < 2.0)))
				{
					pt_stop[SITE]=i;
					find[SITE]=1;
				}
			}
		}
	}
	SERIAL value[SITE] = (pt_stop[SITE]-pt_start[SITE])/1000.0;
	SERIAL result1[SITE]=value[SITE]*interval;//ms
}

void test_tmin(FXVIe_PLUS ramp, ACM200 cap, FXVIe_PLUS_VRNG v_range, FXVIe_PLUS_IRNG i_range, char* reg_str, int interval, double result1[])
{
	double dropV[SITE_NUM];
	double pat1[50];
	int scanSample = 20;
	int capSample = scanSample*interval;
	int capPoint = 10.5*interval;
	//int interval = 10;
	//double step = interval+10;

	for(int i=0;i<50;i++){pat1[i]=0;}
	pat1[10]=3.6;
	ramp.Set(FV, 0, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	ramp.AwgClear();
	SERIAL ramp.SetAlarmMask(SITE);
	ramp.AwgLoader(reg_str, FV, v_range, i_range, pat1, scanSample);
	SERIAL ramp.SetAlarmMask(SITE, false);

	ramp.AwgSelect(reg_str, 0, scanSample - 1, scanSample - 1, interval);
	ramp.MeasureVI(capSample, 1, FXVIe_PLUS_MI_X1, MEAS_AWG);
	cap.MeasureVI(capSample, 1, MEAS_AWG);

	STSEnableAWG(&ramp);
	STSEnableMeas(&ramp, &cap);
	STSAWGRun();

	double start[SITE_NUM];
	double trigger[SITE_NUM];
	
	SERIAL
	{
		start[SITE]=cap.GetMeasResult(SITE,MVRET,0);
		trigger[SITE]=cap.GetMeasResult(SITE,MVRET,capPoint);
		if(((start[SITE]>4.0)&&(trigger[SITE]<1.0))||((start[SITE]<1.0)&&(trigger[SITE]>4.0))){result1[SITE]=1;}
		else{{result1[SITE]=0;}}
	}
}

void calc_ldo_tss(ACM200 cap, int interval, double tss[])
{
	double Vmin[SITE_NUM];
	double Vmax[SITE_NUM];
	double Lval[SITE_NUM];
	double Hval[SITE_NUM];
	int Pstart[SITE_NUM];
	int Pstop[SITE_NUM];
	int Trig[SITE_NUM];
	double pat1[SITE_NUM][1000];
	SERIAL cap.BlockRead(SITE, 0, 1000, pat1[SITE],MVRET);
	SERIAL
	{
		Pstart[SITE]=0;
		Pstop[SITE]=0;
		Vmin[SITE]=cap.GetMeasResult(SITE,MVRET,MIN_RESULT);
		Vmax[SITE]=cap.GetMeasResult(SITE,MVRET,MAX_RESULT);
		Lval[SITE]=(Vmax[SITE]-Vmin[SITE])*0.1+Vmin[SITE];
		Hval[SITE]=(Vmax[SITE]-Vmin[SITE])*0.9+Vmin[SITE];
		Trig[SITE]=0;
		for(int i=0;i<1000;i++)
		{
			if((pat1[SITE][i]>Lval[SITE])&&(Trig[SITE]==0)){Pstart[SITE]=i;Trig[SITE]=1;}
		}
		Trig[SITE]=0;
		//for(int i=1000-1;i>=0;i--)
		//{
		//	if((pat1[SITE][i]<Hval[SITE])&&(Trig[SITE]==0)){Pstop[SITE]=i;Trig[SITE]=1;}
		//}
		for(int i=0;i<1000;i++)
		{
			if((pat1[SITE][i]>Hval[SITE])&&(Trig[SITE]==0)){Pstop[SITE]=i;Trig[SITE]=1;}
		}
		tss[SITE]=(Pstop[SITE]-Pstart[SITE])*interval;
	}
}

void calc_ldo_tss(FXVIe_PLUS cap, int interval, double tss[])
{
	double Vmin[SITE_NUM];
	double Vmax[SITE_NUM];
	double Lval[SITE_NUM];
	double Hval[SITE_NUM];
	int Pstart[SITE_NUM];
	int Pstop[SITE_NUM];
	int Trig[SITE_NUM];
	double pat1[SITE_NUM][1000];
	SERIAL cap.BlockRead(SITE, 0, 1000, pat1[SITE],MVRET);
	SERIAL
	{
		Pstart[SITE]=0;
		Pstop[SITE]=0;
		Vmin[SITE]=cap.GetMeasResult(SITE,MVRET,MIN_RESULT);
		Vmax[SITE]=cap.GetMeasResult(SITE,MVRET,MAX_RESULT);
		Lval[SITE]=(Vmax[SITE]-Vmin[SITE])*0.1+Vmin[SITE];
		Hval[SITE]=(Vmax[SITE]-Vmin[SITE])*0.9+Vmin[SITE];
		Trig[SITE]=0;
		for(int i=0;i<1000;i++)
		{
			if((pat1[SITE][i]>Lval[SITE])&&(Trig[SITE]==0)){Pstart[SITE]=i;Trig[SITE]=1;}
		}
		Trig[SITE]=0;
		//for(int i=1000-1;i>=0;i--)
		//{
		//	if((pat1[SITE][i]<Hval[SITE])&&(Trig[SITE]==0)){Pstop[SITE]=i;Trig[SITE]=1;}
		//}
		for(int i=0;i<1000;i++)
		{
			if((pat1[SITE][i]>Hval[SITE])&&(Trig[SITE]==0)){Pstop[SITE]=i;Trig[SITE]=1;}
		}
		tss[SITE]=(Pstop[SITE]-Pstart[SITE])*interval;
	}
}

void ldo_ss(char* reg_str, double ss_qco[],double ss_qvr[],double ss_qt1[],double ss_qt2[],double ss_qt3[])
{
	int capSample = 1000;
	int interval = 2;

	A_QCO.MeasureVI(capSample, interval, MEAS_AWG);
	A_QVR.MeasureVI(capSample, interval, MEAS_AWG);
	F_QT1.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1,MEAS_AWG);
	F_QT2.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1,MEAS_AWG);
	F_QT3.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1,MEAS_AWG);

	STSEnableMeas(&A_QCO, &A_QVR, &F_QT1, &F_QT2, &F_QT3);
	set_vsx(6.0);
	set_posfb_plus_target(0.1);
	set_fb_plus_target_hc(0.1);
	STSAWGRun();

	calc_ldo_tss(A_QCO, interval, ss_qco);
	calc_ldo_tss(A_QVR, interval, ss_qvr);
	calc_ldo_tss(F_QT1, interval, ss_qt1);
	calc_ldo_tss(F_QT2, interval, ss_qt2);
	calc_ldo_tss(F_QT3, interval, ss_qt3);
}

void ldo_ss_with_ramp(char* reg_str, double ss_qco[], double ss_qvr[], double ss_qt1[], double ss_qt2[], double ss_qt3[])
{
	double pat1[200];
	int capSample = 1000;
	int interval = 2;
	int interval_ramp = 10;

	for (int i = 0; i < 5; i++) { pat1[i] = 4.0; }
	for (int i = 5; i < 200; i++) { pat1[i] = 6.0; }

	F_FB.Set(FV, 4.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	F_FB.AwgClear();
	SERIAL F_FB.SetAlarmMask(SITE);
	F_FB.AwgLoader(reg_str, FV, FXVIe_PLUS_10V, FXVIe_PLUS_1A, pat1, 200);
	SERIAL F_FB.SetAlarmMask(SITE, false);

	F_FB.AwgSelect(reg_str, 0, 200 - 1, 200 - 1, interval_ramp);
	F_FB.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	A_QCO.MeasureVI(capSample, interval, MEAS_AWG);//acm4
	A_QVR.MeasureVI(capSample, interval, MEAS_AWG);//acm3
	F_QT1.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);//
	F_QT2.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);//
	F_QT3.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);//

	STSEnableAWG(&F_FB);
	STSEnableMeas(&F_FB, &A_QCO, &A_QVR, &F_QT1, &F_QT2, &F_QT3);
	set_vsx(6.0);
	set_posfb_plus_target(0.1);
	//set_fb_plus_target_hc(0.1);
	STSAWGRun();

	calc_ldo_tss(A_QCO, interval, ss_qco);
	calc_ldo_tss(A_QVR, interval, ss_qvr);
	calc_ldo_tss(F_QT1, interval, ss_qt1);
	calc_ldo_tss(F_QT2, interval, ss_qt2);
	calc_ldo_tss(F_QT3, interval, ss_qt3);
}

void ldo_qst_quc_ss(char* reg_str, double ss_qst[], double ss_quc[])
{
	int capSample = 1000;
	int interval = 2;

	A_QST.MeasureVI(capSample, interval, MEAS_AWG);//acm0
	A_QUC.MeasureVI(capSample, interval, MEAS_AWG);//acm2

	STSEnableMeas(&A_QST, &A_QUC);
	fxvi4.Set(FV, 6.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	STSAWGRun();

	calc_ldo_tss(A_QST, interval, ss_qst);
	calc_ldo_tss(A_QUC, interval, ss_quc);
}

void ldo_qst_quc_ss_with_ramp(char* reg_str, double ss_qst[], double ss_quc[])
{
	double pat1[200];
	int capSample = 1000;
	int interval = 2;
	int interval_ramp = 10;

	for (int i = 0; i < 5; i++) { pat1[i] = 4.0; }
	for (int i = 5; i < 200; i++) { pat1[i] = 6.0; }

	fxvi4.Set(FV, 4.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	fxvi4.AwgClear();
	SERIAL fxvi4.SetAlarmMask(SITE);
	fxvi4.AwgLoader(reg_str, FV, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, pat1, 200);
	SERIAL fxvi4.SetAlarmMask(SITE, false);

	fxvi4.AwgSelect(reg_str, 0, 200 - 1, 200 - 1, interval_ramp);
	fxvi4.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	A_QST.MeasureVI(capSample, interval, MEAS_AWG);//acm0
	A_QUC.MeasureVI(capSample, interval, MEAS_AWG);//acm2

	STSEnableAWG(&fxvi4);
	STSEnableMeas(&fxvi4, &A_QST, &A_QUC);
	//fxvi4.Set(FV, 6.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	STSAWGRun();

	calc_ldo_tss(A_QST, interval, ss_qst);
	calc_ldo_tss(A_QUC, interval, ss_quc);
}

void test_tss(double tss[])
{
	double result1[SITE_NUM];
	double result2[SITE_NUM];
	double start=0.0;
	double stop=6.0;
	double value1;
	double value2;
	double pat1[1400];
	int scanSample = 1400; 
	int interval = 10;
	for(int i=100;i<1400;i++){pat1[i]=stop;}

	STSAWGCreateRampData(&pat1[0], 100, 1, start, stop);
	F_VST.Set(FV, start, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	F_VST.AwgClear();
	SERIAL F_VST.SetAlarmMask(SITE);
	F_VST.AwgLoader("VS_Vstarttime", FV, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, pat1, scanSample);
	SERIAL F_VST.SetAlarmMask(SITE, false);

	F_VST.AwgSelect("VS_Vstarttime", 0, scanSample - 1, scanSample - 1, interval);
	F_VST.MeasureVI(scanSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);

	A_DBUFO.MeasureVI(scanSample, interval, MEAS_AWG);
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);

	STSEnableAWG(&F_VST);
	STSEnableMeas(&F_VST,&A_DBUFO);
	STSAWGRun();
	double Cap1[SITE_NUM][1400];
	double Cap2[SITE_NUM][1400];
	int point1[SITE_NUM];
	int point2[SITE_NUM];
	int find=0;
	double v1=5.0;
	double v2=2.5;
	SERIAL
	{
		F_VST.BlockRead(SITE, 0, scanSample, Cap1[SITE],MVRET);
		A_DBUFO.BlockRead(SITE, 0, scanSample, Cap2[SITE],MVRET);
	}
	SERIAL
	{
		find=0;
		for(int i=0;i<1400;i++)
		{
			if((Cap1[SITE][i]>v1)&&(find==0)){find=1;point1[SITE]=i;}
		}
		find=0;
		for(int i=0;i<1400;i++)
		{
			if((Cap2[SITE][i]>v2)&&(find==0)){find=1;point2[SITE]=i;}
		}
		tss[SITE]=((point2[SITE]-point1[SITE])*interval)/1000.0;
	}
}

void check_max_speed(double maxspeed[])
{
	int reg_base0[SITE_NUM];
	int reg_base1[SITE_NUM];
	int reg_base2[SITE_NUM];
	int reg0[SITE_NUM];
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int parity0[SITE_NUM];
	int parity1[SITE_NUM];
	int parity2[SITE_NUM];
	//double maxspeed[SITE_NUM];

	CmdReadData(0, reg_base0);
	CmdReadData(1, reg_base1);
	CmdReadData(2, reg_base2);
	int freq = 0;
	int trig[SITE_NUM];
	int failindex[SITE_NUM];
	SERIAL trig[SITE]=0;
	SERIAL failindex[SITE]=0;
	int maxindex = 40;
	for (int i = 10; i < maxindex; i++)
	{
		freq = i * 1 MHz;
		Cmd_Set_Freq(freq);
		CmdReadData(0, reg0,parity0);
		CmdReadData(1, reg1,parity1);
		CmdReadData(2, reg2,parity2);
		SERIAL
		{
			if((trig[SITE]==0)&&((parity0[SITE]!=0)||(parity1[SITE]!=0)||(parity2[SITE]!=0)||(reg0[SITE]!=reg_base0[SITE])||(reg1[SITE]!=reg_base1[SITE])||(reg2[SITE]!=reg_base2[SITE]))){trig[SITE]=1;failindex[SITE]=i;}
		}
	}
	SERIAL
	{
		if(trig[SITE]==0){ maxspeed[SITE]=maxindex;}
		else maxspeed[SITE]=double(failindex[SITE]-1);
	}
}

void qt1_qvr_os(double vqtx[], double os[])
{
	double vqvr[SITE_NUM];
	if(use_amux)
	{
		Cmd_Bank0(true);
		Cmd_AmuxSel(AMUX_Vqvr);
		A_AMUX.MeasureVI(50,10);
		Get_Result(A_AMUX, vqvr, MVRET);
		Cmd_AmuxSel(AMUX_Vqt1);
		A_AMUX.MeasureVI(50,10);
		Get_Result(A_AMUX, vqtx, MVRET);
		SERIAL os[SITE] = (vqtx[SITE] - vqvr[SITE])*1000.0;
	}
	else
	{
		A_QVR.MeasureVI(50,10);
		Get_Result(A_QVR, vqvr, MVRET);
		F_QT1.MeasureVI(50,10);
		Get_Result(F_QT1, vqtx, MVRET);
		SERIAL os[SITE] = (vqtx[SITE] - vqvr[SITE])*1000.0;
		if(1) { SERIAL os[SITE] = os[SITE]-qt1_qvr_err[SITE]; }
	}
}

void qt2_qvr_os(double vqtx[], double os[])
{
	double vqvr[SITE_NUM];
	if(use_amux)
	{
		Cmd_Bank0();
		Cmd_AmuxSel(AMUX_Vqvr);
		A_ABUFO.MeasureVI(50,10);
		Get_Result(A_ABUFO, vqvr, MVRET);
		Cmd_AmuxSel(AMUX_Vqt2);
		A_ABUFO.MeasureVI(50,10);
		Get_Result(A_ABUFO, vqtx, MVRET);
		SERIAL os[SITE] = (vqtx[SITE] - vqvr[SITE])*1000.0;
	}
	else
	{
		A_QVR.MeasureVI(50,10);
		Get_Result(A_QVR, vqvr, MVRET);
		F_QT2.MeasureVI(50,10);
		Get_Result(F_QT2, vqtx, MVRET);
		SERIAL os[SITE] = (vqtx[SITE] - vqvr[SITE])*1000.0;
		if(1) { SERIAL os[SITE] = os[SITE]-qt2_qvr_err[SITE]; }
	}
}

void qt3_qvr_os(double vqtx[], double os[])
{
	double vqvr[SITE_NUM];
	if(use_amux)
	{
		Cmd_Bank0();
		Cmd_AmuxSel(AMUX_Vqvr);
		A_ABUFO.MeasureVI(50,10);
		Get_Result(A_ABUFO, vqvr, MVRET);
		Cmd_AmuxSel(AMUX_Vqt3);
		A_ABUFO.MeasureVI(50,10);
		Get_Result(A_ABUFO, vqtx, MVRET);
		SERIAL os[SITE] = (vqtx[SITE] - vqvr[SITE])*1000.0;
	}
	else
	{
		A_QVR.MeasureVI(50,10);
		Get_Result(A_QVR, vqvr, MVRET);
		F_QT3.MeasureVI(50,10);
		Get_Result(F_QT3, vqtx, MVRET);
		SERIAL os[SITE] = (vqtx[SITE] - vqvr[SITE])*1000.0;
		if(1) { SERIAL os[SITE] = os[SITE]-qt3_qvr_err[SITE]; }
	}
}

void qt1_measure(double vqtx[])
{
	F_QT1.MeasureVI(10,10);
	Get_Result(F_QT1, vqtx, MVRET);
	if(1)
	{
		SERIAL vqtx[SITE] = vqtx[SITE]-qt1_qvr_err[SITE]/1000.0;
	}
}

void qt2_measure(double vqtx[])
{
	F_QT2.MeasureVI(10,10);
	Get_Result(F_QT2, vqtx, MVRET);
	if(1)
	{
		SERIAL vqtx[SITE] = vqtx[SITE]-qt2_qvr_err[SITE]/1000.0;
	}
}

void qt3_measure(double vqtx[])
{
	F_QT3.MeasureVI(10,10);
	Get_Result(F_QT3, vqtx, MVRET);
	if(1)
	{
		SERIAL vqtx[SITE] = vqtx[SITE]-qt3_qvr_err[SITE]/1000.0;
	}
}

void test_qtx_qvr_resource_os(double value_qvr, double os1[],double os2[],double os3[])
{
	double interval = 10;
	int capSample = 50;

	double vqt1[SITE_NUM];
	double vqt2[SITE_NUM];
	double vqt3[SITE_NUM];
	double vqvr[SITE_NUM];
	A_QVR.Set(FV, value_qvr, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON, 1);
	F_QT1.Set(FI, -0.00001, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, -0.00001, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	F_QT3.Set(FI, -0.00001, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(3);
	A_QVR.MeasureVI(capSample, interval, MEAS_AWG);//acm3
	F_QT1.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);//
	F_QT2.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);//
	F_QT3.MeasureVI(capSample, interval, FXVIe_PLUS_MI_X1, MEAS_AWG);//
	STSEnableMeas(&A_QVR, &F_QT1, &F_QT2, &F_QT3);
	STSAWGRun();
	//A_QVR.MeasureVI(50,10);
	//F_QT1.MeasureVI(50,10);
	//F_QT2.MeasureVI(50,10);
	//F_QT3.MeasureVI(50,10);
	Get_Result(A_QVR, vqvr, MVRET);
	Get_Result(F_QT1, vqt1, MVRET);
	Get_Result(F_QT2, vqt2, MVRET);
	Get_Result(F_QT3, vqt3, MVRET);
	SERIAL os1[SITE] = (vqt1[SITE] - vqvr[SITE])*1000.0;
	SERIAL os2[SITE] = (vqt2[SITE] - vqvr[SITE])*1000.0;
	SERIAL os3[SITE] = (vqt3[SITE] - vqvr[SITE])*1000.0;
	Copy_Array(qt1_qvr_err, os1);
	Copy_Array(qt2_qvr_err, os2);
	Copy_Array(qt3_qvr_err, os3);
	F_QT1.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	F_QT3.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	A_QVR.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(3);
	A_QVR.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	F_QT1.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	F_QT2.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	F_QT3.Set(FI, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
}

void boost_oc_dgl(char* reg_str, double level, double dgl[])
{
	#define pat_sample 200
	#define cap_sample 1000
	double pat1[pat_sample];
	double cap0[SITE_NUM][cap_sample];
	double cap1[SITE_NUM][cap_sample];
	int interval = 2;
	int interval_ramp = 10;

	for (int i = 0; i < 5; i++) { pat1[i] = 0.0; }
	for (int i = 5; i < 7; i++) { pat1[i] = 0.6; }
	for (int i = 7; i < 120; i++) { pat1[i] = level; }
	for (int i = 120; i < pat_sample; i++) { pat1[i] = 0.0; }

	fpvi0.Set(FV, 0.0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	fpvi0.AwgClear();
	SERIAL fpvi0.SetAlarmMask(SITE);
	fpvi0.AwgLoader(reg_str, FV, FPVIe_1V, FPVIe_100MA, pat1, pat_sample);
	SERIAL fpvi0.SetAlarmMask(SITE, false);

	fpvi0.AwgSelect(reg_str, 0, pat_sample - 1, pat_sample - 1, interval_ramp);
	fpvi0.MeasureVI(cap_sample, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);

	A_SECPOSFRE.MeasureVI(cap_sample, interval, MEAS_AWG);//acm4

	STSEnableAWG(&fpvi0);
	STSEnableMeas(&fpvi0, &A_SECPOSFRE);
	STSAWGRun();

	int Pstart[SITE_NUM];
	int Pstop[SITE_NUM];
	int Trig[SITE_NUM];
	
	SERIAL fpvi0.BlockRead(SITE, 0, cap_sample, cap0[SITE],MVRET);
	SERIAL A_SECPOSFRE.BlockRead(SITE, 0, cap_sample, cap1[SITE],MVRET);
	SERIAL
	{
		Pstart[SITE]=0;
		Pstop[SITE]=0;
		Trig[SITE]=0;
		for(int i=0;i<cap_sample;i++)
		{
			if((cap0[SITE][i]>0.13)&&(Trig[SITE]==0)){Pstart[SITE]=i;Trig[SITE]=1;}
		}
		Trig[SITE]=0;
		for(int i=0;i<cap_sample;i++)
		{
			if((cap1[SITE][i]>2.5)&&(Trig[SITE]==0)){Pstop[SITE]=i;Trig[SITE]=1;}
		}
		dgl[SITE]=(Pstop[SITE]-Pstart[SITE])*interval;
	}
		fpvi0.Set(FV, 0.0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
}

void boost_oc_dgl2(char* reg_str, double level, double dgl[])
{
#define pat_sample 300
#define cap_sample 300
	double pat1[pat_sample];
	double cap0[SITE_NUM][cap_sample];
	double cap1[SITE_NUM][cap_sample];
	int interval = 25;
	int interval_ramp = 25;

	for (int i = 0; i < 5; i++) { pat1[i] = 0.0; }
	for (int i = 5; i < 7; i++) { pat1[i] = 0.6; }
	for (int i = 7; i < pat_sample; i++) { pat1[i] = level; }

	fpvi0.Set(FV, 0.0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	fpvi0.AwgClear();
	SERIAL fpvi0.SetAlarmMask(SITE);
	fpvi0.AwgLoader(reg_str, FV, FPVIe_1V, FPVIe_100MA, pat1, pat_sample);
	SERIAL fpvi0.SetAlarmMask(SITE, false);

	fpvi0.AwgSelect(reg_str, 0, pat_sample - 1, pat_sample - 1, interval_ramp);
	fpvi0.MeasureVI(cap_sample, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);

	A_SECPOSFRE.MeasureVI(cap_sample, interval, MEAS_AWG);//acm4

	STSEnableAWG(&fpvi0);
	STSEnableMeas(&fpvi0, &A_SECPOSFRE);
	STSAWGRun();

	int Pstart[SITE_NUM];
	int Pstop[SITE_NUM];
	int Trig[SITE_NUM];

	SERIAL fpvi0.BlockRead(SITE, 0, cap_sample, cap0[SITE], MVRET);
	SERIAL A_SECPOSFRE.BlockRead(SITE, 0, cap_sample, cap1[SITE], MVRET);
	SERIAL
	{
		Pstart[SITE] = 0;
		Pstop[SITE] = 0;
		Trig[SITE] = 0;
		for (int i = 0; i < cap_sample; i++)
		{
			if ((cap0[SITE][i] > 0.3) && (Trig[SITE] == 0)) { Pstart[SITE] = i; Trig[SITE] = 1; }
		}
		Trig[SITE] = 0;
		for (int i = 0; i < cap_sample; i++)
		{
			if ((cap1[SITE][i] > 2.5) && (Trig[SITE] == 0)) { Pstop[SITE] = i; Trig[SITE] = 1; }
		}
		dgl[SITE] = (Pstop[SITE] - Pstart[SITE]) * interval;
	}
	fpvi0.Set(FV, 0.0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
}

void boost_oc_dgl3(char* reg_str, double level, double dgl[])
{
#define pat_sample 200
#define cap_sample 1000
	double pat1[pat_sample];
	double cap0[SITE_NUM][cap_sample];
	double cap1[SITE_NUM][cap_sample];
	int interval = 2;
	int interval_ramp = 10;

	for (int i = 0; i < 5; i++) { pat1[i] = 0.0; }
	for (int i = 5; i < 7; i++) { pat1[i] = 0.6; }
	for (int i = 7; i < 120; i++) { pat1[i] = level; }
	for (int i = 120; i < pat_sample; i++) { pat1[i] = 0.0; }

	fpvi0.Set(FV, 0.0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	fpvi0.AwgClear();
	SERIAL fpvi0.SetAlarmMask(SITE);
	fpvi0.AwgLoader(reg_str, FV, FPVIe_1V, FPVIe_100MA, pat1, pat_sample);
	SERIAL fpvi0.SetAlarmMask(SITE, false);

	fpvi0.AwgSelect(reg_str, 0, pat_sample - 1, pat_sample - 1, interval_ramp);
	fpvi0.MeasureVI(cap_sample, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);

	A_DBUFO.MeasureVI(cap_sample, interval, MEAS_AWG);//acm4

	STSEnableAWG(&fpvi0);
	STSEnableMeas(&fpvi0, &A_DBUFO);
	STSAWGRun();

	int Pstart[SITE_NUM];
	int Pstop[SITE_NUM];
	int Trig[SITE_NUM];

	SERIAL fpvi0.BlockRead(SITE, 0, cap_sample, cap0[SITE], MVRET);
	SERIAL A_DBUFO.BlockRead(SITE, 0, cap_sample, cap1[SITE], MVRET);
	SERIAL
	{
		Pstart[SITE] = 0;
		Pstop[SITE] = 0;
		Trig[SITE] = 0;
		for (int i = 0; i < cap_sample; i++)
		{
			if ((cap0[SITE][i] > 0.13) && (Trig[SITE] == 0)) { Pstart[SITE] = i; Trig[SITE] = 1; }
		}
		Trig[SITE] = 0;
		for (int i = 0; i < cap_sample; i++)
		{
			if ((cap1[SITE][i] < 2.5) && (Trig[SITE] == 0)) { Pstop[SITE] = i; Trig[SITE] = 1; }
		}
		dgl[SITE] = (Pstop[SITE] - Pstart[SITE]) * interval;
	}
	fpvi0.Set(FV, 0.0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
}


