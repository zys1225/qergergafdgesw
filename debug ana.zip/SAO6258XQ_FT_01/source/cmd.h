#ifndef __CMD_H_
#define __CMD_H_
//#include "stdafx.h"
//#include "part.h"


#define STATE_FS	00
#define STATE_INI	01
#define STATE_PWD	02
#define STATE_SLP	03
#define STATE_NOR	04
#define STATE_STB	05
#define STATE_WAK	06

#define FBANK_NUM 9
#define BANK_NUM 23
#define USR_NUM 23

extern int FBANK_BURN[9][SITE_NUM];
extern int FBANK_READ0[9][SITE_NUM];
extern int FBANK_READ1[9][SITE_NUM];
extern int FBANK_READ2[9][SITE_NUM];
extern int BANK_BURN[23][SITE_NUM];
extern int BANK_READ0[23][SITE_NUM];
extern int BANK_READ1[23][SITE_NUM];
extern int BANK_READ2[23][SITE_NUM];

//#define I2C_TRIM_BANK	0x74
//#define I2C_TM_EFUSE	0x70
//#define I2C_TM_CMD		0x71
//#define I2C_TM_DATA1	0x72
//#define I2C_TM_DATA2	0x73

//User Reg
#define DEVCFG0			0x00
#define DEVCFG1			0x01
#define DEVCFG2			0x02
#define PROTCFG			0x03
#define SYSPCFG0		0x04
#define SYSPCFG1		0x05
#define WDCFG0			0x06
#define WGCFG1			0x07
#define FWDCFG			0x08
#define WWDCFG0			0x09
#define WWDCFG1			0x0A
#define RSYSPCFG0		0x0B
#define RSYSPCFG1		0x0C
#define RWDCFG0			0x0D
#define RWDCFG1			0x0E
#define RFWDCFG			0x0F
#define RWWDCFG0		0x10
#define RWWDCFG1		0x11
#define WKTIMCFG0		0x12
#define WKTIMCFG1		0x13
#define WKTIMCFG2		0x14
#define DEVCTRL			0x15
#define DEVCTRLN		0x16
#define WWDSCMD			0x17
#define FWDRSP			0x18
#define FWDRSPSYNC		0x19
#define SYSFAIL			0x1A
#define INITERR			0x1B
#define IF				0x1C
#define SYSSF			0x1D
#define WKSF			0x1E
#define SPISF			0x1F
#define MONSF0			0x20
#define MONSF1			0x21
#define MONSF2			0x22
#define MONSF3			0x23
#define OTFAIL			0x24
#define OTWRNSF			0x25
#define VMONSTAT		0x26
#define DEVSTAT			0x27
#define PROTSTAT		0x28
#define WWDSTAT			0x29
#define FWDSTAT0		0x2A
#define FTDSTAT1		0x2B
#define ABIST_CTRL0		0x2C
#define REG_NA			0x2D
#define ABIST_SELCT0	0x2E
#define ABIST_SELCT1	0x2F
#define ABIST_SELCT2	0x30
#define BCK_FREQ_CHANGE	0x31
#define BCK_FRE_SPREAD	0x32
#define DEVSTAT2		0x33
#define MONSF4			0x34
#define ASFCFG			0x35
#define AMUXCFG			0x36
#define AMUX_SELECT		0x37
#define RASFCFG			0x38
#define LMT_PD_CFG		0x39
#define ABIST_SELECT3	0x3A
#define CEFUMON			0x3B
#define MCSMON			0x3C
#define DEVINFO			0x3D
#define REG_DEBUG		0x3E
#define BANK_CTRL		0x3F

//amux ch
#define AMUX_HZ			0x00
#define AMUX_BG1		0x01
#define AMUX_BG2		0x02
#define AMUX_IV1		0x03
#define AMUX_IV2		0x04
#define AMUX_Vcor		0x05
#define AMUX_Vpbk		0x06
#define AMUX_Vquc		0x07
#define AMUX_Vqst		0x08
#define AMUX_Vqvr		0x09
#define AMUX_Vqco		0x0A
#define AMUX_Vqt1		0x0B
#define AMUX_Vqt2		0x0C
#define AMUX_Vqt3		0x0D
#define AMUX_Vsx		0x0E
#define AMUX_Vst		0x0F
#define AMUX_Vsns1		0x10
#define AMUX_Vsns2		0x11
#define AMUX_Vmon		0x12
#define AMUX_Vtemp		0x13
#define AMUX_Vevs		0x14
#define AMUX_BGAmux		0x15

//power off
#define qst_off			0x0001
#define prebk_off		0x0002
#define quc_off			0x0004
#define postbk_off		0x0008
#define dcdc_off		0x000A
#define qvr_off			0x0010
#define qco_off			0x0020
#define qt1_off			0x0040
#define qt2_off			0x0080
#define qs3_off			0x0100
#define except_prebk	0x01FD
#define except_prebk_quc	0x01F9
#define except_prebk_qco	0x01DD
#define except_postbk	0x01F7
#define except_dcdc		0x01F5
#define except_ldo		0x000A
#define except_qst		0x01FE
#define except_quc		0x01FB
#define except_qco		0x01DF
#define all_off			0x01FF
#define none_off		0x0000

#define PDDLY_0ms		0
#define PDDLY_0P2ms		1
#define PDDLY_1ms		2
#define PDDLY_4ms		3
#define QUCLMT_600mA	0
#define QUCLMT_850mA	1
#define QCOLMT_200mA	0
#define QCOLMT_700mA	1
#define PREBKLMT_2A		0
#define PREBKLMT_4A		1
#define CORELMT_2A		0
#define CORELMT_4A		1

void Cmd_Set_Freq(void);
void Cmd_Set_Freq(float Freq);
void Cmd_Set_Freq_Scan(float Freq);
void CmdWriteData(int RegAddress, int data0);//
void CmdWriteData(int RegAddress, int* data0);//
void CmdReadData(int RegAddress, int data0[]);//
void CmdReadData(int RegAddress, int data0[], int parity[]);//

void Cmd_TestMode(bool en);
void Cmd_TestMode(bool en, int in_tm[]);
void Cmd_TestModeCheck(int in_tm[]);
void Cmd_TMSel(unsigned __int64 tm_data);
void Cmd_TMSelCheck(unsigned __int64 TMSel[]);
void Cmd_Masksafe(void);
void Cmd_Masksafe_Exit(void);
void Cmd_LDO_Comp(void);
void En_LDO_Comp(void);
void Cmd_Forceoff(int data);
void Cmd_ForceoffCheck(int data[]);
void Cmd_Bank0(void);
void Cmd_Bank1(void);
void Cmd_Bank0(bool force_write);
void Cmd_Bank1(bool force_write);
void Cmd_BankCheck(int bank[]);
void Cmd_SpeedupMode(bool en);
void Cmd_Scan_Main(void);
void Cmd_Scan_Fs(void);
void Cmd_Dmuxset_Main(int index);
void Cmd_Dmuxset_MainRead(int index[]);
void Cmd_Dmuxset_Fs0(int index);
void Cmd_Dmuxset_Fs0Read(int index[]);
void Cmd_Dmuxset_Fs1(int index);
void Cmd_Dmuxset_Fs1Read(int index[]);
void Cmd_Dis_WwdFwdErrm(void);
//void Cmd_Abus(int index);
void Cmd_ReadState(int state[]);
void Cmd_ReadError(int data_1A[], int data_1E[], int data_20[], int data_21[], int data_22[], int data_23[]);
//void Cmd_AbusAmux(void);
//void Cmd_AbusStu(void);
void Cmd_MaskError(bool en);
//void Cmd_Nvm_Burn(bool globalen, bool* siteen);
void Cmd_Nvm_ReadFs(int index, int data[]);
void Cmd_Nvm_WriteFs(int index, int* data);
void Cmd_Nvm_Read(int index, int data[]);
void Cmd_Nvm_Write(int index, int* data);
void Cmd_Set_State(int state);
void Cmd_Write_DevCfg0(int data);
void Cmd_Write_DevCfg1(int data);
void Cmd_Write_DevCfg2(int data);
void Cmd_Read_LBIST(int pass[]);
void Cmd_EnSyn(bool en);

//Device cmd
void Cmd_Get_OTFAIL(void);
void Cmd_Get_OTWRNSF(void);
void Cmd_Get_MONSF0(void);
void Cmd_Get_MONSF1(void);
void Cmd_Get_MONSF2(void);
void Cmd_Get_MONSF3(void);
void Cmd_Get_SPISF(void);
void Cmd_Get_WKSF(void);
void Cmd_Get_SYSSF(void);
void Cmd_Chk_Error(void);
void Cmd_Get_windows_watchdog_configuration_status(void);
void Cmd_Get_functional_watchdog_configuration_status(void);
void Cmd_Get_err_monitoring_configuration_status(void);
void Cmd_Get_windows_watchdog_error_counter(void);
void Cmd_Get_functional_watchdog_error_counter(void);
void Cmd_Get_FailStatus(void);
void Cmd_Get_InitErrStatus(void);
void Cmd_Get_InterruptStatus(void);
void Cmd_Get_VoltMonStatus(void);
void Cmd_Get_DeviceStatus(void);
void Cmd_Get_ProtectStatus(void);
void Cmd_Get_WakeTimerStatus(void);
void Cmd_Get_tRD(void);
void Cmd_Get_DcdcCfg(void);
void Cmd_Chk_Status(void);
void Cmd_Unlock(void);
void Cmd_Lock(void);
void Cmd_En_WD(bool en_WWD, bool en_FWD, bool en_in_sleep);
void Cmd_En_ERR(bool en, bool en_in_sleep);
void Cmd_Dis_ERR(void);
void Cmd_Dis_WD(void);
void Cmd_Dis_ERR_WD(void);
void Cmd_Go2_Initial(void);
void Cmd_Go2_Normal(void);
void Cmd_Go2_Sleep(void);
void Cmd_Go2_Standby(void);
void Cmd_Go2_Wake(void);
void Cmd_En_Trk1(bool en);
void Cmd_En_Trk2(bool en);
void Cmd_En_Trk3(bool en);
void Cmd_En_Trk(void);
void Cmd_En_Com(bool en);
void Cmd_En_Ref(bool en);
void Cmd_En_Stb(bool en, bool dis_os);
void Cmd_En_Posbk(bool en);
void Cmd_En_WakeupTimer(bool en);
void Cmd_En_AllVout(void);
void Cmd_Dis_AllVout(void);
void Cmd_DisOS(bool en);
void Cmd_AmuxEn(bool en);
void Cmd_AmuxEn_Stb(bool amux, bool stb, bool os);
void Cmd_AmuxSel(int amux);
void Cmd_AmuxCfg(int cfg);
void Cmd_LMTCFG(int CORELMT, int PREBKLMT, int QCOLMT, int QUCLMT, int PDDLY);
void Cmd_WWD_Cfg(string wd_clk = "1ms", string wwd_src = "SPI", int wwd_ethr = 0x09, int wwd_cw_cyc = 50, int wwd_ow_cyc = 50);
void Cmd_FWD_Cfg(string wd_clk = "1ms", int fwd_ethr = 0x09, int heart_beat = 50);
void Cmd_Feed_WWD_UseSPI(void);
void Cmd_WakeTimer_Cfg(string wut_clk = "1s", int wut_cyc = 5);
void Cmd_ErrMon_Cfg(string mode = "immediate", string trec = "1ms");
void Cmd_Device_Ctl(int qvr, int qco, int qt1, int qt2);
void Cmd_Abist_ClkOv(bool CLK_EN, bool OV_TRIG);
void Cmd_Abist_Start(bool INT, bool SINGLE, bool PATH, bool START);
void Cmd_Abist_Sel0(int select0=0);
void Cmd_Abist_Sel1(int select1=0);
void Cmd_Abist_Sel2(int select2=0);
void Cmd_Chk_Abist(void);
void Cmd_Feed_FWD(void);

#endif
