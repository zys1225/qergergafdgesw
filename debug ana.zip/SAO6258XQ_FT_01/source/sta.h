/*****************************************************************************
*
*         Written by:   Hunter Liu
*   Last Modified by:   Hunter Liu
*               Date:   07/12/2024
*        Current Rev:   00
*
*        Description:    Site Trim Analysis
*
*****************************************************************************/
#pragma once

//#include "stdafx.h"
//#include <stdlib.h>
//#include <stdio.h>
//#include <float.h>
//#include <math.h>
//#include <assert.h>
//#include <map>
//#include <vector>
//#include <string>
//#include <Windows.h>
//#include <iostream>
#include <time.h>
#include "inireader.h"
#include "fifo.h"
//using namespace std;

#ifdef WIN32    // windows operating systems
#   include <windows.h>
#   include <direct.h>
#else           // linux & solaris operating systems
#   include <string.h>
#   include <ctype.h>

#   define _vsnprintf vsnprintf
#   define _snprintf  snprintf
#   define _stricmp   strcasecmp
#endif

// Disable warnings produced by VC 6.0
#if defined( _MSC_VER ) && (_MSC_VER <= 1200)    // 1200 = MSVC 6.0.
#   undef copy  // undefine copy macro imported by 'util.h' from ETS shell
#   pragma once
#   pragma warning(push, 3)
#   pragma warning(disable: 4018)    // signed/unsigned mismatch.
#   pragma warning(disable: 4146)    // unary minus operator applied to unsigned type, result still unsigned.

#   include <vector>
#   include <string>

#   pragma warning(pop)
#else
#   include <vector>
#   include <string>
#endif    // _MSC_VER <= 1200

#define  WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
#define _CRT_SECURE_NO_WARNINGS

bool comp_float(float v1, float v2);
bool comp_double(double v1, double v2);
double round_value(double r);
void  calc_qx(float* val, int count, float* result);

class BUF_NODE
{
	#define max_buf_len	256
	public:	double buffer[max_buf_len];
	public:	int buffer_len_max;
	public:	int buffer_len_now;
	public:	int buffer_start;
	public:	int buffer_current;
	public:	int buffer_next;
	public:	double buffer_sum;
	public:	double buffer_avg;
	public:	double buffer_std;

	public:BUF_NODE() { Init(max_buf_len); }

	public:~BUF_NODE() {}

	public:void Init(int max_len)
		{
			if (max_len >max_buf_len){ MessageBox(NULL, "Max Buf Len Beyond 256.", "STA Message", MB_OK); }
			buffer_len_max = max_len;
			buffer_len_now = 0;
			buffer_start = 0;
			buffer_current = 0;
			buffer_next = 0;
			buffer_sum = 0;
			buffer_avg = 0;
			buffer_std = 0;

			for (int i = 0; i < max_buf_len; i++)
			{
				buffer[i] = 0; 
			}
		}

	public:void Empty(void)
		{
			buffer_len_now = 0;
			buffer_start = 0;
			buffer_current = 0;
			buffer_next = 0;
			buffer_sum = 0;
			buffer_avg = 0;
			buffer_std = 0;

			for (int i = 0; i < max_buf_len; i++)
			{
				buffer[i] = 0;
			}
		}

	public:	void Add(double data)
		{
			buffer_current = buffer_next;
			buffer[buffer_current] = data;
			//buf_len ctl, 0~maxlen
			if (buffer_len_now < buffer_len_max) { buffer_len_now++; }
			else { buffer_len_now = buffer_len_max; }
			//buf_stop ctl, 0~maxlen-1
			buffer_next++;
			if (buffer_next >= buffer_len_max) { buffer_next = 0; }

			//calc sum and avg
			buffer_sum = 0;
			for (int i = 0; i < buffer_len_now; i++)
			{
				buffer_sum += buffer[i];
				buffer_std += pow(buffer[i] - buffer_avg, 2);
			}
			buffer_avg = buffer_sum / buffer_len_now;
			buffer_std = sqrt(buffer_std / buffer_len_now);
			//calc_qx(buffer, int count, float* result);
		}

	public:	void Replace(double data)
		{
			buffer[buffer_current] = data;

			//calc sum and avg
			buffer_sum = 0;
			for (int i = 0; i < buffer_len_now; i++)
			{
				buffer_sum += buffer[i];
				buffer_std += pow(buffer[i] - buffer_avg, 2);
			}
			buffer_avg = buffer_sum / buffer_len_now;
			buffer_std = sqrt(buffer_std / buffer_len_now);
		}

	public:	int GetLen(void)
		{
			return buffer_len_now;
		}

	public:	double  GetAvg(void)
		{
			return buffer_avg;
		}

	public:	double GetStd(void)
		{
			return buffer_std;
		}

	public:	double GetSum(void)
		{
			return buffer_sum;
		}

};
class STA_NODE
{
	public:		char *NAME = new char[256];//need to set
	public:		int TYPE_CODE = 1;
	public:		int LEN = 30;//need to set
	public:		double STA_LMT_DIFF;//need to set,current use
	public:		double STA_LMT_SHIFT;//need to set,current haven't use
	public:		int Cvt_N;
	public:		int Cvt_Bit[256];
	public:		int Cvt_BitSize;
	public:		int dut_count[SITE_NUM];

	private:	BUF_NODE buf[SITE_NUM];
	private:	int lcode_init[SITE_NUM];//returned value
	public:		int lcode_current[SITE_NUM];
	public:		double lvalue_init[SITE_NUM];//returned value
	public:		double lvalue_current[SITE_NUM];
	public:		double lvalue_std[SITE_NUM];
	public:		double lvalue_avg_last[SITE_NUM];
	private:	double lvalue_avg_temp[SITE_NUM];
	public:		double lvalue_avg_diff[SITE_NUM];//differ result
	public:		double lvalue_avg_all;//all site
	public:		double lvalue_avg_all_diff;//all site differ result
	public:		double lvalue_avg_max;//all site
	public:		double lvalue_avg_min;//all site

	//public:		bool flag_avg_shift;
	public:		bool flag_avg_diff_trigger = false;//compare result
	public:		bool flag_std_trigger = false;//to be added


	public:STA_NODE() { Init(); }

	public:~STA_NODE() {}

	public:void Init(void)
		{
			for(int i=0;i<SITE_NUM;i++) //initial all site
			{
				dut_count[i] = 0;
				lcode_init[i] = 0;
				lcode_current[i] = 0;
				lvalue_init[i] = 0;
				lvalue_current[i] = 0;
				lvalue_avg_last[i] = 0;
				lvalue_avg_temp[i] = 0;
				lvalue_avg_diff[i] = 0;
				buf[i].Init(LEN);
			}
		
			TYPE_CODE = 1;
			LEN = 30;//need to set
			STA_LMT_DIFF = 5;//need to set
			STA_LMT_SHIFT = 5;//need to set
			lvalue_avg_all = 0;
			lvalue_avg_all_diff = 0;
			lvalue_avg_max = 0;
			lvalue_avg_min = 0;
			//flag_avg_shift = false;
			flag_avg_diff_trigger = false;
			flag_std_trigger = false;
		}

	public:void Run_Calc()
		{
			Update_Index();
			Update_Lvalue_Avg();
			Update_Lvalue_Init();
			Calc_Site_Diff();
			Calc_Max_Diff();
			Check_Result();
		}

	public:void Set_Cvt_Info(int N, int BitArray[], int ArraySize)
		{
			if (TYPE_CODE == 1)
			{
				Cvt_N = N;
				Cvt_BitSize = ArraySize;
				for (int i = 0; i < Cvt_BitSize; i++)
				{
					Cvt_Bit[i] = BitArray[i];
				}
			}
			else if (TYPE_CODE == 0)
			{
				Cvt_N = 1;
				Cvt_BitSize = 1;
				Cvt_Bit[0] = 0;
			}
		}

	//public:void Set_Zcode(string Para, int ZCode[SITE_NUM])
	//	{
	//		for(int i=0;i<SITE_NUM;i++) 
	//		{ 
	//			lcode_current[i] = Z2L(Para, ZCode[i]); 
	//		}
	//	}

	public:void Set_Zcode(int ZCode[SITE_NUM])
		{
			for(int i=0;i<SITE_NUM;i++) 
			{ 
				lcode_current[i] = Z2L(ZCode[i]);
				buf[i].Add(lcode_current[i]);
			}
		}

	//public:void Set_Lcode(int Lcode[SITE_NUM])
	//	{
	//		for (int i = 0; i < SITE_NUM; i++)
	//		{
	//			lcode_current[i] = Lcode[i];
	//		}
	//	}

	public:void Set_Lvalue(double Value[SITE_NUM])
		{
			for (int i = 0; i < SITE_NUM; i++)
			{
				lvalue_current[i] = Value[i];
				buf[i].Add(lcode_current[i]);
			}
		}

	//public:void Set_Lvalue(int Value[SITE_NUM])
	//	{
	//		for (int i = 0; i < SITE_NUM; i++)
	//		{
	//			lcode_current[i] = Value[i];
	//		}
	//	}

	private:void Update_Index(void)
		{
			SERIAL
			{ 
				if (dut_count[SITE]<LEN){ dut_count[SITE]++; } 
				else { dut_count[SITE] = LEN; }
			}//1~30
		}

	private:void Update_Lvalue_Avg(void)
		{
			SERIAL
			{
				lvalue_avg_last[SITE] = Calc_New_Avg(lvalue_avg_last[SITE], lcode_current[SITE], dut_count[SITE]);
			}
		}

	private:void Update_Lvalue_Init()
		{
			//return lcode********
			double tmp_sum = 0;
			int tmp_site = 0;//count each touch down valid site number
			SERIAL
			{
				tmp_site++;
				if (TYPE_CODE == 1)
				{
					lcode_init[SITE] = int(lvalue_avg_last[SITE] + 0.5);
					tmp_sum = tmp_sum + lcode_init[SITE];
				}
				else if (TYPE_CODE == 0)
				{
					lvalue_init[SITE] = lvalue_avg_last[SITE];
					tmp_sum = tmp_sum + lvalue_init[SITE];
				}
			}
			lvalue_avg_all = tmp_sum / tmp_site;
		}

	public:void Get_Lcode(int LCode[SITE_NUM])
		{
			for(int i=0;i<SITE_NUM;i++) 
			{
				LCode[i] = lcode_current[i];
			}
		}

	public:void Get_Lvalue(double LValue[SITE_NUM])
		{
			for (int i = 0; i < SITE_NUM; i++)
			{
				LValue[i] = lvalue_current[i];
			}
		}

	public:void Get_Avg(double LValueAvg[SITE_NUM])
		{
			for (int i = 0; i < SITE_NUM; i++)
			{
				LValueAvg[i] = lvalue_avg_last[i];
			}
		}

	//public:void Get_Zcode(string Para, int ZCode[SITE_NUM])
	//	{
	//		for(int i=0;i<SITE_NUM;i++) 
	//		{
	//			ZCode[i] = Z2L(Para, lcode_init[i]);
	//		}
	//	}

	public:void Get_Zcode(int ZCode[SITE_NUM])
		{
			for(int i=0;i<SITE_NUM;i++) 
			{ 
				//ZCode[i] = Z2L_CVT(lcode_init[i], Cvt_N, Cvt_Bit, Cvt_BitSize); 
				ZCode[i] = Z2L(lcode_init[i]);
			}
		}

	public:void Get_Diff(double LCodeDiff[SITE_NUM])
		{
			for(int i=0;i<SITE_NUM;i++) 
			{
				LCodeDiff[i] = lvalue_avg_diff[i];
			}
		}

	private:void Get_Std(double std[SITE_NUM])//tbd
		{
			for (int i = 0; i<SITE_NUM; i++)
			{
				lvalue_std[i] = buf[i].GetStd();
			}
		}

	private:void Calc_Site_Diff(void)
		{
			SERIAL
			{
				lvalue_avg_diff[SITE] = lvalue_avg_last[SITE] - lvalue_avg_all;
			}
		}

	private:void Calc_Max_Diff(void)
		{
			int j = 0;
			SERIAL
			{
				if (dut_count[SITE]>0)
				{
					lvalue_avg_temp[j] = lvalue_avg_last[SITE];
					j++;
				}
			}

			lvalue_avg_max = *max_element(lvalue_avg_temp, lvalue_avg_temp + j);
			lvalue_avg_min = *min_element(lvalue_avg_temp, lvalue_avg_temp + j);

			lvalue_avg_all_diff = abs(lvalue_avg_max - lvalue_avg_min);
		}

	private:void Check_Result(void)
		{
			bool trim_differ = false;

			if (lvalue_avg_all_diff > STA_LMT_DIFF)	{ flag_avg_diff_trigger = true; }
			//if (trim_differ){ etsMessageBox("TRIM Statistic Result Fail !! Please Check S2S issue for trim item !!", MB_OK | MB_ICONINFORMATION); }
			//else {etsMessageBox("TRIM Statistic Result Pass !!",MB_OK | MB_ICONINFORMATION);}
		}

	public:void Save_File(const char* folderpath)
		{
			char *str1 = "STA_";
			char *str2 = NAME;
			char *str3 = ".txt";
			size_t len = strlen(folderpath) + strlen(str1) + strlen(str2) + strlen(str3) + 1;
			char *filename = new char[len];
			strcpy(filename, folderpath);
			strcat(filename, str1);
			strcat(filename, str2);
			strcat(filename, str3);
			Save_to_file(filename, dut_count, lvalue_avg_all, lvalue_avg_last, lvalue_avg_diff, lcode_init);
		}

	private:double Calc_New_Avg(double LastVal, int NewVal, int Length)
		{
			double NewAvg = 0.0;
			if (Length <= 1){ NewAvg = NewVal; }
			else { NewAvg = ((LastVal * (Length - 1) + NewVal) * 1.0) / Length; }
			return NewAvg;
		}

	private:void Save_to_file(char *FileName, int Count[SITE_NUM], double AvgAll, double AvgLast[SITE_NUM], double AvgShift[SITE_NUM], int Init[SITE_NUM])
		{
			time_t nowtime;
			struct tm *timeinfo = NULL;
			time(&nowtime);
			timeinfo = localtime(&nowtime);
			//localtime_s(timeinfo, &nowtime);
			int year, month, day, hour, minute, second;
			if (timeinfo != NULL)
			{
				year = timeinfo->tm_year + 1900;
				month = timeinfo->tm_mon + 1;
				day = timeinfo->tm_mday;
				hour = timeinfo->tm_hour;
				minute = timeinfo->tm_min;
				second = timeinfo->tm_sec;
			}
			else
			{
				year = 0;
				month = 0;
				day = 0;
				hour = 0;
				minute = 0;
				second = 0;
			}
			FILE *fp;
			fp = fopen(FileName, "w");
			if (fp != NULL)
			{
				fprintf(fp, "%d/%d/%d_%d:%d:%d\n", year, month, day, hour, minute, second);
				char Title[] = "Site	Index	AvgAll	AvgLast	AvgSft	IniCode";
				fprintf(fp, "%s\n", Title);
				for (int i = 0; i<SITE_NUM; i++)
				{
					fprintf(fp, "%s%02d	%03d	%.2f	%.2f	%.2f	%03d\n", "S", i + 1, Count[i], AvgAll, AvgLast[i], AvgShift[i], Init[i]);
				}
				fclose(fp);
			}
			else
				printf("Write Statistic Value Error!\n");
		}

	//public:int Z2L(string Para, int ZCode)
	//	{
	//		int LCode;
	//		if (Para == "BG")//5 bit, bit0,1,2,3
	//		{
	//			LCode = (ZCode ^ 0x0F) & 0x1F;
	//		}
	//		else if (Para == "VDACH")//4 bit, bit3
	//		{
	//			LCode = (ZCode ^ 0x08) & 0x0F;
	//		}
	//		else if (Para == "FBDR")//4 bit, bit3
	//		{
	//			LCode = (ZCode ^ 0x08) & 0x0F;
	//		}
	//		else if (Para == "OSC")//2 bit, bit1
	//		{
	//			LCode = (ZCode ^ 0x02) & 0x03;
	//		}
	//		else//
	//		{
	//			LCode = ZCode;
	//			//MessageBox(NULL, "Wrong Trim Parameter Name", "STT Message", MB_OK);
	//		}
	//		return LCode;
	//	}

	public:int Z2L(int CodeIn)
		{
			return Z2L_CVT(CodeIn, Cvt_N, Cvt_Bit, Cvt_BitSize);
		}

	public:int Z2L_CVT(int ZCode, int N, int InvertBit[], int size)
		{
		int LCode = 0;
		int Mask = 0;
			if (TYPE_CODE == 1)
			{
				int FRng = int(pow(2, N) - 1);
				for (int i = 0; i < size; i++)
				{
					Mask = int(pow(2, InvertBit[i])) + Mask;
				}
				LCode = ZCode ^ Mask;
				LCode = LCode & FRng;
			}
			else if (TYPE_CODE == 0)
			{
				LCode = ZCode;
			}
			else LCode = ZCode;
			return LCode;
		}
};


class STA
{
	public:STA() { Init_Variable(); }
	public:~STA() {}

	public:		bool initialed = false;
	public:		int ItemCount = 0;
	public:		STA_NODE ITEM[256];
	public:		bool Trigger_Diff_Limit = false;
	public:		string pathofini = "";

	private:void Init_Variable(void);
	private:void Read_Cfg(const char *file_name);
	private:int Item(const char *item);

	public:void Init(const char *file_name);//step1
	public:void Set_Zcode(const char *item, int ZCode[SITE_NUM]);//step2
	public:void Update(void);//step3
	public:void Get_Lcode(const char *item, int LCode[SITE_NUM]);//step4
	public:void Get_Count(const char* item, int Count[SITE_NUM]);
	public:void Get_AvgSite(const char *item, double AvgSite[SITE_NUM]);//step4
	public:void Get_AvgShift(const char *item, double AvgShift[SITE_NUM]);//step4
	public:double Get_AvgAll(const char *item);//step4
	public:void Save_to_File(void);//step5
	public:void Result_Message(void);//step6
};

