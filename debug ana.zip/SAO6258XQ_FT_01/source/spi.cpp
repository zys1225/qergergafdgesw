#include "stdafx.h"
#include "spi.h"

extern DCM dcm;

//int add_parity(int data)//add parity to the lsb
//{
//	int bit[16];
//	int p = 0;
//	data = data & 0xFFFE;
//	for (int i = 0; i <= 15; i++) { bit[i] = (data >> i) & 1; }
//	for (int i = 1; i <= 15; i++) { p = p^bit[i]; }
//	data = data + p;
//	return data;
//}

int count_ones(int data)
{
	data = data & 0xFFFF;
	int n = 0;
	for (int i = 0; i <= 15; i++) 
	{ 
		if (((data >> i) & 1)  > 0) n++;
	}
	return n;
}

void dut_spi(int SDI, int SDO[])
{
	ULONG wdata;
	ULONG rdata[SITE_NUM];
	int status[SITE_NUM];
	wdata = SDI;
	dcm.WriteWaveData("D_SDI", "SPI_Data", DCM_ALLSITE, 0, 16, wdata);
	dcm.RunVectorWithGroup("SPI_DUT", "SPI_Start", "SPI_Stop");
	//dcm.SetCapture("D_SDO", "SPI_Data", DCM_ALLSITE, 0, 16);
	SERIAL
	{
		status[SITE] = dcm.GetCaptureData("D_SDO", "SPI_Data", SITE, 0, 16, rdata[SITE]);
		//status[SITE] = dcm.GetCaptureData("D_SDO", SITE, rdata);
		SDO[SITE] = rdata[SITE] & 0xFFFF;
	}
}

void dut_spi(int *SDI, int SDO[])
{
	ULONG wdata;
	ULONG rdata[SITE_NUM];
	int status[SITE_NUM];
	SERIAL
	{
		wdata = SDI[SITE];
		status[SITE] = dcm.WriteWaveData("D_SDI", "SPI_Data", SITE, 0, 16, wdata);
	}
	dcm.RunVectorWithGroup("SPI_DUT", "SPI_Start", "SPI_Stop");
	//dcm.SetCapture("D_SDO", "SPI_Data", DCM_ALLSITE, 0, 16);
	SERIAL
	{
		status[SITE] = dcm.GetCaptureData("D_SDO", "SPI_Data", SITE, 0, 16, rdata[SITE]);
		//status[globalsite] = dcm.GetCaptureData("D_SDO", SITE, rdata);
		SDO[SITE] = rdata[SITE] & 0xFFFF;
	}
}

void tmp126_spi(int SDI1, int SDI2, int SDO1[], int SDO2[])
{
	ULONG wdata;
	ULONG rdata[SITE_NUM];
	int status;
	int status1[SITE_NUM];
	int status2[SITE_NUM];
	int status3[SITE_NUM];
	int status4[SITE_NUM];

	wdata = SDI1;
	status = dcm.WriteWaveData("D_SDI", "TMP126_Data1", DCM_ALLSITE, 0, 16, wdata);
	wdata = SDI2;
	status = dcm.WriteWaveData("D_SDI", "TMP126_Data2", DCM_ALLSITE, 0, 16, wdata);
	status = dcm.RunVectorWithGroup("SPI_TMP126", "TMP126_Start", "TMP126_Stop");
	//dcm.SetCapture("D_SDO", "TMP_SPI_Data2", DCM_ALLSITE, 0, 16);
	SERIAL
	{
		status4[SITE] = dcm.GetCaptureData("D_SDO", "TMP126_Data2", SITE, 0, 16, rdata[SITE]);
		//status4[SITE] = dcm.GetCaptureData("D_SDO", SITE, rdata[SITE]);
		SDO2[SITE] = rdata[SITE] & 0xFFFF;
	}
}

void ad8400_spi(int SDI)
{
	ULONG wdata;
	//ULONG rdata;
	wdata = SDI;
	dcm.WriteWaveData("D_SDI", "AD8400_Data", DCM_ALLSITE, 0, 10, wdata);
	dcm.RunVectorWithGroup("SPI_AD8400", "AD8400_Start", "AD8400_Stop");
}

void dds_spi(int SDI)
{
	ULONG wdata;
	//ULONG rdata;
	wdata = SDI;
	dcm.WriteWaveData("D_SDI", "DDS_Data", DCM_ALLSITE, 0, 16, wdata);
	dcm.RunVectorWithGroup("SPI_DDS", "DDS_Start", "DDS_Stop");
}

void dds_spi(int SDI[])
{
	ULONG wdata[SITE_NUM];
	//ULONG rdata;
	SERIAL wdata[SITE] = SDI[SITE];
	SERIAL dcm.WriteWaveData("D_SDI", "DDS_Data", SITE, 0, 16, wdata[SITE]);
	dcm.RunVectorWithGroup("SPI_DDS", "DDS_Start", "DDS_Stop");
}

//
void SPI_Class::dut_write_x1(int RegAddress, int WriteData)
{
	int wdata;
	int rdata[SITE_NUM];
	SERIAL rdata[SITE]=0;
	wdata = ((RegAddress & 0xFF) << 9) | ((WriteData & 0xff) << 1);
	wdata |= 0x8000;
	if (count_ones(wdata & 0xffff) % 2){ wdata |= 0x1; }

	dut_spi(wdata, rdata);
}

void SPI_Class::dut_write_x1(int RegAddress, int *WriteData)
{
	int wdata[SITE_NUM];
	int rdata[SITE_NUM];
	SERIAL
	{
		wdata[globalsite] = (RegAddress << 9) | ((WriteData[globalsite] & 0xff) << 1);
		wdata[globalsite] |= 0x8000;
		if (count_ones(wdata[globalsite] & 0xffff) % 2){ wdata[globalsite] |= 0x1; }
	}

	dut_spi(wdata, rdata);
}

void SPI_Class::dut_read_x1(int RegAddress, int ReadData[], int Parity[])
{
	int wdata;
	//int rdata[SITE_NUM];
	wdata = RegAddress << 9;
	if (count_ones(wdata & 0xffff) % 2){ wdata |= 0x1; }

	dut_spi(wdata, ReadData);
	SERIAL
	{
		if (count_ones(ReadData[globalsite] & 0xffff) % 2){Parity[globalsite]=1;}
		else{Parity[globalsite]=0;}//0,pass
		ReadData[globalsite] = (ReadData[globalsite] >> 1 ) & 0xFF;
	}
}

void SPI_Class::dut_read_x1(int RegAddress, int ReadData[])
{
	int Parity[SITE_NUM];
	dut_read_x1(RegAddress, ReadData, Parity);
}

void SPI_Class::dds_write_x1(int WriteData)
{
	dds_spi(WriteData);
}

void SPI_Class::dds_write_x1(int WriteData[])
{
	dds_spi(WriteData);
}

void SPI_Class::ad8400_write_x1(int RegAddress, int WriteData)
{
	int wdata;
	wdata = (RegAddress << 8) | (WriteData & 0xff);
	ad8400_spi(wdata);
}

void SPI_Class::tmp126_write_x1(int RegAddress, int WriteData)
{
	int wdata1;
	int wdata2;
	int rdata1[SITE_NUM];
	int rdata2[SITE_NUM];
	int wr = 0;
	int Cmd = ((wr & 0x01) << 8) + (RegAddress & 0xFF);
	wdata1 = Cmd & 0xFFFF;
	wdata2 = WriteData & 0xFFFF;
	tmp126_spi(wdata1, wdata2, rdata1, rdata2);
}

void SPI_Class::tmp126_read_x1(int RegAddress, int ReadData[])
{
	int wdata1;
	int wdata2;
	int rdata1[SITE_NUM];
	int rdata2[SITE_NUM];
	int wr = 1;
	int Cmd = ((wr & 0x01) << 8) + (RegAddress & 0xFF);

	wdata1 = Cmd & 0xFFFF;
	wdata2 = 0xFFFF;
	tmp126_spi(wdata1, wdata2, rdata1, rdata2);
	SERIAL
	{
		ReadData[globalsite] = rdata2[globalsite];
	}
}
