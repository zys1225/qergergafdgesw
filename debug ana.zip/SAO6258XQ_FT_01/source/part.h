#ifndef __PART_H_
#define __PART_H_
#include <time.h>
#include "inireader.h"

#define PN_Count	64
#define PIN_Count	63+35+1
#define R_RELAY_LC	1.0
#define R_RELAY_HC	0.045

//#define FB_TARGET		PN_Prebk_Output
//#define POSFB_TARGET	PN_Posbk_Output

//int PN_Read_N = 0;



struct PartNumberNode
{
	string name_str;
	int name_int;
	int trim_index;
	//string ver_str;
	int ver_int;
	int pin_cnt;
	int flow;
	bool eng_device;
};

struct PinNode
{
	string name;
	//string name_pre;
	//string name_post;
	string name_os;
	string name_lvl;
	string name_leak;
	string name_leak_delt;
	string name_abs;
	bool diode;
	bool pin_valid;
	double pin_volt[SITE_NUM];
	double pin_lvl[SITE_NUM];
	double pin_leak[SITE_NUM];
	double pin_abs[SITE_NUM];
	double pin_leak_pre[SITE_NUM];
	double pin_leak_post[SITE_NUM];
	double pin_leak_delt[SITE_NUM];
};

struct PinListNode
{
	string name;
	bool diode;
	bool valid[32];
};

//struct EepNode
//{
//	int REG[64][SITE_NUM];
//};

void init_pinlist(void);
void init_partnumber(void);
void sel_partnumber(int defaultid);
void Check_Eng_Device(void);
int PART_NUM(void);
int PART_VER(void);
int PIN_CNT(void);
int PROG_VER(void);
int DIE_VER(void);
int PART_ENG(void);
bool PART_QUAL(void);
int calc_ecc(int data0,int data1,int data2,int data3,int data4,int data5);
void update_trim_table_and_target(int index);
void set_trim_table_by_partnumber(void);
void export_partnumber_info(void);
void get_waferid(int *wafer_id, int *x, int *y);
int ctl_waferid(bool ft_char, int *x, int *y, int *xy, int *waferid);
void Nvm_ReadFs(int data[][SITE_NUM]);
void Nvm_Read(int data[][SITE_NUM]);
void Usr_Read(int data[][SITE_NUM]);
void treg2pgs();
void read_partnumber(const char *file_name);
void PartNum_Select_Dialog();
void PartNum_Select_Dialog2();


#define Dmux_PG_STATUS				0
#define Dmux_VSYNC_INT				1
#define Dmux_EN_SYS					2
#define Dmux_UVLO2					3
#define Dmux_EN_IO					4
#define Dmux_EN_DIGDLY				5
#define Dmux_OSC_OK					6
#define Dmux_EN_DCDC				7
#define Dmux_PG_IN_OV				8
#define Dmux_PG_IN_UV				9
#define Dmux_VOUT_OV_ABS			10
#define Dmux_VIN_OV					11
#define Dmux_VOUT_UV				12
#define Dmux_TSD					13
#define Dmux_OCP					14
#define Dmux_EN_SW					15
#define Dmux_SS_END					16
#define Dmux_RD_VOUT_OVP_FLG		17
#define Dmux_RD_VIN_OVP_FLG			18
#define Dmux_RD_TSD_FLG				19
#define Dmux_RD_OCP_FLG				20
#define Dmux_RD_UVP_FLG				21
#define Dmux_PG_IN_UV_DGL			22
#define Dmux_PG_IN_OV_DGL			23
#define Dmux_VOUT_OV_ABS_DGL		24
#define Dmux_VIN_OV_DGL				25
#define Dmux_OCP_DGL				26
#define Dmux_VOUT_UV_DGL			27
#define Dmux_PTC_RST				28
#define Dmux_PTC_STATUS				29
#define Dmux_VOUT_OV_STATUS_POST	30
#define Dmux_VOUT_OV_STATUS_RST		31
#define Dmux_OCP_STATUS_POST		32
#define Dmux_VOUT_UV_STATUS_POST	33
#define Dmux_WARMUP_DONE			34
#define Dmux_PGM_BUSY				35
#define Dmux_SS_ON					36
#define Dmux_EN_TM_TRG				37
#define Dmux_TM2_OUT				38
#define Dmux_TM3_OUT				39
#define Dmux_TM4_OUT				40
#define Dmux_TM789_OUT				41
#define Dmux_TM11_12_13_23_OUT		42
#define Dmux_TM14_OUT				43
#define Dmux_TM16_17_OUT			44
#define Dmux_TM18_OUT				45
#define Dmux_TM19_OUT				46
#define Dmux_WR_EN_DCDC_0			47
#define Dmux_EN_FPWM				48
#define Dmux_EN_APFM				49

#define Adr_eFUSE_BANK0				0x80
#define Adr_eFUSE_BANK1				0x81
#define Adr_eFUSE_BANK2				0x82
#define Adr_eFUSE_BANK3				0x83
#define Adr_eFUSE_BANK4				0x84
#define Adr_eFUSE_BANK5				0x85
#define Adr_eFUSE_BANK6				0x86
#define Adr_eFUSE_BANK7				0x87
#define Adr_eFUSE_BANK8				0x88
#define Adr_eFUSE_BANK9				0x89
#define Adr_eFUSE_BANK10			0x8A
#define Adr_eFUSE_BANK11			0x8B


#endif