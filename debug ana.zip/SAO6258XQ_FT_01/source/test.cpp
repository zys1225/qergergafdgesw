//****************************************************************************
//Revision History:
//****************************************************************************
// Rev   Level          Author            Date              Test time
// ---------------------------------------------------------------------------
// 00    Inital         Hunter           1/6/2025            
//*****************************************************************************
//Change History:
//*****************************************************************************
// 00 --- Create base on SACH96257_A0_00A0
//*********************************************************************************************************************************************
// 00 ---
//*********************************************************************************************************************************************
//SC6258X STS8300 TEST PROGRAM
//---------------------------------------------------------------------------------------------------------------------------------------------
//DEVICE ...........................SC6258X
//PACKAGE...........................QFN48/QFP48/QFP64
//DUT BOARD NUMBER..................SAFDO6258XN48X/SAFDO6258XPXXX
//Test Head BOARD NUMBER............xxxx
//*********************************************************************************************************************************************

//*********************************************************************************************************************************************

#include "stdafx.h"
#include "Pin_Channel_define.h"
#include "BoardCheck.h"
#include "treg.h"
#include "math.h"
//#include "time.h"
#include "sub.h"
#include "cfg.h"
#include "part.h"
#include "cmd.h"
#include "lsi.h"
#include "Coutlier.h"
#include "FMEA.h"
#include "awg.h"
#include "exGPIB.h"
#include "sta.h"
#include <ctime>;

extern "C" int USERRES_API STSMaskTHBConfigCheck(bool maskFlag);
extern "C" int GetPgsFullPath(LPTSTR pgsPath, int chNum);
//string pgs_path;
bool DO_FMEA = false;
bool DO_TRIM = true;
bool DO_CHAR = true;
bool DO_BoardCheck = false;
bool burn_flag[SITE_NUM];
bool QC = false;
bool FLOW_CP = false;
bool DEBUG = true;
bool DO_ABSN = false;
bool use_amux = false;
int globalsite;
float SPI_CLK = 12 MHz;
BYTE sitesta[SITE_NUM];
int trimed_cp0[SITE_NUM];
int trimed_ft0[SITE_NUM];
int trimed_ftb0[SITE_NUM];
int trimed_cp1[SITE_NUM];
int trimed_ft1[SITE_NUM];
int trimed_ftb1[SITE_NUM];
int trimed_cp2[SITE_NUM];
int trimed_ft2[SITE_NUM];
int trimed_ftb2[SITE_NUM];
int burn_lock0[SITE_NUM];
int ecc_pass0[SITE_NUM];
int ecc_read0[SITE_NUM];
int ecc_calc0[SITE_NUM];
int burn_lock1[SITE_NUM];
int ecc_pass1[SITE_NUM];
int ecc_read1[SITE_NUM];
int ecc_calc1[SITE_NUM];
int burn_lock2[SITE_NUM];
int ecc_pass2[SITE_NUM];
int ecc_read2[SITE_NUM];
int ecc_calc2[SITE_NUM];
int crc_opt;
int crc_read[SITE_NUM];
int crc_pass[SITE_NUM];
int test_stage = 0;//0:RT,1:HT,2:LT
int treg_log_mode = 0;//2 for debug ,0 for standard
int G_INDEX = 0;
int G_INDEX_PRE = 0;
bool HW_QFN = true;
double max_temp = 0;
int MainVer;
float SubVer;

int wafer_id[SITE_NUM];
int x_coords[SITE_NUM];
int y_coords[SITE_NUM];
int xy_index[SITE_NUM];

extern double PREBK_HSRDSON[SITE_NUM];
extern double PREBK_LSRDSON[SITE_NUM];
extern double POSBK_HSRDSON[SITE_NUM];
extern double POSBK_LSRDSON[SITE_NUM];

extern double PREBK_LSRDSON_OS;
extern double PREBK_HSRDSON_OS;
extern double POSBK_LSRDSON_OS;
extern double POSBK_HSRDSON_OS;

double iq1_pre[SITE_NUM];
double iq2_pre[SITE_NUM];
double iq3_pre[SITE_NUM];
double iq4_pre[SITE_NUM];
double iq1_pos[SITE_NUM];
double iq2_pos[SITE_NUM];
double iq3_pos[SITE_NUM];
double iq4_pos[SITE_NUM];
double iq1_delt[SITE_NUM];
double iq2_delt[SITE_NUM];
double iq3_delt[SITE_NUM];
double iq4_delt[SITE_NUM];

int data_1A[SITE_NUM];
int data_1E[SITE_NUM];
int data_20[SITE_NUM];
int data_21[SITE_NUM];
int data_22[SITE_NUM];
int data_23[SITE_NUM];
int data_27[SITE_NUM];
int data_33[SITE_NUM];

double qt1_qvr_err[SITE_NUM];
double qt2_qvr_err[SITE_NUM];
double qt3_qvr_err[SITE_NUM];

bool has_hw_cfg = false;
extern BOOL run_diags();     // global funtion for HW checker
DCM dcm;
CBITe cbit;
TREG dut;
SPEC spec;
STA sta;
Coutlier sos;
eFMEA efmea;
eGPIB egpib;
AWG_FUNC awg;
int GPIB_CHAR_ENABLE = 0;
int SOS_MODE = PRODUCTION;

bool use_lsi_dfi = true;
double lsi_dfi_gain = 20;

int  in_tm[SITE_NUM] = { 0 };

int rdata[SITE_NUM] = { 0 };

int Trig_Point[SITE_NUM];
ULONG ulWriteData[SITE_NUM] = { 0 };
int nReadData[SITE_NUM] = { 0 };
int nReadData1[SITE_NUM] = { 0 };

extern PinNode PINarray[PIN_Count];
extern double PN_Posbk_Output;
extern int PN_Tracker_Num;
//extern bool PN_ASF;
extern bool PN_QST_Before_Prebk;
extern int PN_INIT_Timer;
//extern int PN_INIT_Counter;
extern double PN_Prebk_Output;
extern double PN_QST_Output;
extern double PN_QUC_Output;
extern double PN_QVR_Output;
extern double PN_QVR_Output_Target;
extern double PN_QT1_Output_Target;
extern double PN_QT2_Output_Target;
extern double PN_QT3_Output_Target;
extern double PN_QCO_Output;
extern double PN_QT1_Output;
extern double PN_QT2_Output;
extern double PN_QT3_Output;
extern bool PN_LOW_UV;
extern bool PN_SSD;
extern bool PN_EVS;
extern bool PN_SEC_Available;
extern bool PN_VCI_Available;
extern bool PN_AMUX_Available;
extern bool PN_Posbk_Available;

double temp_meas(int site, int state)
{
	double temperature;
	double volt[SITE_NUM];
	double temp[SITE_NUM];
	temperature = 25;
	if (state == 0) //Measure
	{
		C_All_Open;
		C_FXVI_ACM_GND_Connect;
		C_ACM_MPS_Connect;
		delay_ms(2);
		A_MPS.Set(FI, -1 mA, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(4);
	}
	//get test result,and cal the temp
	A_MPS.MeasureVI(100, 10);
	SERIAL volt[SITE] = A_MPS.GetMeasResult(SITE, MVRET);
	ConvertTempDut(volt, temp);
	temperature = temp[site];

	if (state == 2)//Off 
	{
		//off resource ,and ready to run
		A_MPS.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(3);
		A_MPS.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
		cbit.SetOn(-1);
	}
	return temperature;
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
/****multisite settings should be included here****/
DUT_API void HardWareCfg()
{
	//if(!has_hw_cfg)
	//{
		STSSetMultiSiteBindEx(MD_ACM200, 0, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE1_);
		STSSetMultiSiteBindEx(MD_ACM200, 1, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE2_);
		STSSetMultiSiteBindEx(MD_ACM200, 2, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE3_);
		STSSetMultiSiteBindEx(MD_ACM200, 3, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE4_);
		STSSetMultiSiteBindEx(MD_ACM200, 4, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE5_);
		STSSetMultiSiteBindEx(MD_ACM200, 5, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE6_);
		STSSetMultiSiteBindEx(MD_ACM200, 6, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE7_);
		STSSetMultiSiteBindEx(MD_ACM200, 7, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE8_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 0, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE1_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 1, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE2_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 2, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE3_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 3, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE4_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 4, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE5_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 5, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE6_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 6, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE7_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 7, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE8_);
		STSSetMultiSiteBindEx(MD_FPVIe, 0, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE1_);
		STSSetMultiSiteBindEx(MD_FPVIe, 1, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE2_);
		STSSetMultiSiteBindEx(MD_FPVIe, 2, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE3_);
		STSSetMultiSiteBindEx(MD_FPVIe, 3, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE4_);
		STSSetMultiSiteBindEx(MD_FPVIe, 4, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE5_);
		STSSetMultiSiteBindEx(MD_FPVIe, 5, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE6_);
		STSSetMultiSiteBindEx(MD_FPVIe, 6, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE7_);
		STSSetMultiSiteBindEx(MD_FPVIe, 7, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE8_);
		STSSetMultiSiteBindEx(MD_QVMe, NO_SITE, _PIN_SITE_BIND_DEFINE_MD_QVME_NOSITE);
		STSSetMultiSiteBindEx(MD_QTMUe, NO_SITE, _PIN_SITE_BIND_DEFINE_MD_QTMUE_NOSITE);
		has_hw_cfg = true;
	//}
}
//initialize function will be called before all the test functions.
DUT_API void UserLoad()
{
	STSMaskTHBConfigCheck(true);
	G_INDEX = 0;
	G_INDEX_PRE = G_INDEX;
	/**********firmware**********/
	char pgsfullpath[300];
	GetPgsFullPath(pgsfullpath, 300);
	string fullpathpgs(pgsfullpath);
	string pathofpgs = "";

	check_software(&MainVer, &SubVer);

	int pos = fullpathpgs.find_last_of('\\');
	if (pos > -1)
	{
		pathofpgs = fullpathpgs.substr(0, pos + 1);
	}

	int ScanLoad_flag = 0;
	if(DIE_VER()==0){ScanLoad_flag = dcm.LoadVectorFile("SAO6258X_1P0.acvec", FALSE);}
	else if(DIE_VER()==1){ScanLoad_flag = dcm.LoadVectorFile("SAO6258X_1P1.acvec", FALSE);}
	else{ScanLoad_flag = dcm.LoadVectorFile("SAO6258X_1P2.acvec", FALSE);}
	if (ScanLoad_flag != 0) { MessageBoxA(NULL, "Load vector fail", "Error Message", MB_OK); }

	int rt;
	rt = dcm.SetPinGroup("DCM_ALL",		"D_SDI, D_SCK, D_SDO, D_CS, DCM4, DCM5, DCM6, DCM7");
	rt = dcm.SetPinGroup("I2C",			"DCM6, DCM5");
	rt = dcm.SetPinGroup("SPI_IN",		"D_SDI");
	rt = dcm.SetPinGroup("SPI_OUT",		"D_SDO");
	rt = dcm.SetPinGroup("SPI_DUT",		"D_CS, D_SCK, D_SDI, D_SDO");
	rt = dcm.SetPinGroup("SPI_TMP126",	"D_CS, DCM7, D_SCK, D_SDI, D_SDO");
	rt = dcm.SetPinGroup("SPI_AD8400",	"D_CS, DCM7, D_SCK, D_SDI");
	rt = dcm.SetPinGroup("SPI_DDS",		"D_CS, DCM7, D_SCK, D_SDI");

	rt = dcm.SetPinGroup("SCAN",		"D_SCK, D_SDO, D_SDI, D_CS, DCM4");
	rt = dcm.SetPinGroup("SCAN_CLK",	"D_SCK");
	rt = dcm.SetPinGroup("SCAN_OUT",	"D_SDO");
	rt = dcm.SetPinGroup("SCAN_IN",		"D_SDI, D_CS, DCM4");
	rt = dcm.SetPinGroup("DCM_I2C",		"D_SCK, D_SDI");

	rt = dcm.SetPinGroup("SCL", "DCM6");
	rt = dcm.SetPinGroup("SDA", "DCM5");

	rt = dcm.SetPinGroup("SDI", "D_SDI");
	rt = dcm.SetPinGroup("SCK", "D_SCK");
	rt = dcm.SetPinGroup("SDO", "D_SDO");
	rt = dcm.SetPinGroup("CS", "D_CS");
	rt = dcm.SetPinGroup("D4", "DCM4");
	rt = dcm.SetPinGroup("D5", "DCM5");
	rt = dcm.SetPinGroup("D6", "DCM6");
	rt = dcm.SetPinGroup("D7", "DCM7");

	//dcm.InitPPMU("DCM_ALL");
	//dcm.Disconnect("DCM_ALL");

	//if(!has_hw_cfg)
	//{
		STSSetMultiSiteBindEx(MD_ACM200, 0, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE1_);
		STSSetMultiSiteBindEx(MD_ACM200, 1, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE2_);
		STSSetMultiSiteBindEx(MD_ACM200, 2, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE3_);
		STSSetMultiSiteBindEx(MD_ACM200, 3, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE4_);
		STSSetMultiSiteBindEx(MD_ACM200, 4, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE5_);
		STSSetMultiSiteBindEx(MD_ACM200, 5, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE6_);
		STSSetMultiSiteBindEx(MD_ACM200, 6, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE7_);
		STSSetMultiSiteBindEx(MD_ACM200, 7, _PIN_SITE_BIND_DEFINE_MD_ACM200_SITE8_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 0, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE1_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 1, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE2_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 2, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE3_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 3, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE4_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 4, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE5_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 5, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE6_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 6, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE7_);
		STSSetMultiSiteBindEx(MD_FXVIe_PLUS, 7, _PIN_SITE_BIND_DEFINE_MD_FXVIE_PLUS_SITE8_);
		STSSetMultiSiteBindEx(MD_FPVIe, 0, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE1_);
		STSSetMultiSiteBindEx(MD_FPVIe, 1, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE2_);
		STSSetMultiSiteBindEx(MD_FPVIe, 2, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE3_);
		STSSetMultiSiteBindEx(MD_FPVIe, 3, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE4_);
		STSSetMultiSiteBindEx(MD_FPVIe, 4, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE5_);
		STSSetMultiSiteBindEx(MD_FPVIe, 5, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE6_);
		STSSetMultiSiteBindEx(MD_FPVIe, 6, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE7_);
		STSSetMultiSiteBindEx(MD_FPVIe, 7, _PIN_SITE_BIND_DEFINE_MD_FPVIE_SITE8_);
		STSSetMultiSiteBindEx(MD_QVMe, NO_SITE, _PIN_SITE_BIND_DEFINE_MD_QVME_NOSITE);
		STSSetMultiSiteBindEx(MD_QTMUe, NO_SITE, _PIN_SITE_BIND_DEFINE_MD_QTMUE_NOSITE);
		has_hw_cfg = true;
	//}

	AstBindingAllModule();

	BYTE siteStatus[SITE_NUM] = { 0 };
	for (int i = 0; i < SITE_NUM; i++){
		siteStatus[i] = 1;
	}
	STSSetSiteStatusEx(siteStatus, SITE_NUM);

	//////////////Select different Part Number, Set Pin List, Set Trim Optioin
	string pathofpn = pathofpgs + "part.ini";
	//read_partnumber(pathofpn.c_str());
	init_partnumber();
	//sel_partnumber(4);//debug use, SC62584ft
	//sel_partnumber(5);//debug use, SC62584qual
	//sel_partnumber(8);//debug use, SC62583QA1
	//sel_partnumber(9);//debug use, SC62583QA2
	//sel_partnumber(22);//debug use, SC62583QA3
	//sel_partnumber(10);//debug use, SC62584QA1
	//sel_partnumber(11);//debug use, SC62584QA2
	//sel_partnumber(12);//debug use, SC62584QA3
	//sel_partnumber(19);//debug use, SC62584QA4
	//sel_partnumber(13);//debug use, SC62585QA1
	//sel_partnumber(20);//debug use, SC62585QA2
	//sel_partnumber(14);//debug use, SC62586QA1
	//sel_partnumber(25);//debug use, SC62586QA1_1
	//sel_partnumber(26);//debug use, SC62586QA1_2
	//sel_partnumber(15);//debug use, SC62586QA2
	//sel_partnumber(16);//debug use, SC62586QA3
	//sel_partnumber(21);//debug use, SC62586QA4
	//sel_partnumber(23);//debug use, SC62586QA5
	//sel_partnumber(24);//debug use, SC62586QA7
	//sel_partnumber(27);//debug use, SC62586QA8
	//sel_partnumber(28);//debug use, SC62586QA9
	//sel_partnumber(17);//debug use, SC62587QA1
	//sel_partnumber(18);//debug use, SC62586QUAL
	// 
	//sel_partnumber(-1);//production use
	//PartNum_Select_Dialog();
	PartNum_Select_Dialog2();
	
	check_hw();
	LSI_Init(K_EN_SPI, K_EN_OUT, K_SEL_SPI, K_EN_EXSI, K_GAIN0, K_GAIN1, K_EN_LDO);
	LSI_DisConnect();

	//*********define code PGS name*******//
	char pgsname[100];
	int teststageres;
	STSGetPgsName(pgsname, 50);
	string pgsstr = pgsname;
	//Get Char Flag
	if (pgsstr.find("_CHAR_") != -1)
	{
		DO_CHAR = true;
		test_stage = 0;//RT
	}
	//Get Temp Flag
	if (pgsstr.find("_H_") != -1) //== 0x12)
	{test_stage = 1;}//HT
	else
	{
		if (pgsstr.find("_L_") != -1)// == 0x12)
		{test_stage = 2;}//LT
		else
		{test_stage = 0;}//RT
	}
	//Get Flow Flag
	if (pgsstr.find("_QC") != -1) //== 0x14)
	{
		DO_TRIM = false;
		DO_CHAR = false;
		QC = true;
	}
	else
	{
		DO_TRIM = true;
		QC = false;
	}
	//////////////////////
	if (test_stage > 0) {DO_TRIM = false;}
	string pathoftreg = "";
	if(DIE_VER()==0){pathoftreg = pathofpgs + "SAO6258X_1P0.treg";}
	else{pathoftreg = pathofpgs + "SAO6258X_1P1.treg";}

	dut.init(pathoftreg.c_str(), SITE_NUM, QC, DO_TRIM);
	//treg2pgs();////////run one time only
	//export_partnumber_info();

	string pathofsta = "";
	if(DIE_VER()==0){pathofsta = pathofpgs + "sta_1P0.ini";}
	else{pathofsta = pathofpgs + "sta_1P1.ini";}
	sta.Init(pathofsta.c_str());

	spec.init(pgsfullpath);

	string pathofsos = pathofpgs + "\\source\\SOS_Config.csv";
	string pathofdata = pathofpgs + "\\source\\MP_DATA.csv";
	if (!sos.init(pathofsos, SOS_MODE, pathofdata)){
		MessageBoxA(NULL, "�޷��������ļ�����ȷ���ļ��Ƿ�����������", "SOS��ʾ�Ի���", MB_OK);
		PostQuitMessage(0);
	}
	
	set_trim_table_by_partnumber();
	init_pinlist();

	if (DO_FMEA) efmea.fmea_enable = 0;//ͬһ��site������ͬ����
	if (DO_FMEA) efmea.fmea_2_enable = 1;//ͬһ������������ͬsite

	SERIAL qt1_qvr_err[SITE]=0;
	SERIAL qt2_qvr_err[SITE]=0;
	SERIAL qt3_qvr_err[SITE]=0;
	if (DO_BoardCheck){ run_diags();}

	//////////////GPIB enable and setting
	//=========GPIB======================//
	double tempgrp[] = { 25, -20, -40, 85, 125, 150 };

	if (DO_CHAR)
		GPIB_CHAR_ENABLE = 1;
	else 
		GPIB_CHAR_ENABLE = 0;
	//GPIB_CHAR_ENABLE = 0;

	egpib.add_temp_func(temp_meas);
	egpib.set_loopcount(1);
	egpib.set_soaktime(15000);//ms
	egpib.cool_down_target_temp=30.0;
	egpib.cool_down_temp = -40;
	egpib.cooldowntime = 0;
	egpib.tempcycle_setting(tempgrp, sizeof(tempgrp) / sizeof(tempgrp[0]));
	//GPIB_CHAR_ENABLE=1; //enable char,GPIB_CHAR_ENABLE=0 disable char and debug window, GPIB_CHAR_ENABLE>1, disable char ,enable debug window for printf output
	//egpib.userload(GPIB_CHAR_ENABLE);//enable GPIB or disable it
    //egpib.userload(0);//enable GPIB or disable it
	//DO_CHAR = false;
	//egpib.temp_target

}
/*                                                                      */
/************************************************************************/
DUT_API void UserInit()
{
	//awg.awgReload();
	int status = dcm.Connect("SPI_DUT");//Connect all channel's relay
	if (status != 0) { MessageBoxA(NULL, "DCM connect fail", "Error Message", MB_OK); }
	status = dcm.InitMCU("SPI_DUT");//Initialize MCU.
	if (status != 0) { MessageBoxA(NULL, "DCM initMCU fail", "Error Message", MB_OK); }
	delay_us(100);
}
/************************************************************************/
DUT_API void InitBeforeTestFlow()
{
	//efmea.force_item_fail(35,0);
	////check if need reload awg due to site change.
	//int sitecount=0;
	////awg.awgReload();
	//awg.StartLoad();
	//dcm.InitPPMU("DCM_ALL");
	int status = dcm.Disconnect("DCM_ALL");
	if (status != 0) { MessageBoxA(NULL, "DCM disconnect fail", "Error Message", MB_OK); }
	//qvm.Connect();
	SERIAL burn_flag[SITE] = true;
	SERIAL trimed_cp0[SITE] = 0;
	SERIAL trimed_ft0[SITE] = 0;
	SERIAL trimed_ftb0[SITE] = 0;

	dut.sot();
	sos.sot();
	efmea.sot();
	egpib.sot();

	set_trim_table_by_partnumber();
	all_resource_off();
	if (DO_CHAR) dut.force_table_char_active(1);
	//LSI_Connect();
	//AD8400_Connect();
	//AD8400_SetResDiv(0);
	//AD8400_DisConnect();
	//LSI_DisConnect();

	QVM_Init();
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initializefunction will be called after all the test functions.
DUT_API void InitAfterTestFlow()
{
	sos.eot();
	//dcm.InitPPMU("DCM_ALL");
	int status = dcm.Disconnect("DCM_ALL");
	if (status != 0) { MessageBoxA(NULL, "DCM disconnect fail", "Error Message", MB_OK); }
	//awg.EndLoad();
	check_rdson_valid(false);
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
DUT_API void UserExit()
{
	C_All_Open;
	egpib.userexit();
	sta.Result_Message();
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//Fail site hardware set function will be called after failed params, it can be called for serveral times.
DUT_API void SetupFailSite(const unsigned char*byFailSite)
{
	//C_All_Open;
	all_resource_off();
	dcm.Disconnect("DCM_ALL");
	efmea.fmea_onfailsite();
	//awg.Check();
}
/************************************************************************/
/*                                                                      */
/************************************************************************/

DUT_API void BinOutDut()
{
	dut.eot();
	efmea.eot();
	egpib.eot();
}
/************************************************************************/
/*                                                                      */
/************************************************************************/

DUT_API int T00_Info(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	//char waferid[13];
	bool ft_char = true;
	//G_INDEX=20;
	get_waferid(wafer_id, x_coords, y_coords);
	if(!FLOW_CP)
	{
		ctl_waferid(ft_char, x_coords, y_coords, xy_index, wafer_id);
	}

	Ms_LogData(funcindex, "X_Coordinate", x_coords);
	Ms_LogData(funcindex, "Y_Coordinate", y_coords);
	Ms_LogData(funcindex, "XY_Index", xy_index);


	//char pcVer[256]={0}; 
	//STSGetSystemVersion (pcVer ,256);
	//char pcName[256]={0}; 
	//STSGetSystemName (pcName,256);
	//char buf[256] = {0}; 
	//STSGetTHBInfo(THBInfo_Productname, buf, 256);
	int data[SITE_NUM];
	int chip[SITE_NUM];
	int has_lsi[SITE_NUM];
	double res[SITE_NUM];
	double gain[SITE_NUM];
	double vldo[SITE_NUM];
	double clk[SITE_NUM];
	double vmax[SITE_NUM];
	double vmin[SITE_NUM];
	double gain1[SITE_NUM];
	double gain2[SITE_NUM];
	double gain3[SITE_NUM];
	double gain4[SITE_NUM];
	double ampdrvi[SITE_NUM];
	double ampdrvac[SITE_NUM];
	double ampdrvdc[SITE_NUM];
	double ampdutsi[SITE_NUM];
	double ampdutac[SITE_NUM];
	double ampdutdc[SITE_NUM];
	double psrr[SITE_NUM];
	double TempDiode[SITE_NUM];
	double TempSensor[SITE_NUM];
	double TempLsi[SITE_NUM];
	C_All_Open;
	C_FXVI_ACM_GND_Connect;
	//C_AGS_BSG_PG_POSG_GND_Connect;
	all_resource_off();
	check_chip(chip);
	//C_ACM_FB1_Connect;
	//set_fb(4.0);
	//set_quc(3.3);

	//LSI_Read_Temp(TempLsi);
	//LSI_Read_EEP(data);

	Get_HW_Temp(true, false, TempDiode, TempSensor);
	Check_LSI_Exist(has_lsi, res);
	Check_LDO_Vout(vldo);
	//Check_DFI_Gain(gain);
	//Check_LSI_Gain(gain1, gain2, gain3, gain4);
	//Check_LSI_DutIn(2.0, ampdrvi, ampdrvac, ampdrvdc, ampdutsi, ampdutac, ampdutdc);
	//Check_DDS_DIV(clk, vmax, vmin);


	////PSRR_TEST(K_LSI_DUTI_VST, K_LSI_DUTO_QST, psrr);
	//DWORD dwDataArray[SITE_NUM];
	////AT24C_Connect();
	////AT24C_Read(0x00, dwDataArray);
	////AT24C_DisConnect();

	////LSI_Read_EEP(data);
	////LSI_Read_EEP(data);
	LSI_Read_Temp(TempLsi);
	//LSI_DisConnect();
	
	//
	//set_quc(false);
	//set_fb(false);
	//C_ACM_FB1_DisConnect;

	double os1[SITE_NUM];
	double os2[SITE_NUM];
	double os3[SITE_NUM];
	C_FXVI_ACM_GND_Connect;
	cbitclose(K206,K207,K208,K209);
	delay_ms(2);
	test_qtx_qvr_resource_os(5.0, os1, os2, os3);
	cbitopen(K206,K207,K208,K209);
	//delay_ms(2);
	//C_FXVI_ACM_GND_DisConnect;
	//C_AGS_BSG_PG_GND_DisConnect;
	C_All_Open;
	//all_resource_off();

	Ms_LogData(funcindex, "Part_No", PART_NUM());
	Ms_LogData(funcindex, "Part_No_Check", chip);
	Ms_LogData(funcindex, "Part_Ver", PART_VER());
	Ms_LogData(funcindex, "Pin_Cnt", PIN_CNT());
	Ms_LogData(funcindex, "Prog_Ver", PROG_VER());
	Ms_LogData(funcindex, "Die_Ver", DIE_VER());
	Ms_LogData(funcindex, "Flow_FT", !FLOW_CP);
	Ms_LogData(funcindex, "Stage", test_stage);
	Ms_LogData(funcindex, "Trim_Flag", DO_TRIM);
	Ms_LogData(funcindex, "Char_Flag", DO_CHAR);
	Ms_LogData(funcindex, "QC_Flag", QC);
	Ms_LogData(funcindex, "Eng_Flag", PART_ENG());
	Ms_LogData(funcindex, "Wafer_ID", wafer_id);
	Ms_LogData(funcindex, "SPI_CLK", SPI_CLK/1000000.0);
	Ms_LogData(funcindex, "LSI", has_lsi);
	Ms_LogData(funcindex, "RES", res);
	//Ms_LogData(funcindex, "DFI", gain);
	Ms_LogData(funcindex, "LDO", vldo);
	//Ms_LogData(funcindex, "DDS", clk);
	//Ms_LogData(funcindex, "DIV0", vmin);
	//Ms_LogData(funcindex, "DIV255", vmax);
	//Ms_LogData(funcindex, "Gain1", gain1);
	//Ms_LogData(funcindex, "Gain2", gain2);
	//Ms_LogData(funcindex, "Gain3", gain3);
	//Ms_LogData(funcindex, "Gain4", gain4);
	//Ms_LogData(funcindex, "AmpDrvAc", ampdrvac);
	//Ms_LogData(funcindex, "AmpDrvDc", ampdrvdc);
	//Ms_LogData(funcindex, "AmpOutAc", ampdutac);
	//Ms_LogData(funcindex, "AmpOutDc", ampdutdc);
	Ms_LogData(funcindex, "Qt1_Qvr_Err", qt1_qvr_err);
	Ms_LogData(funcindex, "Qt2_Qvr_Err", qt2_qvr_err);
	Ms_LogData(funcindex, "Qt3_Qvr_Err", qt3_qvr_err);
	Ms_LogData(funcindex, "HW_Temp", TempDiode);
	//Ms_LogData(funcindex, "HW_Temp", TempSensor);
	Ms_LogData(funcindex, "LSI_Temp", TempLsi);

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T01_Debug(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here

	return true;

	int reg[64][SITE_NUM];
	int reg0[SITE_NUM];
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int reg3[SITE_NUM];
	int reg4[SITE_NUM];
	int reg5[SITE_NUM];
	int reg6[SITE_NUM];
	int reg7[SITE_NUM];
	int reg8[SITE_NUM];
	int reg9[SITE_NUM];
	int reg10[SITE_NUM];
	int reg11[SITE_NUM];
	int reg12[SITE_NUM];
	int reg13[SITE_NUM];
	int reg14[SITE_NUM];
	int reg15[SITE_NUM];

	double psrr[SITE_NUM];
	int in_tm[SITE_NUM];
	int bank0[SITE_NUM];
	int bank1[SITE_NUM];
	unsigned __int64 TMSel[SITE_NUM];
	int SPI_Speed = 0;

	double Value = -1.0 mA;
	double res_sck[SITE_NUM];
	double res_sdo[SITE_NUM];
	double res_sdi[SITE_NUM];
	double res_cs[SITE_NUM];
	double res_err[SITE_NUM];

	C_All_Open;
	dcm.Connect("DCM_ALL");
	delay_ms(1);
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;

	if(1)
	{
		C_DCM_ERR_Connect;
		delay_ms(1);
		dcm.SetPPMU("D_SCK", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//
		dcm.SetPPMU("D_SDO", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//
		dcm.SetPPMU("D_SDI", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//
		dcm.SetPPMU("D_CS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//
		dcm.SetPPMU("DCM4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);//

		dcm.SetPPMU("D_SCK", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		dcm.SetPPMU("D_SDO", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		dcm.SetPPMU("D_SDI", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		dcm.SetPPMU("D_CS", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		dcm.SetPPMU("DCM4", DCM_PPMU_FIMV, Value, DCM_PPMUIRANGE_32MA);
		delay_ms(1);
		dcm.PPMUMeasure("D_SCK", 10, 10);
		dcm.PPMUMeasure("D_SDO", 10, 10);
		dcm.PPMUMeasure("D_SDI", 10, 10);
		dcm.PPMUMeasure("D_CS", 10, 10);
		dcm.PPMUMeasure("DCM4", 10, 10);
		SERIAL
		{
			res_sck[SITE]=dcm.GetPPMUMeasResult("D_SCK", SITE);
			res_sdo[SITE]=dcm.GetPPMUMeasResult("D_SDO", SITE);
			res_sdi[SITE]=dcm.GetPPMUMeasResult("D_SDI", SITE);
			res_cs[SITE]=dcm.GetPPMUMeasResult("D_CS", SITE);
			res_err[SITE]=dcm.GetPPMUMeasResult("DCM4", SITE);
		}
		dcm.SetPPMU("D_SCK", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D_SDO", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D_SDI", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D_CS", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("DCM4", DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);

		dcm.SetPPMU("D_SCK", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D_SDO", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D_SDI", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("D_CS", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		dcm.SetPPMU("DCM4", DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_2MA);
		C_DCM_ERR_DisConnect;
		delay_ms(1);
		Ms_LogData(funcindex, "Conty_SCS", res_cs);
		Ms_LogData(funcindex, "Conty_SCK", res_sck);
		Ms_LogData(funcindex, "Conty_SDI", res_sdi);
		Ms_LogData(funcindex, "Conty_SDO", res_sdo);
		Ms_LogData(funcindex, "Conty_ERR", res_err);
	}

	if (0)
	{
		BYTE AT24C = 0xA4;
		DWORD Reg = 0x00;
		DWORD data[SITE_NUM] = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 };
		DWORD rdata[SITE_NUM];
		int tmp = 0xAA;
		AT24C_Connect();
		//AT24C_Write(Reg, 1, data);
		AT24C_Read(Reg, rdata);
		AT24C_DisConnect();
	}

	if (1)
	{
		//all_resource_off();
		C_All_Open;
		delay_ms(2);
		Poweron_tm();

		SPI_Speed = 25 MHz;
		DUT_SPI_Connect(4.0);
		Cmd_Set_Freq(SPI_Speed);
		Ms_LogData(funcindex, "SPI", SPI_Speed / 1000000);

		Cmd_TestMode(true,in_tm);
		Cmd_Bank0();
		Cmd_BankCheck(bank0);
		Cmd_Bank1();
		Cmd_BankCheck(bank1);
		Cmd_Masksafe();
		CmdReadData(0x31,reg0);
		Cmd_SpeedupMode(true);
		CmdReadData(0x22, reg1);
		Cmd_SpeedupMode(false);
		CmdReadData(0x22, reg2);
		Cmd_Forceoff(except_quc);
		Cmd_ForceoffCheck(reg3);
		//Cmd_TMSel(0x02);
		//Cmd_TMSelCheck(TMSel);
		//SERIAL reg4[SITE] = TMSel[SITE];
		//Cmd_Dmuxset_Main(0x01);
		//Cmd_Dmuxset_MainRead(reg5);
		//Cmd_Dmuxset_Fs0(0x01);
		//Cmd_Dmuxset_Fs0Read(reg6);
		//Cmd_Dmuxset_Fs1(0x01);
		//Cmd_Dmuxset_Fs1Read(reg7);
		Ms_LogData(funcindex, "TM", in_tm);
		Ms_LogData(funcindex, "BANK0", bank0);
		Ms_LogData(funcindex, "BANK1", bank1);
		Ms_LogData(funcindex, "MaskSafe", reg0);
		Ms_LogData(funcindex, "SpeedUp", reg1);
		Ms_LogData(funcindex, "ForceOff", reg3);
		//Ms_LogData(funcindex, "TMSel", reg4);
		//Ms_LogData(funcindex, "DmuxMain", reg5);
		//Ms_LogData(funcindex, "DmuxFs0", reg6);
		//Ms_LogData(funcindex, "DmuxFs1", reg7);

		//Test Reg
		Cmd_Bank1();
		for (int i = 0; i < 58; i++)
		{
			CmdReadData(i, reg[i]);
		}
		for (int i = 0; i < 58; i++)
		{
			Copy_Array(reg0, reg[i]);
			string Parm = "TREG" + to_string(i);
			//Ms_LogData(funcindex, Parm, reg0);
		}
		////User Reg
		//Cmd_Bank0();
		////Cmd_Unlock();
		//for (int i = 0; i < 64; i++)
		//{
		//	CmdReadData(i, reg[i]);
		//}
		////Cmd_Lock();
		//for (int i = 0; i < 64; i++)
		//{
		//	Copy_Array(reg0, reg[i]);
		//	string Parm = "REG" + to_string(i);
		//	Ms_LogData(funcindex, Parm, reg0);
		//}

		double maxspeed[SITE_NUM];
		check_max_speed(maxspeed);
		Ms_LogData(funcindex, "MaxSpeed", maxspeed);

		Poweroff_tm();
	}

	if(0)
	{
		int reg1[SITE_NUM];
		int reg2[SITE_NUM];
		int reg3[SITE_NUM];

		C_All_Open;
		Poweron_nor();

		//PSRR_TEST(K_LSI_DUTI_VST, K_LSI_DUTO_QST, psrr);

		//double TempDiode[SITE_NUM];
		//double TempSensor[SITE_NUM];
		//Get_HW_Temp(true, true, TempDiode, TempSensor);
		SPI_Speed = 10 MHz;
		DUT_SPI_Connect(4.0);
		Cmd_Set_Freq(SPI_Speed);
		Ms_LogData(funcindex, "SPI", SPI_Speed/1000000);
		Cmd_Bank0();
		//Cmd_Dis_WwdFwdErrm();
		//Cmd_Dis_ERR_WD();
		delay_ms(1);
		Cmd_ReadState(reg0);//1
		delay_ms(1);
		//Cmd_Go2_Normal();
		delay_ms(1);
		Cmd_ReadState(reg1);//2
		delay_ms(1);

		////Cmd_Dis_WwdFwdErrm();
		////Cmd_Forceoff(all_off);
		////Cmd_Masksafe();
		////Cmd_Unlock();
		////CmdWriteData(0, 207);
		//CmdWriteData(0x12, 0x55);//85
		//CmdWriteData(0x13, 0xAA);//170
		//CmdWriteData(0x14, 0x80);//128
		//CmdReadData(0x12, reg1);
		//CmdReadData(0x13, reg2);
		//CmdReadData(0x14, reg3);
		//Cmd_Bank0();
		//for(int i=0;i<64;i++)
		//{
		//	CmdReadData(i, reg[i]);
		//}
		////Cmd_Lock();
		//for(int i=0;i<64;i++)
		//{
		//	Copy_Array(reg0,reg[i]);
		//	string Parm = "REG" + to_string(i);
		//	Ms_LogData(funcindex, Parm, reg0);
		//}
		Poweroff_nor();
	}

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T09_Contact(short funcindex, LPCTSTR funclabel)
{
	double result[SITE_NUM];
	double highRes[SITE_NUM];
	double lowRes[SITE_NUM];
	//
	C_ACML_GND_Connect;
	C_FXVIL_GND_Connect;
	C_FPVIL_AG_Connect;
	delay_ms(2);
	Test_Contact_L(acm0, lowRes);
	Ms_LogData(funcindex, "CT_ACML", lowRes);
	Test_Contact_L(fxvi0, lowRes);
	Ms_LogData(funcindex, "CT_FXVIL", lowRes);
	Test_Contact_L(fpvi0, result);
	Ms_LogData(funcindex, "CT_FPVIL", result);
	F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	C_FPVIL_AG_DisConnect;
	delay_ms(1);
	C_FPVIL_BSG_Connect;
	delay_ms(2);
	Test_Contact_L(fpvi0, result);
	Ms_LogData(funcindex, "CT_BSG", result);
	C_FPVIL_BSG_DisConnect;
	delay_ms(1);
	C_FPVIL_PG_Connect;
	delay_ms(2);
	Test_Contact_L(fpvi0, result);
	Ms_LogData(funcindex, "CT_PG1", result);
	C_FPVIL_PG_DisConnect;
	delay_ms(1);
	C_FPVIL_POSG_Connect;
	delay_ms(2);
	Test_Contact_L(fpvi0, result);
	Ms_LogData(funcindex, "CT_POSG", result);
	C_FPVIL_POSG_DisConnect;
	delay_ms(1);
	Test_Contact_L(F_VST, highRes);
	Ms_LogData(funcindex, "CT_VST", highRes);
	F_VS1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	Test_Contact(F_VS1, highRes);
	Ms_LogData(funcindex, "CT_VS1", highRes);
	C_FXVI_RSH_Connect;
	delay_ms(2);
	Test_Contact(F_RSH, highRes);
	Ms_LogData(funcindex, "CT_RSH", highRes);
	C_FXVI_RSH_DisConnect;
	delay_ms(1);
	C_FXVI_RSL_Connect;
	delay_ms(2);
	Test_Contact(F_RSL, highRes);
	Ms_LogData(funcindex, "CT_RSL", highRes);
	C_FXVI_RSL_DisConnect;
	delay_ms(1);
	C_ACM_VCI_Connect;
	delay_ms(2);
	Test_Contact(A_VCI, highRes);
	Ms_LogData(funcindex, "CT_VCIVMON", highRes);
	C_ACM_VCI_DisConnect;
	delay_ms(1);
	C_ACM_SEC_Connect;
	delay_ms(2);
	Test_Contact(A_SEC, highRes);
	Ms_LogData(funcindex, "CT_SECAMUX", highRes);
	C_ACM_SEC_DisConnect;
	delay_ms(1);
	C_ACM_EVC_Connect;
	delay_ms(2);
	Test_Contact(A_EVC, highRes);
	Ms_LogData(funcindex, "CT_EVCPOSFRE", highRes);
	C_ACM_EVC_DisConnect;
	delay_ms(1);
	C_ACM_STU_Connect;
	delay_ms(2);
	Test_Contact(A_STU, highRes);
	Ms_LogData(funcindex, "CT_STU", highRes);
	C_ACM_STU_DisConnect;
	delay_ms(1);
	Test_Contact(A_QST, highRes);
	Ms_LogData(funcindex, "CT_QST", highRes);
	C_FXVI_SW_Connect;
	delay_ms(2);
	Test_Contact(F_SW, highRes);
	Ms_LogData(funcindex, "CT_SW1", highRes);
	C_FXVI_SW_DisConnect;
	delay_ms(1);
	C_FXVI_FB_Connect;
	delay_ms(2);
	Test_Contact(F_FB, highRes);
	Ms_LogData(funcindex, "CT_FB1", highRes);
	C_FXVI_FB_DisConnect;
	delay_ms(1);
	Test_Contact(A_POSIN, highRes);
	Ms_LogData(funcindex, "CT_POSIN", highRes);
	Test_Contact(A_POSSW, highRes);
	Ms_LogData(funcindex, "CT_POSSW", highRes);
	Test_Contact(A_POSFB, highRes);
	Ms_LogData(funcindex, "CT_POSFB", highRes);
	Test_Contact(A_QUC, highRes);
	Ms_LogData(funcindex, "CT_QUC", highRes);
	Test_Contact(A_QVR, highRes);
	Ms_LogData(funcindex, "CT_QVR", highRes);
	Test_Contact(A_QCO, highRes);
	Ms_LogData(funcindex, "CT_QCO", highRes);
	Test_Contact(F_QT1, highRes);
	Ms_LogData(funcindex, "CT_QT1", highRes);
	Test_Contact(F_QT2, highRes);
	Ms_LogData(funcindex, "CT_QT2", highRes);
	Test_Contact(F_QT3, highRes);
	Ms_LogData(funcindex, "CT_QT3", highRes);

	C_All_Open;
	all_resource_off();
	//efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T10_OS_Pre(short funcindex, LPCTSTR funclabel)
{
	double result_os[PIN_Count][SITE_NUM] = { 0 };
	//
	conty_test(result_os);
	conty_getdata(result_os);
	conty_datalog(funcindex, true);

	//double results1[SITE_NUM];
	//C_FXVI_ACM_GND_Connect;
	//C_AGS_BSG_PG_POSG_GND_Connect;
	//C_FXVI_SW_Connect;
	//delay_ms(2);
	//F_SW.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//fxvi4.Set(FI, -1 mA, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(2);
	//fxvi4.MeasureVI(20, 10);
	//Get_Result(fxvi4, results1, MVRET);
	//Ms_LogData(funcindex, "OS_SW_VS1", results1);
	//fxvi4.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_SW.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	//fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	//C_FXVI_ACM_GND_DisConnect;
	//C_AGS_BSG_PG_POSG_GND_DisConnect;
	//C_FXVI_SW_DisConnect;
	//delay_ms(2);

	//efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T11_P2P_Pre(short funcindex, LPCTSTR funclabel)
{
	double result_lvl[PIN_Count][SITE_NUM] = { 0 };

	lvl_test(result_lvl, true);
	lvl_getdata(result_lvl);
	lvl_datalog(funcindex, true);

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T20_NVM_Read0(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	//int reg[64][SITE_NUM];
	//int reg0[SITE_NUM];
	C_All_Open;
	dcm.Connect("SPI_DUT");//Connect all channel's relay
	dcm.InitMCU("SPI_DUT");//Initialize MCU.

	//C_ACM_SEC_Connect;
	//C_ACM_STU_Connect;
	//C_FRE_PD_Connect;
	//A_SEC.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//A_STU.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(2);

	Poweron_tm();
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	//set_vsx(6.0);
	//set_fb_plus_target(0.2);
	//Nvm_PreviewFs(-1);
	//Nvm_Preview(-1);

	//User Reg
	User_Read(funcindex, false);


	//read otp
	NVM_Read0();

	//datalog
	NVM_Read0_datalog(funcindex);

	Poweroff_tm();

	//A_SEC.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	//A_STU.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	//C_ACM_SEC_DisConnect;
	//C_ACM_STU_DisConnect;
	//C_FRE_PD_DisConnect;

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T21_Trim_REF(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	double results[SITE_NUM];
	double Vqst[SITE_NUM];
	double Vqvr[SITE_NUM];
	double Vqco[SITE_NUM];
	double Vquc[SITE_NUM];
	double Vqt1[SITE_NUM];
	double Vqt2[SITE_NUM];
	double Vqt3[SITE_NUM];
	double Vqt1_os[SITE_NUM];
	double Vqt2_os[SITE_NUM];
	double Vqt3_os[SITE_NUM];
	unsigned __int64 tm_data = 0;

	C_All_Open;
	all_resource_off();
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	//A_AMUX.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	A_ABUFO.Set(FI, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	C_ACM_STU_Connect;
	C_ACM_ABUFO_Connect;
	//C_ACM_AMUX_Connect;
	C_ABUFI_STU;
	C_ABUF_Usage;

	Poweron_tm();
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Dis_WwdFwdErrm();
	Cmd_Forceoff(all_off);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	Cmd_Bank0(true);
	Cmd_AmuxEn_Stb(true,true,true);
	Cmd_AmuxSel(AMUX_BGAmux);
	set_stu(1.2);
	delay_ms(1);
	
	//bg1_ref,bg1_tc
	//bit 47, bit 62 set 1
	//tm_data = 0x0010001000080121;
	//tm_data = tm_data | 0x4000800000000000;
	//Cmd_TMSel(0x4011800000800121);
	//unsigned __int64 TMSeldata[SITE_NUM];
	//Cmd_TMSelCheck(TMSeldata);
	//A_AMUX.MeasureVI(1000,10);
	//tm_data = 0x4011801000080121;
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(1);
	Cmd_Bank1(true);
	Cmd_TMSel(0x4011801000080121);
	int bg1tc_code_ini[SITE_NUM];
	SERIAL bg1tc_code_ini[SITE]=dut.trim("bg1_tc").get_working(SITE);
	int bg1_tc_hcode = 0;
	if(DIE_VER()==0){bg1_tc_hcode = 3;}
	else{bg1_tc_hcode = 0;}
	//dut.trim("bg1_ref").execute(measure_bg1_ref, spec, funcindex, funclabel, 1, treg_log_mode, "bg1_ref");//1.0 V
	if(DO_CHAR)
	{
		dut.trim("bg1_tc").execute(measure_bg1_tc, spec, funcindex, funclabel, 1, treg_log_mode, "bg1_tc");//1.0 V
		SERIAL if(trimed_ftb0[SITE] == 0){dut.trim("bg1_tc").set_working(bg1_tc_hcode,SITE);}//if fresh, reset code to 3
	}
	//SERIAL dut.trim("bg1_tc").set_working(bg1_tc_hcode,SITE);
	Nvm_Preview(1);
	delay_ms(1);
	A_ABUFO.MeasureVI(10, 10);
	Get_Result(A_ABUFO, results, MVRET);
	Ms_LogData(funcindex, "bg1_tc_hardcode", bg1_tc_hcode);
	Ms_LogData(funcindex, "bg1_tc_hardvalue", results);
	dut.trim("bg1_ref").execute(measure_bg1_ref, spec, funcindex, funclabel, 1, treg_log_mode, "bg1_ref");//1.0 V

	//bg2_ref,bg2_tc
	//tm_data = 0x0010000200080121;
	//tm_data = tm_data | 0x4000800000000000;
	//CmdWriteData(AMUX_SELECT,AMUX_BG2);
	//Cmd_TMSel(0x4010800000800121);
	//tm_data = 0x4011800200080121;
	Cmd_TMSel(0x4011800200080121);
	int bg2tc_code_ini[SITE_NUM];
	SERIAL bg2tc_code_ini[SITE]=dut.trim("bg2_tc").get_working(SITE);
	int bg2_tc_hcode = 0;
	if(DIE_VER()==0){bg2_tc_hcode = 3;}
	else{bg1_tc_hcode = 0;}
	if(DO_CHAR)
	{
		dut.trim("bg2_tc").execute(measure_bg2_tc, spec, funcindex, funclabel, 1, treg_log_mode, "bg2_tc");//1.0 V
		SERIAL if(trimed_ftb0[SITE] == 0){dut.trim("bg2_tc").set_working(bg2_tc_hcode,SITE);}//if fresh, reset code to 3
	}
	//SERIAL dut.trim("bg2_tc").set_working(bg2_tc_hcode,SITE);
	Nvm_Preview(4);
	delay_ms(1);
	A_ABUFO.MeasureVI(10, 10);
	Get_Result(A_ABUFO, results, MVRET);
	Ms_LogData(funcindex, "bg2_tc_hardcode", bg2_tc_hcode);
	Ms_LogData(funcindex, "bg2_tc_hardvalue", results);
	dut.trim("bg2_ref").execute(measure_bg2_ref, spec, funcindex, funclabel, 1, treg_log_mode, "bg2_ref");//1.0 V
	
	//vmon
	set_fb_plus_target(0.1);
	Cmd_TMSel(0x0011030000000041);
	dut.trim("vmon_buf").execute(measure_vmon_buf, spec, funcindex, funclabel, 1, treg_log_mode, "vmon_buf");//1.6V

	//quc
	set_vsx(6.0);
	set_posfb_plus_target(0.1);
	Cmd_TMSel(0x0011050000000001);
	dut.trim("quc_buf").execute(measure_quc_buf, spec, funcindex, funclabel, 1, treg_log_mode, "quc_buf");//1.655V

	set_fb(5.5);
	set_quc(5.0);
	//DUT_SPI_Connect(5.0);
	//Cmd_Set_Freq(10 MHz);
	//val12,dvdd12
	double Vval1[SITE_NUM];
	double Vval2[SITE_NUM];
	double Dvdd1[SITE_NUM];
	double Dvdd2[SITE_NUM];
	set_stu(3.0);
	//set_vsx(5.0);
	A_STU.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(1);
	Cmd_TMSel(0x0010002000800121);
	delay_ms(1);
	A_STU.MeasureVI(10,10);
	Get_Result(A_STU, Vval1, MVRET);
	Ms_LogData(funcindex, "Val1", Vval1);
	Cmd_TMSel(0x0010000400800121);
	delay_ms(1);
	A_STU.MeasureVI(10,10);
	Get_Result(A_STU, Vval2, MVRET);
	Ms_LogData(funcindex, "Val2", Vval2);
	Cmd_TMSel(0x0010007000800121);
	delay_ms(1);
	A_STU.MeasureVI(10,10);
	Get_Result(A_STU, Dvdd1, MVRET);
	Ms_LogData(funcindex, "Dvdd1", Dvdd1);
	Cmd_TMSel(0x0010000E00800121);
	delay_ms(1);
	A_STU.MeasureVI(10,10);
	Get_Result(A_STU, Dvdd2, MVRET);
	Ms_LogData(funcindex, "Dvdd2", Dvdd2);
	//delay_ms(2);

	//ldo_ibias
	Cmd_Forceoff(except_qst);
	Cmd_TMSel(0x0011020000000121);
	A_STU.Set(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(1);
	dut.trim("ldo_ibias").execute(measure_ldo_ibias, spec, funcindex, funclabel, 1, treg_log_mode, "ldo_ibias");//10 uA

	//dvdd1_ov_por
	double Vvs=0;
	double Vsec=0;
	double val[SITE_NUM];
	double val1[SITE_NUM];
	double val2[SITE_NUM];
	int find[SITE_NUM];
	int point[SITE_NUM];
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	C_ACM_SECPOSFRE_Connect;
	C_FRE_PU_Connect;
	C_DBUFI_FRE;
	C_ACM_DBUFO_Connect;
	Cmd_Forceoff(all_off);
	set_vsx(4.6);
	Cmd_Dmuxset_Main(7);
	set_sec_posfre(FV, 4.6, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	Cmd_TMSel(0x0140000000800101);
	ramp2vmv(fxvi4, A_SECPOSFRE, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, ACM200_10V, ACM200_100MA, "ramp_dvdd1_ov", 4.6, 8.0, 4.6, 8.0, 2.5, TRIG_RISING, val1, val2);
	Ms_LogData(funcindex, "DVDD1_OV", val2);
	set_sec_posfre(FV, 4.6, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	set_vsx(4.6);
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	Cmd_Dmuxset_Main(7);
	set_sec_posfre(FV, 4.5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	Cmd_TMSel(0x0140000000800101);
	ramp2vmv(fxvi4, A_SECPOSFRE, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, ACM200_10V, ACM200_100MA, "ramp_dvdd1_uv", 4.6, 0.1, 4.5, 0.0, 2.5, TRIG_RISING, val1, val2);
	Ms_LogData(funcindex, "DVDD1_POR", val2);

	C_ACM_SECPOSFRE_DisConnect;
	C_FRE_PU_DisConnect;
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);

	Cmd_TMSel(0x00);
	set_stu(false);
	//A_AMUX.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);
	C_ACM_STU_DisConnect;
	//C_ACM_AMUX_DisConnect;
	C_ACM_ABUFO_DisConnect;
	C_ABUFI_DisConnect;
	C_ABUF_Bypass;
	set_posfb(false);
	Poweroff_tm();
	delay_ms(1);

	int state[SITE_NUM];
	A_AMUX.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);//acm9
	C_ACM_AMUX_Connect;
	C_ACM_FB1_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3)F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	Poweron_tm_hc();
	set_fb_hc(5.5);
	set_quc(5.0);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Dis_WwdFwdErrm();
	//Cmd_Forceoff(none_off);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	Cmd_Dis_ERR_WD();
	Cmd_Bank0(true);
	Cmd_AmuxEn(true);
	Cmd_AmuxCfg(0x00);
	Cmd_AmuxSel(AMUX_Vqvr);
	Cmd_En_Trk();
	Cmd_En_Stb(true, true);
	//Cmd_Go2_Normal();
	Cmd_ReadState(state);
	//delay_ms(2);
	//qst
	set_vsx(6.0);
	//set_fb_plus_target_hc(0.1);
	//set_fb(5.5);
	set_posfb_plus_target(0.1);
	//set_posfb(1.5);
	double Val[SITE_NUM];
	A_AMUX.MeasureVI(10,10);
	Get_Result(A_AMUX, Val, MVRET);
	double iload1 = -0.1 mA;
	double iload2 = -1.0 mA;
	A_QUC.Set(FI, iload1, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_QST.Set(FI, iload1, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//A_QUC.Set(FI, iload, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, iload1, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, iload1, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, iload1, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, iload1, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3)F_QT3.Set(FI, iload1, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	//F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//if(PN_Tracker_Num==3)F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	Cmd_En_Stb(true, true);
	delay_ms(2);
	A_QST.Set(FI, iload2, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	dut.trim("qst_vref1").execute(measure_qst_vref1, spec, funcindex, funclabel, 1, treg_log_mode, "qst_vref1");//3.3V,5V

	Cmd_En_Stb(true, false);
	int qst_os = dut.sel("QSTOS_DIS").get_working(0);
	Cmd_Bank1(true);
	dut.sel("QSTOS_DIS").set_working(0);
	Nvm_PreviewFs(0);
	A_QST.Set(FI, -10 mA, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(3);
	A_QST.Set(FI, iload2, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(1);
	dut.trim("qst_vref2").execute(measure_qst_vref2, spec, funcindex, funclabel, 1, treg_log_mode, "qst_vref2");//270mV,180mV
	Cmd_Bank1(true);
	dut.sel("QSTOS_DIS").set_working(qst_os);
	Nvm_PreviewFs(0);

	dut.trim("qst_oc").execute(measure_qst_oc, spec, funcindex, funclabel, 1, treg_log_mode, "qst_oc");//40mA
	A_QST.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//qvr
	A_QVR.Set(FI, iload2, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	dut.trim("qvr_vref").execute(measure_qvr_vref, spec, funcindex, funclabel, 1, treg_log_mode, "qvr_vref");//3.3V,5V
	A_QVR.Set(FI, iload1, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//qco
	A_QCO.Set(FI, iload2, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	dut.trim("qco_ea").execute(measure_qco_ea, spec, funcindex, funclabel, 1, treg_log_mode, "qco_ea");//1.8,3.3,5
	A_QCO.Set(FI, iload1, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//qtx
	if(dut.sel("QT1_VOUT").get_working(0)==0){dut.trim("qt1_vref").table_char_active();}
	F_QT1.Set(FI, iload2, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	dut.trim("qt1_vref").execute(measure_qt1_vref, spec, funcindex, funclabel, 1, treg_log_mode, "qt1_vref");//qvr,1.8,3.3,5
	F_QT1.Set(FI, iload1, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	if(dut.sel("QT2_VOUT").get_working(0)==0){dut.trim("qt2_vref").table_char_active();}
	F_QT2.Set(FI, iload2, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	dut.trim("qt2_vref").execute(measure_qt2_vref, spec, funcindex, funclabel, 1, treg_log_mode, "qt2_vref");//qvr,1.8,3.3,5
	F_QT2.Set(FI, iload1, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3) 
	{
		if(dut.sel("QT3_VOUT").get_working(0)==0){dut.trim("qt3_vref").table_char_active();}
		F_QT3.Set(FI, iload2, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		dut.trim("qt3_vref").execute(measure_qt3_vref, spec, funcindex, funclabel, 1, treg_log_mode, "qt3_vref");//qvr,1.8,3.3,5
		F_QT3.Set(FI, iload1, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	}

	A_QUC.MeasureVI(10, 10);
	Get_Result(A_QUC, Vquc, MVRET);
	//if(PN_Tracker_Num==3)F_QT3.MeasureVI(10, 10);
	//if(PN_Tracker_Num==3)Get_Result(F_QT3, Vqt3, MVRET);

	SERIAL Vqst[SITE] = dut.trim("qst_vref1").get_post_reading(SITE);
	SERIAL Vqvr[SITE] = dut.trim("qvr_vref").get_post_reading(SITE);
	SERIAL Vqco[SITE] = dut.trim("qco_ea").get_post_reading(SITE);
	SERIAL Vqt1[SITE] = dut.trim("qt1_vref").get_post_reading(SITE);
	SERIAL Vqt2[SITE] = dut.trim("qt2_vref").get_post_reading(SITE);
	if(PN_Tracker_Num==3)SERIAL Vqt3[SITE] = dut.trim("qt3_vref").get_post_reading(SITE);

	if(PN_QST_Output==3.3){Ms_LogData(funcindex, "qst_out1", Vqst);}
	if(PN_QST_Output==5.0){Ms_LogData(funcindex, "qst_out2", Vqst);}
	if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "qvr_out1", Vqvr);}
	if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "qvr_out2", Vqvr);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "quc_out1", Vquc);}
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "quc_out2", Vquc);}
	if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "qco_out1", Vqco);}
	if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "qco_out2", Vqco);}
	if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "qco_out3", Vqco);}
	if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "qt1_out1", Vqt1);}
	if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "qt1_out2", Vqt1);}
	if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "qt1_out3", Vqt1);}
	if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "qt2_out1", Vqt2);}
	if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "qt2_out2", Vqt2);}
	if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "qt2_out3", Vqt2);}
	if((PN_Tracker_Num==3)&&(PN_QT3_Output==1.8)){Ms_LogData(funcindex, "qt3_out1", Vqt3);}
	if((PN_Tracker_Num==3)&&(PN_QT3_Output==3.3)){Ms_LogData(funcindex, "qt3_out2", Vqt3);}
	if((PN_Tracker_Num==3)&&(PN_QT3_Output==5.0)){Ms_LogData(funcindex, "qt3_out3", Vqt3);}

	SERIAL Vqt1_os[SITE]=(Vqt1[SITE]-PN_QVR_Output_Target)*1000.0;
	SERIAL Vqt2_os[SITE]=(Vqt2[SITE]-PN_QVR_Output_Target)*1000.0;
	SERIAL Vqt3_os[SITE]=(Vqt3[SITE]-PN_QVR_Output_Target)*1000.0;
	if(dut.sel("QT1_VOUT").get_working(0)==0){Ms_LogData(funcindex, "qt1_os", Vqt1_os);}
	if(dut.sel("QT2_VOUT").get_working(0)==0){Ms_LogData(funcindex, "qt2_os", Vqt2_os);}
	if((PN_Tracker_Num==3)&&(dut.sel("QT3_VOUT").get_working(0)==0)){Ms_LogData(funcindex, "qt3_os", Vqt3_os);}

	//A_QST.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//A_QUC.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//A_QVR.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//A_QCO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//if(PN_Tracker_Num==3)F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);

	//double target = dut.trim("ldo_ibias").get_target(0);


	//dvdd1_ov_por
	//double val[SITE_NUM];
	//int find[SITE_NUM];
	//int point[SITE_NUM];
	set_quc(5.0);
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	C_ACM_SECPOSFRE_Connect;
	C_FRE_PU_Connect;
	C_DBUFI_FRE;
	C_ACM_DBUFO_Connect;
	Cmd_Forceoff(all_off);
	set_vsx(4.6);
	Cmd_Dmuxset_Main(7);
	set_sec_posfre(FV, 4.6, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	Cmd_TMSel(0x00C0000000800101);
	ramp2vmv(fxvi4, A_SECPOSFRE, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, ACM200_10V, ACM200_100MA, "ramp_dvdd2_ov", 4.6, 8.0, 4.6, 8.0, 2.5, TRIG_RISING, val1, val2);
	Ms_LogData(funcindex, "DVDD2_OV", val2);
	set_sec_posfre(FV, 4.6, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	set_vsx(4.6);
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	Cmd_Dmuxset_Main(7);
	set_sec_posfre(FV, 4.5, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	Cmd_TMSel(0x00C0000000800101);
	ramp2vmv(fxvi4, A_SECPOSFRE, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, ACM200_10V, ACM200_100MA, "ramp_dvdd2_uv", 4.6, 0.1, 4.5, 0.0, 2.5, TRIG_RISING, val1, val2);
	Ms_LogData(funcindex, "DVDD2_POR", val2);

	C_ACM_SECPOSFRE_DisConnect;
	C_FRE_PU_DisConnect;
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//acm10
	set_sec_posfre(FV, 4.6, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	set_posfb(false);

	A_AMUX.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);//acm9
	C_ACM_AMUX_DisConnect;

	C_ACM_FB1_DisConnect;
	C_QUC_SQUC_DisConnect;
	C_QT1_SQT1_DisConnect;
	C_QT2_SQT2_DisConnect;
	A_QST.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QUC.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QVR.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QCO.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	F_QT1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	F_QT2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	Poweroff_tm_hc();
	//crc_opt = NVM_OPTION_CACL_TREG();
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T22_Trim_OSC(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	all_resource_off();
	C_All_Open;

	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];

	DDS_Connect();
	DDS_Initial();
	DDS_SetFreq(100 KHz);

	//C_FRE_PU_Connect;
	//C_DCM_FRE_Connect;//dcm7
	//C_DCM_ERR_Connect;//dcm4
	C_DCM_SECPOSFRE_Connect;//dcm7,dcm6
	C_ACM_SECPOSFRE_Connect;
	//C_DCM_DBUFO_Connect;//dcm5
	C_DDS_ERR_Connect;
	
	Poweron_tm();
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Dis_WwdFwdErrm();
	Cmd_Forceoff(all_off);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	//dut.sel("ERR_FREQ").set_working(0);
	//Nvm_PreviewFs(4);
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//C_FRE_PU_Connect;
	//C_DCM_FRE_Connect;//dcm7
	//delay_ms(1);
	//A_SECPOSFRE.MeasureVI(1000,10);
	//lfo12 100k
	//Cmd_Dmuxset_Main(2);
	//Cmd_TMSel(0x0048000000800121);
	//delay_ms(2);
	////A_DBUFO.MeasureVI(1000, 10);
	//measure_freq_duty_set("DCM7",5.0);
	//dut.trim("lfo12").execute(measure_lfo12_100k, spec, funcindex, funclabel, 1, treg_log_mode, "lfo12");//100KHz
	Cmd_Dmuxset_Fs0(3);
	Cmd_TMSel(0x0048000000800121);
	if(DIE_VER()==0)
	{
		if(PN_SEC_Available){measure_freq_duty_set("DCM7",5.0);dcm.SetTMUParam("DCM7", DCM_POS, 4, 0);}
		else {measure_freq_duty_set("DCM6",5.0);dcm.SetTMUParam("DCM6", DCM_POS, 4, 0);}
		dut.trim("lfo12").execute(measure_lfo12, spec, funcindex, funclabel, 1, treg_log_mode, "lfo12");//200KHz
	}
	else
	{
		if(PN_SEC_Available){measure_freq_duty_set("DCM7",5.0);dcm.SetTMUParam("DCM7", DCM_POS, 10, 0);}
		else {measure_freq_duty_set("DCM6",5.0);dcm.SetTMUParam("DCM6", DCM_POS, 10, 0);}
		dut.trim("lfo2").execute(measure_lfo2, spec, funcindex, funclabel, 1, treg_log_mode, "lfo2");//200KHz
	}
	//hfo12
	Cmd_Dmuxset_Fs0(5);
	Cmd_TMSel(0x0048000000800121);
	//if(PN_SEC_Available){measure_freq_duty_set("DCM7",1.2);}
	//else {measure_freq_duty_set("DCM6",1.2);}
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	if(PN_SEC_Available){measure_freq_duty_set("DCM7",5.0);dcm.SetTMUParam("DCM7", DCM_POS, 4, 0);}
	else {measure_freq_duty_set("DCM6",5.0);dcm.SetTMUParam("DCM6", DCM_POS, 4, 0);}
	dut.trim("hfo12").execute(measure_hfo12, spec, funcindex, funclabel, 1, treg_log_mode, "hfo12");//4MHz
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);

	//lfo12 100k
	C_DCM_SECPOSFRE_DisConnect;
	delay_ms(1);
	C_FRE_PU_Connect;
	C_DCM_FRE_Connect;//dcm7
	double results[SITE_NUM];
	Cmd_Dmuxset_Fs0(0);
	Cmd_Dmuxset_Main(2);
	Cmd_TMSel(0x0048000000800121);
	delay_ms(2);

	if(DIE_VER()==0)
	{
		//A_DBUFO.MeasureVI(1000, 10);
		measure_freq_duty_set("DCM7",5.0,DCM_HIGH);
		dcm.SetTMUParam("DCM7", DCM_POS, 30, 0);
		dcm.TMUMeasure("DCM7", DCM_MEAS_FREQ_DUTY, 50, 20);
		SERIAL { results[SITE] = dcm.GetTMUMeasureResult("DCM7", SITE, DCM_FREQ);}
		Ms_LogData(funcindex, "lfo12_100kHz", results);
	}
	else
	{
		measure_freq_duty_set("DCM7",5.0, DCM_HIGH);
		dcm.SetTMUParam("DCM7", DCM_POS, 30, 0);
		dcm.TMUMeasure("DCM7", DCM_MEAS_FREQ_DUTY, 100, 20);
		dut.trim("lfo1").execute(measure_lfo1, spec, funcindex, funclabel, 1, treg_log_mode, "lfo1");//100KHz
	}
	Cmd_Dmuxset_Main(0);
	

	set_vsx(6.0);
	//set_fb(5.5);
	//set_quc(5.0);
	//set_quc_target();
	set_sec_posfre(FV, 5.0,ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);

	//lfo12 checker
	//200K * 0.72 slow warning
	//200K * 1.55 fast warning
	//200K * 1.245 fast warning pre
	//Cmd_Dmuxset_Fs0(8);//slow
	//Cmd_TMSel(0x0048003000800121);//129
	//set_fb(5.5);
	//set_quc_target();
	Cmd_Dmuxset_Fs0(0);
	Cmd_TMSel(0);
	C_FXVI_WDI_Connect;
	delay_ms(1);
	F_WDI.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(5);
	C_FXVI_WDI_DisConnect;
	delay_ms(1);
	F_WDI.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	F_SS1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_SS1_Connect;
	delay_ms(1);
	int CHK_EN = dut.sel("OSC_CHK_EN").get_working(0);
	//Cmd_Dmuxset_Fs0(7);//fast
	//Cmd_TMSel(0x0048003000800121);
	//set_sec_posfre(FV, 3.3, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	int tempd[SITE_NUM];
	//set_fb(5.2);
	//set_quc(5.2);
	delay_ms(1);
	Cmd_Bank0(true);
	Cmd_Unlock();
	CmdWriteData(0x05, 0);
    CmdWriteData(0x06, 0);
	//CmdReadData(ASFCFG,data0);
	CmdWriteData(ASFCFG,0xFF);
	//CmdReadData(ASFCFG,data1);
	//Cmd_En_ERR(true, true);
	Cmd_Lock();
	//Cmd_ReadState(tempd);//1
	//Cmd_Dis_ERR_WD();
	//Cmd_En_ERR(true, true);
	Cmd_Go2_Normal();
	//Cmd_ReadState(tempd);//2
	//Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);

	Cmd_Bank1(true);
	//measure_freq_duty_set("DCM4",5.0);
	//dcm.SetTMUParam("DCM4", DCM_POS, 100, 0);
	Cmd_TMSel(0x0048003000800121);//129
	//if(!PN_SEC_Available){dut.trim("lfo_check").execute(measure_lfo_check, spec, funcindex, funclabel, 1, treg_log_mode, "lfo_check");}//200KHz
	//dut.trim("lfo_check").execute(measure_lfo_check, spec, funcindex, funclabel, 1, treg_log_mode, "lfo_check");//200KHz
	dut.trim("lfo_check").execute(measure_lfo_check_ss_onetime, spec, funcindex, funclabel, 1, treg_log_mode, "lfo_check");//200KHz
	//Cmd_Dmuxset_Fs0(7);//fast
	//Cmd_TMSel(0x0048000000800131);
	//delay_ms(2);
	//dut.trim("lfo_check").execute(measure_lfo_check, spec, funcindex, funclabel, 1, treg_log_mode, "lfo_check");//200KHz
	datalog_clk_chk(funcindex);
	//double target = dut.trim("hfo12").get_target(0);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	C_ACM_SECPOSFRE_DisConnect;
	C_FXVI_SS1_DisConnect;
	delay_ms(1);
	F_SS1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	Poweroff_tm();
	C_DCM_FRE_DisConnect;
	C_DCM_ERR_DisConnect;
	C_DCM_SECPOSFRE_DisConnect;
	C_DDS_ERR_DisConnect;
	C_DCM_DBUFO_DisConnect;
	C_FRE_PU_DisConnect;
	DDS_DisConnect();

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T23_Trim_BST(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	//double Idrg_src[SITE_NUM];
	//double Idrg_snk[SITE_NUM];
	//double rsh_current[SITE_NUM];
	//double rsl_current[SITE_NUM];

	use_lsi_dfi = true;
	//lsi_dfi_gain = 19.8;

	all_resource_off();
	C_All_Open;
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	F_RSL.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//A_STU.Set(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	C_ACM_STU_Connect;
	C_ACM_SECPOSFRE_Connect;
	//C_DBUFI_DRG;
	//C_DCM_DBUFO_Connect;//dcm5
	C_DCM_DRG_Connect;//dcm7
	C_FPVIH_RSH_Connect;
	C_FPVIL_RSL_Connect;
	if(use_lsi_dfi){cbitclose(K100);cbitclose(K133_134);}
	else{cbitclose(K101);}
	C_RSL_PD_Connect;
	//C_FXVI_RSL_Connect;
	//F_RSL.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	Poweron_tm();
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	Cmd_Forceoff(all_off);
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);

	double result[SITE_NUM];
	//C_FXVI_DRG_Connect;
	//delay_ms(2);
	//awg.rampvmvf(F_VST, fxvi5, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_Tss", 4, 6, 0.01, 20, 1.0, TRIG_RISING, result);

	//bst_pvdd
	//dut.sel("bst_pvdd").set_working(0);//
	//bst_osc
	set_vsx(6.0);

	//Cmd_Dmuxset_Fs0(254);
	//Cmd_TMSel(0x2608280000800100);
	Cmd_TMSel(0x0000280000000000);
	measure_freq_duty_set("DCM7", 5.0);//420KHz
	dcm.SetTMUParam("DCM7", DCM_POS, 100, 0);
	dut.trim("bst_osc").execute(measure_bst_osc, spec, funcindex, funclabel, 1, treg_log_mode, "bst_osc");//420kHz
	dcm.Disconnect("DCM7");
	set_vsx(8.0);
	set_fb_plus_target(-0.5);//target-0.5V

	//bst_gain
	//ramp rsh-rsl, monitor stu i
	//170mV/10K=17uA
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	Cmd_Dmuxset_Fs0(254);
	if(DIE_VER()==0) {Cmd_TMSel(0x0020200000800100);}
	else {Cmd_TMSel(0x0010200000800100);}
	set_vsx(8.0);
	set_fb_plus_target(-0.5);//target-0.5V
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	if(DIE_VER()==0)
	{
		A_STU.Set(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		dut.trim("bst_gain").set_working(0);//hard code trim for 1p0
	}
	else
	{
		A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
		dut.trim("bst_gain").execute(measure_bst_gain, spec, funcindex, funclabel, 1, treg_log_mode, "bst_gain");//4.5
	}
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	//bst_ilos
	Cmd_Dmuxset_Fs0(254);
	if(DIE_VER()==0) {Cmd_TMSel(0x0020200000800100);}
	else {Cmd_TMSel(0x0010200000800100);}
	set_vsx(8.0);
	fpvi0.MeasureVI(100,10);
	fpvi0.Set(FV, 0.0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	dut.trim("bst_ilos").execute(measure_bst_ilos, spec, funcindex, funclabel, 1, treg_log_mode, "bst_ilos");//1mV-10mV
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	
	//bst_minpk
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2608200000800100);
	set_vsx(8.0);
	set_fb_plus_target(-0.5);//target-0.5V
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	dut.trim("bst_minpk").execute(measure_bst_minpk, spec, funcindex, funclabel, 1, treg_log_mode, "bst_minpk");//20mV
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	//bst_maxpk
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2608200000800100);//TM30
	set_vsx(6.0);
	//fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	//dut.trim("bst_maxpk").execute(measure_bst_maxpk, spec, funcindex, funclabel, 1, treg_log_mode, "bst_maxpk");//170mV
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	//bst_ocp_stg_war
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2C08200000800100);//TM24,stg
	//Cmd_TMSel(0x2A08200000800100);//TM25,oc
	//set_vsx(4.0);
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	dut.trim("bst_ocp_stg_war").execute(measure_bst_ocp_stg_war, spec, funcindex, funclabel, 1, treg_log_mode, "bst_ocp_stg_war");//160mV
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	double ocp_post[SITE_NUM];
	Cmd_TMSel(0x2A08200000800100);//TM25,oc
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	double current = 0;
	double voltage = 0.5;
	if (use_lsi_dfi)
	{
		current = voltage / lsi_dfi_gain;
		double step = calc_step(0, current, 100);
		awg.rampimi(fpvi0, A_SECPOSFRE, FPVIe_5V, FPVIe_100MA, "bst_ocp_stg_war", 0, current, step, 20, 5 mA, TRIG_RISING, ocp_post);
		SERIAL ocp_post[SITE] = ocp_post[SITE] * lsi_dfi_gain;
	}
	else
	{
		double step = calc_step(0, voltage, 100);
		awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_1V, FPVIe_1MA, "bst_ocp_stg_war", 0, voltage, step, 20, 5 mA, TRIG_RISING, ocp_post);
	}
	SERIAL  ocp_post[SITE] = ocp_post[SITE] * 1000.0;
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	//bst_maxpk,lmtos
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2608200000800100);//TM30
	set_vsx(6.0);
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	dut.trim("bst_maxpk").execute(measure_bst_lmtos, spec, funcindex, funclabel, 1, treg_log_mode, "bst_maxpk");//170mV,20mV
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);

	
	double lmtos_post[SITE_NUM];
	SERIAL lmtos_post[SITE]=dut.trim("bst_maxpk").get_post_reading(SITE);//20
	double maxpk_post[SITE_NUM];
	SERIAL maxpk_post[SITE]=dut.trim("bst_maxpk").get_post_reading(SITE)+dut.trim("bst_ocp_stg_war").get_post_reading(SITE);//170
	double ocp_stg_post[SITE_NUM];
	SERIAL ocp_stg_post[SITE]=dut.trim("bst_ocp_stg_war").get_post_reading(SITE);//160

	Ms_LogData(funcindex, "bst_lmtos_post_new", lmtos_post);
	Ms_LogData(funcindex, "bst_ocp_war_post_new", ocp_post);
	Ms_LogData(funcindex, "bst_ocp_stg_war_post_new", ocp_stg_post);
	Ms_LogData(funcindex, "bst_maxpk_post_new", maxpk_post);

	//set_quc(4.5);
	//C_FXVI_INT_Connect;
	//double res[SITE_NUM];
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//F_INT.MeasureVI(100,10);
	//Cmd_Dmuxset_Fs0(71);
	//Cmd_TMSel(0x2A08280000800100);//TM26
	//F_INT.MeasureVI(100,10);
	current = 0;
	//fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	//if(use_lsi_dfi)
	//{
	//	current = 0.5/lsi_dfi_gain;
	//	double step = calc_step(0,current,100);
	//	awg.rampimi(fpvi0, A_SECPOSFRE, FPVIe_5V, FPVIe_100MA, "oc_digl", 0, current, step, 20, 5 mA, TRIG_RISING, res);
	//	SERIAL res[SITE]=res[SITE]*lsi_dfi_gain;
	//}
	//else
	//{
	//	double step = calc_step(0,0.5,100);
	//	awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_1V, FPVIe_1MA, "oc_digl", 0, 0.5, step, 20, 5 mA, TRIG_RISING, res);
	//}
	//fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	//C_FXVI_INT_DisConnect;
	//bst_ea
	//ramp vs1, monitor posfre
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	delay_ms(2);
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	if(use_lsi_dfi)
	{
		current = 0.1/lsi_dfi_gain;
		fpvi0.Set(FI, current, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	}
	else
	{
		fpvi0.Set(FV, 0.1, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	}
	//Cmd_Dmuxset_Fs0(254);
	//Cmd_TMSel(0x2608300000800100);
	//set_fb_plus_target(-0.5);//target-0.5V
	double vfb = PN_Prebk_Output;
	set_fb(4.5);
	set_vsx(8.5);
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2248200000800100);//meas bst uv
	dut.trim("bst_ea").execute(measure_bst_uv, spec, funcindex, funclabel, 1, treg_log_mode, "bst_ea");//8.25V
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2608300000800100);//meas bst ea
	dut.trim("bst_voutsel").execute(measure_bst_ea2, spec, funcindex, funclabel, 1, treg_log_mode, "bst_voutsel");//7.5V
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	delay_ms(2);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	set_stu(false);
	C_ACM_SECPOSFRE_DisConnect;
	C_ACM_STU_DisConnect;
	F_RSL.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	C_FPVIH_RSH_DisConnect;
	C_FPVIL_RSL_DisConnect;
	if(use_lsi_dfi){cbitopen(K100);cbitopen(K133_134);}
	else{cbitopen(K101);}
	C_DCM_DRG_DisConnect;
	C_RSL_PD_DisConnect;
	C_FXVI_RSL_DisConnect;
	F_RSL.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_OFF);
	Poweroff_tm();
	//C_All_Open;
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T24_Trim_PREBK(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	double freq[SITE_NUM];
	int tempd[SITE_NUM];
	int tempd1[SITE_NUM];
	int tempd2[SITE_NUM];
	int tempd3[SITE_NUM];
	int tempd4[SITE_NUM];
	int tempd5[SITE_NUM];
	int tempd6[SITE_NUM];
	int tempd7[SITE_NUM];
	int tempd8[SITE_NUM];
	int tempd9[SITE_NUM];
	int tempd10[SITE_NUM];

	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];

	double hsrdson_v[SITE_NUM];
	double hsrdson_r[SITE_NUM];
	double lsrdson_v[SITE_NUM];
	double lsrdson_r[SITE_NUM];

	double results[SITE_NUM];
	double value[SITE_NUM];

	C_All_Open;
	all_resource_off();
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	C_ACM_STU_Connect;
	//C_ACM_SECPOSFRE_Connect;

	//Prebk
	//F_VS2.Set(FI, 0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	C_FRE_PD_Connect;
	Poweron_tm_hc();
	//C_VST_VS1_DisConnect;
	//delay_ms(2);
	//C_FXVI_VS2_Connect;
	//F_VS2.Set(FV, 4, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	Cmd_Forceoff(except_dcdc);
	set_vsx(6.0);
	set_fb_hc(4.0);

	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	Cmd_ReadState(tempd);//1
	CmdWriteData(BCK_FRE_SPREAD,0x00);//no spsp
	CmdReadData(BCK_FRE_SPREAD,data0);

	//prebk_osc
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2248000000810100);//
	C_FRE_PD_DisConnect;
	delay_ms(2);
	C_FRE_PU_Connect;
	C_DBUFI_DisConnect;
	//C_DBUF_Usage;
	C_DBUFI_FRE;
	C_DCM_DBUFO_Connect;//dcm5
	Cmd_Bank0(true);
	Cmd_ReadState(tempd);
	//measure_freq_duty_set("DCM5",4.0, DCM_HIGH_IMPEDANCE);//420KHz
	measure_freq_duty_set("DCM5",1.0, DCM_HIGH_IMPEDANCE);//2.1MHz
	dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
	dut.trim("prebk_osc").execute(measure_prebk_osc, spec, funcindex, funclabel, 1, treg_log_mode, "prebk_osc");//420kHz,2.1MHz
	dcm.Disconnect("DCM5");
	Cmd_Dmuxset_Main(0);
	C_DCM_DBUFO_DisConnect;
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	C_ACM_DBUFO_Connect;
	//prebk_ea fre dbuf
	Cmd_Forceoff(except_dcdc);
	set_vsx(6.0);
	C_FB_CAP_DisConnect;
	//set_fb_hc(4.0);
	Cmd_Bank1(true);
	Cmd_Masksafe();
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2248000000800900);
	int prebk_c=dut.sel("prebck_c").get_working(0);
	int prebk_r=dut.sel("prebk_r").get_working(0);
	dut.sel("prebck_c").set_working(2);
	dut.sel("prebk_r").set_working(1);
	Nvm_Preview(10);
	Nvm_Preview(13);
	dut.trim("prebk_ea").execute(measure_prebk_ea, spec, funcindex, funclabel, 1, treg_log_mode, "prebk_ea");//5.8,5.65,3.9V
	double Vprebk[SITE_NUM];
	SERIAL Vprebk[SITE] = dut.trim("prebk_ea").get_post_reading(SITE);
	if(PN_Prebk_Output==5.8){Ms_LogData(funcindex, "prebk_ea_post1", Vprebk);}
	if(PN_Prebk_Output==5.65){Ms_LogData(funcindex, "prebk_ea_post2", Vprebk);}
	if(PN_Prebk_Output==3.9){Ms_LogData(funcindex, "prebk_ea_post3", Vprebk);}
	bool all_vout = true;

	if(all_vout)
	{
		int interval = 100;
		if(DIE_VER()==0){interval = 100;}
		else{interval = 50;}
		//A_POSFB.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		int code = dut.sel("PREBK_VOUT").get_working(0);
		dut.sel("PREBK_VOUT").set_working(0);//5.8V
		Cmd_Bank1(true);
		Nvm_PreviewFs(1);
		delay_ms(5);
		double val1[SITE_NUM];
		double val2[SITE_NUM];
		double start = 5.8-0.5;
		double stop = 5.8+0.6;
		double step = calc_step(start,stop,100);
		awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", start, stop, step, interval, 2.5 V, TRIG_RISING, val1);
		awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", stop, start, step, interval, 2.5 V, TRIG_FALLING, val2);
		SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
		Ms_LogData(funcindex, "prebk_eaV1", results);
		dut.sel("PREBK_VOUT").set_working(1);//5.65V
		Cmd_Bank1(true);
		Nvm_PreviewFs(1);
		delay_ms(5);
		start = 5.65-0.5;
		stop = 5.65+0.6;
		step = calc_step(start,stop,100);
		awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", start, stop, step, interval, 2.5 V, TRIG_RISING, val1);
		awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", stop, start, step, interval, 2.5 V, TRIG_FALLING, val2);
		SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
		Ms_LogData(funcindex, "prebk_eaV2", results);
		dut.sel("PREBK_VOUT").set_working(2);//3.9V
		Cmd_Bank1(true);
		Nvm_PreviewFs(1);
		delay_ms(5);
		start = 3.9-0.5;
		stop = 3.9+0.6;
		step = calc_step(start,stop,100);
		awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", start, stop, step, interval, 2.5 V, TRIG_RISING, val1);
		awg.rampvmv(F_FB, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ea", stop, start, step, interval, 2.5 V, TRIG_FALLING, val2);
		SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
		Ms_LogData(funcindex, "prebk_eaV3", results);
		dut.sel("PREBK_VOUT").set_working(code);
		Nvm_PreviewFs(1);
	}

	dut.sel("prebck_c").set_working(prebk_c);
	dut.sel("prebk_r").set_working(prebk_r);
	Nvm_Preview(10);
	Nvm_Preview(13);
	Cmd_Dmuxset_Main(0);
	C_FB_CAP_Connect;
	delay_ms(2);

	Cmd_Bank1(true);
	Cmd_TMSel(0x2210000000841800);
	set_vsx(12.0);
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	//Cmd_ReadState(tempd);//2

	int prebk_limit = dut.sel("PREBK_LMT").get_working(0);
	Cmd_LMTCFG(0, prebk_limit, 0, 0, 0);
	CmdReadData(LMT_PD_CFG,data0);

	Cmd_Go2_Sleep();
	Cmd_ReadState(tempd);//3
	set_fb_hc(6.0);
	delay_ms(2);
	Cmd_Bank1(true);
	//prebk_pvss_f, stu mv
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	dut.trim("prebk_pvss_f").execute(measure_prebk_pvss_f, spec, funcindex, funclabel, 1, treg_log_mode, "prebk_pvss_f");//0.8V
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	//dut.trim("prebk_pvss_f").set_working(3);
	//Nvm_Preview(13);
	////prebk_ipfm
	//double result[SITE_NUM];
	//set_vsx(6.0);
	//Cmd_Bank1(true);
	//Cmd_TMSel(0x2210000000800900);//tm59
	//A_STU.Set(FV, 1.0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	//delay_ms(2);
	//A_STU.MeasureVI(20,10);//acm1
	//Get_Result(A_STU, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	//Ms_LogData(funcindex, "prebk_ipfm", result);


	C_ACM_DBUFO_DisConnect;
	C_DBUFI_DisConnect;
	C_DBUF_Bypass;
	Cmd_Dmuxset_Main(0);
		
	//prebk_minpk vs1 to sw1
	//fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	C_SW_PD_Connect;
	C_FPVIH_VS1_Connect;
	C_FPVIL_SW_Connect;
	delay_ms(2);
	set_vsx(4.0);
	Cmd_Masksafe();
	set_vsx(6.0);
	Cmd_Forceoff(except_prebk);

	//hsrdson
	//fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON);
	double rdson_i = 500 mA;
	Cmd_TMSel(0x0000000000900100);//hsrdson tm
	//Cmd_TMSel(0x0048000000A00100);
	set_fb_hc(4.0);
	delay_ms(2);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	rdson_hs_prebk(hsrdson_r);
	Ms_LogData(funcindex, "prebk_hsrdson", hsrdson_r);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	fpvi0.Set(FI, 0.1, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);

	//C_VST_VS1_DisConnect;
	//delay_ms(2);
	//C_FXVI_VS2_Connect;
	//C_VS1_VS2_Connect;
	//delay_ms(2);
	//F_VS2.Set(FV, 6, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);

	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	fpvi0.MeasureVI(30,10);
	//Cmd_ReadState(tempd1);
	Cmd_Go2_Normal();
	fpvi0.MeasureVI(30,10);
	//Cmd_ReadState(tempd2);
	Cmd_Go2_Sleep();
	fpvi0.MeasureVI(30,10);
	Cmd_ReadState(tempd3);
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(0);
	//Cmd_TMSel(0x0000000000900100);//hsrdson tm
	//Cmd_TMSel(0x0048000000A00100);
	fpvi0.MeasureVI(30,10);
	//set_vsx(12.0);
	Cmd_Bank0(true);
	Cmd_ReadState(tempd2);
	set_fb_hc(6.0);
	delay_ms(2);
	C_VST_CAP_DisConnect;
	//C_VS1_CAP_DisConnect;
	C_DBUFI_SW1;
	C_ACM_DBUFO_Connect;
	delay_ms(2);
	fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
	delay_ms(2);
	//fpvi0.MeasureVI(1000,10);
	//dut.trim("prebk_pvss_f").set_working(3);
	//dut.trim("prebk_minpk").set_target(0.29);
	//dut.trim("prebk_minpk").set_trim_type("max");
	string typex = dut.trim("prebk_minpk").get_trim_type();
	dut.trim("prebk_minpk").restart_table_char();
	//dut.trim("prebk_minpk").force_table_char_active(true);
	//dut.trim("prebk_minpk").table_char_active();
	//dut.trim("prebk_minpk").start_learn_valid();
	//Nvm_Preview(13);
	//double value[SITE_NUM];
	double start = -0.5;
	double stop = 1.5;
	double step = calc_step(start,stop,100);
	//Cmd_Forceoff(except_dcdc);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	Cmd_TMSel(0x00);
	Cmd_TMSel(0x0000000000900100);
    //Nvm_Preview(12);
	delay_ms(1);
	awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_2A, "prebk_minpk", start, stop, step, 25, 4.5, TRIG_FALLING, results);//Imode
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	delay_ms(1);
	dut.trim("prebk_minpk").execute(measure_prebk_minpk2, spec, funcindex, funclabel, 1, treg_log_mode, "prebk_minpk");//0.6A
	fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	//fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	delay_ms(2);
	Cmd_Bank0(true);
	Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	CmdWriteData(0x22,0xFF);
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	//prebk_hscl vs1 to sw1
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	//CmdWriteData(0x39,0x40);
	//CmdReadData(0x34,tempd4);
	//Cmd_Bank0(true);
	//Cmd_ReadState(tempd5);
	//Cmd_Unlock();
	//Cmd_LMTCFG(1, 1, 1, 1, 1);
	//CmdReadData(0x39,tempd6);
	//Cmd_Lock();
	//Cmd_ReadState(tempd7);
	dut.trim("prebk_hscl").restart_table_char();
	if(DIE_VER()==0)
	{
		Cmd_Dmuxset_Main(0);
		Cmd_TMSel(0x0048000000A00100);
		set_fb_hc(4.0);
		delay_ms(3);
		fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
		delay_ms(1);
		fpvi0.Set(FV, -0.3, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
		dut.trim("prebk_hscl").execute(measure_prebk_hscl, spec, funcindex, funclabel, 1, treg_log_mode, "prebk_hscl");//5/2.4AVflip/Rdson
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
		fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	}
	else
	{
		Cmd_Dmuxset_Main(0);
		Cmd_TMSel(0x0000000000900100);
		Cmd_TMSel(0x0048000000B00100);
		set_fb_hc(4.0);
		delay_ms(3);
		fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
		delay_ms(1);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
		dut.trim("prebk_hscl").execute(measure_prebk_hscl2, spec, funcindex, funclabel, 1, treg_log_mode, "prebk_hscl");//5/2.4AVflip/Rdson
		Cmd_TMSel(0x0000000000900100);
		Cmd_TMSel(0x0048000000B00100);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
		fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
	}
	SERIAL results[SITE] = dut.trim("prebk_hscl").get_post_reading(SITE);
	if(dut.sel("PREBK_LMT").get_working(0)==0) { Ms_LogData(funcindex, "prebk_hscl_post1", results); }
	else{ Ms_LogData(funcindex, "prebk_hscl_post2", results); }

	//if (0)
	//{
	//	if (DIE_VER() == 0)
	//	{
	//		Cmd_Dmuxset_Main(0);
	//		Cmd_TMSel(0x0048000000A00900);
	//		set_vsx(8.0);
	//		set_fb_hc(4.0);
	//		//delay_ms(2);
	//		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
	//		delay_ms(2);
	//		fpvi0.Set(FV, -0.3, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
	//		//awg.rampvmi_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_max_clampcomp", 0 V, 2 V, 0.02 V, 20, 13.8 mA, TRIG_RISING, value);
	//		prebk_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_max_clampcomp", -0.3, 2, value);
	//		fpvi0.Set(FI, 0, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
	//		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	//		delay_ms(2);
	//		SERIAL  value[SITE] = value[SITE] / (PREBK_HSRDSON[SITE] / 1000.0);
	//	}
	//	else
	//	{
	//		Cmd_Dmuxset_Main(0);
	//		Cmd_TMSel(0x0000000000900900);
	//		//Cmd_TMSel(0x0048000000A00900);
	//		set_vsx(8.0);
	//		set_fb_hc(4.0);
	//		//delay_ms(2);
	//		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
	//		delay_ms(2);
	//		fpvi0.Set(FI, 0.0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
	//		fpvi0.Set(FI, 1.0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
	//		//awg.rampvmi_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_max_clampcomp", 0 V, 2 V, 0.02 V, 20, 13.8 mA, TRIG_RISING, value);
	//		prebk_hscl(fpvi0, FPVIe_5V, FPVIe_10A, "prebk_max_clampcomp", 1.0, 6.5, value);
	//		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
	//		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	//		delay_ms(2);
	//	}
	//	Ms_LogData(funcindex, "prebk_max_clamp", value);
	//}
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	delay_ms(2);
	Cmd_Forceoff(all_off);
	set_vsx(6.0);
	C_FPVIH_VS1_DisConnect;
	C_FPVIL_SW_DisConnect;
	C_SW_PD_DisConnect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	delay_ms(2);

	//F_VS2.Set(FI, 0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	//C_FXVI_VS2_DisConnect;
	//C_VS1_VS2_DisConnect;
	//delay_ms(2);
	//C_VST_VS1_Connect;
	//delay_ms(2);
	//F_VS2.Set(FI, 0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

	//prebk_lscl sw1 to pg
	//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);

	Poweroff_tm_hc();
	delay_ms(2);
	Poweron_tm_hc();
	set_fb_hc(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	set_vsx(6.0);

	C_DBUFI_FRE;
	C_ACM_DBUFO_Connect;
	C_FPVIH_SW_Connect;
	C_FPVIL_PG_Connect;
	delay_ms(2);
	//lsrdson
	rdson_i = 500 mA;
	Cmd_Forceoff(except_prebk);
	set_fb_hc(6.0);
	if(DIE_VER()==0)
	{
		Cmd_Bank1(true);
		Cmd_TMSel(0x0000000000840100);
		Cmd_TMSel(0x0000000000820100);
	}
	else
	{
		Cmd_Bank1(true);
		Cmd_TMSel(0x0000000000000000);
		Cmd_TMSel(0x0000000000840100);
		Cmd_TMSel(0x0000000000820100);
	}
	set_fb_hc(6.0);
	delay_ms(2);
	//C_PG_GND_DisConnect;
	//delay_ms(2);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	rdson_ls_prebk(lsrdson_r);
	//C_PG_GND_Connect;
	//delay_ms(2);
	Ms_LogData(funcindex, "prebk_lsrdson", lsrdson_r);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON);
	fpvi0.Set(FI, 0, FPVIe_2V, FPVIe_2A, FPVIe_RELAY_ON);
	//prebk_lscl sw1 to pg, check fre
	Cmd_Bank0(true);
	//Cmd_ReadState(tempd);
	Cmd_Go2_Wake();
	//Cmd_ReadState(tempd);
	Cmd_Go2_Normal();
	Cmd_ReadState(tempd);
	//Cmd_Go2_Initial();
	//Cmd_ReadState(tempd);//still in sleep
	Cmd_Bank1(true);
	Cmd_Forceoff(except_dcdc);
	set_vsx(6.0);
	dut.trim("prebk_lscl").restart_table_char();
	if(DIE_VER()==0)
	//if (1)
	{
		Cmd_Dmuxset_Main(254);
		Cmd_TMSel(0x2248000000840100);//tm62
		set_fb_hc(4.0);
		delay_ms(2);//acm10
		step=calc_step(0.6,-1.2,100);
		awg.rampvmv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_2A, "prebk_lscl", 0.6, -1.2, step, 20, 2.5, TRIG_FALLING, results);
		dut.trim("prebk_lscl").execute(measure_prebk_lscl, spec, funcindex, funclabel, 1, treg_log_mode, "prebk_lscl");//2.2/4.6A
	}
	else
	{
		Cmd_Dmuxset_Main(254);
		Cmd_TMSel(0x0000000000840100);
		Cmd_TMSel(0x2248000000820100);//tm62
		set_fb_hc(4.0);
		delay_ms(2);//acm10
		step=calc_step(0.6,-6,100);
		awg.rampimv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_10A, "prebk_lscl2", 0.6, -6, step, 20, 2.5, TRIG_FALLING, results);
		fpvi0.Set(FI, 0, FPVIe_2V, FPVIe_10A, FPVIe_RELAY_ON);
		dut.trim("prebk_lscl").execute(measure_prebk_lscl2, spec, funcindex, funclabel, 1, treg_log_mode, "prebk_lscl");//2.2/4.6A
	}
	fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	SERIAL results[SITE] = dut.trim("prebk_lscl").get_post_reading(SITE);
	if(dut.sel("PREBK_LMT").get_working(0)==0) { Ms_LogData(funcindex, "prebk_lscl_post1", results); }
	else{ Ms_LogData(funcindex, "prebk_lscl_post2", results); }

	//prebk_zcd_neg_ls_limit
	//double value[SITE_NUM];

	//if (0)
	//{
	//	if (DIE_VER() == 0)
	//	{
	//		Cmd_Dmuxset_Main(254);
	//		//Cmd_TMSel(0x2248000000820100);
	//		Cmd_TMSel(0x2248000000840100);//tm66
	//		set_fb_hc(4.0);
	//		//delay_ms(2);//acm10
	//		//-0.3 to 0.3
	//		start = -0.3;
	//		stop = 1.0;
	//		step = calc_step(start, stop, 100);
	//		fpvi0.Set(FV, start, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	//		awg.rampvmv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_100MA, "zc_neg_ls", start, stop, step, 20, 2.5 V, TRIG_FALLING, value);
	//		SERIAL  value[SITE] = value[SITE] / (PREBK_LSRDSON[SITE] / 1000.0); //A
	//	}
	//	else
	//	{
	//		Cmd_Dmuxset_Main(254);
	//		//Cmd_TMSel(0x2248000000820100);
	//		Cmd_TMSel(0x2248000000820100);//tm66
	//		set_fb_hc(4.0);
	//		//delay_ms(2);//acm10
	//		//-0.3 to 0.3
	//		start = 0.5;
	//		stop = 1.5;
	//		step = calc_step(start, stop, 100);
	//		fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	//		fpvi0.Set(FI, start, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	//		awg.rampimv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_2A, "zc_neg_ls", start, stop, step, 20, 2.0 V, TRIG_FALLING, value);
	//		fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	//		SERIAL  value[SITE] = value[SITE]; //A
	//	}
	//	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	//	delay_ms(1);
	//	Ms_LogData(funcindex, "prebk_zc_neg_ls", value);

	//	//double value[SITE_NUM];
	//	//prebk_max_negative_ls_limit
	//	if (DIE_VER() == 0)
	//	{
	//		Cmd_Dmuxset_Main(254);
	//		//Cmd_TMSel(0x2248000000820100);
	//		Cmd_TMSel(0x2248000000840100);//tm64
	//		set_vsx(6.0);
	//		set_fb_hc(6.0);//acm10
	//		//1.0 to -0.5
	//		start = 1.0;
	//		stop = -0.5;
	//		step = calc_step(start, stop, 100);
	//		awg.rampvmv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_100MA, "max_neg_ls", start, stop, step, 50, 2.5 V, TRIG_RISING, value);
	//		SERIAL  value[SITE] = value[SITE] / (PREBK_LSRDSON[SITE] / 1000.0); //A
	//	}
	//	else
	//	{
	//		Cmd_Dmuxset_Main(254);
	//		//Cmd_TMSel(0x2248000000820100);
	//		Cmd_TMSel(0x2248000000820100);//tm64
	//		set_vsx(6.0);
	//		set_fb_hc(6.0);//acm10
	//		//1.0 to -0.5
	//		start = 1.6;
	//		stop = 1.0;
	//		step = calc_step(start, stop, 100);
	//		fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	//		fpvi0.Set(FI, start, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	//		awg.rampimv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_2A, "max_neg_ls", start, stop, step, 50, 0.1 V, TRIG_RISING, value);
	//		//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	//		fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
	//		SERIAL  value[SITE] = value[SITE]; //A
	//	}
	//	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	//	delay_ms(1);
	//	Ms_LogData(funcindex, "prebk_max_neg_ls", value);
	//}
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	Cmd_Dmuxset_Main(0);
	Cmd_TMSel(0x00);
	
	//prebk_zc
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	//CmdReadData(0x27, tempd);
	Cmd_Go2_Sleep();
	//CmdReadData(0x27, tempd);
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	if(DIE_VER()==0)
	{
		Cmd_TMSel(0x2248000000840100);
	}
	else
	{
		Cmd_TMSel(0x0000000000840100);
		Cmd_TMSel(0x2248000000820100);
	}
	set_fb_hc(4.0);
	dut.trim("prebk_zc").execute(measure_prebk_zc, spec, funcindex, funclabel, 1, treg_log_mode, "prebk_zc");//0A
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	C_FPVIH_SW_DisConnect;
	C_FPVIL_PG_DisConnect;
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	C_FRE_PU_DisConnect;
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_OFF);
	//set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	set_stu(false);
	//C_ACM_SECPOSFRE_DisConnect;
	C_ACM_STU_DisConnect;
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	Poweroff_tm_hc();
	//C_All_Open;
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T25_Trim_POSBK(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	double hsrdson_v[SITE_NUM];
	double hsrdson_r[SITE_NUM];
	double lsrdson_v[SITE_NUM];
	double lsrdson_r[SITE_NUM];
	double results[SITE_NUM];

	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];
	int data5[SITE_NUM];
	int data6[SITE_NUM];
	int data7[SITE_NUM];
	int data8[SITE_NUM];
	int data9[SITE_NUM];

	Ms_LogData(funcindex, "posbk_available0", PN_Posbk_Available);
	if(!PN_Posbk_Available){return true;}

	C_All_Open;
	all_resource_off();
	//A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	//C_ACM_STU_Connect;
	//C_ACM_SECPOSFRE_Connect;

	//postbk_osc_fl, monitor possw
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	C_POSFRE_PD_Connect;
	//C_POSFRE_PD_DisConnect;
	C_FRE_PU_Connect;
	C_DBUFI_FRE;
	C_FRE_PU_Connect;
	C_DCM_DBUFO_Connect;//dcm5
	Poweron_tm();
	set_qst(5.1);
	set_posin(4.0);
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	Cmd_Forceoff(except_postbk);
	//Cmd_Bank0(true);
	//Cmd_ReadState(data3);//1
	//CmdReadData(0x33,data4);
	//Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2A48000006000100);
	set_posfb_plus_target(-0.2);
	set_vsx(6.0);
	set_posin(6.0);
	measure_freq_duty_set("DCM5",3.0);//420KHz
	dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
	dut.trim("postbk_osc_fl").execute(measure_postbk_osc_fl, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_osc_fl");//420kHz
	dcm.Disconnect("DCM5");
	C_DBUFI_DisConnect;
	C_FRE_PU_DisConnect;
	C_DCM_DBUFO_DisConnect;
	C_POSFRE_PD_DisConnect;
	Poweroff_tm();
	delay_ms(2);

	//postbk_osc_fh, monitor possw
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	C_POSFRE_PD_DisConnect;
	//C_POSFRE_PD_Connect;
	C_DBUFI_FRE;
	C_FRE_PU_Connect;
	C_DCM_DBUFO_Connect;//dcm5
	delay_ms(2);
	Poweron_tm();
	set_fb(5.5);
	set_quc(5.0);
	set_qst(5.1);
	set_posin(4.0);
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);
	Cmd_Forceoff(except_postbk);
	set_vsx(6.0);
	set_posin(6.0);
	set_posfb_plus_target(-0.2);//1.45V
	//delay_ms(5);
	//Cmd_Bank0(true);
	//Cmd_ReadState(data1);//1
	//CmdReadData(0x26,data2);
	//CmdReadData(0x33,data3);//9, posbk worked
	//Cmd_ReadState(data4);
	//Cmd_Bank1(true);
	unsigned __int64 SEL[SITE_NUM];
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2A48000006000100);
	//Cmd_TMSelCheck(SEL);
	//set_posfb_plus_target(0.2);
	//set_vsx(6.0);
	//set_posin(6.0);
	//delay_ms(5);
	measure_freq_duty_set("DCM5",0.8, DCM_HIGH);//2.1MHz
	dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
	dut.trim("postbk_osc_fh").execute(measure_postbk_osc_fh, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_osc_fh");//2.1MHz
	dcm.Disconnect("DCM5");

	set_vsx(10.0);
	set_posin(6.0);
	//postbk_ea, ramp posfb, monitor fre
	C_ACM_DBUFO_Connect;
	delay_ms(2);
	set_posfb(0.0);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2C480000C2000100);//acm7,acm10
	delay_ms(2);
	dut.trim("postbk_ea").execute(measure_postbk_ea, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_ea");//1.25V

	bool all_vout = true;

	if(all_vout)
	{
		double val1[SITE_NUM];
		double val2[SITE_NUM];
		//A_POSFB.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		int code = dut.sel("POSBK_VOUT").get_working(0);
		dut.sel("POSBK_VOUT").set_working(0);//0.8V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		double start = 0.7;
		double stop = 0.9;
		double step = calc_step(start,stop,100);
		awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", start, stop, step, 20, 2.5 V, TRIG_FALLING, val1);
		awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", stop, start, step, 20, 2.5 V, TRIG_RISING, val2);
		SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
		Ms_LogData(funcindex, "postbk_eaV1", results);
		dut.sel("POSBK_VOUT").set_working(2);//0.9V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		start = 0.8;
		stop = 1.0;
		step = calc_step(start,stop,100);
		awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", start, stop, step, 20, 2.5 V, TRIG_FALLING, val1);
		awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", stop, start, step, 20, 2.5 V, TRIG_RISING, val2);
		SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
		Ms_LogData(funcindex, "postbk_eaV2", results);
		dut.sel("POSBK_VOUT").set_working(9);//1.25V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		start = 1.15;
		stop = 1.35;
		step = calc_step(start,stop,100);
		awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", start, stop, step, 20, 2.5 V, TRIG_FALLING, results);
		Ms_LogData(funcindex, "postbk_eaV3", results);
		dut.sel("POSBK_VOUT").set_working(15);//1.8V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		start = 1.7;
		stop = 1.9;
		step = calc_step(start,stop,100);
		awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", start, stop, step, 20, 2.5 V, TRIG_FALLING, val1);
		awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", stop, start, step, 20, 2.5 V, TRIG_RISING, val2);
		SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
		Ms_LogData(funcindex, "postbk_eaV4", results);
		dut.sel("POSBK_VOUT").set_working(17);//3.3V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		start = 3.1;
		stop = 3.5;
		step = calc_step(start,stop,100);
		awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", start, stop, step, 20, 2.5 V, TRIG_FALLING, val1);
		awg.rampvmv(A_POSFB, A_DBUFO, ACM200_10V, ACM200_100MA, "postbk_ea", stop, start, step, 20, 2.5 V, TRIG_RISING, val2);
		SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
		Ms_LogData(funcindex, "postbk_eaV5", results);
		dut.sel("POSBK_VOUT").set_working(code);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
	}

	//postbk_ss///////////////////, fre h to l to h
		//double value = dut.trim("postbk_ea").get_working(0);
		//dut.trim("postbk_ea").set_working(0);
		//Cmd_Bank1(true);
		//Nvm_Preview(15);
		//delay_ms(2);

	F_SCS.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_SCS_Connect;
	test_ss(F_SCS, A_DBUFO, 3500, 1, results);//fxvi5,acm10
	set_posfb_plus_target(-0.2);
	//dut.sel("POSTBK_SS").set_working(0);//2ms
	//Nvm_PreviewFs(4);
	int state0[SITE_NUM];
	Cmd_Bank0(true);
	Cmd_ReadState(state0);
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	//Cmd_TMSel(0x2C480000C3000100);
	//Cmd_TMSel(0x2C480000C2000100);//rst
	//Cmd_TMSel(0x2C480000C3000100);
	//Cmd_TMSel(0x2C480000C2000100);//rst
	int ss_code_ini[SITE_NUM];
	int POSTBK_SS = dut.sel("POSTBK_SS").get_working(0);
	SERIAL ss_code_ini[SITE]=dut.trim("postbk_ss").get_working(SITE);
	int posbk_ss_hcode = 0;
	if (POSTBK_SS == 0){posbk_ss_hcode = 0;}
	else{posbk_ss_hcode = 4;}
	if(DIE_VER()==0)
	{
		if(DO_CHAR)
		{
			dut.trim("postbk_ss").execute(measure_postbk_ss, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_ss");//0.2mS,2mS	
			SERIAL if(trimed_ftb0[SITE] == 0){dut.trim("postbk_ss").set_working(posbk_ss_hcode,SITE);}//if fresh, reset code to 0
		}
	}
	else
	{
		dut.trim("postbk_ss").execute(measure_postbk_ss, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_ss");//0.2mS,2mS
	}
	SERIAL results[SITE] = dut.trim("postbk_ss").get_post_reading(SITE);
	if (POSTBK_SS == 0) { Ms_LogData(funcindex, "postbk_ss_post1", results); }
	else { Ms_LogData(funcindex, "postbk_ss_post2", results); }
	//SERIAL dut.trim("postbk_ss").set_working(posbk_ss_hcode,SITE);

	if(DIE_VER()==0)
	{
		Nvm_Preview(20);
		delay_ms(1);
		CmdWriteData(0x28, 0x00);
		CmdWriteData(0x29, 0x01);
		CmdWriteData(0x2A, 0x00);
		CmdWriteData(0x2C, 0x00);
		CmdWriteData(0x2D, 0x00);
		CmdWriteData(0x2E, 0x48);
		CmdWriteData(0x2F, 0x2C);
		Cmd_Set_Freq(100 KHz);
		int state2 = dcm.RunVectorWithGroup("SPI_DUT", "CMD1_Start", "CMD1_Stop", false);
		test_ss(F_SCS, A_DBUFO, 3500, 1, results);//fxvi5,acm10
		SERIAL results[SITE]=results[SITE]+0.0232;
		Cmd_Set_Freq();
		Cmd_TMSel(0x2C480000C2000100);//rst
		Ms_LogData(funcindex, "postbk_ss_hardcode", posbk_ss_hcode);
		if (POSTBK_SS == 0) { Ms_LogData(funcindex, "postbk_ss_hardvalue1", results); }
		else { Ms_LogData(funcindex, "postbk_ss_hardvalue2", results); }
	}
	//dut.trim("postbk_ss").set_working(0);
	C_FXVI_SCS_DisConnect;
	F_SCS.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
		//Cmd_Bank1(true);
		//dut.trim("postbk_ea").set_working(value);
		//Nvm_Preview(15);
		//delay_ms(2);

	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	delay_ms(2);
	C_FPVIH_POSSW_Connect;
	C_FPVIL_POSG_Connect;
	delay_ms(2);
	//ls rdson
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x0000000006000100);
	set_fb(4.0);
	delay_ms(2);
	rdson_ls_posbk(lsrdson_r);
	Ms_LogData(funcindex, "posbk_lsrdson", lsrdson_r);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	//postbk_vy_negcl, -0.7A, ramp possw 0A,2A, monitor cont signal
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2E48000006000100);//tm82
	Cmd_Bank0(true);
	CmdReadData(0x33,data3);//11
	Cmd_Bank1(true);
	//set_posfb(3.0);//target+0.2V
	set_posfb_plus_target(0.3);
	set_vsx(6.0);
	set_posin(5.0);

	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	int posbk_limit = dut.sel("POSTBK_LMT").get_working(0);
	Cmd_LMTCFG(posbk_limit, 0, 0, 0, 0);
	CmdReadData(LMT_PD_CFG,data0);
	Cmd_Bank1(true);

	fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	dut.trim("postbk_vy_negcl").execute(measure_postbk_vy_negcl, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_vy_negcl");//-0.7A
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	
	//postbk_negcl, -1.7A, ramp possw -2A,0A, monitor zcd signal
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2648000016000100);//tm83
	delay_ms(1);
	dut.trim("postbk_negcl").execute(measure_postbk_negcl, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_negcl");//-1.7A
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	
	//postbk_vymax, 5.7A, ramp possw 0A,2A, monitor FRE signal
	Cmd_Dmuxset_Main(254);
	dut.trim("postbk_vymax").restart_table_char();
	if(1)//mirror down
	{
		//Cmd_TMSel(0x2E48000006000100);//no mirror down mode
		Cmd_TMSel(0x2E48000026000100);//mirror down mode
		set_posfb(0.0);//target-0.2V
		delay_ms(1);
		dut.trim("postbk_vymax").execute(measure_postbk_vymax, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_vymax");//5.7A
	}
	else
	{
		Cmd_TMSel(0x2E48000006000100);//no mirror down mode
		//Cmd_TMSel(0x2E48000026000100);//mirror down mode
		set_posfb(0.0);//target-0.2V
		delay_ms(1);
		dut.trim("postbk_vymax").execute(measure_postbk_vymax2, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_vymax");//5.7A
	}
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL results[SITE] = dut.trim("postbk_vymax").get_post_reading(SITE);
	if (dut.sel("POSTBK_LMT").get_working(0) == 0) { Ms_LogData(funcindex, "postbk_vymax_post1", results); }
	else { Ms_LogData(funcindex, "postbk_vymax_post2", results); }

	//postbk_zcd, 0A, ramp possw -2A,A, monitor zcd signal
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2648000016000100);
	//set_posfb(3.0);//target+0.2V
	set_posfb_plus_target(0.3);
	set_vsx(6.0);
	set_posin(5.0);
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();

	//Cmd_Bank0(true);
	//CmdReadData(0x33,data0);
	//int posbk_limit = dut.sel("POSTBK_LMT").get_working(0);
	//Cmd_LMTCFG(posbk_limit, 0, 0, 0, 0);
	//CmdReadData(LMT_PD_CFG,data0);

	Cmd_Go2_Sleep();
	Cmd_Bank1(true);
	double step = calc_step(-1,1,100);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	awg.rampimv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_1A, "postbk_zcd", -1 A, 1 A, step, 20, 2.5 V, TRIG_FALLING, results);
	dut.trim("postbk_zcd").execute(measure_postbk_zcd, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_zcd");//0mA
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(2);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(2);
	C_FPVIH_POSSW_DisConnect;
	C_FPVIL_POSG_DisConnect;
	delay_ms(2);

	C_FPVIH_POSIN_Connect;
	C_FPVIL_POSSW_Connect;
	delay_ms(2);
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x0000000082000100);
	rdson_hs_posbk(hsrdson_r);
	Ms_LogData(funcindex, "posbk_hsrdson", hsrdson_r);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	//postbk_pkmax, 5.7A, ramp possw 0A,2A, monitor FRE signal
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	dut.trim("postbk_pkmax").restart_table_char();
	if(0)//mirror down
	{
		Cmd_TMSel(0x2C480000C2000100);//tm77
		//Cmd_TMSel(0x2C48000082000100);//no mirror down mode
		Cmd_Bank1(true);
		set_posfb(0.0);//target-0.2V
		delay_ms(2);
		dut.trim("postbk_pkmax").execute(measure_postbk_pkmax, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_pkmax");//5.7A
	}
	else
	{
		//Cmd_TMSel(0x2C480000C2000100);//tm77
		Cmd_TMSel(0x2C48000082000100);//no mirror down mode
		Cmd_Bank1(true);
		set_posfb(0.0);//target-0.2V
		delay_ms(2);
		dut.trim("postbk_pkmax").execute(measure_postbk_pkmax2, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_pkmax");//5.7A
	}
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	SERIAL results[SITE] = dut.trim("postbk_pkmax").get_post_reading(SITE);
	if (dut.sel("POSTBK_LMT").get_working(0) == 0) { Ms_LogData(funcindex, "postbk_pkmax_post1", results); }
	else { Ms_LogData(funcindex, "postbk_pkmax_post2", results); }

	//postbk_pkmin, 0.95A, ramp possw 0A,2A, monitor FRE signal
	
	if(0)//1/8 Mirror down
	{
		Cmd_Dmuxset_Main(254);
		Cmd_TMSel(0x2C480000C2000100);
		//set_posfb(3.0);//target+0.2V
		set_posfb_plus_target(0.3);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_Go2_Sleep();
		Cmd_ReadState(data0);//3
		Cmd_Bank1(true);
		dut.trim("postbk_pkmin").execute(measure_postbk_pkmin, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_pkmin");//0.95A
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
		delay_ms(2);
	}
	else//No Mirror down
	{
		Cmd_Dmuxset_Main(254);
		Cmd_TMSel(0x2C48000082000100);
		//set_posfb(3.0);//target+0.2V
		set_posfb_plus_target(0.3);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_Go2_Sleep();
		Cmd_ReadState(data0);//3
		Cmd_Bank1(true);
		dut.trim("postbk_pkmin").execute(measure_postbk_pkmin2, spec, funcindex, funclabel, 1, treg_log_mode, "postbk_pkmin");//0.95A
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
		delay_ms(2);
	}

	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_POSSW_DisConnect;
	delay_ms(2);
	fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(2);
	C_DCM_DBUFO_DisConnect;
	C_POSFRE_PD_DisConnect;
	C_DBUFI_DisConnect;
	C_FRE_PU_DisConnect;
	C_DCM_FRE_DisConnect;
	C_ACM_DBUFO_DisConnect;
	A_DBUFO.Set(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_OFF);
	set_posfb(0.0);
	set_posin(0.0);
	delay_ms(2);
	set_posfb(false);
	set_posin(false);
	Poweroff_tm();
	//C_All_Open;
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T27_STA(short funcindex, LPCTSTR funclabel)
{
	if(QC){return 0;}

	int count[SITE_NUM];
	int lcode_bg1[SITE_NUM];
	int lcode_bg2[SITE_NUM];
	int lcode_lfo[SITE_NUM];
	int lcode_lfo1[SITE_NUM];
	int lcode_lfo2[SITE_NUM];
	int lcode_hfo[SITE_NUM];
	int zcode_bg1[SITE_NUM];
	int zcode_bg2[SITE_NUM];
	int zcode_lfo[SITE_NUM];
	int zcode_lfo1[SITE_NUM];
	int zcode_lfo2[SITE_NUM];
	int zcode_hfo[SITE_NUM];
	double lcode_avg_bg1[SITE_NUM];
	double lcode_avg_bg2[SITE_NUM];
	double lcode_avg_lfo[SITE_NUM];
	double lcode_avg_lfo1[SITE_NUM];
	double lcode_avg_lfo2[SITE_NUM];
	double lcode_avg_hfo[SITE_NUM];
	double dcode_bg1[SITE_NUM];
	double dcode_bg2[SITE_NUM];
	double dcode_lfo[SITE_NUM];
	double dcode_lfo1[SITE_NUM];
	double dcode_lfo2[SITE_NUM];
	double dcode_hfo[SITE_NUM];
	double all_avg_bg1;
	double all_avg_bg2;
	double all_avg_lfo;
	double all_avg_lfo1;
	double all_avg_lfo2;
	double all_avg_hfo;

	SERIAL{ zcode_bg1[SITE] = dut.trim("bg1_ref").get_working(SITE); }
	sta.Set_Zcode("bg1_ref", zcode_bg1);
	SERIAL{ zcode_bg2[SITE] = dut.trim("bg2_ref").get_working(SITE); }
	sta.Set_Zcode("bg2_ref", zcode_bg2);
	//if(DIE_VER()==0)
	//{
	//	SERIAL{ zcode_lfo[SITE] = dut.trim("lfo12").get_working(SITE); }
	//	sta.Set_Zcode("lfo12", zcode_lfo);
	//}
	//else
	//{
		SERIAL{ zcode_lfo1[SITE] = dut.trim("lfo1").get_working(SITE); }
		sta.Set_Zcode("lfo1", zcode_lfo1);
		SERIAL{ zcode_lfo2[SITE] = dut.trim("lfo2").get_working(SITE); }
		sta.Set_Zcode("lfo2", zcode_lfo2);
	//}
	SERIAL{ zcode_hfo[SITE] = dut.trim("hfo12").get_working(SITE); }
	sta.Set_Zcode("hfo12", zcode_hfo);

	sta.Update();
	sta.Get_Count("bg1_ref", count);
	all_avg_bg1 = sta.Get_AvgAll("bg1_ref");
	sta.Get_Lcode("bg1_ref", lcode_bg1);//per site
	sta.Get_AvgSite("bg1_ref", lcode_avg_bg1);//per site
	sta.Get_AvgShift("bg1_ref", dcode_bg1);//per site
	Ms_LogData(funcindex, "Sta_count", count);
	Ms_LogData(funcindex, "Sta_bg1_lcode", lcode_bg1);
	Ms_LogData(funcindex, "Sta_bg1_all_avg_lcode", all_avg_bg1);
	Ms_LogData(funcindex, "Sta_bg1_avg_lcode", lcode_avg_bg1);
	Ms_LogData(funcindex, "Sta_bg1_diff_lcode", dcode_bg1);
	all_avg_bg2 = sta.Get_AvgAll("bg2_ref");
	sta.Get_Lcode("bg2_ref", lcode_bg2);//per site
	sta.Get_AvgSite("bg2_ref", lcode_avg_bg2);//per site
	sta.Get_AvgShift("bg2_ref", dcode_bg2);//per site
	Ms_LogData(funcindex, "Sta_bg2_lcode", lcode_bg2);
	Ms_LogData(funcindex, "Sta_bg2_all_avg_lcode", all_avg_bg2);
	Ms_LogData(funcindex, "Sta_bg2_avg_lcode", lcode_avg_bg2);
	Ms_LogData(funcindex, "Sta_bg2_diff_lcode", dcode_bg2);
	//if(DIE_VER()==0)
	//{
	//	all_avg_lfo = sta.Get_AvgAll("lfo12");
	//	sta.Get_Lcode("lfo12", lcode_lfo);//per site
	//	sta.Get_AvgSite("lfo12", lcode_avg_lfo);//per site
	//	sta.Get_AvgShift("lfo12", dcode_lfo);//per site
	//	Ms_LogData(funcindex, "Sta_lfo_lcode", lcode_lfo);
	//	Ms_LogData(funcindex, "Sta_lfo_all_avg_lcode", all_avg_lfo);
	//	Ms_LogData(funcindex, "Sta_lfo_avg_lcode", lcode_avg_lfo);
	//	Ms_LogData(funcindex, "Sta_lfo_diff_lcode", dcode_lfo);
	//}
	//else
	//{
		all_avg_lfo1 = sta.Get_AvgAll("lfo1");
		sta.Get_Lcode("lfo1", lcode_lfo1);//per site
		sta.Get_AvgSite("lfo1", lcode_avg_lfo1);//per site
		sta.Get_AvgShift("lfo1", dcode_lfo1);//per site
		Ms_LogData(funcindex, "Sta_lfo1_lcode", lcode_lfo1);
		Ms_LogData(funcindex, "Sta_lfo1_all_avg_lcode", all_avg_lfo1);
		Ms_LogData(funcindex, "Sta_lfo1_avg_lcode", lcode_avg_lfo1);
		Ms_LogData(funcindex, "Sta_lfo1_diff_lcode", dcode_lfo1);
		all_avg_lfo2 = sta.Get_AvgAll("lfo2");
		sta.Get_Lcode("lfo2", lcode_lfo2);//per site
		sta.Get_AvgSite("lfo2", lcode_avg_lfo2);//per site
		sta.Get_AvgShift("lfo2", dcode_lfo2);//per site
		Ms_LogData(funcindex, "Sta_lfo2_lcode", lcode_lfo2);
		Ms_LogData(funcindex, "Sta_lfo2_all_avg_lcode", all_avg_lfo2);
		Ms_LogData(funcindex, "Sta_lfo2_avg_lcode", lcode_avg_lfo2);
		Ms_LogData(funcindex, "Sta_lfo2_diff_lcode", dcode_lfo2);
	//.............................................................}
	all_avg_hfo = sta.Get_AvgAll("hfo12");
	sta.Get_Lcode("hfo12", lcode_hfo);//per site
	sta.Get_AvgSite("hfo12", lcode_avg_hfo);//per site
	sta.Get_AvgShift("hfo12", dcode_hfo);//per site
	Ms_LogData(funcindex, "Sta_hfo_lcode", lcode_hfo);
	Ms_LogData(funcindex, "Sta_hfo_all_avg_lcode", all_avg_hfo);
	Ms_LogData(funcindex, "Sta_hfo_avg_lcode", lcode_avg_hfo);
	Ms_LogData(funcindex, "Sta_hfo_diff_lcode", dcode_hfo);

	sta.Save_to_File();

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T28_NVM_Burn(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	if(QC){return 0;}

	int pvr_f[SITE_NUM];
	int pvr[SITE_NUM];
	double v_burn[SITE_NUM];
	all_resource_off();
	C_All_Open;

	SERIAL
	{
		if (burn_flag[SITE] == true) { v_burn[SITE]=5.0; }
		else{ v_burn[SITE]=0.0; }
	}
	//DDS_Connect();
	//DDS_Initial();
	//DDS_SetFreq(100 KHz);

	set_burn_voltage(0.0);
	C_ACM_SECPOSFRE_Connect;
	Poweron_tm();
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	set_vsx(4.7);
	//fxvi4.Set(FV, 4.7, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON,3);
	delay_ms(1);
	Cmd_Bank1(true);
	CmdWriteData(0x2F, 0x01);//bypass SEC to DVDD1, 3.4V
	CmdWriteData(0x2D, 0x03);//disable QUC/FBX IQ and discharge
	CmdWriteData(0x2A, 0x80);//disable prebuck discharge
	//A_SECPOSFRE.Set(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//set_burn_voltage(v_burn);

	//C_DDS_ERR_Connect;
	//delay_ms(1);
	//Burn_Flag_Ctl(DO_TRIM, trimed_cp0, trimed_ft0, trimed_ftb0, burn_lock0, burn_flag);
	if(FLOW_CP)
	{
		dut.sel("Burn_lock").set_working(0);
		Setup_CP_Trim_Item();
	}
	else
	{
		dut.sel("Burn_lock").set_working(1);
	}
	Nvm_PreviewFs(-1);
	Nvm_Preview(-1);

	//SERIAL burn_flag[SITE] = true;
	//DO_TRIM = true;
	set_burn_voltage(v_burn);
	Nvm_Burn(DO_TRIM, burn_flag);
	//C_DDS_ERR_DisConnect;
	//A_SECPOSFRE.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	CmdWriteData(0x2F, 0x00);
	set_burn_voltage(0.0);

	//read otp
	NVM_Read1(pvr_f, pvr);

	//datalog
	Ms_LogData(funcindex, "Burn_Enable", DO_TRIM);
	Ms_LogData(funcindex, "Burn_Voltage", v_burn);
	Ms_LogData(funcindex, "Flag_Trimed_CP", trimed_cp0);
	Ms_LogData(funcindex, "Flag_Trimed_FTA", trimed_ft0);
	Ms_LogData(funcindex, "Flag_Trimed_FTB", trimed_ftb0);
	Ms_LogData(funcindex, "Flag_Burn", burn_flag);
	Ms_LogData(funcindex, "Prog_Vs_Read_F", pvr_f);
	Ms_LogData(funcindex, "Prog_Vs_Read", pvr);
	NVM_Pgm_datalog(funcindex);
	NVM_Read1_datalog(funcindex);
	
	Poweroff_tm();
	//DDS_DisConnect();
	//A_SECPOSFRE.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	set_burn_voltage(false);
	C_ACM_SECPOSFRE_DisConnect;

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T30_Leakage_Pre(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	//return true;

	double result_leak[PIN_Count][SITE_NUM] = { 0 };

	leak_test(result_leak);
	leak_getdata(result_leak, true);
	leak_datalog(funcindex, true);
	
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T31_Absmax(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	if(QC){return 0;}

	if(DIE_VER()!=0){DO_ABSN = true;}

	double result[SITE_NUM];
	double result_abs[PIN_Count][SITE_NUM] = { 0 };
	double fall[SITE_NUM];

	int reg0[SITE_NUM];
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int reg3[SITE_NUM];

	abs_test(result_abs);
	abs_getdata(result_abs);
	abs_datalog(funcindex);

	C_All_Open;
	all_resource_off();


	//C_FXVI_ACM_GND_Connect;
	//C_AGS_BSG_PG_GND_Connect;
	//C_POSG_GND_Connect;
	//C_ACM_FB1_Connect;
	//vicurve_v(A_FB1, ACM200_10V, ACM200_100MA, 0, 8);
	//A_FB1.Set(FV, 8, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB1.Set(FV, 8, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB1.MeasureVI(20,10);//fxvi0
	//Get_Result(A_FB1, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//Ms_LogData(funcindex, "ABS_FB1", result);
	//C_ACM_FB1_DisConnect;
	//delay_ms(1);
	//C_ACM_FB2_Connect;
	//delay_ms(1);
	//A_FB2.Set(FV, 8, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB2.MeasureVI(20,10);//fxvi0
	//Get_Result(A_FB2, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//Ms_LogData(funcindex, "ABS_FB2", result);
	//C_ACM_FB2_DisConnect;
	//delay_ms(1);
	//C_ACM_FB3_Connect;
	//delay_ms(1);
	//A_FB3.Set(FV, 8, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB3.MeasureVI(20,10);//fxvi0
	//Get_Result(A_FB3, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//Ms_LogData(funcindex, "ABS_FB3", result);
	//C_ACM_FB3_DisConnect;
	//delay_ms(1);
	//C_ACM_FB4_Connect;
	//delay_ms(1);
	//A_FB4.Set(FV, 8, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB4.MeasureVI(20,10);//fxvi0
	//Get_Result(A_FB4, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//Ms_LogData(funcindex, "ABS_FB4", result);
	//C_ACM_FB4_DisConnect;
	//delay_ms(1);

	//Poweron_tm();
	//DUT_SPI_Connect(4.0);
	//Cmd_Set_Freq(10 MHz);
	//Cmd_TestMode(true);
	//Cmd_Masksafe();
	//Cmd_Bank0(true);
	//Cmd_Dis_ERR_WD();
	////set_vsx(6.0);
	////set_fb(6.0);
	//set_vsx(9.0);
	//set_fb_plus_target(0.1);//
	//set_quc(false);
	//A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//Cmd_ReadState(reg0);//1
	//Cmd_Go2_Normal();
	//Cmd_ReadState(reg1);//2
	//Cmd_Go2_Sleep();
	//Cmd_ReadState(reg2);//3
	//F_VST.MeasureVI(1000,1);//fxvi4
	//A_FB1.MeasureVI(1000,1);//acm11
	//A_QUC.MeasureVI(1000,1);//acm2
	////set_quc(5.0);
	//set_fb_plus_target(0.1);//
	//A_FB1.Set(FV, 8.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB1.MeasureVI(1000,10);//fxvi0
	//A_QUC.MeasureVI(1000,1);//acm2

	//set_fb_plus_target(0.1);//
	//delay_ms(1);
	//A_FB1.MeasureVI(1000,1);//fxvi0

	//vicurve_v(A_FB1, ACM200_10V, ACM200_100MA, 5.75, 8);

	//Poweroff_tm();




	//C_AGS_BSG_PG_POSG_GND_Connect;
	//C_ACM_FB1_Connect;
	//C_VST_VS1_Connect;
	//set_vsx(0.0);
	//A_FB1.Set(FV, 8, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB1.Set(FV, 8, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB1.MeasureVI(20,10);//fxvi0
	//Get_Result(A_FB1, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//Ms_LogData(funcindex, "ABS_FB1", result);
	//A_FB1.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(1);

	//C_ACM_FB1_Connect;
	//awg.rampvmi(A_FB1, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "mps_thres2", 4.0 V, 8.5 V, 0.05 V, 20, 5 mA, TRIG_FALLING, fall);
	//set_fb(false);
	//C_ACM_FB1_DisConnect;
	Poweron_tm();
	set_fb(6.0);
	set_quc(5.5);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Dis_WwdFwdErrm();
	Nvm_PreviewFs(-1);
	Cmd_Forceoff(none_off);
	set_vsx(6.0);
	set_fb(6.0);//
	C_QST_CAP_DisConnect;
	C_FB_CAP_DisConnect;
	C_QVR_CAP_DisConnect;
	C_QUC_CAP_DisConnect;
	C_QCO_CAP_DisConnect;
	delay_ms(1);
	Cmd_TMSel(0x0000030000800001);//qst abs
	delay_ms(1);
	A_QST.Set(FV, 6, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_QST.Set(FV, 6, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(1);
	A_QST.MeasureVI(20,10);//acm0
	Get_Result(A_QST, result, MIRET);
	SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	Ms_LogData(funcindex, "ABS_QST", result);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_OFF);
	//set_qst(5.1);
	Cmd_Forceoff(all_off);
	delay_ms(1);
	//set_vsx(8.0);
	//dut.sel("SSD_EVS").s
	vicurve_v(A_FB1, ACM200_10V, ACM200_10MA, 5.75, 8);
	//awg.rampvmi(A_FB1, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "mps_thres2", 4.0 V, 8.5 V, 0.05 V, 20, 5 mA, TRIG_FALLING, fall);
	//A_FB1.Set(FV, 8, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB1.Set(FV, 8, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB1.MeasureVI(20,10);//fxvi0
	//Get_Result(A_FB1, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	////Ms_LogData(funcindex, "ABS_FB1", result);
	//C_ACM_FB1_DisConnect;
	//delay_ms(1);
	//C_ACM_FB2_Connect;
	//delay_ms(1);
	//A_FB2.Set(FV, 8, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB2.MeasureVI(20,10);//fxvi0
	//Get_Result(A_FB2, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//Ms_LogData(funcindex, "ABS_FB2", result);
	//C_ACM_FB2_DisConnect;
	//delay_ms(1);
	//C_ACM_FB3_Connect;
	//delay_ms(1);
	//A_FB3.Set(FV, 8, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB3.MeasureVI(20,10);//fxvi0
	//Get_Result(A_FB3, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//Ms_LogData(funcindex, "ABS_FB3", result);
	//C_ACM_FB3_DisConnect;
	//delay_ms(1);
	//C_ACM_FB4_Connect;
	//delay_ms(1);
	//A_FB4.Set(FV, 8, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(1);
	//A_FB4.MeasureVI(20,10);//fxvi0
	//Get_Result(A_FB4, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//Ms_LogData(funcindex, "ABS_FB4", result);
	//C_ACM_FB4_DisConnect;
	//delay_ms(1);
	C_ACM_FB1_Connect;
	delay_ms(1);
	Cmd_Forceoff(none_off);
	Cmd_TMSel(0x0004030000800001);//syn,evc,qco,,,,
	set_fb(6.0);
	set_quc(6.0);
	if(PN_SEC_Available)//no posfre, has evc
	{
		C_ACM_EVC_Connect;//10uA
		delay_ms(1);
		A_EVC.Set(FV, 6, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_EVC.Set(FV, 6, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		A_EVC.MeasureVI(20,10);//acm9
		Get_Result(A_EVC, result, MIRET);
		SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
		Ms_LogData(funcindex, "ABS_EVC", result);
		A_EVC.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		C_ACM_EVC_DisConnect;
		delay_ms(1);
	}
	if (PINarray[28].pin_valid)//syn
	{
		C_ACM_SYN_Connect;//should be < 1uA.
		delay_ms(1);
		A_SYN.Set(FV, 6, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_SYN.Set(FV, 6, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
		delay_ms(1);
		A_SYN.MeasureVI(20,10);//acm10
		Get_Result(A_SYN, result, MIRET);
		SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
		Ms_LogData(funcindex, "ABS_SYN", result);
		A_SYN.Set(FV, 6, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		C_ACM_SYN_DisConnect;
		delay_ms(1);
	}

	////set_vsx(5.0);
	A_QVR.Set(FV, 6, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);//acm3,20uA
	delay_ms(1);
	A_QVR.Set(FV, 6, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(1);
	A_QVR.MeasureVI(20,10);//acm10
	Get_Result(A_QVR, result, MIRET);
	SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	Ms_LogData(funcindex, "ABS_QVR", result);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);

	A_QCO.Set(FV, 6, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//
	delay_ms(1);
	A_QCO.Set(FV, 6, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_QCO.MeasureVI(20,10);//acm10
	Get_Result(A_QCO, result, MIRET);
	SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	Ms_LogData(funcindex, "ABS_QCO", result);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);

	A_QUC.Set(FV, 6, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//
	delay_ms(1);
	A_QUC.Set(FV, 6, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_QUC.MeasureVI(20,10);//acm10
	Get_Result(A_QUC, result, MIRET);
	SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	Ms_LogData(funcindex, "ABS_QUC", result);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);

	//F_QT1.Set(FV, 40, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);//
	//delay_ms(1);
	////F_QT1.Set(FV, 40, FXVIe_PLUS_40V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	////delay_ms(1);
	//F_QT1.MeasureVI(20,10);//acm10
	//Get_Result(F_QT1, result, MIRET);
	//SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	//Ms_LogData(funcindex, "ABS_QT1", result);
	//F_QT1.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	Poweroff_tm();
	A_QVR.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	A_QCO.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	A_QUC.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	A_QST.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T32_SupplyIq_Pre(short funcindex, LPCTSTR funclabel)
{
	//return true;

	double Iq_LFmin[SITE_NUM];
	double Iq_LFmax[SITE_NUM];
	double Iq_HF[SITE_NUM];
	double Iq_Slp1[SITE_NUM];
	double Iq_Slp2[SITE_NUM];
	double Iq_Stb1[SITE_NUM];
	double Iq_Stb2[SITE_NUM];
	double Iq_Stb3[SITE_NUM];
	double Iq_FS[SITE_NUM];
	double Vsw[SITE_NUM];

	Test_Iq2(true, Iq_LFmin, Iq_LFmax, Iq_HF, Iq_Slp1, Iq_Slp2, Iq_Stb1, Iq_Stb2, Iq_Stb3, Iq_FS, Vsw);
	Copy_Array(iq1_pre,Iq_LFmin);
	Copy_Array(iq2_pre,Iq_LFmax);
	Ms_LogData(funcindex, "VS_IQlfmin", Iq_LFmin);
	Ms_LogData(funcindex, "VS_IQlfmax", Iq_LFmax);
	Ms_LogData(funcindex, "VS_IQhf", Iq_HF);
	Ms_LogData(funcindex, "VS_IQslp1", Iq_Slp1);
	Ms_LogData(funcindex, "VS_IQslp2", Iq_Slp2);
	Ms_LogData(funcindex, "VS_IQstb1", Iq_Stb1);
	Ms_LogData(funcindex, "VS_IQstb2", Iq_Stb2);
	Ms_LogData(funcindex, "VS_IQstb3", Iq_Stb3);
	Ms_LogData(funcindex, "VS_IQfs", Iq_FS);
	Ms_LogData(funcindex, "VS_VswSleep", Vsw);
	
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T40_LDO(short funcindex, LPCTSTR funclabel)
{
	//QST,QUC,QVR,QCO,QT1,QT2,QT3

	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	double results0[SITE_NUM];
	double results1[SITE_NUM];
	double results2[SITE_NUM];
	double results3[SITE_NUM];
	double results4[SITE_NUM];
	double results5[SITE_NUM];
	double results6[SITE_NUM];
	double results7[SITE_NUM];
	double results8[SITE_NUM];
	double results9[SITE_NUM];
	double results10[SITE_NUM];

	double results0b[SITE_NUM];
	double results1b[SITE_NUM];
	double results2b[SITE_NUM];
	double results0c[SITE_NUM];
	double results1c[SITE_NUM];
	double results2c[SITE_NUM];

	int state0[SITE_NUM];
	int state1[SITE_NUM];
	int state2[SITE_NUM];
	int state3[SITE_NUM];
	int state4[SITE_NUM];
	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];

	double ss_qst[SITE_NUM];
	double ss_quc[SITE_NUM];
	double ss_qco[SITE_NUM];
	double ss_qvr[SITE_NUM];
	double ss_qt1[SITE_NUM];
	double ss_qt2[SITE_NUM];
	double ss_qt3[SITE_NUM];

	double v_fb[SITE_NUM];
	double v_qst[SITE_NUM];
	double v_vst[SITE_NUM];
	double v_quc[SITE_NUM];
	double v_qco[SITE_NUM];
	double v_qvr[SITE_NUM];
	double v_qt1[SITE_NUM];
	double v_qt2[SITE_NUM];
	double v_qt3[SITE_NUM];
	double v_qt1os[SITE_NUM];
	double v_qt2os[SITE_NUM];
	double v_qt3os[SITE_NUM];

	double vdrop = 0;
	double step = 0;

	double rise[SITE_NUM];
	double fall[SITE_NUM];
	double hys[SITE_NUM];

	bool all_vout = true;
	all_resource_off();
	C_All_Open;
	////Power up//////////////////////////////////////////////////////////////////////////////////
	//A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	//C_ACM_VCI_Connect;
	//C_ACM_STU_Connect;
	//C_FRE_PU_Connect;
	//C_DBUFI_FRE;
	//C_ACM_DBUFO_Connect;
	//Poweron_tm();
	//DUT_SPI_Connect(4.0);
	//Cmd_Set_Freq(10 MHz);
	//Cmd_TestMode(true, in_tm);
	//Cmd_Masksafe();
	//set_vsx(6.0);
	//set_fb(5.5);
	//set_quc(5.0);
	//set_fb_plus_target(0.1);//target+0.1V,5.75V
	////quc tsw
	////Cmd_Bank1(true);
	////Cmd_Forceoff(except_prebk_quc);
	//Cmd_Dmuxset_Fs0(25);
	//Cmd_TMSel(0x005B030000000009);//tm134
	//delay_ms(2);//acm1,acm10
	//step = calc_step(0,3,100);
	//awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "quc_tsw", 0 V, 3 V, step, 20, 2.5 V, TRIG_RISING, results1);
	//Ms_LogData(funcindex, "QUC_Tsw", results1);
	//Cmd_Dmuxset_Fs0(24);
	//Cmd_TMSel(0x005B070000000009);//tm135
	//delay_ms(2);
	//awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "quc_tsd", 0 V, 3 V, step, 20, 2.5 V, TRIG_RISING, results1);
	//Ms_LogData(funcindex, "QUC_Tsd", results1);
	////qco tsw
	//A_STU.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	//C_ACM_STU_DisConnect;
	//delay_ms(2);
	//Poweroff_tm();

	//vs
	A_QST.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	fxvi4.Set(FV, 0.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_MPS_PU_Connect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_QUC_CAP_Connect;
	C_VST_VS1_Connect;
	C_ACM_FB1_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	fxvi4.Set(FV, 4.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	set_fb_plus_target(0.1);
	//set_posfb_plus_target(0.1);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(2);
	//ldo_qst_quc_ss("qst_ss", ss_qst, ss_quc);
	ldo_qst_quc_ss_with_ramp("qst_ss", ss_qst, ss_quc);
	Ms_LogData(funcindex, "QST_Tss", ss_qst);
	Ms_LogData(funcindex, "QUC_Tss", ss_quc);
	//C_QST_CAP_Connect;
	//delay_ms(2);
	fxvi4.Set(FV, 6.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	Cmd_En_Stb(true, true);
	//Cmd_En_Ref(true);
	//Cmd_En_Com(true);
	//Cmd_En_Trk();
	delay_ms(2);
	//Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	//QST LineReg
	double qst_load = -1 mA;
	fxvi4.Set(FV, 8.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	A_QST.Set(FI, qst_load, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(3);
	A_QST.MeasureVI(30,10);
	Get_Result(A_QST, results1, MVRET);
	for(int i=8;i<37;i++){fxvi4.Set(FV, i, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);}
	fxvi4.Set(FV, 36.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON,2);
	delay_ms(3);
	A_QST.MeasureVI(30,10);
	Get_Result(A_QST, results2, MVRET);
	SERIAL results3[SITE] = ((results2[SITE] - results1[SITE])*1000.0)/(36.0-8.0);
	Ms_LogData(funcindex, "QST_LineReg", results3);
	fxvi4.Set(FV, 6.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	set_quc(false);
	set_fb(false);
	//set_posfb(false);
	fxvi4.Set(FV, 0.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	A_QST.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(2);
	fxvi4.Set(FV, 0.0, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	A_QST.Set(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	C_All_Open;

	//test ldo//////////////////////////////////////////////////////////////////////////////////
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	A_VCI.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	set_sec_posfre(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	C_ACM_VCI_Connect;
	C_ACM_STU_Connect;
	C_FRE_PU_Connect;
	C_DBUFI_FRE;
	C_ACM_DBUFO_Connect;
	C_ACM_SECPOSFRE_Connect;
	Poweron_tm_hc();
	set_fb_hc(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	//Nvm_PreviewFs(-1);
	set_quc(3.0);
	set_fb_hc(3.0);
	//C_QUC_CAP_DisConnect;
	//C_QCO_CAP_DisConnect;
	//C_QVR_CAP_DisConnect;
	//C_QT1_CAP_DisConnect;
	//C_QT2_CAP_DisConnect;
	//C_QT3_CAP_DisConnect;
	//delay_ms(2);
	//qst
	set_qst(3.0);
	delay_ms(1);
	A_QST.MeasureVI(20,10);
	Get_Result(A_QST, results1, MIRET);
	SERIAL results1[SITE]=results1[SITE]*1000.0;//mA
	Ms_LogData(funcindex, "QST_Ipd", results1);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//quc
	set_quc(3.0);
	delay_ms(1);
	A_QUC.MeasureVI(20,10);
	Get_Result(A_QUC, results1, MIRET);
	SERIAL results1[SITE]=results1[SITE]*1000.0;//mA
	Ms_LogData(funcindex, "QUC_Ipd", results1);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//qco
	set_qco(3.0);
	delay_ms(1);
	A_QCO.MeasureVI(20,10);
	Get_Result(A_QCO, results1, MIRET);
	SERIAL results1[SITE]=results1[SITE]*1000.0;//mA
	Ms_LogData(funcindex, "QCO_Ipd", results1);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//qvr
	set_qvr(3.0);
	delay_ms(1);
	A_QVR.MeasureVI(20,10);
	Get_Result(A_QVR, results1, MIRET);
	SERIAL results1[SITE]=results1[SITE]*1000.0;//mA
	Ms_LogData(funcindex, "QVR_Ipd", results1);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//qt1
	set_qt1(3.0);
	delay_ms(1);
	F_QT1.MeasureVI(20,10);
	Get_Result(F_QT1, results1, MIRET);
	SERIAL results1[SITE]=results1[SITE]*1000.0;//mA
	Ms_LogData(funcindex, "QT1_Ipd", results1);
	SERIAL results1[SITE]=3.0/results1[SITE];//kohm
	Ms_LogData(funcindex, "QT1_Rpd", results1);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//qt2
	set_qt2(3.0);
	delay_ms(1);
	F_QT2.MeasureVI(20,10);
	Get_Result(F_QT2, results1, MIRET);
	SERIAL results1[SITE]=results1[SITE]*1000.0;//mA
	Ms_LogData(funcindex, "QT2_Ipd", results1);
	SERIAL results1[SITE]=3.0/results1[SITE];//kohm
	Ms_LogData(funcindex, "QT2_Rpd", results1);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//qt3
	if(PN_Tracker_Num==3)
	{
		set_qt3(3.0);
		delay_ms(1);
		F_QT3.MeasureVI(20,10);
		Get_Result(F_QT3, results1, MIRET);
		SERIAL results1[SITE]=results1[SITE]*1000.0;//mA
		Ms_LogData(funcindex, "QT3_Ipd", results1);
		SERIAL results1[SITE]=3.0/results1[SITE];//kohm
		Ms_LogData(funcindex, "QT3_Rpd", results1);
		F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	}
	A_QCO.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FV, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	delay_ms(1);
	set_fb_hc(4.5);
	set_quc(4.5);
	set_qst(5.1);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Dis_WwdFwdErrm();
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);//probably need to remove
	//Cmd_Forceoff(except_dcdc);
	Cmd_Forceoff(none_off);
	//delay_ms(1);
	//set_vsx(6.0);
	//set_fb_plus_target_hc(0.1);//target+0.1V
	//delay_ms(5);
	//A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//ldo_ss("ldo_ss", ss_qco,ss_qvr,ss_qt1,ss_qt2,ss_qt3);
	set_vci(0.8);
	ldo_ss_with_ramp("ldo_ss", ss_qco, ss_qvr, ss_qt1, ss_qt2, ss_qt3);
	//set_posfb_plus_target(0.1);//target+0.1V
	//set_posfb(1.5);
	//set_vci(0.8);
	Ms_LogData(funcindex, "QCO_Tss", ss_qco);
	Ms_LogData(funcindex, "QVR_Tss", ss_qvr);
	Ms_LogData(funcindex, "QT1_Tss", ss_qt1);
	Ms_LogData(funcindex, "QT2_Tss", ss_qt2);
	if (PN_Tracker_Num == 3){Ms_LogData(funcindex, "QT3_Tss", ss_qt3);}

	//C_QUC_CAP_Connect;
	//C_QCO_CAP_Connect;
	//C_QVR_CAP_Connect;
	//C_QT1_CAP_Connect;
	//C_QT2_CAP_Connect;
	//C_QT3_CAP_Connect;
	//delay_ms(2);
	//quc tsw
	//Cmd_Bank1(true);
	//Cmd_Forceoff(except_prebk_quc);
	bool meas_tj = true;
	double quc_tsw_tj[SITE_NUM];
	double quc_tsd_tj[SITE_NUM];
	double qco_tsw_tj[SITE_NUM];
	double qco_tsd_tj[SITE_NUM];
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	Cmd_Dmuxset_Fs0(25);
	Cmd_TMSel(0x005B030000000009);//tm134
	//delay_ms(1);//acm1,acm10
	step = calc_step(-0.1,1,100);
	//A_STU.Set(FV, -0.1, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	if(meas_tj)
	{
		A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(100);
		A_STU.MeasureVI(20,10);
		Get_Result(A_STU, quc_tsw_tj, MVRET);
	}
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "quc_tswr", -0.1 V, 1 V, step, 20, 2.5 V, TRIG_RISING, rise);
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "quc_tswf", 1 V, -0.1 V, step, 20, 2.5 V, TRIG_FALLING, fall);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "QUC_TSWriseV", rise);
	Ms_LogData(funcindex, "QUC_TSWfallV", fall);
	Ms_LogData(funcindex, "QUC_TSWhysV", hys);
	if(meas_tj)
	{
		SERIAL rise[SITE]=(quc_tsw_tj[SITE]-rise[SITE])/0.0039;
		SERIAL fall[SITE]=(quc_tsw_tj[SITE]-fall[SITE])/0.0039;
		SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
		Ms_LogData(funcindex, "QUC_TSW_TJ", quc_tsw_tj);
		Ms_LogData(funcindex, "QUC_TSWrise", rise);
		Ms_LogData(funcindex, "QUC_TSWfall", fall);
		Ms_LogData(funcindex, "QUC_TSWhys", hys);
	}
	Cmd_Dmuxset_Fs0(24);
	Cmd_TMSel(0x005B070000000009);//tm135
	if(meas_tj)
	{
		A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(100);
		A_STU.MeasureVI(20,10);
		Get_Result(A_STU, quc_tsd_tj, MVRET);
	}
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "quc_tsdr", -0.1 V, 1 V, step, 20, 2.5 V, TRIG_RISING, rise);
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "quc_tsdf", 1 V, -0.1 V, step, 20, 2.5 V, TRIG_FALLING, fall);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "QUC_TSDriseV", rise);
	Ms_LogData(funcindex, "QUC_TSDfallV", fall);
	Ms_LogData(funcindex, "QUC_TSDhysV", hys);
	if(meas_tj)
	{
		SERIAL rise[SITE]=(quc_tsd_tj[SITE]-rise[SITE])/0.0039;
		SERIAL fall[SITE]=(quc_tsd_tj[SITE]-fall[SITE])/0.0039;
		SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
		Ms_LogData(funcindex, "QUC_TSD_TJ", quc_tsd_tj);
		Ms_LogData(funcindex, "QUC_TSDrise", rise);
		Ms_LogData(funcindex, "QUC_TSDfall", fall);
		Ms_LogData(funcindex, "QUC_TSDhys", hys);
	}
	//qco tsw
	Cmd_Dmuxset_Fs0(46);
	Cmd_TMSel(0x0052030000000009);//tm149
	Cmd_Bank0(true);
	//CmdReadData(0x27,state0);
	//Cmd_Bank1(true);
	//delay_ms(1);
	step = calc_step(-0.1,1,100);
	if(meas_tj)
	{
		A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(100);
		A_STU.MeasureVI(20,10);
		Get_Result(A_STU, qco_tsw_tj, MVRET);
	}
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "qco_tswr", -0.1 V, 1 V, step, 20, 2.5 V, TRIG_RISING, rise);
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "qco_tswf", 1 V, -0.1 V, step, 20, 2.5 V, TRIG_FALLING, fall);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "QCO_TSWriseV", rise);
	Ms_LogData(funcindex, "QCO_TSWfallV", fall);
	Ms_LogData(funcindex, "QCO_TSWhysV", hys);
	if(meas_tj)
	{
		SERIAL rise[SITE]=(qco_tsw_tj[SITE]-rise[SITE])/0.0039;
		SERIAL fall[SITE]=(qco_tsw_tj[SITE]-fall[SITE])/0.0039;
		SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
		Ms_LogData(funcindex, "QCO_TSW_TJ", qco_tsw_tj);
		Ms_LogData(funcindex, "QCO_TSWrise", rise);
		Ms_LogData(funcindex, "QCO_TSWfall", fall);
		Ms_LogData(funcindex, "QCO_TSWhys", hys);
	}
	Cmd_Dmuxset_Fs0(45);
	Cmd_TMSel(0x0051040000000009);//tm150
	if(meas_tj)
	{
		A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(100);
		A_STU.MeasureVI(20,10);
		Get_Result(A_STU, qco_tsd_tj, MVRET);
	}
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "qco_tsdr", -0.1 V, 1 V, step, 20, 2.5 V, TRIG_RISING, rise);
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_10MA, "qco_tsdf", 1 V, -0.1 V, step, 20, 2.5 V, TRIG_FALLING, fall);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "QCO_TSDriseV", rise);
	Ms_LogData(funcindex, "QCO_TSDfallV", fall);
	Ms_LogData(funcindex, "QCO_TSDhysV", hys);
	if(meas_tj)
		{
		SERIAL rise[SITE]=(qco_tsd_tj[SITE]-rise[SITE])/0.0039;
		SERIAL fall[SITE]=(qco_tsd_tj[SITE]-fall[SITE])/0.0039;
		SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
		Ms_LogData(funcindex, "QCO_TSD_TJ", qco_tsd_tj);
		Ms_LogData(funcindex, "QCO_TSDrise", rise);
		Ms_LogData(funcindex, "QCO_TSDfall", fall);
		Ms_LogData(funcindex, "QCO_TSDhys", hys);
	}
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	C_ACM_STU_DisConnect;
	Cmd_Dmuxset_Fs0(0);
	Cmd_TMSel(0x00);//tm150
	//DUT_SPI_Connect(5.0);
	//Cmd_Set_Freq(10 MHz);
	Cmd_Bank0(true);
	//Cmd_Dis_WwdFwdErrm();
	Cmd_Dis_ERR_WD();
	Cmd_ReadState(state0);
	Cmd_Go2_Normal();
	Cmd_ReadState(state1);//2
	Cmd_En_Stb(true, true);
	Cmd_En_Trk();
	delay_ms(1);
	A_VCI.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}

	//if(PN_Tracker_Num==3)
	C_ACM_SECPOSFRE_DisConnect;
	delay_ms(1);
	A_AMUX.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	C_ACM_AMUX_Connect;
	delay_ms(1);
	En_LDO_Comp();
	Cmd_Bank1(true);
	Cmd_TMSel(0x4000000000000000);
	//Vout//////////////////////////////////////////////////////////////////////////////////
	double Vfb = PN_Prebk_Output+0.1;
	double Iload1 = -0.1 mA;
	double Iload2 = -20 mA;
	double Iload3 = -30 mA;
	//qst//////////////////////////////////////////////////////////////////////////////////
	set_vsx(6.0);
	//set_posfb_plus_target(0.0);
	//set_fb_hc(5.0);//6.0
	Cmd_Bank0(true);
	//Cmd_AmuxEn(true);
	Cmd_AmuxEn_Stb(true, true,true);
	//Cmd_AmuxCfg(0x00);//14
	//Cmd_AmuxSel(AMUX_Vqvr);
	//delay_ms(1);
	Cmd_AmuxSel(AMUX_Vqst);
	//Cmd_En_Stb(true, true);//04,83
	delay_ms(10);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_QST.MeasureVI(20,10);
	Get_Result(A_QST, results0, MVRET);//acm0
	ldo_load_test(A_QST, ACM200_10V, ACM200_100MA, "qst_load", 0, -21 mA, Iload1, Iload2, results1, results2, results3);
	SERIAL v_qst[SITE] = results2[SITE];
	if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_LoadReg1", results3);}
	if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_LoadReg2", results3);}
	Ms_LogData(funcindex, "QST_V0", results0);
	if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_V1", v_qst);}
	if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_V2", v_qst);}
	if(all_vout)
	{
		A_QST.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		int code = dut.sel("QST_VOUT").get_working(0);
		dut.sel("QST_VOUT").set_working(0);
		Nvm_PreviewFs(0);
		delay_ms(5);
		A_QST.MeasureVI(20,10);
		Get_Result(A_QST, results0, MVRET);//acm0
		Ms_LogData(funcindex, "QST_V1", results0);
		dut.sel("QST_VOUT").set_working(1);
		Nvm_PreviewFs(0);
		delay_ms(5);
		A_QST.MeasureVI(20,10);
		Get_Result(A_QST, results0, MVRET);//acm0
		Ms_LogData(funcindex, "QST_V2", results0);
		dut.sel("QST_VOUT").set_working(code);
		Nvm_PreviewFs(0);
	}
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_AMUX.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(2);
	C_ACM_AMUX_DisConnect;
	delay_ms(2);
	C_ACM_SECPOSFRE_Connect;
	delay_ms(2);
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	//ldo_ilimit_test(A_QST, ACM200_10V, ACM200_200MA, PN_QST_Output, results1);
	//A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	Cmd_Dmuxset_Fs0(19);//tm175
	Cmd_TMSel(0x0009030000000001);//acm0,acm9
	step = calc_step(0 mA,-70 mA,100);
	awg.rampimi(A_QST, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qst_oc", 0 mA, -70 mA, step, 20, 5 mA, TRIG_RISING, rise);
	F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_INT_Connect;
	delay_ms(1);
	double Ival=3.0 mA;
	F_INT.Set(FI, Ival, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_INT.MeasureVI(100,10);
	Get_Result(F_INT, results1, MVRET, MIN_RESULT);
	Ms_LogData(funcindex, "INT_Vol2", results1);
	SERIAL results1[SITE]=results1[SITE]/Ival;
	Ms_LogData(funcindex, "INT_Rpd2", results1);
	F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_INT_DisConnect;
	delay_ms(1);
	F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	double oc_value[SITE_NUM];
	SERIAL oc_value[SITE]=rise[SITE]-10 mA;
	SERIAL results1[SITE]=-rise[SITE]*1000.0;
	Ms_LogData(funcindex, "QST_Ilimit", results1);
	Cmd_Dmuxset_Fs0(182);//tm176
	Cmd_TMSel(0x0009030000000001);//acm0,acm9
	delay_ms(1);
	int sample = 1000;
	int interval = 2;
	SERIAL {if(oc_value[SITE]>0.1){oc_value[SITE]=0.1;}}
	A_QST.SetSyn(FI, oc_value, SITE_NUM, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//A_QST.Set(FI, -57 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_SECPOSFRE.MeasureVI(sample,interval);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	double CapV[SITE_NUM][1024];
	int point1[SITE_NUM];
	int find1[SITE_NUM];
	SERIAL { A_SECPOSFRE.BlockRead(SITE, 0, sample, CapV[SITE],MIRET); }
	SERIAL
	{
		point1[SITE] = 0;
		find1[SITE] = 0;
		for(int i=0;i<sample;i++)
		{
			if(find1[SITE]==0)
			{
				if(CapV[SITE][i]>5 mA)
				{
					find1[SITE]=1;
					point1[SITE] = i;
				}
			}
		}
		results1[SITE] = (point1[SITE]*interval)/1000.0;//ms
	}

	//step = calc_step(-45 mA,-50 mA,100);
	//double Tpoint[SITE_NUM];
	//qst_dgl(A_QST, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qst_oc_dig", 50 mA, -50 mA, rise);
	//SERIAL Tpoint[SITE]=(rise[SITE]-(-45 mA))/step;
	//SERIAL results1[SITE]=(Tpoint[SITE]*50.0)/1000.0;//ms
	Ms_LogData(funcindex, "QST_Tocdgl", results1);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	C_ACM_SECPOSFRE_DisConnect;
	Cmd_Dmuxset_Fs0(0);
	Cmd_TMSel(0x00);//acm0,acm9
	if(dut.sel("QSTOS_DIS").get_working(0)==0)
	{
		Cmd_En_Stb(true, false);
		A_QST.Set(FI, Iload2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		delay_ms(2);
		A_QST.MeasureVI(30,10);
		A_QUC.MeasureVI(30,10);
		Get_Result(A_QST, results1, MVRET);
		Get_Result(A_QUC, results2, MVRET);
		SERIAL results3[SITE] = (results1[SITE] - results2[SITE])*1000.0;//mV
		if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_Vos1", results3);}
		if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_Vos2", results3);}
		Cmd_Bank1(true);
		A_QST.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		int code = dut.sel("QST_VOUT").get_working(0);
		int code2 = dut.sel("QUC_VOUT").get_working(0);
		A_QST.MeasureVI(20,10);
		Get_Result(A_QST, results0, MVRET);//acm0
		if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_V1os", results0);}
		if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_V2os", results0);}

		//dut.sel("QST_VOUT").set_working(0);
		//dut.sel("QUC_VOUT").set_working(0);
		//Nvm_PreviewFs(0);
		//delay_ms(5);
		//A_QST.MeasureVI(20,10);
		//Get_Result(A_QST, results0, MVRET);//acm0
		//Ms_LogData(funcindex, "QST_V1os", results0);
		//dut.sel("QST_VOUT").set_working(1);
		//dut.sel("QUC_VOUT").set_working(1);
		//Nvm_PreviewFs(0);
		//delay_ms(5);
		//A_QST.MeasureVI(20,10);
		//Get_Result(A_QST, results0, MVRET);//acm0
		//Ms_LogData(funcindex, "QST_V2os", results0);
		//dut.sel("QST_VOUT").set_working(code);
		//dut.sel("QUC_VOUT").set_working(code2);
		//Nvm_PreviewFs(0);
		Cmd_Bank0(true);
		Cmd_En_Stb(true, true);
	}
	//drop out
	set_vsx(6.0);
	C_VS1_CAP_DisConnect;
	C_VST_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	delay_ms(1);
	A_QST.Set(FI, Iload2, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);//fxvi4,acm0
	vdrop = PN_QST_Output*0.99;
	ldo_drop_testf(F_VST, A_QST, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "qst_drop", 6, vdrop, results1);
	Ms_LogData(funcindex, "QST_Vdrop", results1);
	A_QST.Set(FI, Iload3, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);//fxvi4,acm0
	vdrop = PN_QST_Output*0.99;
	ldo_drop_testf(F_VST, A_QST, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "qst_drop", 6, vdrop, results1);
	Ms_LogData(funcindex, "QST_Vdrop30", results1);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	set_vsx(6.0);
	C_VS1_CAP_Connect;
	C_VST_CAP_Connect;
	C_QST_CAP_Connect;
	delay_ms(1);

	//qvr//////////////////////////////////////////////////////////////////////////////////
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);//probably need to remove
	int qvrovfs = dut.sel("QVROVFS").get_working(0);
	dut.sel("QVROVFS").set_working(0);
	//Cmd_Bank1(true);
	Nvm_PreviewFs(4);
	En_LDO_Comp();
	set_vsx(6.0);
	set_fb_plus_target_hc(0.2);
	delay_ms(1);
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	Cmd_ReadState(state2);//2
	Cmd_En_Trk();
	//Cmd_En_Ref(true);
	C_FB_CAP_Connect;
	Iload1 = -1 mA;
	Iload2 = -150 mA;
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	C_FPVIH_QVR_Connect;
	C_FPVIL_FB_Connect;
	delay_ms(1);
	A_QVR.Set(FI, -1 mA, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_QVR.MeasureVI(50,10);
	fpvi0.MeasureVI(50,10);
	F_FB.MeasureVI(50,10);
	Get_Result(A_QVR, results0, MVRET);
	Get_Result(fpvi0, results0b, MVRET);
	Get_Result(F_FB, results0c, MVRET);
	fpvi0.Set(FI, Iload1, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(2);
	A_QVR.MeasureVI(50,10);
	fpvi0.MeasureVI(50,10);
	F_FB.MeasureVI(50,10);
	Get_Result(A_QVR, results1, MVRET);
	Get_Result(fpvi0, results1b, MVRET);
	Get_Result(F_FB, results1c, MVRET);
	fpvi0.Set(FI, Iload2, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON,1);
	delay_ms(2);
	A_QVR.MeasureVI(50,10);
	fpvi0.MeasureVI(50,10);
	F_FB.MeasureVI(50,10);
	Get_Result(A_QVR, results2, MVRET);
	Get_Result(fpvi0, results2b, MVRET);
	Get_Result(F_FB, results2c, MVRET);
	//SERIAL results3[SITE] = (results1[SITE] - results2[SITE])*1000.0;
	SERIAL results3[SITE] = ((results1c[SITE]+results1b[SITE]) - (results2c[SITE]+results2b[SITE]))*1000.0;
	//SERIAL v_qvr[SITE] = v_fb[SITE]-results2b[SITE];
	SERIAL v_qvr[SITE] = results2[SITE];
	if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_LoadReg1", results3);}
	if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_LoadReg2", results3);}
	Ms_LogData(funcindex, "QVR_V0", results0);
	if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_V1", v_qvr);}
	if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_V2", v_qvr);}
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON,1);
	if(all_vout)
	{
		A_QVR.Set(FI, -10 mA, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
		int code = dut.sel("QVR_VOUT").get_working(0);
		dut.sel("QVR_VOUT").set_working(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		A_QVR.MeasureVI(20,10);
		fpvi0.MeasureVI(20,10);
		F_FB.MeasureVI(20,10);
		Get_Result(A_QVR, results0, MVRET);
		Get_Result(fpvi0, results0b, MVRET);
		Get_Result(F_FB, results0c, MVRET);
		SERIAL results3[SITE] = results0c[SITE]+results0b[SITE];
		Ms_LogData(funcindex, "QVR_V1", results3);
		dut.sel("QVR_VOUT").set_working(1);
		Nvm_PreviewFs(1);
		delay_ms(10);
		A_QVR.MeasureVI(20,10);
		fpvi0.MeasureVI(20,10);
		F_FB.MeasureVI(20,10);
		Get_Result(A_QVR, results0, MVRET);
		Get_Result(fpvi0, results0b, MVRET);
		Get_Result(F_FB, results0c, MVRET);
		SERIAL results3[SITE] = results0c[SITE]+results0b[SITE];
		Ms_LogData(funcindex, "QVR_V2", results3);
		dut.sel("QVR_VOUT").set_working(code);
		Nvm_PreviewFs(1);
	}
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_1A, FPVIe_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	ldo_ilimit_test(fpvi0, FPVIe_5V, FPVIe_1A, Vfb, PN_QVR_Output_Target, results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	Ms_LogData(funcindex, "QVR_Ilimit", results1);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, -150 mA, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	delay_ms(1);//fxvi0,acm3
	vdrop = PN_QVR_Output*0.99;
	ldo_drop_test(F_FB, A_QVR, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qvr_drop", Vfb, vdrop, results1);
	Ms_LogData(funcindex, "QVR_Vdrop", results1);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	delay_ms(1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	C_FPVIH_QVR_DisConnect;
	C_FPVIL_FB_DisConnect;
	delay_ms(1);
	dut.sel("QVROVFS").set_working(qvrovfs);
	Cmd_Bank1(true);
	Nvm_PreviewFs(4);
	//quc//////////////////////////////////////////////////////////////////////////////////
	C_FB_CAP_Connect;
	set_vsx(6.0);
	//set_qst(5.1);
	set_fb_plus_target_hc(0.2);
	//A_QCO.MeasureVI(2000,10);
	A_STU.Set(FI,0,ACM200_3p6V, ACM200_10MA,ACM200_RELAY_ON);
	C_ACM_STU_Connect;
	C_FRE_PU_Connect;
	C_DBUFI_FRE;
	C_ACM_DBUFO_Connect;
	C_ACM_SECPOSFRE_Connect;
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(48);
	Cmd_TMSel(0x0041030000000001);//acm2,acm10
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	//0,1,2,3
	//0,4,8,12
	double start=0;
	double stop=0;
	//double step=0;
	//double rise[SITE_NUM];
	//double fall[SITE_NUM];
	CmdWriteData(DEVCFG2,0);
	start = 0 mA;
	stop = -30 mA;
	step = calc_step(start,stop,100);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampimv(A_QUC, A_DBUFO, ACM200_10V, ACM200_200MA, "quc_lp", start, stop, 1 mA, 20, 2.5 V, TRIG_FALLING, rise);
	awg.rampimv(A_QUC, A_DBUFO, ACM200_10V, ACM200_200MA, "quc_lp", stop, start, 1 mA, 20, 2.5 V, TRIG_RISING, fall);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	SERIAL rise[SITE]=-rise[SITE]*1000.0;
	SERIAL fall[SITE]=-fall[SITE]*1000.0;
	SERIAL hys[SITE]=((rise[SITE]-fall[SITE])/fall[SITE])*100.0;
	Ms_LogData(funcindex, "QUC_Imon_10", rise);
	Ms_LogData(funcindex, "QUC_Imon_10fall", fall);
	Ms_LogData(funcindex, "QUC_Imon_10hys", hys);
	CmdWriteData(DEVCFG2,4);
	start = -20 mA;
	stop = -50 mA;
	step = calc_step(start,stop,100);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampimv(A_QUC, A_DBUFO, ACM200_10V, ACM200_200MA, "quc_lp", start, stop, 1 mA, 20, 2.5 V, TRIG_FALLING, rise);
	awg.rampimv(A_QUC, A_DBUFO, ACM200_10V, ACM200_200MA, "quc_lp", stop, start, 1 mA, 20, 2.5 V, TRIG_RISING, fall);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	SERIAL results1[SITE]=-results1[SITE]*1000.0;
	SERIAL rise[SITE]=-rise[SITE]*1000.0;
	SERIAL fall[SITE]=-fall[SITE]*1000.0;
	SERIAL hys[SITE]=((rise[SITE]-fall[SITE])/fall[SITE])*100.0;
	Ms_LogData(funcindex, "QUC_Imon_30", rise);
	Ms_LogData(funcindex, "QUC_Imon_30fall", fall);
	Ms_LogData(funcindex, "QUC_Imon_30hys", hys);
	CmdWriteData(DEVCFG2,8);
	start = -40 mA;
	stop = -100 mA;
	step = calc_step(start,stop,100);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampimv(A_QUC, A_DBUFO, ACM200_10V, ACM200_200MA, "quc_lp", start, stop, 1 mA, 20, 2.5 V, TRIG_FALLING, rise);
	awg.rampimv(A_QUC, A_DBUFO, ACM200_10V, ACM200_200MA, "quc_lp", stop, start, 1 mA, 20, 2.5 V, TRIG_RISING, fall);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	SERIAL results1[SITE]=-results1[SITE]*1000.0;
	SERIAL rise[SITE]=-rise[SITE]*1000.0;
	SERIAL fall[SITE]=-fall[SITE]*1000.0;
	SERIAL hys[SITE]=((rise[SITE]-fall[SITE])/fall[SITE])*100.0;
	Ms_LogData(funcindex, "QUC_Imon_60", rise);
	Ms_LogData(funcindex, "QUC_Imon_60fall", fall);
	Ms_LogData(funcindex, "QUC_Imon_60hys", hys);
	CmdWriteData(DEVCFG2,12);
	start = -80 mA;
	stop = -150 mA;
	step = calc_step(start,stop,100);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampimv(A_QUC, A_DBUFO, ACM200_10V, ACM200_200MA, "quc_lp", start, stop, 1 mA, 20, 2.5 V, TRIG_FALLING, rise);
	awg.rampimv(A_QUC, A_DBUFO, ACM200_10V, ACM200_200MA, "quc_lp", stop, start, 1 mA, 20, 2.5 V, TRIG_RISING, fall);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	SERIAL results1[SITE]=-results1[SITE]*1000.0;
	SERIAL rise[SITE]=-rise[SITE]*1000.0;
	SERIAL fall[SITE]=-fall[SITE]*1000.0;
	SERIAL hys[SITE]=((rise[SITE]-fall[SITE])/fall[SITE])*100.0;
	Ms_LogData(funcindex, "QUC_Imon_100", rise);
	Ms_LogData(funcindex, "QUC_Imon_100fall", fall);
	Ms_LogData(funcindex, "QUC_Imon_100hys", hys);
	Cmd_Dmuxset_Main(0);

	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	A_STU.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	A_DBUFO.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);
	C_ACM_STU_DisConnect;
	C_FRE_PU_DisConnect;
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	C_ACM_SECPOSFRE_DisConnect;
	
	//Cmd_Bank1(true);
	//Cmd_LDO_Comp();
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	Cmd_ReadState(state2);//2
	//A_QCO.MeasureVI(2000,10);
	C_FB_CAP_Connect;
	Iload1 = -50 mA;
	Iload2 = -850 mA;
	Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_700mA, QUCLMT_850mA, PDDLY_0ms);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	C_FPVIH_QUC_Connect;
	C_FPVIL_FB_Connect;
	delay_ms(1);
	A_QUC.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_QUC.MeasureVI(20,10);
	fpvi0.MeasureVI(20,10);
	F_FB.MeasureVI(20,10);
	Get_Result(A_QUC, results0, MVRET);
	Get_Result(fpvi0, results0b, MVRET);
	Get_Result(F_FB, results0c, MVRET);
	fpvi0.Set(FI, Iload1, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	delay_ms(2);
	A_QUC.MeasureVI(20,10);
	fpvi0.MeasureVI(20,10);
	F_FB.MeasureVI(20,10);
	Get_Result(A_QUC, results1, MVRET);
	Get_Result(fpvi0, results1b, MVRET);
	Get_Result(F_FB, results1c, MVRET);
	fpvi0.Set(FI, Iload2, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	delay_ms(2);
	A_QUC.MeasureVI(20,10);
	fpvi0.MeasureVI(20,10);
	F_FB.MeasureVI(20,10);
	Get_Result(A_QUC, results2, MVRET);
	Get_Result(fpvi0, results2b, MVRET);
	Get_Result(F_FB, results2c, MVRET);
	//SERIAL results3[SITE] = (results1[SITE] - results2[SITE])*1000.0;
	SERIAL results3[SITE] = ((results1c[SITE]+results1b[SITE]) - (results2c[SITE]+results2b[SITE]))*1000.0;
	SERIAL v_quc[SITE] = results2[SITE];
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "QUC_LoadReg1", results3);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "QUC_LoadReg2", results3);}
	Ms_LogData(funcindex, "QUC_V0", results0);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "QUC_V1", v_quc);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "QUC_V2", v_quc);}
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	if(all_vout)
	{
		A_QUC.Set(FI, -10 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		int code = dut.sel("QUC_VOUT").get_working(0);
		dut.sel("QUC_VOUT").set_working(0);
		Nvm_PreviewFs(0);
		delay_ms(5);
		A_QUC.MeasureVI(20,10);
		fpvi0.MeasureVI(20,10);
		F_FB.MeasureVI(20,10);
		Get_Result(A_QUC, results0, MVRET);
		Get_Result(fpvi0, results0b, MVRET);
		Get_Result(F_FB, results0c, MVRET);
		SERIAL results3[SITE] = results0c[SITE]+results0b[SITE];
		Ms_LogData(funcindex, "QUC_V1", results3);
		dut.sel("QUC_VOUT").set_working(1);
		Nvm_PreviewFs(0);
		delay_ms(10);
		A_QUC.MeasureVI(20,10);
		fpvi0.MeasureVI(20,10);
		F_FB.MeasureVI(20,10);
		Get_Result(A_QUC, results0, MVRET);
		Get_Result(fpvi0, results0b, MVRET);
		Get_Result(F_FB, results0c, MVRET);
		SERIAL results3[SITE] = results0c[SITE]+results0b[SITE];
		Ms_LogData(funcindex, "QUC_V2", results3);
		dut.sel("QUC_VOUT").set_working(code);
		Nvm_PreviewFs(0);
	}
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_700mA, QUCLMT_600mA, PDDLY_0ms);
	//CmdWriteData(LMT_PD_CFG,0x00);
	//CmdReadData(LMT_PD_CFG,data0);
	delay_ms(1);
	ldo_ilimit_test(fpvi0, FPVIe_5V, FPVIe_2A, Vfb, PN_QUC_Output, results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	Ms_LogData(funcindex, "QUC_Ilimit2", results1);
	Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_700mA, QUCLMT_850mA, PDDLY_0ms);
	//CmdWriteData(LMT_PD_CFG,0x10);
	//CmdReadData(LMT_PD_CFG,data1);
	delay_ms(1);
	ldo_ilimit_test(fpvi0, FPVIe_5V, FPVIe_2A, Vfb, PN_QUC_Output, results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	Ms_LogData(funcindex, "QUC_Ilimit1", results1);
	delay_ms(1);
	//Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_200mA, QUCLMT_850mA, PDDLY_0ms);
	fpvi0.Set(FI, -600 mA, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	delay_ms(1);//fxvi0,acm2
	vdrop = PN_QUC_Output*0.99;
	ldo_drop_test(F_FB, A_QUC, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "quc_drop", Vfb, vdrop, results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	set_fb_plus_target_hc(0.2);
	Ms_LogData(funcindex, "QUC_Vdrop1", results1);
	fpvi0.Set(FI, -850 mA, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	delay_ms(1);
	ldo_drop_test(F_FB, A_QUC, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "quc_drop", Vfb, vdrop, results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	Ms_LogData(funcindex, "QUC_Vdrop2", results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	C_FPVIH_QUC_DisConnect;
	C_FPVIL_FB_DisConnect;
	delay_ms(1);
	//A_QCO.MeasureVI(2000,10);
	//qco//////////////////////////////////////////////////////////////////////////////////
	//Cmd_Bank1(true);
	//Cmd_LDO_Comp();
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	Cmd_ReadState(state2);//2
	Cmd_En_Stb(true, true);
	Cmd_En_Trk();
	C_FB_CAP_Connect;
	Iload1 = -1 mA;
	Iload2 = -700 mA;//700
	Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_700mA, QUCLMT_600mA, PDDLY_0ms);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	C_FPVIH_QCO_Connect;
	C_FPVIL_FB_Connect;
	delay_ms(1);
	A_QCO.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_QCO.MeasureVI(20,10);
	fpvi0.MeasureVI(20,10);
	F_FB.MeasureVI(20,10);
	Get_Result(A_QCO, results0, MVRET);
	Get_Result(fpvi0, results0b, MVRET);
	Get_Result(F_FB, results0c, MVRET);
	fpvi0.Set(FI, Iload1, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	delay_ms(2);
	A_QCO.MeasureVI(20,10);
	fpvi0.MeasureVI(20,10);
	F_FB.MeasureVI(20,10);
	Get_Result(A_QCO, results1, MVRET);
	Get_Result(fpvi0, results1b, MVRET);
	Get_Result(F_FB, results1c, MVRET);
	fpvi0.Set(FI, Iload2, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	delay_ms(2);
	A_QCO.MeasureVI(20,10);
	fpvi0.MeasureVI(20,10);
	F_FB.MeasureVI(20,10);
	Get_Result(A_QCO, results2, MVRET);
	Get_Result(fpvi0, results2b, MVRET);
	Get_Result(F_FB, results2c, MVRET);
	//SERIAL results3[SITE] = (results1[SITE] - results2[SITE])*1000.0;
	SERIAL results3[SITE] = ((results1c[SITE]+results1b[SITE]) - (results2c[SITE]+results2b[SITE]))*1000.0;
	SERIAL v_qco[SITE] = results2[SITE];
	if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_LoadReg1", results3);}
	if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_LoadReg2", results3);}
	if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_LoadReg3", results3);}
	Ms_LogData(funcindex, "QCO_V0", results0);
	if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_V1", v_qco);}
	if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_V2", v_qco);}
	if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_V3", v_qco);}
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	if(all_vout)
	{
		A_QCO.Set(FI, -10 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		int code = dut.sel("QCO_VOUT").get_working(0);
		dut.sel("QCO_VOUT").set_working(0);
		Cmd_Bank1(true);
		Nvm_PreviewFs(1);
		delay_ms(5);
		A_QCO.MeasureVI(20,10);
		fpvi0.MeasureVI(20,10);
		F_FB.MeasureVI(20,10);
		Get_Result(A_QCO, results0, MVRET);
		Get_Result(fpvi0, results0b, MVRET);
		Get_Result(F_FB, results0c, MVRET);
		SERIAL results3[SITE] = results0c[SITE]+results0b[SITE];
		Ms_LogData(funcindex, "QCO_V1", results3);
		dut.sel("QCO_VOUT").set_working(1);
		Nvm_PreviewFs(1);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
		delay_ms(10);
		A_QCO.MeasureVI(20,10);
		fpvi0.MeasureVI(20,10);
		F_FB.MeasureVI(20,10);
		Get_Result(A_QCO, results0, MVRET);
		Get_Result(fpvi0, results0b, MVRET);
		Get_Result(F_FB, results0c, MVRET);
		SERIAL results3[SITE] = results0c[SITE]+results0b[SITE];
		Ms_LogData(funcindex, "QCO_V2", results3);
		dut.sel("QCO_VOUT").set_working(3);
		Nvm_PreviewFs(1);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
		delay_ms(10);
		A_QCO.MeasureVI(20,10);
		fpvi0.MeasureVI(20,10);
		F_FB.MeasureVI(20,10);
		Get_Result(A_QCO, results0, MVRET);
		Get_Result(fpvi0, results0b, MVRET);
		Get_Result(F_FB, results0c, MVRET);
		SERIAL results3[SITE] = results0c[SITE]+results0b[SITE];
		Ms_LogData(funcindex, "QCO_V3", results3);
		dut.sel("QCO_VOUT").set_working(code);
		Nvm_PreviewFs(1);
	}
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_700mA, QUCLMT_600mA, PDDLY_0ms);
	delay_ms(1);
	ldo_ilimit_test(fpvi0, FPVIe_5V, FPVIe_2A, Vfb, PN_QCO_Output, results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	Ms_LogData(funcindex, "QCO_Ilimit1", results1);
	Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_200mA, QUCLMT_600mA, PDDLY_0ms);
	delay_ms(1);
	ldo_ilimit_test(fpvi0, FPVIe_5V, FPVIe_2A, Vfb, PN_QCO_Output, results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	Ms_LogData(funcindex, "QCO_Ilimit2", results1);
	delay_ms(1);
	Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_700mA, QUCLMT_600mA, PDDLY_0ms);
	delay_ms(1);
	vdrop = PN_QCO_Output*0.99;
	//fpvi0.Set(FI, -100 mA, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	fpvi0.Set(FI, -200 mA, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	//delay_ms(1);
	ldo_drop_test(F_FB, A_QCO, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qco_drop", Vfb, vdrop, results1);//fxvi0,acm4
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	Ms_LogData(funcindex, "QCO_Vdrop2", results1);
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	//Cmd_ReadState(state2);//2
	Cmd_En_Stb(true, true);
	Cmd_En_Trk();
	fpvi0.Set(FI, -700 mA, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
	//delay_ms(1);
	ldo_drop_test(F_FB, A_QCO, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qco_drop", Vfb, vdrop, results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
	Ms_LogData(funcindex, "QCO_Vdrop1", results1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
	C_FPVIH_QCO_DisConnect;
	C_FPVIL_FB_DisConnect;
	delay_ms(1);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_OFF);

	QVM_Init();
	QVM_Connect();
	//A_AMUX.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	//C_ACM_AMUX_Connect;
	//delay_ms(1);
	//qt1//////////////////////////////////////////////////////////////////////////////////
	double iload = -1.0 mA;
	A_QVR.Set(FI, iload, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	En_LDO_Comp();
	//int data0[SITE_NUM];
	//int data1[SITE_NUM];
	//int data2[SITE_NUM];
	Cmd_Bank0();
	//double vqt1[SITE_NUM];
	Cmd_AmuxEn(true);
	Cmd_AmuxSel(AMUX_Vqt1);//div 2.5
	Cmd_En_Trk();
	//A_AMUX.MeasureVI(20,10);
	//Get_Result(A_AMUX, vqt1, MVRET);
	//SERIAL vqt1[SITE]=vqt1[SITE]*2.5;
	////CmdReadData(0x27,data0);
	////CmdReadData(0x33,data1);
	set_vsx(6.0);
	set_fb_plus_target_hc(0.2);
	C_FB_CAP_Connect;
	//C_QT1_CAP_Connect;
	Iload1 = -0.1 mA;
	Iload2 = -200 mA;
	F_QT1.Set(FI, iload, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	qt1_qvr_os(results0, v_qt1os);
	F_QT1.Set(FI, Iload1, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	//C_PWRX_QT1_Connect;
	//C_QTMUB_PWRX_Connect;
	//C_QTMUB_DBUFO_Connect;
	//C_ACM_DBUFO_Connect;
	C_ACM_ABUFO_Connect;
	C_QVMH_ABUFO_Connect;
	C_QVML_GND_Connect;
	ldo_load_test(F_QT1, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt1_load", 0, -201 mA, Iload1, Iload2, results1, results2, results3);
	//C_PWRX_QT1_DisConnect;
	//C_QTMUB_DisConnect;
	//C_ACM_DBUFO_DisConnect;
	C_ACM_ABUFO_DisConnect;
	C_QVMH_DisConnect;
	C_QVML_DisConnect;
	SERIAL v_qt1[SITE] = results2[SITE];
	if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_LoadReg1", results3);}
	if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_LoadReg2", results3);}
	if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_LoadReg3", results3);}
	Ms_LogData(funcindex, "QT1_V0", results0);
	if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_V1", v_qt1);}
	if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_V2", v_qt1);}
	if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_V3", v_qt1);}
	Cmd_Bank0();
	Cmd_En_Trk();
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	ldo_ilimit_test(F_QT1, FXVIe_PLUS_10V, FXVIe_PLUS_1A, PN_QT1_Output, results1);
	Ms_LogData(funcindex, "QT1_Ilimit", results1);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);

	//F_FB.Set(FV, 5.8, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_QT1.Set(FV, 5.8, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_QT1.MeasureVI(1000,10);
	//F_FB.MeasureVI(1000,10);
	//F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);

	F_QT1.Set(FI, -100 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	delay_ms(1);
	vdrop = PN_QT1_Output*0.99;
	ldo_drop_test(F_FB, F_QT1, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt1_drop", Vfb, vdrop, results1);
	Ms_LogData(funcindex, "QT1_Vdrop_100", results1);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	Cmd_Bank0();
	Cmd_En_Trk();
	F_QT1.Set(FI, -190 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	delay_ms(1);
	vdrop = PN_QT1_Output*0.99;
	ldo_drop_test(F_FB, F_QT1, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt1_drop", Vfb, vdrop, results1);
	Ms_LogData(funcindex, "QT1_Vdrop", results1);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	if(all_vout)
	{
		F_QT1.Set(FI, -10 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
		int code = dut.sel("QT1_VOUT").get_working(0);
		dut.sel("QT1_VOUT").set_working(3);
		Cmd_Bank1(true);
		Nvm_PreviewFs(2);
		delay_ms(5);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
		F_QT1.Set(FI, -1 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
		delay_ms(5);
		F_QT1.MeasureVI(20,10);
		Get_Result(F_QT1, results0, MVRET);//acm0
		Ms_LogData(funcindex, "QT1_V3", results0);
		dut.sel("QT1_VOUT").set_working(2);
		Cmd_Bank1(true);
		Nvm_PreviewFs(2);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
		delay_ms(5);
		F_QT1.MeasureVI(20,10);
		Get_Result(F_QT1, results0, MVRET);//acm0
		Ms_LogData(funcindex, "QT1_V2", results0);
		dut.sel("QT1_VOUT").set_working(1);
		Cmd_Bank1(true);
		Nvm_PreviewFs(2);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
		delay_ms(5);
		F_QT1.MeasureVI(20,10);
		Get_Result(F_QT1, results0, MVRET);//acm0
		Ms_LogData(funcindex, "QT1_V1", results0);
		dut.sel("QT1_VOUT").set_working(code);
		Cmd_Bank1(true);
		Nvm_PreviewFs(2);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
	}
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	//ldo_ilimit_test(F_QT1, FXVIe_PLUS_10V, FXVIe_PLUS_1A, PN_QT1_Output, results1);
	//Ms_LogData(funcindex, "QT1_Ilimit", results1);
	//F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	//F_QT1.Set(FI, -190 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	//delay_ms(1);
	//vdrop = PN_QT1_Output*0.99;
	//ldo_drop_test(F_FB, F_QT1, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt1_drop", Vfb, vdrop, results1);
	//Ms_LogData(funcindex, "QT1_Vdrop", results1);
	//F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);

	//qt2//////////////////////////////////////////////////////////////////////////////////
	Cmd_Bank0();
	Cmd_AmuxEn(true);
	Cmd_AmuxSel(AMUX_Vqt2);//div 2.5
	Cmd_En_Trk();
	//CmdReadData(0x27,data0);
	//CmdReadData(0x33,data1);
	set_vsx(6.0);
	set_fb_plus_target_hc(0.2);
	C_FB_CAP_Connect;
	Iload1 = -0.1 mA;
	Iload2 = -200 mA;
	F_QT2.Set(FI, iload, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	qt2_qvr_os(results0, v_qt2os);
	F_QT2.Set(FI, Iload1, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	//C_PWRX_QT2_Connect;
	//C_QTMUB_PWRX_Connect;
	//C_QTMUB_DBUFO_Connect;
	//C_ACM_DBUFO_Connect;
	C_ACM_ABUFO_Connect;
	C_QVMH_ABUFO_Connect;
	C_QVML_GND_Connect;
	ldo_load_test(F_QT2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt2_load", 0, -201 mA, Iload1, Iload2, results1, results2, results3);
	//C_PWRX_QT2_DisConnect;
	//C_QTMUB_DisConnect;
	//C_ACM_DBUFO_DisConnect;
	C_ACM_ABUFO_DisConnect;
	C_QVMH_DisConnect;
	C_QVML_DisConnect;
	SERIAL v_qt2[SITE] = results2[SITE];
	if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_LoadReg1", results3);}
	if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_LoadReg2", results3);}
	if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_LoadReg3", results3);}
	Ms_LogData(funcindex, "QT2_V0", results0);
	if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_V1", v_qt2);}
	if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_V2", v_qt2);}
	if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_V3", v_qt2);}
	Cmd_Bank0();
	Cmd_En_Trk();
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	ldo_ilimit_test(F_QT2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, PN_QT2_Output, results1);
	Ms_LogData(funcindex, "QT2_Ilimit", results1);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	F_QT2.Set(FI, -100 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	delay_ms(1);
	vdrop = PN_QT2_Output*0.99;
	ldo_drop_test(F_FB, F_QT2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt2_drop", Vfb, vdrop, results1);
	Ms_LogData(funcindex, "QT2_Vdrop_100", results1);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	Cmd_Bank0();
	Cmd_En_Trk();
	F_QT2.Set(FI, -190 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	delay_ms(1);
	vdrop = PN_QT2_Output*0.99;
	ldo_drop_test(F_FB, F_QT2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt2_drop", Vfb, vdrop, results1);
	Ms_LogData(funcindex, "QT2_Vdrop", results1);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	if(all_vout)
	{
		F_QT2.Set(FI, -10 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
		int code = dut.sel("QT2_VOUT").get_working(0);
		dut.sel("QT2_VOUT").set_working(3);
		Cmd_Bank1(true);
		Nvm_PreviewFs(2);
		delay_ms(5);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
		F_QT2.Set(FI, -1 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
		delay_ms(5);
		F_QT2.MeasureVI(20,10);
		Get_Result(F_QT2, results0, MVRET);//acm0
		Ms_LogData(funcindex, "QT2_V3", results0);
		dut.sel("QT2_VOUT").set_working(2);
		Cmd_Bank1(true);
		Nvm_PreviewFs(2);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
		delay_ms(5);
		F_QT2.MeasureVI(20,10);
		Get_Result(F_QT2, results0, MVRET);//acm0
		Ms_LogData(funcindex, "QT2_V2", results0);
		dut.sel("QT2_VOUT").set_working(1);
		Cmd_Bank1(true);
		Nvm_PreviewFs(2);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
		delay_ms(5);
		F_QT2.MeasureVI(20,10);
		Get_Result(F_QT2, results0, MVRET);//acm0
		Ms_LogData(funcindex, "QT2_V1", results0);
		dut.sel("QT2_VOUT").set_working(code);
		Cmd_Bank1(true);
		Nvm_PreviewFs(2);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(state2);//2
		Cmd_En_Stb(true, true);
		Cmd_En_Trk();
	}
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	//ldo_ilimit_test(F_QT2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, PN_QT2_Output, results1);
	//Ms_LogData(funcindex, "QT2_Ilimit", results1);
	//F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	//F_QT2.Set(FI, -190 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
	//delay_ms(1);
	//vdrop = PN_QT2_Output*0.99;
	//ldo_drop_test(F_FB, F_QT2, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt2_drop", Vfb, vdrop, results1);
	//Ms_LogData(funcindex, "QT2_Vdrop", results1);
	//F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);

	//qt3//////////////////////////////////////////////////////////////////////////////////
	if(PN_Tracker_Num==3)
	{
		Cmd_Bank0();
		Cmd_AmuxEn(true);
		Cmd_AmuxSel(AMUX_Vqt3);//div 2.5
		Cmd_En_Trk();
		//CmdReadData(0x27,data0);
		//CmdReadData(0x33,data1);
		set_vsx(6.0);
		set_fb_plus_target_hc(0.2);
		C_FB_CAP_Connect;
		Iload1 = -0.1 mA;
		Iload2 = -200 mA;
		F_QT3.Set(FI, iload, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
		qt3_qvr_os(results0, v_qt3os);
		F_QT3.Set(FI, Iload1, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
		//C_PWRX_QT3_Connect;
		//C_QTMUB_PWRX_Connect;
		//C_QTMUB_DBUFO_Connect;
		//C_ACM_DBUFO_Connect;
		C_ACM_ABUFO_Connect;
		C_QVMH_ABUFO_Connect;
		C_QVML_GND_Connect;
		ldo_load_test(F_QT3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt3_load", 0, -201 mA, Iload1, Iload2, results1, results2, results3);
		//C_PWRX_QT3_DisConnect;
		//C_QTMUB_DisConnect;
		//C_ACM_DBUFO_DisConnect;
		C_ACM_ABUFO_DisConnect;
		C_QVMH_DisConnect;
		C_QVML_DisConnect;
		SERIAL v_qt3[SITE] = results2[SITE];
		if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_LoadReg1", results3);}
		if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_LoadReg2", results3);}
		if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_LoadReg3", results3);}
		Ms_LogData(funcindex, "QT3_V0", results0);
		if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_V1", v_qt3);}
		if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_V2", v_qt3);}
		if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_V3", v_qt3);}
		Cmd_Bank0();
		Cmd_En_Trk();
		F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
		ldo_ilimit_test(F_QT3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, PN_QT3_Output, results1);
		Ms_LogData(funcindex, "QT3_Ilimit", results1);
		F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
		F_QT3.Set(FI, -100 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
		delay_ms(1);
		vdrop = PN_QT3_Output*0.99;
		ldo_drop_test(F_FB, F_QT3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt3_drop", Vfb, vdrop, results1);
		Ms_LogData(funcindex, "QT3_Vdrop_100", results1);
		F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
		Cmd_Bank0();
		Cmd_En_Trk();
		F_QT3.Set(FI, -190 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
		delay_ms(1);
		vdrop = PN_QT3_Output*0.99;
		ldo_drop_test(F_FB, F_QT3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt3_drop", Vfb, vdrop, results1);
		Ms_LogData(funcindex, "QT3_Vdrop", results1);
		F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
		if(all_vout)
		{
			F_QT3.Set(FI, -10 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
			int code = dut.sel("QT3_VOUT").get_working(0);
			dut.sel("QT3_VOUT").set_working(3);
			Cmd_Bank1(true);
			Nvm_PreviewFs(2);
			delay_ms(5);
			Cmd_Bank0(true);
			Cmd_Dis_ERR_WD();
			Cmd_Go2_Normal();
			Cmd_ReadState(state2);//2
			Cmd_En_Stb(true, true);
			Cmd_En_Trk();
			F_QT3.Set(FI, -1 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
			delay_ms(5);
			F_QT3.MeasureVI(20,10);
			Get_Result(F_QT3, results0, MVRET);//acm0
			Ms_LogData(funcindex, "QT3_V3", results0);
			dut.sel("QT3_VOUT").set_working(2);
			Cmd_Bank1(true);
			Nvm_PreviewFs(2);
			Cmd_Bank0(true);
			Cmd_Dis_ERR_WD();
			Cmd_Go2_Normal();
			Cmd_ReadState(state2);//2
			Cmd_En_Stb(true, true);
			Cmd_En_Trk();
			delay_ms(5);
			F_QT3.MeasureVI(20,10);
			Get_Result(F_QT3, results0, MVRET);//acm0
			Ms_LogData(funcindex, "QT3_V2", results0);
			dut.sel("QT3_VOUT").set_working(1);
			Cmd_Bank1(true);
			Nvm_PreviewFs(2);
			Cmd_Bank0(true);
			Cmd_Dis_ERR_WD();
			Cmd_Go2_Normal();
			Cmd_ReadState(state2);//2
			Cmd_En_Stb(true, true);
			Cmd_En_Trk();
			delay_ms(5);
			F_QT3.MeasureVI(20,10);
			Get_Result(F_QT3, results0, MVRET);//acm0
			Ms_LogData(funcindex, "QT3_V1", results0);
			dut.sel("QT3_VOUT").set_working(code);
			Cmd_Bank1(true);
			Nvm_PreviewFs(2);
			Cmd_Bank0(true);
			Cmd_Dis_ERR_WD();
			Cmd_Go2_Normal();
			Cmd_ReadState(state2);//2
			Cmd_En_Stb(true, true);
			Cmd_En_Trk();
		}
		F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
		//ldo_ilimit_test(F_QT3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, PN_QT3_Output, results1);
		//Ms_LogData(funcindex, "QT3_Ilimit", results1);
		//F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
		//F_QT3.Set(FI, -190 mA, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON,1);
		//delay_ms(1);
		//vdrop = PN_QT3_Output*0.99;
		//ldo_drop_test(F_FB, F_QT3, FXVIe_PLUS_10V, FXVIe_PLUS_1A, "qt3_drop", Vfb, vdrop, results1);
		//Ms_LogData(funcindex, "QT3_Vdrop", results1);
		//F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
		//delay_ms(1);
	}
	
	if(dut.sel("QT1_VOUT").get_working(0)==0){Ms_LogData(funcindex, "QT1_Vos", v_qt1os);}
	if(dut.sel("QT2_VOUT").get_working(0)==0){Ms_LogData(funcindex, "QT2_Vos", v_qt2os);}
	if(PN_Tracker_Num==3){if(dut.sel("QT3_VOUT").get_working(0)==0){Ms_LogData(funcindex, "QT3_Vos", v_qt3os);}}
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	QVM_DisConnect();

	//STB//////////////////////////////////////////////////////////////////////////////////
	//qt123 STB
	F_QT1.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);}
	Cmd_Bank0();
	Cmd_En_Trk();
	set_vsx(12.0);
	set_fb_plus_target_hc(0.1);//target+0.1V
	set_posfb_plus_target(0.1);//target+0.1V
	set_vci(0.8);
	double valueV = 40.0;//40V
	//qt1
	F_QT1.Set(FV, valueV, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_QT1.MeasureVI(20,10);
	Get_Result(F_QT1, results1, MIRET);
	SERIAL results1[SITE] = results1[SITE]*1000.0;
	Ms_LogData(funcindex, "QT1_STB", results1);
	F_QT1.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//qt2
	F_QT2.Set(FV, valueV, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_QT2.MeasureVI(20,10);
	Get_Result(F_QT2, results1, MIRET);
	SERIAL results1[SITE] = results1[SITE]*1000.0;
	Ms_LogData(funcindex, "QT2_STB", results1);
	F_QT2.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//qt3
	if(PN_Tracker_Num==3)
	{
		F_QT3.Set(FV, valueV, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
		F_QT3.MeasureVI(20,10);
		Get_Result(F_QT3, results1, MIRET);
		SERIAL results1[SITE] = results1[SITE]*1000.0;
		Ms_LogData(funcindex, "QT3_STB", results1);
		F_QT3.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	}

	//A_QST.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//Power dowm//////////////////////////////////////////////////////////////////////////////////
	A_QST.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	F_QT1.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	F_QT2.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_40V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);}
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_OFF);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	A_POSFB.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	A_VCI.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	A_AMUX.Set(FI, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_OFF);
	C_ACM_AMUX_DisConnect;
	C_ACM_VCI_DisConnect;
	Poweroff_tm_hc();

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T41_BST(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	double results[SITE_NUM];
	double rise[SITE_NUM];
	double fall[SITE_NUM];
	double hys[SITE_NUM];
	double duty[SITE_NUM];
	double ton[SITE_NUM];
	double freq[SITE_NUM];
	double hsrdson[SITE_NUM];
	double lsrdson[SITE_NUM];
	double Ilk[SITE_NUM];
	double irsh[SITE_NUM];
	double irsl[SITE_NUM];
	double irs[SITE_NUM];

	all_resource_off();
	C_All_Open;
	F_DRG.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	F_RSH.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_DRG_Connect;
	C_FXVI_ACM_GND_Connect;
	C_ACM_SECPOSFRE_Connect;
	C_RSL_PD_Connect;
	C_FXVI_RSH_Connect;
	Poweron_tm();
	set_fb(5.5);
	set_quc(5.0);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	set_vsx_hc(4.0);
	//Cmd_Bank1(true);
	//Nvm_PreviewFs(-1);
	set_vsx_hc(8.0);
	//F_RSH.Set(FV, 0.1, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//Cmd_Forceoff(except_dcdc);
	//Cmd_Forceoff(all_off);
	//F_DRG.Set(FV, 5.0, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_DRG.MeasureVI(200,1);
	////Get_Result(F_DRG, results, MIRET);
	//Get_Result(F_DRG, results, MIRET, MAX_RESULT);
	//SERIAL results[SITE]=results[SITE]*1000.0;//mA
	//Ms_LogData(funcindex, "PreBST_IDRGsnk", results);
	F_DRG.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	Cmd_Forceoff(all_off);
	set_vsx_hc(6.0);
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	/////////////////PRE BOOST CONVERT//////////////////////
	delay_ms(12);//needed
	F_RSH.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	F_RSH.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	F_RSH.MeasureVI(20,10);
	Get_Result(F_RSH, irsh, MIRET);
	SERIAL irsh[SITE]=irsh[SITE]*1000000.0;
	Ms_LogData(funcindex, "PreBST_Irsh", irsh);
	C_FXVI_RSL_Connect;
	C_RSL_PD_DisConnect;
	delay_ms(2);
	F_RSL.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	F_RSL.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	F_RSL.MeasureVI(20,10);
	Get_Result(F_RSL, irs, MIRET);
	SERIAL irs[SITE]=irs[SITE]*1000000.0;
	SERIAL irsl[SITE]=irs[SITE]-irsh[SITE];
	Ms_LogData(funcindex, "PreBST_Irsl", irsl);
	C_RSL_PD_Connect;
	//C_FXVI_RSL_DisConnect;
	delay_ms(2);

	//measure dutycycle
	//C_FXVI_RSH_Connect;
	//C_FXVI_RSL_Connect;
	//F_RSH.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	C_DCM_DRG_Connect;
	delay_ms(2);
	measure_freq_duty_set("DCM7", 3.0);
	dcm.SetTMUParam("DCM7", DCM_POS, 4, 0);
	measure_duty_get("DCM7", freq, duty);
	Ms_LogData(funcindex, "PreBST_Dmax", duty);
	C_FXVI_RSL_DisConnect;
	delay_ms(2);
	//F_RSH.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	F_RSH.Set(FV, 1.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	//set_vsx(7.0);
	//measure_ton_get("DCM7", freq, ton);
	//Ms_LogData(funcindex, "PreBST_Fsw", freq);
	measure_tblank_set("DCM7");
	//delay_ms(2);
	measure_ton_get("DCM7", freq, ton);
	Ms_LogData(funcindex, "PreBST_Fsw", freq);
	Ms_LogData(funcindex, "PreBST_Tblank", ton);
	F_RSH.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	dcm.Disconnect("DCM7");
	C_DCM_DRG_DisConnect;
	delay_ms(5);

	//vdrg
	double vqvm[SITE_NUM];
	double vdrg[SITE_NUM];
	double vrsl[SITE_NUM];
	C_FXVI_RSL_Connect;
	C_RSL_PD_DisConnect;
	C_DBUFI_DRG;
	C_DBUFI_ABUFO;
	C_QVMH_ABUFO_Connect;
	C_QVML_RSL_Connect;
	QVM_Connect();
	F_RSH.Set(FV, 1.5, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	F_DRG.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_SENSE_ON);
	delay_ms(2);
	F_DRG.MeasureVI(100,3);//fxvi5
	F_RSH.MeasureVI(100,3);//fxvi0
	C_QVM_1357;
	delay_ms(2);
	qvm0.MeasureHADC(200, 0.1, QVMe_HADC_4V, MEAS_NORMAL);
	qvm1.MeasureHADC(200, 0.1, QVMe_HADC_4V, MEAS_NORMAL);
	qvm2.MeasureHADC(200, 0.1, QVMe_HADC_4V, MEAS_NORMAL);
	qvm3.MeasureHADC(200, 0.1, QVMe_HADC_4V, MEAS_NORMAL);
	QVM_GetResult1357(vqvm,MAX_RESULT);
	C_QVM_2468;
	delay_ms(2);
	qvm0.MeasureHADC(200, 0.1, QVMe_HADC_4V, MEAS_NORMAL);
	qvm1.MeasureHADC(200, 0.1, QVMe_HADC_4V, MEAS_NORMAL);
	qvm2.MeasureHADC(200, 0.1, QVMe_HADC_4V, MEAS_NORMAL);
	qvm3.MeasureHADC(200, 0.1, QVMe_HADC_4V, MEAS_NORMAL);
	QVM_GetResult2468(vqvm,MAX_RESULT);
	Get_Result(F_RSL, vrsl, MVRET, MAX_RESULT); 
	Get_Result(F_DRG, results, MVRET, MAX_RESULT); 
	SERIAL vdrg[SITE]=vqvm[SITE]+vrsl[SITE];
	//_LogData(funcindex, "PreBST_VDRG", results);
	Ms_LogData(funcindex, "PreBST_VDRG", vdrg);
	C_QVM_RESET;
	C_DBUFI_DisConnect;
	C_QVMH_DisConnect;
	C_QVML_DisConnect;
	C_RSL_PD_Connect;
	C_FXVI_RSL_DisConnect;
	QVM_DisConnect();
	F_RSH.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);

	//idrg src,snk
	//F_DRG.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	set_vsx_hc(9.0);
	//src
	Cmd_Bank1(true);
	Cmd_TMSel(0x0000300000000100);
	delay_ms(1);
	F_DRG.Set(FV, 1.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_DRG.MeasureVI(20,10);
	Get_Result(F_DRG, results, MIRET);
	//Get_Result(F_DRG, results, MIRET, MIN_RESULT);
	SERIAL results[SITE]=-(results[SITE]*1000.0);//mA
	Ms_LogData(funcindex, "PreBST_IDRGsrc", results);
	F_DRG.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//snk
	Cmd_Bank1(true);
	Cmd_TMSel(0x0000200000000100);
	delay_ms(1);
	F_DRG.Set(FV, 2.5, FXVIe_PLUS_10V, FXVIe_PLUS_1A, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_DRG.MeasureVI(20, 10);
	Get_Result(F_DRG, results, MIRET);
	//Get_Result(F_DRG, results, MIRET, MIN_RESULT);
	SERIAL results[SITE] = (results[SITE] * 1000.0);//mA
	Ms_LogData(funcindex, "PreBST_IDRGsnk", results);

	F_DRG.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	set_vsx_hc(12.0);
	delay_ms(1);
	double voff = 1.0;
	F_DRG.Set(FV, 6.0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_DRG.Set(FV, voff, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_DRG.MeasureVI(20,10);
	Get_Result(F_DRG, results, MIRET);
	SERIAL results[SITE]=results[SITE]*1000.0;//mA
	Ms_LogData(funcindex, "PreBST_IDRGoff", results);
	SERIAL results[SITE]=(voff/results[SITE])*1000.0;//OHM
	//Ms_LogData(funcindex, "PreBST_RDRGoff", results);
	F_DRG.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_DRG_DisConnect;
	F_DRG.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	delay_ms(1);
	
	set_vsx_hc(7.0);
	set_fb_plus_target(-0.5);
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	//vs_6pV
	int reg0[SITE_NUM];
	Cmd_Bank0(true);
	Cmd_ReadState(reg0);//1
	Cmd_Bank1(true);
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2448200000800100);//fxvi4,acm9
	double start = 5.0;
	double stop = 8.0;
	double step = calc_step(start, stop,100);
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_6P5V", start, stop, step, 20, 2.5 mA, TRIG_RISING, rise);
	Ms_LogData(funcindex, "PreBST_6P5V", rise);
	//vs_uv,8.25
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2248200000800100);//fxvi4,acm9
	start = 7.8;
	stop = 9.0;
	step = calc_step(start, stop,100);
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_UV1", start, stop, step, 30, 2.5 mA, TRIG_RISING, rise);
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_UV2", stop, start, step, 30, 2.5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = (abs(rise[SITE] - fall[SITE]))*1000.0;//mV
	Ms_LogData(funcindex, "PreBST_UVrise", rise);
	Ms_LogData(funcindex, "PreBST_UVfall", fall);
	Ms_LogData(funcindex, "PreBST_UVhys", hys);
	//vs_10V
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2048200000800100);//fxvi4,acm9
	start = 8.0;
	stop = 12.0;
	step = calc_step(start, stop,100);
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_10V", start, stop, step, 20, 2.5 mA, TRIG_RISING, rise);
	Ms_LogData(funcindex, "PreBST_10V", rise);
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;

	//use_lsi_dfi = false;
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	C_FPVIH_RSH_Connect;
	C_FPVIL_RSL_Connect;
	if(use_lsi_dfi){cbitclose(K100);cbitclose(K133_134);}
	else{cbitclose(K101);}
	C_RSL_PD_Connect;
	//bst_ocp_stg
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2C08200000800100);//TM24
	set_vsx_hc(4.0);
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	double current = 0;
	double voltage = 0.5;
	if(use_lsi_dfi)
	{
		current = voltage/lsi_dfi_gain;
		double step = calc_step(0,current,100);
		awg.rampimi(fpvi0, A_SECPOSFRE, FPVIe_5V, FPVIe_100MA, "bst_ocp_stg", 0, current, step, 20, 5 mA, TRIG_RISING, results);
		SERIAL results[SITE]=results[SITE]*lsi_dfi_gain;
	}
	else
	{
		double step = calc_step(0,voltage,100);
		awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_1V, FPVIe_1MA, "bst_ocp_stg", 0, voltage, step, 20, 5 mA, TRIG_RISING, results);
	}
	SERIAL  results[SITE] = results[SITE] * 1000.0; //160mV
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	Ms_LogData(funcindex, "PreBST_RSstg", results);
	//bst_ocp_oc
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2A08200000800100);//TM25
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	//double current = 0;
	//double voltage = 0.5;
	if(use_lsi_dfi)
	{
		current = voltage/lsi_dfi_gain;
		double step = calc_step(0,current,100);
		awg.rampimi(fpvi0, A_SECPOSFRE, FPVIe_5V, FPVIe_100MA, "bst_ocp_oc", 0, current, step, 20, 5 mA, TRIG_RISING, results);
		SERIAL results[SITE]=results[SITE]*lsi_dfi_gain;
	}
	else
	{
		double step = calc_step(0,voltage,100);
		awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_1V, FPVIe_1MA, "bst_ocp_oc", 0, voltage, step, 20, 5 mA, TRIG_RISING, results);
	}
	SERIAL  results[SITE] = results[SITE] * 1000.0; //130mV
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);

	////CmdWriteData(0x31, 0x00);
	//Cmd_Dmuxset_Fs0(81);
	//Cmd_TMSel(0x2A08200000800000);
	//Cmd_Dmuxset_Fs0(0);
	//Cmd_TMSel(0x00);
	//CmdWriteData(0x31, 0x00);
	//int data0[SITE_NUM];
	//int data1[SITE_NUM];
	//set_vsx(7.0);
	//set_fb(5.5);
	//set_quc(5.0);
	//Cmd_Bank0(true);
	//Cmd_ReadState(data0);
	//CmdReadData(0x3B,data0);
	//
	////Cmd_Bank1(true);

	////C_ACM_SECPOSFRE_Connect;
	////set_sec_posfre(FV, 5.0,ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//voltage = 0.16;
	//if(use_lsi_dfi)
	//{
	//	current = voltage/lsi_dfi_gain;
	//	fpvi0.Set(FI, current, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	//}
	//else
	//{
	//	fpvi0.Set(FV, voltage, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	//}
	//CmdReadData(0x3B,data1);
	//double results1[SITE_NUM];
	//double Il = -1.0 mA;
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_Connect;
	//delay_ms(1);
	//F_INT.Set(FI, Il, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_INT.MeasureVI(2000,1);
	//Get_Result(F_INT, results1, MVRET);
	//Ms_LogData(funcindex, "INT_VOL", results1);
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_DisConnect;
	//delay_ms(1);
	////set_sec_posfre(FV, 0.0,ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	////C_ACM_SECPOSFRE_DisConnect;
	//fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	////Cmd_Masksafe();
	set_vsx_hc(4.0);
	//Cmd_Bank1(true);
	//Nvm_PreviewFs(-1);
	Ms_LogData(funcindex, "PreBST_RSoc", results);
	double oc_level[SITE_NUM];
	Copy_Array(oc_level,results);
	//oc_digl
	C_FXVI_RSH_Connect;
	double res[SITE_NUM];
	set_fb_plus_target(0.1);
	set_quc_target();
	//C_FXVI_INT_Connect;
	//double res[SITE_NUM];
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//F_INT.MeasureVI(100,10);
	Cmd_Bank1(true);

	if (1)//stg dgl
	{
		//Poweroff_tm();
		//delay_ms(2);
		//Poweron_tm();
		//set_fb(5.5);
		//set_quc(5.0);
		//DUT_SPI_Connect(5.0);
		//Cmd_Set_Freq();
		//Cmd_TestMode(true);
		set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);

		Cmd_Masksafe_Exit();
		set_vsx_hc(5.3);
		set_fb_plus_target(-1.0);

		Cmd_Dmuxset_Fs0(0);
		Cmd_Dmuxset_Fs1(0);
		Cmd_Dmuxset_Main(114);//en
		Cmd_TMSel(0x2A08280000800108);//TM26

		voltage = 0.5;
		current = voltage / lsi_dfi_gain;
		if (use_lsi_dfi) { cbitopen(K100); cbitopen(K133_134); }
		else { cbitopen(K101); }delay_ms(2);
		cbitclose(K101);
		delay_ms(2);

		boost_oc_dgl2("oc_digl", 0.3, results);
		SERIAL results[SITE] = results[SITE] / 1000.0;//ms

		fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
		cbitopen(K101);
		delay_ms(2);
		if (use_lsi_dfi) { cbitclose(K100); cbitclose(K133_134); }
		else { cbitclose(K101); }
		Ms_LogData(funcindex, "DCDC_STG_Tdet", results);
	}

	Cmd_Masksafe_Exit();
	set_fb_plus_target(0.1);


	//if(PN_SEC_Available)//sec version work
	if(0)
	{
		//A_SEC.Set(FI, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		//C_ACM_STU_Connect;
		//A_SEC.Set(FV, 3.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);

		C_FRE_PU_Connect;
		//dut.assy("FBANK0").set_working(0x31);
		//dut.assy("FBANK1").set_working(0x00);
		//dut.assy("FBANK2").set_working(0x21);
		//dut.assy("FBANK3").set_working(0xB0);
		//dut.assy("FBANK4").set_working(0x00);
		//Nvm_PreviewFs(-1);
		Cmd_Dmuxset_Fs0(81);
		Cmd_Dmuxset_Fs1(81);
		Cmd_TMSel(0x2A08280000800108);//TM26
		current = 0;
		fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
		set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		voltage = 0.5;
		current = voltage / lsi_dfi_gain;
		if (use_lsi_dfi) { cbitopen(K100); cbitopen(K133_134); }
		else { cbitopen(K101); }delay_ms(2);
		cbitclose(K101);
		delay_ms(2);

		boost_oc_dgl("oc_digl", 0.3, results);

		fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
		cbitopen(K101);
		delay_ms(2);
		if (use_lsi_dfi) { cbitclose(K100); cbitclose(K133_134); }
		else { cbitclose(K101); }
		C_FRE_PU_DisConnect;

		//A_SEC.Set(FI, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		//C_ACM_STU_DisConnect;
		//A_SEC.Set(FI, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	}

	else//all version work
	{
		Cmd_Dmuxset_Fs0(71);
		Cmd_TMSel(0x2A08280000800100);//TM26
		if(use_lsi_dfi)
		{
			current = 0.25/lsi_dfi_gain;
			double step = calc_step(0,current,150);
			awg.rampimi(fpvi0, A_SECPOSFRE, FPVIe_5V, FPVIe_100MA, "oc_digl", 0, current, step, 20, 5 mA, TRIG_RISING, res);
			SERIAL res[SITE]=res[SITE]*lsi_dfi_gain;
		}
		else
		{
			double step = calc_step(0,0.25,150);
			awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_1V, FPVIe_1MA, "oc_digl", 0, 0.25, step, 20, 5 mA, TRIG_RISING, res);
		}
		SERIAL  res[SITE] = res[SITE] * 1000.0;
		double stepv=calc_step(0,0.25,100)*1000.0;
		SERIAL
		{
			results[SITE]=((res[SITE]-oc_level[SITE])/stepv)*20.0;
		}
	}

	if (0)//new,not work
	{
		A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		C_FRE_PU_Connect;
		C_DBUFI_FRE;
		C_ACM_DBUFO_Connect;
		delay_ms(2);
		//Cmd_Masksafe_Exit();
		Cmd_Dmuxset_Fs0(81);
		Cmd_Dmuxset_Fs1(81);
		Cmd_TMSel(0x2A08280000800108);//TM26
		current = 0;
		fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
		set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		voltage = 0.5;
		current = voltage / lsi_dfi_gain;
		if (use_lsi_dfi) { cbitopen(K100); cbitopen(K133_134); }
		else { cbitopen(K101); }delay_ms(2);
		cbitclose(K101);
		delay_ms(2);

		boost_oc_dgl3("oc_digl", 0.3, results);

		fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
		cbitopen(K101);
		delay_ms(2);
		if (use_lsi_dfi) { cbitclose(K100); cbitclose(K133_134); }
		else { cbitclose(K101); }
		C_FRE_PU_DisConnect;
		C_DBUFI_DisConnect;
		C_ACM_DBUFO_DisConnect;
		A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	}
	Ms_LogData(funcindex, "PreBST_Tocdgl", results);

	//Cmd_Bank0(true);
	//int data[512][SITE_NUM];
	//Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	//for(int i=0x1A; i<= 0x3B;i++)
	//{
	//	CmdReadData(i,data[i]);
	//}
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	//C_FXVI_INT_DisConnect;
	//bst_vout
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	if(use_lsi_dfi)
	{
		current = 0.1/lsi_dfi_gain;
		fpvi0.Set(FI, current, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	}
	else
	{
		fpvi0.Set(FV, 0.1, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	}
	Cmd_Bank1(true);
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x2608300000800100);
	set_fb_plus_target(-0.5);//target-0.5V
	set_vsx_hc(8.5);
	double val1[SITE_NUM];
	double val2[SITE_NUM];
	start = 8.2;
	stop = 6.2;
	step = calc_step(start,stop,100);
	delay_ms(2);//acm9
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "bst_ea", start, stop, step, 50, 0.5 mA, TRIG_FALLING, val1);
	awg.rampvmif(F_VS1, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "bst_ea", stop, start, step, 50, 0.5 mA, TRIG_RISING, val2);
	SERIAL results[SITE]=(val1[SITE]+val2[SITE])/2.0;
	Ms_LogData(funcindex, "PreBST_V", results);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	C_FPVIH_RSH_DisConnect;
	C_FPVIL_RSL_DisConnect;
	if(use_lsi_dfi){cbitopen(K100);cbitopen(K133_134);}
	else{cbitopen(K101);}
	C_RSL_PD_DisConnect;
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	Poweroff_tm();
	C_ACM_SECPOSFRE_DisConnect;
	C_RSL_PD_DisConnect;
	C_FXVI_RSH_DisConnect;
	C_FXVI_RSL_DisConnect;
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_OFF);
	F_RSH.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_OFF);

	//int data0[SITE_NUM];
	//int data1[SITE_NUM];
	//C_FXVI_ACM_GND_Connect;
	//C_ACM_SECPOSFRE_Connect;
	//C_RSL_PD_Connect;
	//Poweron_tm();
	////set_fb_plus_target(-0.2);
	//set_posfb_plus_target(-0.1);
	////set_quc(5.0);
	//DUT_SPI_Connect(4.0);
	//Cmd_Set_Freq(10 MHz);
	//Cmd_TestMode(true, in_tm);
	////Cmd_Masksafe();
	////Cmd_Bank1(true);
	////Nvm_PreviewFs(-1);
	////Cmd_Forceoff(except_dcdc);
	//set_vsx(5.1);
	//Cmd_Bank0(true);
	//Cmd_Dis_ERR_WD();
	//Cmd_ReadState(data0);
	//CmdReadData(0x3B,data0);
	//Cmd_Go2_Normal();
	//Cmd_ReadState(data0);
	//CmdWriteData(0x31, 0x00);
	//Cmd_ReadState(data1);
	//Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	//use_lsi_dfi = false;
	//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	//C_FPVIH_RSH_Connect;
	//C_FPVIL_RSL_Connect;
	//if(use_lsi_dfi){cbitclose(K100);cbitclose(K133_134);}
	//else{cbitclose(K101);}
	//C_RSL_PD_Connect;
	////set_vsx(7.0);

	//voltage = 0.16;
	//if(use_lsi_dfi)
	//{
	//	current = voltage/lsi_dfi_gain;
	//	fpvi0.Set(FI, current, FPVIe_1V, FPVIe_10MA, FPVIe_RELAY_ON);
	//}
	//else
	//{
	//	fpvi0.Set(FV, voltage, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	//}
	//CmdReadData(0x3B,data1);
	//double results1[SITE_NUM];
	//double Il = -1.0 mA;
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_Connect;
	//delay_ms(1);
	//F_INT.Set(FI, Il, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_INT.MeasureVI(2000,1);
	//Get_Result(F_INT, results1, MVRET);
	//Ms_LogData(funcindex, "INT_VOL", results1);
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_DisConnect;
	//delay_ms(1);
	//fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	//C_FPVIH_RSH_DisConnect;
	//C_FPVIL_RSL_DisConnect;
	//if(use_lsi_dfi){cbitopen(K100);cbitopen(K133_134);}
	//else{cbitopen(K101);}
	//C_RSL_PD_DisConnect;
	//set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	//Poweroff_tm();
	//C_RSL_PD_DisConnect;
	//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_OFF);

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T42_PREBK(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	double results[SITE_NUM];
	double freq[SITE_NUM];
	double duty[SITE_NUM];
	double ton[SITE_NUM];
	double toff[SITE_NUM];
	double rise[SITE_NUM];
	double fall[SITE_NUM];
	double hys[SITE_NUM];
	double hsrdson[SITE_NUM];
	double lsrdson[SITE_NUM];
	double Ilk[SITE_NUM];
	int tempd[SITE_NUM];

	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];
	int data5[SITE_NUM];
	int data6[SITE_NUM];
	int data7[SITE_NUM];
	int data8[SITE_NUM];
	int data9[SITE_NUM];

	int reg0[SITE_NUM];
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int reg3[SITE_NUM];
	int reg4[SITE_NUM];
	int reg5[SITE_NUM];
	int reg6[SITE_NUM];

	double hsrdson_v[SITE_NUM];
	double hsrdson_r[SITE_NUM];
	double lsrdson_v[SITE_NUM];
	double lsrdson_r[SITE_NUM];

	double value[SITE_NUM];
	double start = 0;
	double stop = 0;

	Ms_LogData(funcindex, "PreBK_Rhs", PREBK_HSRDSON);
	Ms_LogData(funcindex, "PreBK_Rls", PREBK_LSRDSON);

	all_resource_off();
	C_All_Open;
	//fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	//C_FXVI_ACM_GND_Connect;
	/////////////////PRE BUCK CONVERT//////////////////////
	C_FRE_PD_Connect;
	Poweron_tm_hv();
	set_fb_hc(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	//Cmd_Forceoff(except_dcdc);
	set_vsx_hv(6.0);
	//set_fb_plus_target_hc(0.1);
	set_fb_hc(6.0);
	delay_ms(2);
	//prebk_ipfm
	double result[SITE_NUM];
	set_vsx_hv(6.0);
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	//Cmd_ReadState(tempd);//2
	CmdWriteData(BCK_FRE_SPREAD,0x00);//no spsp

	if (PINarray[28].pin_valid)//syn available
	{
		//set_fb_hc(5.0);
		//set_quc(5.0);
		//A_EVC2.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_DCM_SYN_Connect;//dcm6
		//C_ACM_SYN_Connect;//acm10
		Cmd_EnSyn(true);
		delay_ms(2);
		//A_EVC2.MeasureVI(100,1);
		measure_freq_duty_set("DCM6",5.0, DCM_HIGH_IMPEDANCE);
		dcm.SetPinLevel("DCM6", 5.0, 0.0, 4.0, 1.0);
		dcm.SetTMUParam("DCM6", DCM_POS, 50, 5);
		measure_duty_get("DCM6",freq, duty);
		Ms_LogData(funcindex, "PreBK_Syn_Freq", freq);
		Ms_LogData(funcindex, "PreBK_Syn_Duty", duty);

		////dcm.SetTMUParam("DCM6", DCM_POS, 5, 5);
		//measure_edge_set1("DCM6", 4.0, DCM_POS);
		//measure_edge_get1("DCM6", rise);
		//measure_edge_set2("DCM6", 4.0, DCM_POS);
		//measure_edge_get2("DCM6", rise);
		//Ms_LogData(funcindex, "PreBK_Syn_Trise", rise);//22ns
		//measure_edge_set1("DCM6", 4.0, DCM_NEG);
		//measure_edge_get1("DCM6", fall);
		//measure_edge_set2("DCM6", 4.0, DCM_NEG);
		//measure_edge_get2("DCM6", fall);
		//Ms_LogData(funcindex, "PreBK_Syn_Tfall", fall);//22ns

		C_DCM_SYN_DisConnect;
		//C_ACM_SYN_DisConnect;
		//A_EVC2.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	}
	set_fb_hc(6.0);
	//A_EVC2.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	C_SW_PD_Connect;
	C_DBUFI_SW1;
	C_DBUF_Bypass;
	C_DCM_DBUFO_Connect;
	C_ACM_DBUFO_Connect;
	delay_ms(2);
	//double freq[SITE_NUM];
	//double duty[SITE_NUM];
	//double ton[SITE_NUM];
	//double toff[SITE_NUM];
	int prebk_limit[SITE_NUM];
	int prebk_trim[SITE_NUM];
	if(DIE_VER()!=0)
	{
		//mini_on
		if(0)//not work
		{
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			C_FPVIH_SW_Connect;
			C_FPVIL_PG_Connect;
			delay_ms(2);
			set_fb_hc(6.0);
			delay_ms(1);
			fpvi0.Set(FI, 1.5 A, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			fpvi0.MeasureVI(100, 10);
			fpvi0.Set(FI, 0 A, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			C_FPVIH_SW_DisConnect;
			C_FPVIL_PG_DisConnect;
			delay_ms(2);
		}

		if(1)
		{
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			C_DBUF_Bypass;
			C_FPVIH_SW_Connect;
			C_FPVIL_PG_Connect;
			delay_ms(2);
			SERIAL prebk_limit[SITE] = dut.sel("PREBK_LMT").get_working(SITE);
			SERIAL prebk_trim[SITE] = dut.trim("prebk_hscl").get_working(SITE);
			SERIAL dut.sel("PREBK_LMT").set_working(1, SITE);//low
			SERIAL dut.trim("prebk_hscl").set_working(8, SITE);//low
			Nvm_PreviewFs(3);
			Nvm_Preview(11);
			delay_ms(1);
			set_fb_plus_target_hc(-0.3);
			delay_ms(1);
			fpvi0.Set(FI, -0.5 A, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			//fpvi0.Set(FI, -1.0 A, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			//fpvi0.Set(FI, -1.5 A, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			//fpvi0.Set(FI, -2.0 A, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			//fpvi0.MeasureVI(1000, 10);
			delay_ms(1);
			measure_freq_duty_set("DCM5",5.0, DCM_HIGH);
			//measure_freq_duty_set("DCM5",5.0, DCM_LOW);
			//measure_freq_duty_set("DCM5",5.0);
			dcm.SetPinLevel("DCM5", 5.0, 0.0, 3.5, 3.5);
			dcm.SetTMUParam("DCM5", DCM_POS, 10, 0);
			measure_ton_get("DCM5",freq, ton);
			Ms_LogData(funcindex, "PreBK_Ton", ton);
			fpvi0.Set(FI, 0 A, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			C_FPVIH_SW_DisConnect;
			C_FPVIL_PG_DisConnect;
			delay_ms(2);
			SERIAL dut.sel("PREBK_LMT").set_working(prebk_limit[SITE], SITE);//low
			SERIAL dut.trim("prebk_hscl").set_working(prebk_trim[SITE], SITE);
			Nvm_PreviewFs(3);
			Nvm_Preview(11);
		}

		if(0)
		{
			Cmd_Bank1(true);
			Cmd_TMSel(0x0000000000010000);
			//A_DBUFO.Set(FI, -100 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
			C_DBUF_Bypass;
			delay_ms(1);
			set_fb_hc(6.0);
			A_DBUFO.Set(FI, -100 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
			//ramp_sine(F_FB, FXVIe_PLUS_10V, FXVIe_PLUS_1A, 5.5, 1.0);
			delay_ms(1);
			//A_DBUFO.MeasureVI(100,1);
			measure_freq_duty_set("DCM5",5.0, DCM_HIGH);
			//measure_freq_duty_set("DCM5",5.0, DCM_LOW);
			//measure_freq_duty_set("DCM5",5.0);
			dcm.SetPinLevel("DCM5", 5.0, 0.0, 2.1, 2.1);
			dcm.SetTMUParam("DCM5", DCM_POS, 10, 0);
			delay_ms(1);
			measure_ton_get("DCM5",freq, ton);
			Ms_LogData(funcindex, "PreBK_Ton", ton);
		}

		//mini_off
		A_DBUFO.Set(FI, -10 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		//set_fb_hc(5.2);
		set_fb_plus_target_hc(-0.3);
		C_DBUF_Usage;
		delay_ms(1);
		//A_DBUFO.MeasureVI(100,1);
		measure_freq_duty_set("DCM5",5.0, DCM_LOW);
		dcm.SetPinLevel("DCM5", 5.0, 0.0, 2.0, 2.0);
		dcm.SetTMUParam("DCM5", DCM_NEG, 10, 0);
		delay_ms(1);
		measure_toff_get("DCM5",freq, toff);//KHz
		double tonmax[SITE_NUM];
		SERIAL duty[SITE]=100.0-(100.0*toff[SITE]*freq[SITE])/1000000.0;
		SERIAL tonmax[SITE] = ((1000000.0/freq[SITE])- toff[SITE])/1000.0;//us
		Ms_LogData(funcindex, "PreBK_TonMax", tonmax);
		Ms_LogData(funcindex, "PreBK_Toff", toff);
		Ms_LogData(funcindex, "PreBK_Dmax", duty);
		A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	}
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	C_DBUFI_DisConnect;
	C_DCM_DBUFO_DisConnect;
	C_ACM_DBUFO_DisConnect;
	C_SW_PD_DisConnect;
	C_DBUF_Bypass;
	//A_EVC2.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);

	////osc
	//C_DBUFI_SW1;
	//C_DCM_DBUFO_Connect;
	//delay_ms(1);
	//measure_freq_duty_set("DCM5",2.0);//420KHz
	//Nvm_Preview(13);
	//delay_ms(5);
	//measure_freq_get("DCM5",freq);
	//SERIAL  freq[SITE] = freq[SITE]*2.0;
	//Ms_LogData(funcindex, "PreBK_Fswl", freq);
	//C_DBUFI_DisConnect;
	//C_DCM_DBUFO_DisConnect;
	//delay_ms(1);

	//bool sec=PN_SEC_Available;
	C_ACM_SECPOSFRE_Connect;
	Cmd_Bank1(true);
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x1C48000000800100);//
	//delay_ms(1);
	double step = calc_step(4,6,100);
	awg.rampvmif(F_VST, A_SECPOSFRE, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, "VS1_uv5", 4 V, 6 V, step, 20, 5 mA, TRIG_FALLING, rise);//acm9
	Ms_LogData(funcindex, "PreBK_Uv5V", rise);
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x1A48000000800100);//
	//delay_ms(1);
	step = calc_step(5,7,100);
	awg.rampvmif(F_VST, A_SECPOSFRE, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, "VS1_uv6", 5 V, 7 V, step, 20, 5 mA, TRIG_FALLING, rise);//acm9
	Ms_LogData(funcindex, "PreBK_Uv6V", rise);
	Cmd_Dmuxset_Fs0(254);
	Cmd_TMSel(0x1848000000800100);//
	//delay_ms(1);
	step = calc_step(28,32,100);
	set_vsx_hv(28.0);
	//delay_ms(1);
	awg.rampvmif(F_VST, A_SECPOSFRE, FXVIe_PLUS_40V, FXVIe_PLUS_100MA, "VS1_uv30", 28 V, 32 V, step, 20, 5 mA, TRIG_FALLING, rise);//acm9
	Ms_LogData(funcindex, "PreBK_Uv30V", rise);
	Cmd_Dmuxset_Fs0(0);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	C_ACM_SECPOSFRE_DisConnect;

	set_vsx_hv(6.0);
	//
	//prebk_osc
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2248000000810100);//
	C_FRE_PD_DisConnect;
	delay_ms(2);
	C_FRE_PU_Connect;
	C_DBUFI_DisConnect;
	C_DBUF_Usage;
	C_DBUFI_FRE;
	C_DCM_DBUFO_Connect;//dcm5
	Cmd_Bank0(true);
	CmdReadData(0x27, tempd);
	//A_DBUFO.MeasureVI(1000,1);
	measure_freq_duty_set("DCM5",4.0, DCM_HIGH_IMPEDANCE);//420KHz
	dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
	Nvm_Preview(13);
	delay_ms(5);
	measure_freq_get("DCM5",freq);
	SERIAL  freq[SITE] = freq[SITE]*2.0;
	Ms_LogData(funcindex, "PreBK_Fswl", freq);
	//set_fb(6.0);
	//measure_t_get("DCM5",freq, duty, ton,toff);
	//set_fb(5.2);
	//measure_t_get("DCM5",freq, duty, ton,toff);

	//prebk_osc_freqshift
	double freq0[SITE_NUM];
	double freqn5[SITE_NUM];
	double freqn3[SITE_NUM];
	double freqn1[SITE_NUM];
	double freqp5[SITE_NUM];
	double freqp3[SITE_NUM];
	double freqp1[SITE_NUM];
	Cmd_Bank0(true);
	//Cmd_Dis_ERR_WD();
	//Cmd_Go2_Normal();
	Cmd_ReadState(tempd);//2
	CmdWriteData(BCK_FRE_SPREAD,0x00);//no spsp
	CmdWriteData(BCK_FREQ_CHANGE,0x04);//0%
	measure_freq_get("DCM5",freq0);
	SERIAL  freq0[SITE] = freq0[SITE]*2.0;
	Ms_LogData(funcindex, "PreBK_Fsw0", freq0);
	CmdWriteData(BCK_FREQ_CHANGE,0x07);//-5%
	measure_freq_get("DCM5",freqn5);
	SERIAL  freqn5[SITE] = freqn5[SITE]*2.0;
	SERIAL	freqn5[SITE] = ((freqn5[SITE] - freq0[SITE])/freq0[SITE])*100.0;
	Ms_LogData(funcindex, "PreBK_Fsw_SftN5", freqn5);
	CmdWriteData(BCK_FREQ_CHANGE,0x03);//+5%
	measure_freq_get("DCM5",freqp5);
	SERIAL  freqp5[SITE] = freqp5[SITE]*2.0;
	SERIAL	freqp5[SITE] = ((freqp5[SITE] - freq0[SITE])/freq0[SITE])*100.0;
	Ms_LogData(funcindex, "PreBK_Fsw_SftP5", freqp5);
	CmdWriteData(BCK_FREQ_CHANGE,0x04);//0%
	CmdWriteData(BCK_FRE_SPREAD,0xFF);//spsp,-10%~7.5%


	CmdWriteData(BCK_FRE_SPREAD,0x00);//no spsp
	dcm.Disconnect("DCM5");
	C_DCM_DBUFO_DisConnect;
	C_DBUF_Bypass;
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(0);
	//////////////////////////////
	////SS
	//double tx[512][SITE_NUM];
	//double tdet[512];
	//double tdet_min[SITE_NUM];
	//double tdet_max[SITE_NUM];
	//
	//double f_cen[SITE_NUM];
	//double f_min[SITE_NUM];
	//double f_max[SITE_NUM];
	//double f_dther[SITE_NUM];
	//double f_dther_range[SITE_NUM];
	//double f_dther_ratio[SITE_NUM];
	//delay_ms(1);

	//qtmu0.SetInSource(QTMUe_SINGLE_SOURCE_A); 
	//qtmu0.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 1.5, QTMUe_FILTER_PASS); //signal input to CHA, select 50V range, trigger=1.5V, rising edge 
	//qtmu0.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 13.5, QTMUe_FILTER_PASS); //50V range, trigger=13.5V, rising edge 
	//qtmu0.Connect(QTMUe_RELAY_CHA,500); //connect CHA relay 
	//qtmu0.Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 10, 20, QTMUe_TRANGE_MS); //sampleNum=10, Timeout=20mS 
	//qtmu0.GetMeasureResult(0, AVERAGE_RESULT,QTMUe_MU1); // Get average time of site1 
	//qtmu0.GetMeasureResult(0, 5, QTMUe_MU1); // Get the of sixth point time of site1

	////qtmu0.SetSinglePulseEventCounter(512);
	////qtmu0.SetTimeOut(200);
	////qtmu0.SinglePulseEventCounter();
	////SERIAL
	////{
	////	for (int i = 0; i < 512; i++) { tx[i][SITE] = qtmu0.GetEventCounterMeasureResult(SITE, i); }
	////}
	////Calc_MinMaxF(tx, f_cen, f_min, f_max, f_dther, f_dther_range, f_dther_ratio);


	////////////////////////////
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	C_ACM_STU_Connect;
	Cmd_Forceoff(except_dcdc);
	Cmd_Bank0(true);
	Cmd_Go2_Sleep();
	set_fb_hc(6.0);
	delay_ms(2);
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	//prebk_ipfm
	set_vsx_hv(6.0);
	Cmd_Bank1(true);
	Cmd_TMSel(0x2210000000800900);//tm59
	A_STU.Set(FV, 1.0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(2);
	A_STU.MeasureVI(20,10);//acm1
	Get_Result(A_STU, result, MIRET);
	SERIAL result[SITE] = result[SITE] * 1000000.0;//uA
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	Ms_LogData(funcindex, "PreBK_Ipfm", result);
	set_stu(false);
	C_ACM_STU_DisConnect;
	Poweroff_tm_hv();

	C_FRE_PU_Connect;
	C_DBUFI_FRE;
	Poweron_tm_hc();
	set_fb_hc(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	F_FB.MeasureVI(20,10);
	Get_Result(F_FB, Ilk, MIRET);
	SERIAL Ilk[SITE]=Ilk[SITE]*1000.0;
	Ms_LogData(funcindex, "PreBK_Idis", Ilk);
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Forceoff(except_dcdc);
	set_vsx(6.0);
	set_fb_plus_target_hc(0.1);//target+0.1V
	//prebk_osc
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2248000000810100);//
	delay_ms(2);
	C_FRE_PU_Connect;
	C_DCM_FRE_Connect;//dcm7
	measure_freq_duty_set("DCM7",1.0, DCM_HIGH_IMPEDANCE);//2100KHz
	dcm.SetTMUParam("DCM7", DCM_POS, 100, 0);
	Nvm_Preview(13);
	delay_ms(5);
	measure_freq_get("DCM7",results);
	SERIAL  results[SITE] = results[SITE]*2.0;
	Ms_LogData(funcindex, "PreBK_Fswh", results);
	C_DCM_FRE_DisConnect;
	Cmd_Dmuxset_Main(0);

	set_sec_posfre(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	C_FRE_PU_Connect;
	C_DBUFI_FRE;
	C_ACM_DBUFO_Connect;
	C_ACM_SECPOSFRE_Connect;
	delay_ms(2);

	//prebk_tsw
	//set_fb(5.0);
	//set_quc(5.0);
	//set_qst(5.0);
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	//Cmd_ReadState(data1);//1
	Cmd_Go2_Normal();
	Cmd_ReadState(data2);//2
	//CmdReadData(0x33,data3);//9
	Cmd_Bank1(true);
	Cmd_Forceoff(none_off);
	Cmd_Dmuxset_Fs0(14);//2.5,1.3
	Cmd_TMSel(0x2260000000C00108);//tm48,acm9,acm10
	step = calc_step(0.5 uA,-4 uA,120);
	set_sec_posfre(FI, 0 uA, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	set_sec_posfre(FI, -10 uA, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	set_sec_posfre(FI, 0 uA, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	awg.rampimv(A_SECPOSFRE, A_DBUFO, ACM200_10V, ACM200_10UA, "prebk_tsw_rise", 0.5 uA, -4 uA, step, 50, 2.5 V, TRIG_FALLING, rise);
	awg.rampimv(A_SECPOSFRE, A_DBUFO, ACM200_10V, ACM200_10UA, "prebk_tsw_fall", -4 uA, 0.5 uA, step, 50, 2.5 V, TRIG_RISING, fall);
	set_sec_posfre(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	SERIAL rise[SITE]=-rise[SITE]*1000000.0;
	SERIAL fall[SITE]=-fall[SITE]*1000000.0;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "PreBK_OTWriseV", rise);
	Ms_LogData(funcindex, "PreBK_OTWfallV", fall);
	Ms_LogData(funcindex, "PreBK_OTWhysV", hys);
	SERIAL rise[SITE]=rise[SITE]/0.0175+30.0;
	SERIAL fall[SITE]=fall[SITE]/0.0175+30.0;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "PreBK_OTWrise", rise);
	Ms_LogData(funcindex, "PreBK_OTWfall", fall);
	Ms_LogData(funcindex, "PreBK_OTWhys", hys);
	//prebk_tsd
	Cmd_Dmuxset_Fs0(13);//3.6,1.0
	Cmd_TMSel(0x2260000000880108);//tm47,acm9,acm10
	step = calc_step(0.5 uA,-5 uA,120);
	awg.rampimv(A_SECPOSFRE, A_DBUFO, ACM200_10V, ACM200_10UA, "prebk_tsd_rise", 0.5 uA, -5 uA, step, 50, 2.5 V, TRIG_FALLING, rise);
	awg.rampimv(A_SECPOSFRE, A_DBUFO, ACM200_10V, ACM200_10UA, "prebk_tsd_fall", -5 uA, 0.5 uA, step, 50, 2.5 V, TRIG_RISING, fall);
	set_sec_posfre(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	SERIAL rise[SITE]=-rise[SITE]*1000000.0;
	SERIAL fall[SITE]=-fall[SITE]*1000000.0;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "PreBK_TSDriseV", rise);
	Ms_LogData(funcindex, "PreBK_TSDfallV", fall);
	Ms_LogData(funcindex, "PreBK_TSDhysV", hys);
	SERIAL rise[SITE]=rise[SITE]/0.01926+30.0;
	SERIAL fall[SITE]=fall[SITE]/0.01926+30.0;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "PreBK_TSDrise", rise);
	Ms_LogData(funcindex, "PreBK_TSDfall", fall);
	Ms_LogData(funcindex, "PreBK_TSDhys", hys);
	Cmd_Dmuxset_Fs0(0);

	//prebk_tss, fre h to l
	F_SCS.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_SCS_Connect;
	int sample = 1000;
	int interval = 1;
	
	//dut.sel("PREBK_SS").set_working(0);//
	//Nvm_PreviewFs(4);
	int tss = dut.sel("PREBK_SS").get_working(0);

	if(tss==0){interval = 1;}
	else{interval = 10;}
	test_ss(F_SCS, A_DBUFO, sample, interval, results);
	A_DBUFO.MeasureVI(20,1);
	Cmd_Dmuxset_Main(254);
	//Cmd_TMSel(0x2248000000C00100);//
	CmdWriteData(0x28, 0x00);
	CmdWriteData(0x29, 0x01);
	CmdWriteData(0x2B, 0x00);
	CmdWriteData(0x2C, 0x00);
	CmdWriteData(0x2D, 0x00);
	CmdWriteData(0x2E, 0x48);
	CmdWriteData(0x2F, 0x22);
	//CmdWriteData(0x2A, 0xC0);//0xD580
	Cmd_Set_Freq(100 KHz);
	dcm.RunVectorWithGroup("SPI_DUT", "CMD2_Start", "CMD2_Stop", false);
	test_ss(F_SCS, A_DBUFO, sample, interval, results);
	SERIAL results[SITE]=results[SITE]+0.0232;
	SERIAL results[SITE] = results[SITE]/1.05;//2026_2_7 by correlation
	//F_SCS.MeasureVI(sample,1);
	//time_t stop = time(NULL)-start;
	if(tss==0){Ms_LogData(funcindex, "PreBK_Tssf", results);}//0.5ms, total 1ms
	else{Ms_LogData(funcindex, "PreBK_Tssl", results);}//5ms, total 10ms
	
	C_FXVI_SCS_DisConnect;
	F_SCS.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	Cmd_Dmuxset_Main(0);
	Cmd_Bank0(true);
	Cmd_ReadState(data1);
	Cmd_Bank1(true);
	Cmd_TMSel(0x0000000000000000);
	Cmd_Set_Freq();
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);

	//prebk_max_clampcomp
	C_FPVIH_VS1_Connect;
	C_FPVIL_SW_Connect;
	C_SW_PD_Connect;
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	delay_ms(2);
	bool test_current = false;
	if(DIE_VER()==0)
	{
		if(max_temp<50){test_current=true;}
	}
	else
	{
		test_current=true;
	}
	if(test_current)
	{
		double start = 0;
		double stop = 0;
		int prebk_limit = dut.sel("PREBK_LMT").get_working(0);
		set_fb_hc(4.0);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		//Cmd_ReadState(data2);//2
		Cmd_LMTCFG(0, 1, 0, 0, 0);
		//CmdReadData(LMT_PD_CFG,data0);
		Cmd_Bank1(true);
		Cmd_Masksafe();
		if(DIE_VER()==0)
		{
			Cmd_Dmuxset_Main(0);
			Cmd_TMSel(0x0048000000A00100);
			set_fb_hc(4.0);
			delay_ms(3);
			fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
			delay_ms(1);
			fpvi0.Set(FV, -0.3, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
			start = -0.3;
			stop = 2.4;
			prebk_hscl(fpvi0, fxvi4, FPVIe_5V, FPVIe_100MA, "prebk_hscl", start, stop, value);
			SERIAL  results[SITE] = value[SITE]/(PREBK_HSRDSON[SITE]/1000.0); 
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
			fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
		}
		else
		{
			Cmd_Dmuxset_Main(0);
			Cmd_TMSel(0x0000000000900100);
			Cmd_TMSel(0x0048000000B00100);
			set_fb_hc(4.0);
			delay_ms(3);
			fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			delay_ms(1);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			double start = 0;
			double stop = 6.0;
			double step = calc_step(start,stop, 100);
			prebk_hscl(fpvi0, FPVIe_5V, FPVIe_10A, "prebk_hscl2", start, stop, value);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			SERIAL  results[SITE] = value[SITE];
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			//Cmd_TMSel(0x0000000000900100);
			//Cmd_TMSel(0x0048000000B00100);
		}
		Ms_LogData(funcindex, "PreBK_Ipk1", results);
		set_fb_hc(4.0);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		//Cmd_ReadState(data2);//2
		//Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
		Cmd_LMTCFG(0, 0, 0, 0, 0);
		//CmdReadData(LMT_PD_CFG,data0);
		Cmd_Bank1(true);
		Cmd_Masksafe();
		if(DIE_VER()==0)
		{
			Cmd_Dmuxset_Main(0);
			Cmd_TMSel(0x0048000000A00100);
			set_fb_hc(4.0);
			delay_ms(3);
			fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
			delay_ms(1);
			fpvi0.Set(FV, -0.3, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
			start = -0.3;
			stop = 2.4;
			prebk_hscl(fpvi0, fxvi4, FPVIe_5V, FPVIe_100MA, "prebk_hscl", start, stop, value);
			SERIAL  results[SITE] = value[SITE]/(PREBK_HSRDSON[SITE]/1000.0); 
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
			fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
		}
		else
		{
			Cmd_Dmuxset_Main(0);
			Cmd_TMSel(0x0000000000900100);
			Cmd_TMSel(0x0048000000B00100);
			set_fb_hc(4.0);
			delay_ms(3);
			fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			delay_ms(1);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			double start = 0;
			double stop = 4.0;
			double step = calc_step(start,stop, 100);
			prebk_hscl(fpvi0, FPVIe_5V, FPVIe_10A, "prebk_hscl2", start, stop, value);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			SERIAL  results[SITE] = value[SITE];
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			//Cmd_TMSel(0x0000000000900100);
			//Cmd_TMSel(0x0048000000B00100);
		}
		Ms_LogData(funcindex, "PreBK_Ipk2", results);
		Cmd_Bank0(true);
		Cmd_LMTCFG(0, prebk_limit, 0, 0, 0);
		CmdReadData(LMT_PD_CFG,data0);
		set_fb_hc(4.0);
	}

	if (DIE_VER() == 0)
	{
		Cmd_Dmuxset_Main(0);
		Cmd_TMSel(0x0048000000A00900);
		set_vsx(8.0);
		set_fb_hc(4.0);
		//delay_ms(2);
		fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
		delay_ms(2);
		fpvi0.Set(FV, -0.3, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
		//awg.rampvmi_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_max_clampcomp", 0 V, 2 V, 0.02 V, 20, 13.8 mA, TRIG_RISING, value);
		prebk_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_max_clampcomp", -0.3, 2, value);
		fpvi0.Set(FI, 0, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
		delay_ms(2);
		SERIAL  value[SITE] = value[SITE] / (PREBK_HSRDSON[SITE] / 1000.0);
	}
	else
	{
		Cmd_Dmuxset_Main(0);
		Cmd_TMSel(0x0000000000900900);
		//Cmd_TMSel(0x0048000000A00900);
		set_vsx(8.0);
		set_fb_hc(4.0);
		//delay_ms(2);
		fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON);
		delay_ms(2);
		fpvi0.Set(FI, 0.0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
		fpvi0.Set(FI, 1.0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
		//awg.rampvmi_hscl(fpvi0, fxvi4, FPVIe_2V, FPVIe_100MA, "prebk_max_clampcomp", 0 V, 2 V, 0.02 V, 20, 13.8 mA, TRIG_RISING, value);
		prebk_hscl(fpvi0, FPVIe_5V, FPVIe_10A, "prebk_max_clampcomp", 1.0, 4.5, value);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
		delay_ms(2);
	}
	Ms_LogData(funcindex, "PreBK_MaxClamp", value);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	delay_ms(2);
	C_FPVIH_VS1_DisConnect;
	C_FPVIL_SW_DisConnect;
	C_SW_PD_DisConnect;
	C_VST_CAP_Connect;
	C_VS1_CAP_Connect;
	delay_ms(2);

	Poweroff_tm_hc();
	delay_ms(2);
	Poweron_tm_hc();
	set_fb_hc(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	set_vsx(6.0);

	C_FPVIH_SW_Connect;
	C_FPVIL_PG_Connect;
	delay_ms(2);
	set_fb_hc(6.0);
	if (DIE_VER() == 0)
	{
		Cmd_Bank1(true);
		Cmd_TMSel(0x0000000000840100);
		Cmd_TMSel(0x0000000000820100);
	}
	else
	{
		Cmd_Bank1(true);
		Cmd_TMSel(0x0000000000000000);
		Cmd_TMSel(0x0000000000840100);
		Cmd_TMSel(0x0000000000820100);
	}
	set_fb_hc(6.0);
	delay_ms(2);
	////lsrdson
	//set_vsx(12.0);
	//set_vsx(6.0);
	//double rdson_i = 500 mA;
	//Cmd_Bank1(true);
	//Cmd_Dmuxset_Main(0);
	//Cmd_TMSel(0x0000000000840100);
	//Cmd_TMSel(0x0000000000820100);
	//set_fb_hc(6.0);
	//delay_ms(2);
	//fpvi0.Set(FI, rdson_i, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON,1);
	//delay_ms(1);
	//fpvi0.MeasureVI(30,10);
	//Get_Result(fpvi0, lsrdson_v, MVRET);
	//SERIAL lsrdson_r[SITE]=(lsrdson_v[SITE]/rdson_i)*1000.0;
	//SERIAL PREBK_LSRDSON[SITE]=lsrdson_r[SITE];
	////Ms_LogData(funcindex, "prebk_lsrdson", lsrdson_r);
	//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	Cmd_Bank0(true);
	Cmd_Go2_Normal();
	Cmd_ReadState(data1);
	Cmd_Bank1(true);
	//Cmd_Forceoff(except_dcdc);
	set_vsx(6.0);
	if(test_current)
	{
		int prebk_limit = dut.sel("PREBK_LMT").get_working(0);
		Cmd_Bank0(true);
		Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
		CmdWriteData(0x22,0xFF);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_ReadState(data2);//2
		Cmd_LMTCFG(0, 1, 0, 0, 0);
		//CmdReadData(LMT_PD_CFG,data0);
		Cmd_Bank1(true);
		//Cmd_Forceoff(except_dcdc);
		//set_vsx(6.0);
		if(DIE_VER()==0)
		{
			Cmd_Dmuxset_Main(254);
			Cmd_TMSel(0x2248000000840100);//tm62
			set_fb_hc(4.0);
			delay_ms(2);//acm10
			start = 0.5;
			stop = -1.2;
			step=calc_step(start,stop,100);
			//awg.rampvmv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_2A, "prebk_lscl", start, stop, step, 20, 2.5, TRIG_FALLING, value);
			awg.rampvmv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_2A, "prebk_lscl", start, stop, step, 20, 2.5, TRIG_FALLING, value);
			fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
			SERIAL  results[SITE] = -value[SITE]/(PREBK_LSRDSON[SITE]/1000.0); //A
		}
		else
		{
			Cmd_Dmuxset_Main(254);
			Cmd_TMSel(0x0000000000840100);
			Cmd_TMSel(0x2248000000820100);//tm62
			set_fb_hc(4.0);
			delay_ms(2);//acm10
			step=calc_step(0,-6,100);
			awg.rampimv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_10A, "prebk_lscl2", 0, -6, step, 20, 2.5, TRIG_FALLING, value);
			fpvi0.Set(FI, 0, FPVIe_2V, FPVIe_10A, FPVIe_RELAY_ON);
			SERIAL  results[SITE] = -value[SITE]; //A
		}
		Ms_LogData(funcindex, "PreBK_Ivy1", results);
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		//Cmd_ReadState(data2);//2
		Cmd_LMTCFG(0, 0, 0, 0, 0);
		CmdReadData(LMT_PD_CFG,data0);
		Cmd_Bank1(true);
		if(DIE_VER()==0)
		{
			Cmd_Dmuxset_Main(254);
			Cmd_TMSel(0x2248000000840100);//tm62
			set_fb_hc(4.0);
			delay_ms(2);//acm10
			start = 0.5;
			stop = -1.2;
			step=calc_step(start,stop,100);
			//awg.rampvmv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_2A, "prebk_lscl", start, stop, step, 20, 2.5, TRIG_FALLING, value);
			awg.rampvmv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_2A, "prebk_lscl", start, stop, step, 20, 2.5, TRIG_FALLING, value);
			fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
			SERIAL  results[SITE] = -value[SITE]/(PREBK_LSRDSON[SITE]/1000.0); //A
		}
		else
		{
			Cmd_Dmuxset_Main(254);
			Cmd_TMSel(0x0000000000840100);
			Cmd_TMSel(0x2248000000820100);//tm62
			set_fb_hc(4.0);
			delay_ms(2);//acm10
			step=calc_step(0,-4,100);
			awg.rampimv(fpvi0, A_DBUFO, FPVIe_2V, FPVIe_10A, "prebk_lscl2", 0, -4, step, 20, 2.5, TRIG_FALLING, value);
			fpvi0.Set(FI, 0, FPVIe_2V, FPVIe_10A, FPVIe_RELAY_ON);
			SERIAL  results[SITE] = -value[SITE]; //A
		}
		Ms_LogData(funcindex, "PreBK_Ivy2", results);
	}
	fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_100MA, FPVIe_RELAY_ON);
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	delay_ms(2);

	Cmd_Forceoff(except_dcdc);
	set_vsx(6.0);
	if (DIE_VER() == 0)
	{
		Cmd_Dmuxset_Main(254);
		//Cmd_TMSel(0x2248000000820100);
		Cmd_TMSel(0x2248000000840100);//tm66
		set_fb_hc(4.0);
		//delay_ms(2);//acm10
		//-0.3 to 0.3
		start = -0.3;
		stop = 1.0;
		step = calc_step(start, stop, 100);
		fpvi0.Set(FV, start, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
		awg.rampvmv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_100MA, "zc_neg_ls", start, stop, step, 20, 2.5 V, TRIG_FALLING, value);
		SERIAL  value[SITE] = value[SITE] / (PREBK_LSRDSON[SITE] / 1000.0); //A
	}
	else
	{
		Cmd_Dmuxset_Main(254);
		//Cmd_TMSel(0x2248000000820100);
		Cmd_TMSel(0x0000000000840100);
		Cmd_TMSel(0x2248000000820100);//tm66
		set_fb_hc(4.0);
		//delay_ms(2);//acm10
		//-0.3 to 0.3
		start = 0.5;
		stop = 1.5;
		step = calc_step(start, stop, 100);
		fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
		fpvi0.Set(FI, start, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
		awg.rampimv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_2A, "zc_neg_ls", start, stop, step, 20, 2.0 V, TRIG_FALLING, value);
		fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
		SERIAL  value[SITE] = value[SITE]; //A
	}
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	delay_ms(2);
	Ms_LogData(funcindex, "PreBK_ZcNeg", value);

	//double value[SITE_NUM];
	//prebk_max_negative_ls_limit
	if (DIE_VER() == 0)
	{
		Cmd_Dmuxset_Main(254);
		//Cmd_TMSel(0x2248000000820100);
		Cmd_TMSel(0x2248000000840100);//tm64
		set_vsx(6.0);
		set_fb_hc(6.0);//acm10
		//1.0 to -0.5
		start = 1.0;
		stop = -0.5;
		step = calc_step(start, stop, 100);
		awg.rampvmv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_100MA, "max_neg_ls", start, stop, step, 50, 2.5 V, TRIG_RISING, value);
		SERIAL  value[SITE] = value[SITE] / (PREBK_LSRDSON[SITE] / 1000.0); //A
	}
	else
	{
		double value0[SITE_NUM];
		double value1[SITE_NUM];
		if (1)
		{
			int zcd_code[SITE_NUM];
			SERIAL zcd_code[SITE] = dut.trim("prebk_zc").get_working(SITE);
			dut.trim("prebk_zc").set_working(1);//
			Nvm_Preview(14);
			Cmd_Dmuxset_Main(254);
			//Cmd_TMSel(0x2248000000820100);
			Cmd_TMSel(0x0000000000840100);
			Cmd_TMSel(0x2248000000820100);//tm64
			set_vsx(6.0);
			set_fb_hc(6.0);//acm10
			//1.0 to -0.5
			start = 1.6;
			stop = 1.0;
			step = calc_step(start, stop, 100);
			fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			fpvi0.Set(FI, start, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			awg.rampimv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_2A, "max_neg_ls", start, stop, step, 50, 0.1 V, TRIG_FALLING, value1);
			dut.trim("prebk_zc").set_working(0);//
			Nvm_Preview(14);
			fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			fpvi0.Set(FI, start, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			awg.rampimv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_2A, "max_neg_ls", start, stop, step, 50, 0.1 V, TRIG_RISING, value0);
			//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			SERIAL
			{
				if (value1[SITE] > 999) { value[SITE] = value0[SITE]; }
				else { value[SITE] = value1[SITE]; }
			}
			//SERIAL  value[SITE] = value[SITE]; //A
			SERIAL dut.trim("prebk_zc").set_working(zcd_code[SITE],SITE);//
			Nvm_Preview(14);
		}
		else
		{
			Cmd_Dmuxset_Main(254);
			//Cmd_TMSel(0x2248000000820100);
			Cmd_TMSel(0x0000000000840100);
			Cmd_TMSel(0x2248000000820100);//tm64
			set_vsx(6.0);
			set_fb_hc(6.0);//acm10
			//1.0 to -0.5
			start = 1.6;
			stop = 1.0;
			step = calc_step(start, stop, 100);
			fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			fpvi0.Set(FI, start, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			awg.rampimv(fpvi0, A_DBUFO, FPVIe_1V, FPVIe_2A, "max_neg_ls", start, stop, step, 50, 0.1 V, TRIG_RISING, value);
			//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_2A, FPVIe_RELAY_ON);
			SERIAL  value[SITE] = value[SITE]; //A
		}
	}
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_100MA, FPVIe_RELAY_ON);
	Ms_LogData(funcindex, "PreBK_MaxNeg", value);
	Cmd_Dmuxset_Main(0);
	Cmd_TMSel(0x00);
	C_FPVIH_SW_DisConnect;
	C_FPVIL_PG_DisConnect;
	delay_ms(2);

	//C_DBUFI_SW1;
	//C_DCM_DBUFO_Connect;
	//delay_ms(2);
	////double freq[SITE_NUM];
	////double duty[SITE_NUM];
	////double ton[SITE_NUM];
	////double toff[SITE_NUM];
	////mini_on
	//set_fb_hc(6.0);
	//measure_freq_duty_set("DCM5",5.0);
	//delay_ms(1);
	//measure_t_get("DCM5",freq, duty, ton, toff);
	//Ms_LogData(funcindex, "PreBK_Ton", ton);
	////mini_off
	//set_fb_hc(5.2);
	//measure_freq_duty_set("DCM5",5.0);
	//delay_ms(1);
	//measure_t_get("DCM5",freq, duty, ton, toff);
	//Ms_LogData(funcindex, "PreBK_Toff", toff);
	//Ms_LogData(funcindex, "PreBK_Dmax", duty);
	//C_DBUFI_DisConnect;
	//C_DCM_DBUFO_DisConnect;
	//C_SW_PD_DisConnect;
	delay_ms(2);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_OFF);

	//prebk output
	set_posfb_plus_target(0.1);
	double v_fb[SITE_NUM];
	//set_vsx(4.0);
	Cmd_Bank1(true);
	Cmd_Masksafe();
	//prebk_load_connect();
	//set_vsx(6.0);
	//set_fb_plus_target_hc(0.1);//target+0.1V
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	Cmd_ReadState(tempd);
	Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	CmdWriteData(0x22,0xFF);
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	delay_ms(2);
	prebk_load_connect();
	delay_ms(2);
	set_vsx(12.0);
	double results1[SITE_NUM];
	//if (PINarray[29].pin_valid)//ssd
	//{
	//	int code = dut.sel("SSD_EVS").get_working(0);
	//	set_vsx(12.0);
	//	set_fb_plus_target_hc(0.1);
	//	Cmd_Bank0(true);
	//	Cmd_Go2_Normal();
	//	Cmd_ReadState(tempd);
	//	Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	//	F_FB.MeasureVI(100,10);
	//	Get_Result(F_FB, v_fb, MVRET);
	//	A_SSD.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);//acm10
	//	C_ACM_SSD_Connect;
	//	delay_ms(1);
	//	A_SSD.MeasureVI(100,1);
	//	A_SSD.Set(FI, -10 uA, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//	A_SSD.MeasureVI(20,10);
	//	Get_Result(A_SSD, results1, MVRET);
	//	SERIAL results1[SITE]=results1[SITE]-v_fb[SITE];
	//	Ms_LogData(funcindex, "SSD_Voh", results1);
	//	double ssd_value[SITE_NUM];
	//	SERIAL ssd_value[SITE]=v_fb[SITE]+3.5;
	//	A_SSD.SetSyn(FV, ssd_value, SITE_NUM, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//	A_SSD.MeasureVI(20,10);
	//	Get_Result(A_SSD, results1, MIRET);
	//	SERIAL results1[SITE]=results1[SITE]*1000000.0;
	//	Ms_LogData(funcindex, "SSD_Isrc", results1);
	//	// 
	//	//Cmd_Forceoff(all_off);
	//	A_SSD.Set(FI, 10 uA, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//	A_SSD.MeasureVI(20,10);
	//	Get_Result(A_SSD, results1, MVRET);
	//	SERIAL results1[SITE]=results1[SITE]-v_fb[SITE];
	//	Ms_LogData(funcindex, "SSD_Vol", results1);
	//	SERIAL ssd_value[SITE]=v_fb[SITE]+1.5;
	//	A_SSD.SetSyn(FV, ssd_value, SITE_NUM, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//	A_SSD.MeasureVI(20,10);
	//	Get_Result(A_SSD, results1, MIRET);
	//	SERIAL results1[SITE]=results1[SITE]*1000000.0;
	//	Ms_LogData(funcindex, "SSD_Isnk", results1);
	//	A_SSD.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//	C_ACM_SSD_DisConnect;
	//	delay_ms(1);
	//}
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//prebk_load_connect();
	F_FB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//prebk_load_connect();

	////prebk output
	//double v_fb[SITE_NUM];
	//Cmd_Bank0(true);
	////set_vsx(6.0);
	//set_fb_plus_target_hc(0.1);//target+0.1V
	//Cmd_Dis_ERR_WD();
	//Cmd_Go2_Normal();
	//Cmd_ReadState(tempd);
	//Cmd_Bank1(true);
	//Nvm_PreviewFs(-1);
	//set_vsx(12.0);
	////delay_ms(2);
	////A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//F_FB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//prebk_load_connect();


	delay_ms(2);
	F_FB.MeasureVI(100,10);
	Get_Result(F_FB, v_fb, MVRET);
	if(PN_Prebk_Output == 5.8){Ms_LogData(funcindex, "PreBK_V1", v_fb);}
	else if(PN_Prebk_Output == 5.65){Ms_LogData(funcindex, "PreBK_V2", v_fb);}
	else if(PN_Prebk_Output == 3.9){Ms_LogData(funcindex, "PreBK_V3", v_fb);}
	else{}

	bool all_vout = false;

	if(all_vout)
	{
		int code = dut.sel("PREBK_VOUT").get_working(0);
		dut.sel("PREBK_VOUT").set_working(0);
		Cmd_Bank1(true);
		Nvm_PreviewFs(1);
		delay_ms(5);
		F_FB.MeasureVI(100,10);
		Get_Result(F_FB, v_fb, MVRET);
		Ms_LogData(funcindex, "PreBK_V1", v_fb);
		dut.sel("PREBK_VOUT").set_working(1);
		Cmd_Bank1(true);
		Nvm_PreviewFs(1);
		delay_ms(5);
		F_FB.MeasureVI(100,10);
		Get_Result(F_FB, v_fb, MVRET);
		Ms_LogData(funcindex, "PreBK_V2", v_fb);
		dut.sel("PREBK_VOUT").set_working(2);
		Cmd_Bank1(true);
		Nvm_PreviewFs(1);
		delay_ms(5);
		F_FB.MeasureVI(100,10);
		Get_Result(F_FB, v_fb, MVRET);
		Ms_LogData(funcindex, "PreBK_V3", v_fb);
		dut.sel("PREBK_VOUT").set_working(code);
		Nvm_PreviewFs(1);
	}
	
	Poweroff_tm_hc();
	set_posfb(false);
	C_FRE_PU_DisConnect;
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	C_ACM_SECPOSFRE_DisConnect;
	prebk_load_disconnect();
	A_DBUFO.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T43_POSBK(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];
	int data5[SITE_NUM];
	int data6[SITE_NUM];
	int data7[SITE_NUM];
	int data8[SITE_NUM];
	int data9[SITE_NUM];

	double results[SITE_NUM];
	double freq[SITE_NUM];
	double duty[SITE_NUM];
	double ton[SITE_NUM];
	double toff[SITE_NUM];
	double rise[SITE_NUM];
	double fall[SITE_NUM];
	double hys[SITE_NUM];
	double hsrdson[SITE_NUM];
	double lsrdson[SITE_NUM];
	double Ilk[SITE_NUM];

	Ms_LogData(funcindex, "posbk_available1", PN_Posbk_Available);
	if(!PN_Posbk_Available){return true;}

	Ms_LogData(funcindex, "PosBK_Rhs", POSBK_HSRDSON);
	Ms_LogData(funcindex, "PosBK_Rls", POSBK_LSRDSON);

	set_sec_posfre(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
	C_FXVI_ACM_GND_Connect;
	C_ACM_SECPOSFRE_Connect;
	//C_ACM_FB1_Connect;

	Poweron_tm();
	set_fb(5.5);
	set_quc(5.0);
	set_qst(5.1);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	//Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	//Cmd_Forceoff(except_postbk);
	/////////////////POST BUCK CONVERT//////////////////////
	A_POSFB.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	Cmd_Forceoff(all_off);
	set_vsx(6.0);
	set_posin(6.0);
	delay_ms(1);
	A_POSFB.Set(FV, 2.5, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_POSFB.MeasureVI(20,10);
	Get_Result(A_POSFB, Ilk, MIRET);
	SERIAL Ilk[SITE]=Ilk[SITE]*1000.0;//mA
	Ms_LogData(funcindex, "PosBK_Idis", Ilk);
	A_POSFB.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);

	//hsleak
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_POSIN.Set(FV, 6.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	A_POSIN.Set(FV, 6.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(1);
	A_POSIN.MeasureVI(20,10);
	Get_Result(A_POSIN, Ilk, MIRET);
	SERIAL Ilk[SITE]=Ilk[SITE]*1000000.0;//nA
	Ms_LogData(funcindex, "PosBK_Idshs", Ilk);
	A_POSSW.Set(FV, 6.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_POSSW.Set(FV, 6.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(1);
	A_POSSW.MeasureVI(20,10);
	Get_Result(A_POSSW, Ilk, MIRET);
	SERIAL Ilk[SITE]=Ilk[SITE]*1000000.0;//nA
	Ms_LogData(funcindex, "PosBK_Idsls", Ilk);
	A_POSSW.Set(FI, 0.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_POSSW.Set(FI, 0.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	set_posin(6.0);
	set_posfb_plus_target(-0.2);
	//Cmd_Forceoff(none_off);
	Cmd_Forceoff(except_postbk);
	C_DBUFI_POSSW;
	C_DCM_DBUFO_Connect;
	A_DBUFO.Set(FI, 0.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	C_ACM_DBUFO_Connect;
	delay_ms(1);
	//A_DBUFO.MeasureVI(1000,1);//acm10
	//measure_freq_duty_set("DCM5",5.0);
	//dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
	//delay_ms(1);
	//measure_duty_get("DCM5", freq, duty);
	//Ms_LogData(funcindex, "PosBK_Dmax", duty);
	//set_posin(5.0);
	//set_posfb_plus_target(0.1);
	//measure_freq_duty_set("DCM5",5.0);
	//delay_ms(1);
	//measure_ton_get("DCM5", freq, ton);
	//Ms_LogData(funcindex, "PosBK_Ton", ton);

	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	C_DCM_DBUFO_DisConnect;
	//Ileakage_LS_Gate
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2020000102000100);
	set_posfb_plus_target(-0.2);
	set_vsx(6.0);
	set_posin(5.0);
	delay_ms(1);
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(2);
	A_SECPOSFRE.MeasureVI(20,10);
	Get_Result(A_SECPOSFRE, Ilk, MIRET);
	SERIAL Ilk[SITE]=Ilk[SITE]*1000000.0;//uA
	Ms_LogData(funcindex, "PosBK_Igtls", Ilk);
	//
	//
	//Ileakage_HS_Gate
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2020000102000100);
	set_posin(6.0);
	delay_ms(1);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(2);
	A_SECPOSFRE.MeasureVI(20,10);
	Get_Result(A_SECPOSFRE, Ilk, MIRET);
	SERIAL Ilk[SITE]=Ilk[SITE]*1000000.0;//uA
	Ms_LogData(funcindex, "PosBK_Igths", Ilk);

	set_sec_posfre(FI, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//
	//
	set_sec_posfre(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	//VIN_Min5v
	C_DBUFI_FRE;
	C_FRE_PU_Connect;
	C_ACM_DBUFO_Connect;
	C_ACM_SECPOSFRE_Connect;
	double value[SITE_NUM];
	
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2848000016000100);
	set_posfb_plus_target(-0.2);
	set_vsx(6.0);
	set_posin(4.5);//acm5,acm10
	double start = 4.7;
	double stop = 5.3;
	double step = calc_step(start, stop, 100);
	awg.rampvmv(A_POSIN, A_DBUFO, ACM200_10V, ACM200_10MA, "VIN_Min5v", start, stop, step, 30, 2.5 V, TRIG_RISING, value);
	//awg.rampvmv(A_POSIN, A_DBUFO, ACM200_10V, ACM200_10MA, "VIN_Min5v", stop, 4.2, step, 30, 2.5 V, TRIG_FALLING, value);
	Ms_LogData(funcindex, "PosBK_Min5V", value);
	Cmd_Dmuxset_Main(0);
	Cmd_TMSel(0x00);

	Cmd_Dmuxset_Fs0(31);//2.5,1.3
	Cmd_TMSel(0x0060000006000108);//tm48,acm9,acm10
	step = calc_step(1.0 uA,-4 uA,120);
	set_sec_posfre(FI, 0 uA, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	set_sec_posfre(FI, -10 uA, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	set_sec_posfre(FI, 0 uA, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	awg.rampimv(A_SECPOSFRE, A_DBUFO, ACM200_10V, ACM200_10UA, "posbk_tsw_rise", 1.0 uA, -4 uA, step, 50, 2.5 V, TRIG_FALLING, rise);
	awg.rampimv(A_SECPOSFRE, A_DBUFO, ACM200_10V, ACM200_10UA, "posbk_tsw_fall", -4 uA, 1.0 uA, step, 50, 2.5 V, TRIG_RISING, fall);
	set_sec_posfre(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	SERIAL rise[SITE]=-rise[SITE]*1000000.0;
	SERIAL fall[SITE]=-fall[SITE]*1000000.0;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "PosBK_OTWriseV", rise);
	Ms_LogData(funcindex, "PosBK_OTWfallV", fall);
	Ms_LogData(funcindex, "PosBK_OTWhysV", hys);
	SERIAL rise[SITE]=rise[SITE]/0.0175+30.0;
	SERIAL fall[SITE]=fall[SITE]/0.0175+30.0;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "PosBK_OTWrise", rise);
	Ms_LogData(funcindex, "PosBK_OTWfall", fall);
	Ms_LogData(funcindex, "PosBK_OTWhys", hys);
	//prebk_tsd
	Cmd_Dmuxset_Fs0(30);//3.6,1.0
	Cmd_TMSel(0x0060000082000108);//tm47,acm9,acm10
	step = calc_step(0.5 uA,-5 uA,120);
	awg.rampimv(A_SECPOSFRE, A_DBUFO, ACM200_10V, ACM200_10UA, "posbk_tsd_rise", 0.5 uA, -5 uA, step, 50, 2.5 V, TRIG_FALLING, rise);
	awg.rampimv(A_SECPOSFRE, A_DBUFO, ACM200_10V, ACM200_10UA, "posbk_tsd_fall", -5 uA, 0.5 uA, step, 50, 2.5 V, TRIG_RISING, fall);
	set_sec_posfre(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	SERIAL rise[SITE]=-rise[SITE]*1000000.0;
	SERIAL fall[SITE]=-fall[SITE]*1000000.0;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "PosBK_TSDriseV", rise);
	Ms_LogData(funcindex, "PosBK_TSDfallV", fall);
	Ms_LogData(funcindex, "PosBK_TSDhysV", hys);
	SERIAL rise[SITE]=rise[SITE]/0.01926+30.0;
	SERIAL fall[SITE]=fall[SITE]/0.01926+30.0;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "PosBK_TSDrise", rise);
	Ms_LogData(funcindex, "PosBK_TSDfall", fall);
	Ms_LogData(funcindex, "PosBK_TSDhys", hys);
	Cmd_Dmuxset_Fs0(0);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x2848000016000100);

	C_DBUFI_DisConnect;
	C_FRE_PU_DisConnect;
	C_ACM_DBUFO_DisConnect;
	Cmd_Dmuxset_Main(0);
	Cmd_TMSel(0x00);

	set_vsx(6.0);
	set_posin(6.0);
	set_posfb_plus_target(0.2);
	//set_posfb(1.5);
	Cmd_Bank0(true);
	Cmd_Dis_ERR_WD();
	Cmd_Go2_Normal();
	//Cmd_ReadState(data2);//2
	//CmdReadData(0x33,data3);//1
	//Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	//Cmd_Bank0(true);
	//Cmd_Dis_ERR_WD();
	//Cmd_Go2_Normal();
	////Cmd_ReadState(tempd);//2
	//CmdWriteData(BCK_FRE_SPREAD,0x00);//no spsp
	//A_POSSW.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	C_DBUFI_DisConnect;
	C_DBUFI_POSSW;
	C_DBUF_Usage;
	C_DCM_DBUFO_Connect;
	delay_ms(2);
	measure_freq_duty_set("DCM5",5.0);
	measure_ton_get("DCM5",freq, ton);
	if (!PART_QUAL())
	{
		Ms_LogData(funcindex, "PosBK_Fswl", freq);
		Ms_LogData(funcindex, "PosBK_Ton", ton);
	}
	set_posfb_plus_target(0.0);
	measure_freq_duty_set("DCM5",5.0);
	dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
	delay_ms(1);

	A_POSSW.MeasureVI(100,1);
	//mini_off
	set_posin(6.0);
	set_posfb_plus_target(-0.5);
	delay_ms(1);
	A_POSSW.MeasureVI(10,10);
	Get_Result(A_POSSW, results, MVRET);
	measure_freq_duty_set("DCM5",5.0, DCM_LOW);
	//dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
	measure_freq_get("DCM5",freq);
	SERIAL
	{
		if(freq[SITE]>9999999999)
		{
			if(results[SITE]>4.5){duty[SITE]=100.0;}
			else{duty[SITE]=0.0;}
		}	
	}
	Ms_LogData(funcindex, "PosBK_Dmax", duty);
	C_DBUFI_DisConnect;
	C_DCM_DBUFO_DisConnect;
	C_DBUF_Bypass;
	//A_POSSW.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	delay_ms(2);

	if(1)
	{
		C_DBUFI_FRE;
		C_FRE_PU_Connect;
		C_ACM_DBUFO_Connect;//dcm5
		delay_ms(2);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_100UA, FPVIe_RELAY_ON);
		delay_ms(2);
		C_FPVIH_POSSW_Connect;
		C_FPVIL_POSG_Connect;
		delay_ms(2);

		Cmd_Bank1(true);
		Cmd_Dmuxset_Main(254);
		Cmd_TMSel(0x0000000006000100);
		set_fb(4.0);
		delay_ms(2);
		Cmd_Bank1(true);
		Cmd_Dmuxset_Main(254);
		Cmd_TMSel(0x2E48000006000100);//tm82
		set_posfb_plus_target(0.3);
		set_vsx(6.0);
		set_posin(5.0);

		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		Cmd_Bank1(true);

		//vy_negcl
		fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
		awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_vy_negcl", 0 A, 1.5 A, step, 30, 2.5 V, TRIG_FALLING, results);
		SERIAL results[SITE] = -results[SITE]; 
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);

		double vy_negcl[SITE_NUM];
		double result[SITE_NUM];
		//SERIAL vy_negcl[SITE]=dut.trim("postbk_vy_negcl").get_post_reading(SITE);
		SERIAL vy_negcl[SITE] = results[SITE];

		int posbk_limit = dut.sel("POSTBK_LMT").get_working(0);
		if(1)//mirror down
		{
			Cmd_LMTCFG(0, 0, 0, 0, 0);
			//CmdReadData(LMT_PD_CFG,data0);
			Cmd_Bank1(true);
			Cmd_Dmuxset_Main(254);
			//Cmd_TMSel(0x2E48000006000100);//no mirror down mode
			Cmd_TMSel(0x2E48000026000100);//mirror down mode
			set_posfb(0.0);//target-0.2V
			delay_ms(1);
			double start = 0.0;
			double stop = -1.8;
			double step = calc_step(start,stop,100);
			fpvi0.Set(FI, start, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON);
			awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_2A, "postbk_vymax", start, stop, step, 20, 2.5 V, TRIG_RISING, result);
			posbk_vymax_convert(result, vy_negcl, results);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_2A, FPVIe_RELAY_ON,1);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
			Ms_LogData(funcindex, "PosBK_Ivy1", results);
			Cmd_Bank0(true);
			Cmd_Dis_ERR_WD();
			Cmd_Go2_Normal();
			Cmd_LMTCFG(1, 0, 0, 0, 0);
			//CmdReadData(LMT_PD_CFG,data0);
			Cmd_Bank1(true);
			Cmd_Dmuxset_Main(254);
			//Cmd_TMSel(0x2E48000006000100);//no mirror down mode
			Cmd_TMSel(0x2E48000026000100);//mirror down mode
			set_posfb(0.0);//target-0.2V
			delay_ms(1);
			start = 0.0;
			stop = -2.8;
			step = calc_step(start,stop,100);
			//double vy_negcl[SITE_NUM];
			//SERIAL vy_negcl[SITE]=dut.trim("postbk_vy_negcl").get_post_reading(SITE);
			fpvi0.Set(FI, start, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_vymax", start, stop, step, 20, 2.5 V, TRIG_RISING, result);
			posbk_vymax_convert(result, vy_negcl, results);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
			Ms_LogData(funcindex, "PosBK_Ivy2", results);
			Cmd_LMTCFG(posbk_limit, 0, 0, 0, 0);
		}
		else
		{
			Cmd_LMTCFG(0, 0, 0, 0, 0);
			//CmdReadData(LMT_PD_CFG,data0);
			Cmd_Bank1(true);
			Cmd_Dmuxset_Main(254);
			Cmd_TMSel(0x2E48000006000100);//no mirror down mode
			//Cmd_TMSel(0x2E48000026000100);//mirror down mode
			set_posfb(0.0);//target-0.2V
			delay_ms(1);
			double start = -0.5;
			double stop = -4.0;
			double step = calc_step(start,stop,100);
			fpvi0.Set(FI, start, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_vymax", start, stop, step, 20, 2.5 V, TRIG_RISING, results);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
			Ms_LogData(funcindex, "PosBK_Ivy1", results);
			Cmd_Bank0(true);
			Cmd_Dis_ERR_WD();
			Cmd_Go2_Normal();
			Cmd_LMTCFG(1, 0, 0, 0, 0);
			//CmdReadData(LMT_PD_CFG,data0);
			Cmd_Bank1(true);
			Cmd_Dmuxset_Main(254);
			Cmd_TMSel(0x2E48000006000100);//no mirror down mode
			//Cmd_TMSel(0x2E48000026000100);//mirror down mode
			set_posfb(0.0);//target-0.2V
			delay_ms(1);
			start = -2.5;
			stop = -6.5;
			step = calc_step(start,stop,100);
			fpvi0.Set(FI, start, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON);
			awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_vymax", start, stop, step, 20, 2.5 V, TRIG_RISING, results);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
			fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
			Ms_LogData(funcindex, "PosBK_Ivy2", results);
			Cmd_LMTCFG(posbk_limit, 0, 0, 0, 0);
		}
		delay_ms(2);
		C_FPVIH_POSSW_DisConnect;
		C_FPVIL_POSG_DisConnect;
		delay_ms(2);
		C_FPVIH_POSIN_Connect;
		C_FPVIL_POSSW_Connect;
		delay_ms(2);
		//fpvi0.Set(FI, 0, FPVIe_2V, FPVIe_1A, FPVIe_RELAY_ON);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
		//postbk_pkmax, 5.7A, ramp possw 0A,2A, monitor FRE signal
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		//int posbk_limit = dut.sel("POSTBK_LMT").get_working(0);
		Cmd_LMTCFG(0, 0, 0, 0, 0);
		//CmdReadData(LMT_PD_CFG,data0);
		Cmd_Bank1(true);
		Cmd_Dmuxset_Main(254);
		//Cmd_TMSel(0x2C480000C2000100);//tm77
		Cmd_TMSel(0x2C48000082000100);//no mirror down mode
		Cmd_Bank1(true);
		set_posfb(0.0);//target-0.2V
		delay_ms(2);
		start = 1.0;
		stop = 5.5;
		step = calc_step(start,stop,100);
		fpvi0.Set(FI, start, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
		awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_pkmax", start, stop, step, 20, 2.5 V, TRIG_FALLING, results);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
		//SERIAL  results[SITE]=results[SITE]*8.0;
		//fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
		Ms_LogData(funcindex, "PosBK_Ipk1", results); 
		Cmd_Bank0(true);
		Cmd_Dis_ERR_WD();
		Cmd_Go2_Normal();
		//int posbk_limit = dut.sel("POSTBK_LMT").get_working(0);
		Cmd_LMTCFG(1, 0, 0, 0, 0);
		//CmdReadData(LMT_PD_CFG,data0);
		Cmd_Bank1(true);
		Cmd_Dmuxset_Main(254);
		//Cmd_TMSel(0x2C480000C2000100);//tm77
		Cmd_TMSel(0x2C48000082000100);//no mirror down mode
		Cmd_Bank1(true);
		set_posfb(0.0);//target-0.2V
		delay_ms(2);
		start = 3.5;
		stop = 7.6;
		step = calc_step(start,stop,100);
		fpvi0.Set(FI, start, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
		awg.rampimv(fpvi0, A_DBUFO, FPVIe_5V, FPVIe_10A, "postbk_pkmax", start, stop, step, 30, 2.5 V, TRIG_FALLING, results);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10A, FPVIe_RELAY_ON,1);
		fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
		//SERIAL  results[SITE]=results[SITE]*8.0;
		//fpvi0.Set(FI, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
		Ms_LogData(funcindex, "PosBK_Ipk2", results); 
		Cmd_LMTCFG(posbk_limit, 0, 0, 0, 0);

		C_FPVIH_POSIN_DisConnect;
		C_FPVIL_POSSW_DisConnect;
		delay_ms(2);
		fpvi0.Set(FV, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_OFF);
	}

	//postbk_ss///////////////////, fre h to l to h
	F_SCS.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_SCS_Connect;
	test_ss(F_SCS, A_DBUFO, 3500, 1, results);//fxvi5,acm10
	set_posfb_plus_target(-0.2);
	//dut.sel("POSTBK_SS").set_working(0);//2ms
	//Nvm_PreviewFs(4);
	int state0[SITE_NUM];
	Cmd_Bank0(true);
	Cmd_ReadState(state0);
	Cmd_Bank1(true);
	Cmd_Dmuxset_Main(254);
	int POSTBK_SS = dut.sel("POSTBK_SS").get_working(0);

	Nvm_Preview(20);
	delay_ms(1);
	CmdWriteData(0x28, 0x00);
	CmdWriteData(0x29, 0x01);
	CmdWriteData(0x2A, 0x00);
	CmdWriteData(0x2C, 0x00);
	CmdWriteData(0x2D, 0x00);
	CmdWriteData(0x2E, 0x48);
	CmdWriteData(0x2F, 0x2C);
	Cmd_Set_Freq(100 KHz);
	int state2 = dcm.RunVectorWithGroup("SPI_DUT", "CMD1_Start", "CMD1_Stop", false);
	test_ss(F_SCS, A_DBUFO, 3500, 1, results);//fxvi5,acm10
	SERIAL results[SITE] = results[SITE] + 0.0232;
	Cmd_Set_Freq();
	Cmd_TMSel(0x2C480000C2000100);//rst
	if (POSTBK_SS == 0) { Ms_LogData(funcindex, "PosBK_Tssf", results); }
	else { Ms_LogData(funcindex, "PosBK_Tssl", results); }
	//dut.trim("postbk_ss").set_working(0);
	C_FXVI_SCS_DisConnect;
	F_SCS.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	A_DBUFO.Set(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_POSSW.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);

	/*fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	C_FPVIH_POSIN_Connect;
	C_FPVIL_POSSW_Connect;
	C_SW_PD_Connect;
	delay_ms(1);
	Cmd_Dmuxset_Main(254);
	Cmd_TMSel(0x0000000082000100);
	set_fb(4.0);
	fpvi0.Set(FI, 100 mA, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	delay_ms(1);
	fpvi0.MeasureVI(20,10);
	Get_Result(fpvi0, results, MVRET);
	SERIAL hsrdson[SITE] = results[SITE]/0.1;
	SERIAL hsrdson[SITE]=hsrdson[SITE]*1000.0;
	Ms_LogData(funcindex, "PosBK_Rhs", hsrdson);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_POSSW_DisConnect;
	delay_ms(1);
	C_FPVIH_POSSW_Connect;
	C_FPVIL_POSG_Connect;
	Cmd_TMSel(0x0000000006000100);
	set_fb(6.0);
	fpvi0.Set(FI, 100 mA, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	delay_ms(1);
	fpvi0.MeasureVI(20,10);
	Get_Result(fpvi0, results, MVRET);
	SERIAL lsrdson[SITE] = results[SITE]/0.1;
	SERIAL lsrdson[SITE]=lsrdson[SITE]*1000.0;
	Ms_LogData(funcindex, "PosBK_Rls", lsrdson);
	fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1A, FPVIe_RELAY_ON);
	C_FPVIH_POSSW_DisConnect;
	C_FPVIL_POSG_DisConnect;*/
	//set_posfb_plus_target(-0.5);

	set_posfb(false);
	set_posin(false);
	//C_POSFRE_PD_Connect;
	C_FRE_PU_DisConnect;
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	C_DBUF_Bypass;
	//A_POSSW.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	Poweroff_tm();
	C_ACM_SECPOSFRE_DisConnect;

	/////////////////POST BUCK CONTROLLER//////////////////////

	//A_POSFB.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	C_POSFRE_PD_DisConnect;//HF
	C_DBUFI_POSSW;
	C_DBUF_Usage;
	C_DCM_DBUFO_Connect;
	delay_ms(2);
	Poweron_tm();
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	//Nvm_PreviewFs(-1);
	Cmd_Forceoff(except_postbk);
	set_vsx(6.0);
	//set_fb(5.5);
	set_posin(5.0);
	delay_ms(1);
	//set_posfb_plus_target(0.001);
	//set_posfb_plus_target(0.002);
	//set_posfb_plus_target(0.003);
	//set_posfb_plus_target(0.004);
	set_posfb_plus_target(0.2);
	delay_ms(1);
	measure_freq_duty_set("DCM5",5.0);
	measure_ton_get("DCM5",freq, ton);
	if (!PART_QUAL())
	{
		Ms_LogData(funcindex, "PosBK_Fswh", freq);
	}
	//Ms_LogData(funcindex, "PosBK_Ton", ton);
	A_POSFB.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	set_posin(0.0);
	delay_ms(1);
	posbk_load_connect();
	delay_ms(1);
	set_posin(5.0);
	delay_ms(2);
	A_POSFB.MeasureVI(200,10);//acm7
	Get_Result(A_POSFB, results, MVRET);
	Ms_LogData(funcindex, "PosBK_V", results);

	bool all_vout = false;

	if(all_vout)
	{
		A_POSFB.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
		int code = dut.sel("POSBK_VOUT").get_working(0);
		dut.sel("POSBK_VOUT").set_working(0);//0.8V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		A_POSFB.MeasureVI(200,10);//acm7
		Get_Result(A_POSFB, results, MVRET);
		Ms_LogData(funcindex, "PosBK_V1", results);
		dut.sel("POSBK_VOUT").set_working(2);//0.9V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		A_POSFB.MeasureVI(200,10);//acm7
		Get_Result(A_POSFB, results, MVRET);
		Ms_LogData(funcindex, "PosBK_V2", results);
		dut.sel("POSBK_VOUT").set_working(9);//1.25V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		A_POSFB.MeasureVI(200,10);//acm7
		Get_Result(A_POSFB, results, MVRET);
		Ms_LogData(funcindex, "PosBK_V3", results);
		dut.sel("POSBK_VOUT").set_working(15);//1.8V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		A_POSFB.MeasureVI(200,10);//acm7
		Get_Result(A_POSFB, results, MVRET);
		Ms_LogData(funcindex, "PosBK_V4", results);
		dut.sel("POSBK_VOUT").set_working(17);//3.3V
		Cmd_Bank1(true);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
		delay_ms(5);
		A_POSFB.MeasureVI(200,10);//acm7
		Get_Result(A_POSFB, results, MVRET);
		Ms_LogData(funcindex, "PosBK_V5", results);
		dut.sel("POSBK_VOUT").set_working(code);
		Nvm_PreviewFs(0);
		Nvm_PreviewFs(1);
	}

	C_DBUFI_DisConnect;
	C_DCM_DBUFO_DisConnect;
	C_POSFRE_PD_DisConnect;
	C_DBUF_Bypass;
	set_posin(0.0);
	delay_ms(1);
	posbk_load_disconnect();
	set_posin(false);
	set_posfb(false);
	Poweroff_tm();
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T45_IO_Logic(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	double results1[SITE_NUM];
	double results2[SITE_NUM];
	double results3[SITE_NUM];
	double results4[SITE_NUM];
	double results5[SITE_NUM];
	double results6[SITE_NUM];
	double results7[SITE_NUM];
	double results8[SITE_NUM];
	double results9[SITE_NUM];
	double results10[SITE_NUM];

	int reg0[SITE_NUM];
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int reg3[SITE_NUM];
	int reg4[SITE_NUM];
	int reg5[SITE_NUM];
	int reg6[SITE_NUM];

	int tempd1[SITE_NUM];
	int tempd2[SITE_NUM];
	int tempd3[SITE_NUM];
	int tempd4[SITE_NUM];
	int tempd5[SITE_NUM];
	int tempd6[SITE_NUM];
	int tempd7[SITE_NUM];
	int tempd8[SITE_NUM];

	int tmpdata[SITE_NUM];

	double Vh = 0;
	double Vl = 0;
	double Ih = 0;
	double Il = 0;

	Ih = -5.0 mA;
	Il = 5.0 mA;

	double vstart = 0;
	double vstop = 0;
	double step = 0;

	double rise[SITE_NUM];
	double fall[SITE_NUM];
	double hys[SITE_NUM];

	double invalid_value = 9999999999.0;

	C_FRE_PU_Connect;
	C_FXVI_ACM_GND_Connect;
	//C_DBUF_Bypass;
	//C_DBUFI_FRE;
	//C_ACM_DBUFO_Connect;
	C_ACM_SECPOSFRE_Connect;

	Poweron_tm();
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(PN_QUC_Output);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Cmd_Forceoff(all_off);
	set_vsx(6.0);
	set_fb(5.5);
	//set_quc(5.0);
	set_quc_target();
	set_sec_posfre(FV, 5.0,ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);

	if(DIE_VER()!=0)
	{
		Cmd_TMSel(0x0000000000800201);
		F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		C_FXVI_INT_Connect;
		delay_ms(1);
		F_INT.Set(FI, Il, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
		F_INT.MeasureVI(20,10);
		Get_Result(F_INT, results1, MVRET);
		Ms_LogData(funcindex, "INT_Vol", results1);
		//SERIAL results1[SITE] = results1[SITE] / Il;
		//Ms_LogData(funcindex, "INT_Rpd", results1);
		F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		C_FXVI_INT_DisConnect;
		delay_ms(1);
	}

	//ss1,ss2 vol, rpd
	Ih = -5.0 mA;
	Il = 5.0 mA;
	F_SS1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_SS1_Connect;
	delay_ms(1);
	F_SS1.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SS1.MeasureVI(20,10);
	Get_Result(F_SS1, results1, MIRET);
	SERIAL results2[SITE] = (1.0/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) {results2[SITE] = invalid_value;}
	Ms_LogData(funcindex, "SS1_Rpd", results2);
	set_quc(0.0);
	delay_ms(2);
	F_SS1.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SS1.MeasureVI(20,10);
	Get_Result(F_SS1, results1, MIRET);//6ua
	SERIAL results2[SITE] = (1.0/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
	Ms_LogData(funcindex, "SS1_RpdL", results2);
	set_quc_target();
	F_SS1.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_SS1_DisConnect;
	delay_ms(1);
	F_SS2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_SS2_Connect;
	delay_ms(1);
	F_SS2.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SS2.MeasureVI(20,10);
	Get_Result(F_SS2, results1, MIRET);
	SERIAL results2[SITE] = (1.0/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
	Ms_LogData(funcindex, "SS2_Rpd", results2);
	set_quc(0.0);
	delay_ms(2);
	F_SS2.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SS2.MeasureVI(20,10);
	Get_Result(F_SS2, results1, MIRET);
	SERIAL results2[SITE] = (1.0/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
	Ms_LogData(funcindex, "SS2_RpdL", results2);
	set_quc_target();
	F_SS2.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_SS2_DisConnect;
	delay_ms(1);
	// 
	// 
	//ena
	double tmin_pass[SITE_NUM];
	C_FXVI_ENA_Connect;
	delay_ms(1);
	Cmd_Dmuxset_Fs0(87);
	Cmd_TMSel(0x0048000002000100);
	test_tmin(F_ENA, A_SECPOSFRE, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "ena_thres", 20, tmin_pass);
	Ms_LogData(funcindex, "ENA_Tmin", tmin_pass);
	vstart = 1.0;
	vstop = 2.0;
	step = calc_step(vstart,vstop,100);
	F_ENA.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	awg.rampvmi(F_ENA, A_SECPOSFRE, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, "ena_thres1", vstart, vstop, step, 20, 5 mA, TRIG_RISING, rise);
	vstart = 0.8;
	vstop = 1.6;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(F_ENA, A_SECPOSFRE, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, "ena_thres2", vstop, vstart, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	Ms_LogData(funcindex, "ENA_Vih", rise);
	Ms_LogData(funcindex, "ENA_Vil", fall);
	Ms_LogData(funcindex, "ENA_Hys", hys);
	set_vsx(12.0);
	Vh = 16.0;
	Vl = 0.5;
	F_ENA.Set(FV, Vh, FXVIe_PLUS_20V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_ENA.Set(FV, Vh, FXVIe_PLUS_20V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_ENA.MeasureVI(20,10);
	Get_Result(F_ENA, results1, MIRET);
	SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	//SERIAL results2[SITE] = (Vh/results1[SITE])/1000000.0;//Mohm
	Ms_LogData(funcindex, "ENA_Iih", results2);
	F_ENA.Set(FV, Vl, FXVIe_PLUS_20V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_ENA.Set(FV, Vl, FXVIe_PLUS_20V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_ENA.MeasureVI(20,10);
	Get_Result(F_ENA, results1, MIRET);
	SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	//SERIAL results2[SITE] = (Vl/results1[SITE])/1000000.0;//Mohm
	Ms_LogData(funcindex, "ENA_Iil", results2);
	F_ENA.Set(FV, 0, FXVIe_PLUS_20V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_ENA_DisConnect;
	delay_ms(1);
	//wak
	C_FXVI_WAK_Connect;
	delay_ms(1);
	Cmd_Dmuxset_Fs0(88);
	Cmd_TMSel(0x0048000002000100);
	test_tmin(F_WAK, A_SECPOSFRE, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, "ena_thres", 40, tmin_pass);
	Ms_LogData(funcindex, "WAK_Tmin", tmin_pass);
	vstart = 1.0;
	vstop = 2.0;
	step = calc_step(vstart,vstop,100);
	F_WAK.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	awg.rampvmi(F_WAK, A_SECPOSFRE, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, "wak_thres1", vstart, vstop, step, 20, 5 mA, TRIG_RISING, rise);
	vstart = 0.8;
	vstop = 1.6;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(F_WAK, A_SECPOSFRE, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, "wak_thres2", vstop, vstart, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	Ms_LogData(funcindex, "WAK_Vih", rise);
	Ms_LogData(funcindex, "WAK_Vil", fall);
	Ms_LogData(funcindex, "WAK_Hys", hys);
	set_vsx(12.0);
	Vh = 5.0;
	Vl = 0.5;
	F_WAK.Set(FV, Vh, FXVIe_PLUS_20V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_WAK.Set(FV, Vh, FXVIe_PLUS_20V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_WAK.MeasureVI(20,10);
	Get_Result(F_WAK, results1, MIRET);
	SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	//SERIAL results2[SITE] = (Vh/results1[SITE])/1000000.0;//Mohm
	Ms_LogData(funcindex, "WAK_Iih", results2);
	F_WAK.Set(FV, Vl, FXVIe_PLUS_20V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_WAK.Set(FV, Vl, FXVIe_PLUS_20V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_WAK.MeasureVI(20,10);
	Get_Result(F_WAK, results1, MIRET);
	SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	//SERIAL results2[SITE] = (Vl/results1[SITE])/1000000.0;//Mohm
	Ms_LogData(funcindex, "WAK_Iil", results2);
	F_WAK.Set(FV, 0, FXVIe_PLUS_20V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_WAK_DisConnect;
	delay_ms(1);
	//err
	C_FXVI_ERR_Connect;
	delay_ms(1);
	Cmd_Dmuxset_Fs0(86);
	Cmd_TMSel(0x0048000002000100);
	vstart = 0.9;
	vstop = 3.7;
	step = calc_step(vstart,vstop,100);
	F_ERR.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	awg.rampvmi(F_ERR, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "err_thres1", vstart, vstop, step, 20, 5 mA, TRIG_RISING, rise);
	vstart = 0.7;
	vstop = 2.6;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(F_ERR, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "err_thres2", vstop, vstart, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "ERR_Vih1", rise);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "ERR_Vih2", rise);}
	Ms_LogData(funcindex, "ERR_Vil", fall);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "ERR_Hys1", hys);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "ERR_Hys2", hys);}
	Vh = PN_QUC_Output;
	F_ERR.Set(FV, Vh, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_ERR.MeasureVI(20,10);
	Get_Result(F_ERR, results1, MIRET);
	//SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	SERIAL results2[SITE] = (Vh/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
	Ms_LogData(funcindex, "ERR_Rpd", results2);
	F_ERR.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_ERR_DisConnect;
	delay_ms(1);
	//wdi
	C_FXVI_WDI_Connect;
	delay_ms(1);
	Cmd_Dmuxset_Fs0(85);
	Cmd_TMSel(0x0048000002000100);
	vstart = 0.9;
	vstop = 3.7;
	step = calc_step(vstart,vstop,100);
	F_WDI.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	awg.rampvmi(F_WDI, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "wdi_thres1", vstart, vstop, step, 20, 5 mA, TRIG_RISING, rise);
	vstart = 0.7;
	vstop = 2.6;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(F_WDI, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "wdi_thres2", vstop, vstart, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "WDI_Vih1", rise);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "WDI_Vih2", rise);}
	Ms_LogData(funcindex, "WDI_Vil", fall);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "WDI_Hys1", hys);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "WDI_Hys2", hys);}
	Vh = PN_QUC_Output;
	F_WDI.Set(FV, Vh, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_WDI.MeasureVI(20,10);
	Get_Result(F_WDI, results1, MIRET);
	//SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	SERIAL results2[SITE] = (Vh/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
	Ms_LogData(funcindex, "WDI_Rpd", results2);
	F_WDI.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_WDI_DisConnect;
	delay_ms(1);
	Cmd_Dmuxset_Fs0(0);
	Cmd_TMSel(0);
	C_FRE_PU_DisConnect;

	//SS1,SS1 voh
	Cmd_Bank0(true);
	Cmd_Unlock();
    CmdWriteData(SYSPCFG1, 0);
    CmdWriteData(WDCFG0, 0);
    Cmd_Lock();
	//Cmd_Unlock();
	//CmdReadData(0x05, tempd1);
	//CmdReadData(0x06, tempd2);
	//Cmd_Lock();
	Cmd_Bank1(true);
	Cmd_Masksafe();
	Cmd_Forceoff(all_off);
	Cmd_Bank0(true);
	//Cmd_ReadState(reg0);//1
	Cmd_Go2_Normal();
	//Cmd_ReadState(reg1);//2, ss1,ss2 high
	//ss1
	F_SS1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_SS1_Connect;
	delay_ms(1);
	Ih = -5.0 mA;
	Il = 5.0 mA;
	F_SS1.Set(FI, Ih, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SS1.MeasureVI(20,10);
	Get_Result(F_SS1, results1, MVRET);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SS1_Voh1", results1);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SS1_Voh2", results1);}
	F_SS1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_SS1_DisConnect;
	delay_ms(1);
	//ss2
	F_SS2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_SS2_Connect;
	delay_ms(1);
	Ih = -5.0 mA;
	Il = 5.0 mA;
	F_SS2.Set(FI, Ih, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SS2.MeasureVI(20,10);
	Get_Result(F_SS2, results1, MVRET);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SS2_Voh1", results1);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SS2_Voh2", results1);}
	F_SS2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_SS2_DisConnect;
	delay_ms(1);

	//C_DDS_ERR_Connect;
	//DDS_Connect();
	//DDS_Initial();
	//DDS_SetFreq(100 KHz);
	//Cmd_Bank0(true);
	////Cmd_ReadState(tempd);//1
	//Cmd_Dis_ERR_WD();
	//Cmd_En_ERR(true, true);
	//Cmd_Go2_Normal();
	////Cmd_ReadState(tempd);//2
	////Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	//Cmd_Unlock();
	//CmdWriteData(0x05, 0);
 //   CmdWriteData(0x06, 0);
	////CmdReadData(ASFCFG,data0);
	//CmdWriteData(ASFCFG,0xFF);
	////CmdReadData(ASFCFG,data1);
	////Cmd_En_ERR(true, true);
	//Cmd_Lock();
	//Cmd_Bank1(true);
	//Cmd_Dmuxset_Fs0(8);//slow
	//Cmd_TMSel(0x0048003000800121);//129
	////measure_freq_duty_set("DCM4",5.0);
	////dcm.SetTMUParam("DCM4", DCM_POS, 100, 0);
	//if(!PN_SEC_Available){dut.trim("lfo_check").execute(measure_lfo_check, spec, funcindex, funclabel, 1, treg_log_mode, "lfo_check");}//200KHz
	//C_DDS_ERR_DisConnect;
	//DDS_DisConnect();

	Cmd_Bank0(true);
	Cmd_Go2_Standby();
	Cmd_ReadState(tempd3);
	F_ROT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_ROT_Connect;
	delay_ms(1);
	//F_ROT.MeasureVI(20,10);//fxvi5
	F_ROT.Set(FI, Il, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_ROT.MeasureVI(20,10);
	Get_Result(F_ROT, results1, MVRET);
	Ms_LogData(funcindex, "ROT_Vol", results1);
	F_ROT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_ROT_DisConnect;
	delay_ms(1);

	////Cmd_Dmuxset_Fs0(87);
	////Cmd_TMSel(0x0048000002000000);
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_Connect;
	//delay_ms(1);
	//F_INT.MeasureVI(20,10);//fxvi5
	//F_INT.Set(FI, Il, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_INT.MeasureVI(20,10);
	//Get_Result(F_INT, results1, MVRET);
	//Ms_LogData(funcindex, "INT_Vol", results1);
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_DisConnect;
	//delay_ms(1);

	Poweroff_tm();
	//mps
	Poweron_tm_hc();
	set_vsx(6.0);
	set_fb_hc(5.0);
	set_quc(5.0);
	DUT_SPI_Connect(5.0);
	//set_quc_target();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Cmd_Forceoff(all_off);
	C_MPS_PU_DisConnect;
	delay_ms(1);
	set_fb_hc(5.0);
	C_ACM_MPS_Connect;
	delay_ms(1);
	Cmd_Dmuxset_Fs0(84);
	//Cmd_Dmuxset_Fs0Read(tmpdata);
	Cmd_TMSel(0x0048000002000100);
	awg.rampvmi(A_MPS, A_SECPOSFRE, ACM200_3p6V, ACM200_10MA, "mps_thres1", 0 V, 2 V, 0.05 V, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(A_MPS, A_SECPOSFRE, ACM200_3p6V, ACM200_10MA, "mps_thres2", 2 V, 0 V, 0.05 V, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "MPS_Vih", rise);
	Ms_LogData(funcindex, "MPS_Vil", fall);
	//Ms_LogData(funcindex, "MPS_Hys", hys);
	set_vsx(12.0);
	Vh = 3.3;
	A_MPS.Set(FV, Vh, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_MPS.MeasureVI(20,10);
	Get_Result(A_MPS, results1, MIRET);
	//SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	SERIAL results2[SITE] = (Vh/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
	Ms_LogData(funcindex, "MPS_Rpd", results2);
	A_MPS.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(1);
	C_ACM_MPS_DisConnect;
	delay_ms(1);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	C_ACM_SECPOSFRE_DisConnect;
	Poweroff_tm_hc();
	
	//evc,syn,rot,int
	Ih = -5.0 mA;
	Il = 5.0 mA;
	double freq[SITE_NUM];
	C_All_Open;
	Poweron_tm();
	set_fb(4.5);
	set_quc(4.5);
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Nvm_PreviewFs(-1);
	if (PINarray[31].pin_valid)//evc
	{
		A_EVC2.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_ACM_EVC2_Connect;
		delay_ms(1);
		A_EVC2.Set(FV, 1.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_EVC2.MeasureVI(20,10);
		Get_Result(A_EVC2, results1, MIRET);
		SERIAL results2[SITE] = 1.0/results1[SITE];
		SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
		Ms_LogData(funcindex, "EVC_Rpd", results2);
		A_EVC2.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		A_EVC2.Set(FI, Il, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_EVC2.MeasureVI(20,10);
		Get_Result(A_EVC2, results1, MVRET);
		Ms_LogData(funcindex, "EVC_Vol", results1);
		A_EVC2.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_ACM_EVC2_DisConnect;
		delay_ms(1);
	}
	if (PINarray[28].pin_valid)//syn
	{
		A_SYN.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_ACM_SYN_Connect;
		delay_ms(1);
		A_SYN.Set(FV, 1.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_SYN.MeasureVI(20,10);
		Get_Result(A_SYN, results1, MIRET);
		SERIAL results2[SITE] = 1.0/results1[SITE];
		SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
		Ms_LogData(funcindex, "SYN_Rpd", results2);
		A_SYN.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		A_SYN.Set(FI, Il, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_SYN.MeasureVI(20,10);
		Get_Result(A_SYN, results1, MVRET);
		Ms_LogData(funcindex, "SYN_Vol", results1);
		A_SYN.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_ACM_SYN_DisConnect;
		delay_ms(1);
		A_SYN.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	}
	//if (PINarray[29].pin_valid)//ssd
	//{
	//	A_SSD.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);//acm10
	//	C_ACM_SSD_Connect;
	//	delay_ms(1);
	//	A_SSD.MeasureVI(100,1);
	//	Cmd_Forceoff(except_prebk);
	//	A_SSD.Set(FI, 10 uA, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//	A_SSD.MeasureVI(20,10);
	//	Get_Result(A_SSD, results1, MVRET);
	//	Ms_LogData(funcindex, "SSD_Vol", results1);
	//	A_SSD.Set(FI, -10 uA, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//	A_SSD.MeasureVI(20,10);
	//	Get_Result(A_SSD, results1, MVRET);
	//	Ms_LogData(funcindex, "SSD_Voh", results1);
	//	A_SSD.Set(FV, 3.5, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//	A_SSD.MeasureVI(20,10);
	//	Get_Result(A_SSD, results1, MIRET);
	//	SERIAL results1[SITE]=results1[SITE]*1000000.0;
	//	Ms_LogData(funcindex, "SSD_Isrc", results1);
	//	A_SSD.Set(FV, 1.5, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	//	A_SSD.MeasureVI(20,10);
	//	Get_Result(A_SSD, results1, MIRET);
	//	SERIAL results1[SITE]=results1[SITE]*1000000.0;
	//	Ms_LogData(funcindex, "SSD_Isnk", results1);
	//	A_SSD.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//	C_ACM_SSD_DisConnect;
	//	delay_ms(1);
	//}
	if(1)
	{
		int ssd_evs_bk = dut.sel("SSD_EVS").get_working(0);
		Cmd_Bank1(true);
		dut.sel("SSD_EVS").set_working(0);
		Nvm_PreviewFs(3);
		delay_ms(1);
		A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_SENSE_ON);
		A_SSD.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);//acm10
		C_ACM_STU_Connect;
		C_FRE_PU_Connect;
		C_DCM_FRE_Connect;//dcm7
		C_ACM_SSD_Connect;
		delay_ms(1);

		if (PINarray[29].pin_valid)//ssd
		{
			double v_fb[SITE_NUM];
			double ssd_value[SITE_NUM];
			A_FB1.MeasureVI(100,10);
			Get_Result(A_FB1, v_fb, MVRET);
			A_SSD.Set(FI, 10 uA, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
			A_SSD.MeasureVI(20,10);
			Get_Result(A_SSD, results1, MVRET);
			SERIAL results1[SITE]=results1[SITE]-v_fb[SITE];
			Ms_LogData(funcindex, "SSD_Vol", results1);
			SERIAL ssd_value[SITE]=v_fb[SITE]+1.5;
			SERIAL {if(ssd_value[SITE]>10){ssd_value[SITE]=10;}}
			A_SSD.SetSyn(FV, ssd_value, SITE_NUM, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
			A_SSD.MeasureVI(20,10);
			Get_Result(A_SSD, results1, MIRET);
			SERIAL results1[SITE]=results1[SITE]*1000000.0;
			Ms_LogData(funcindex, "SSD_Isnk", results1);
			A_SSD.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		}
		//set_qvr(5.0);
		//set_qco(5.0);
		//set_quc(5.0);
		set_vsx(6.0);
		set_fb(5.5);
		//set_fb(6.0);
		Cmd_Bank0();
		//Cmd_En_Stb(true, true);
		Cmd_En_Trk();
		delay_ms(1);
		//CmdReadData(0x27,reg0);
		Cmd_Bank1();
		//delay_ms(2);
		//Cmd_Forceoff(except_prebk);
		//ssd_clk
		Cmd_Dmuxset_Main(254);
		Cmd_TMSel(0x3048000000002100); 
		set_vsx(6.0);
		delay_ms(2);
		measure_freq_duty_set("DCM7",0.7, DCM_HIGH);
		//measure_freq_duty_set("DCM7", 0.7);
		dcm.SetTMUParam("DCM7", DCM_POS, 100, 0);
		measure_freq_get("DCM7",freq);
		SERIAL freq[SITE]=freq[SITE]/1000.0;
		Ms_LogData(funcindex, "SSD_Clk", freq);

		Cmd_Dmuxset_Main(254);
		Cmd_TMSel(0x3058000000002100); 
		delay_ms(2);
		A_STU.MeasureVI(20,10);
		Get_Result(A_STU, results1, MVRET);
		Ms_LogData(funcindex, "SSD_Vout", results1);
		//Cmd_Dmuxset_Main(254);
		//Cmd_TMSel(0x3058000000002100); 
		//delay_ms(2);
		//A_STU.MeasureVI(20,10);
		//Get_Result(A_STU, results1, MVRET);
		//Ms_LogData(funcindex, "SSD_Vcp", results1);
		C_FRE_PU_DisConnect;
		C_DCM_FRE_DisConnect;//dcm7
		C_ACM_STU_DisConnect;
		A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_OFF);
		Cmd_Dmuxset_Main(0);
		Cmd_TMSel(0x00);

		if (PINarray[29].pin_valid)//ssd
		{
			double v_fb[SITE_NUM];
			double ssd_value[SITE_NUM];
			A_FB1.MeasureVI(100,10);
			Get_Result(A_FB1, v_fb, MVRET);
			A_SSD.Set(FI, -10 uA, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
			A_SSD.MeasureVI(20,10);
			Get_Result(A_SSD, results1, MVRET);
			SERIAL results1[SITE]=results1[SITE]-v_fb[SITE];
			Ms_LogData(funcindex, "SSD_Voh", results1);
			SERIAL ssd_value[SITE]=v_fb[SITE]+3.5;
			SERIAL {if(ssd_value[SITE]>10){ssd_value[SITE]=10;}}
			A_SSD.SetSyn(FV, ssd_value, SITE_NUM, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
			A_SSD.MeasureVI(20,10);
			Get_Result(A_SSD, results1, MIRET);
			SERIAL results1[SITE]=results1[SITE]*1000000.0;
			Ms_LogData(funcindex, "SSD_Isrc", results1);
			A_SSD.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		}

		A_SSD.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_ACM_SSD_DisConnect;
		delay_ms(1);
		A_SSD.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
		Cmd_Bank1(true);
		dut.sel("SSD_EVS").set_working(ssd_evs_bk);
		Nvm_PreviewFs(3);
	}

	set_vsx(6.0);
	set_fb(5.5);
	//set_quc(5.0);
	set_quc_target();
	Cmd_Bank1(true);
	Cmd_Forceoff(all_off);
	Cmd_Bank0(true);
	Cmd_Dis_WwdFwdErrm();
	set_fb_plus_target(0.1);
	set_posfb_plus_target(0.1);

	//int ss_h = dut.sel("LOW_UV").get_working(0);
	//Cmd_Bank1(true);
	//dut.sel("SS_HIGH").set_working(0);
	////dut.assy("FBANK0").set_working(0);
	////dut.assy("FBANK1").set_working(0);
	////dut.assy("FBANK2").set_working(0);
	////dut.assy("FBANK3").set_working(0);
	////dut.assy("FBANK4").set_working(0);
	////dut.assy("FBANK5").set_working(0);
	////dut.assy("FBANK6").set_working(0);
	////dut.assy("FBANK7").set_working(0);
	////dut.assy("FBANK8").set_working(0);
	//Nvm_PreviewFs(-1);
	//Nvm_PreviewFs(0);
	//Nvm_PreviewFs(1);
	//Nvm_PreviewFs(2);
	//Nvm_PreviewFs(3);
	//Nvm_PreviewFs(4);
	//Nvm_PreviewFs(5);
	//Nvm_PreviewFs(6);
	//Nvm_PreviewFs(7);
	//Nvm_PreviewFs(8);

	//Cmd_Bank0(true);
	//Cmd_ReadState(tempd1);
	//Cmd_Go2_Normal();
	//Cmd_Go2_Sleep();
	//Cmd_ReadState(tempd2);
	//Cmd_Bank1(true);

	//F_ROT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_ROT_Connect;
	//delay_ms(1);
	//F_ROT.MeasureVI(20,10);//fxvi5
	//F_ROT.Set(FI, Il, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_ROT.MeasureVI(20,10);
	//Get_Result(F_ROT, results1, MVRET);
	//Ms_LogData(funcindex, "ROT_Vol", results1);
	//F_ROT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_ROT_DisConnect;
	//delay_ms(1);

	//Cmd_Bank1(true);
	//dut.sel("SSD_EVS").set_working(ss_h);


	C_FXVI_INT_Connect;
	delay_ms(1);
	F_INT.Set(FI, Ih, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_INT.MeasureVI(20,10);
	Get_Result(F_INT, results1, MVRET);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "INT_Voh1", results1);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "INT_Voh2", results1);}
	F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_INT_DisConnect;
	delay_ms(1);

	double Vquc[SITE_NUM];
	double Vrot[SITE_NUM];
	double Irot[SITE_NUM];
	double Rpu[SITE_NUM];
	set_vsx(6.0);
	Cmd_TestMode(true);
	Cmd_Dis_WwdFwdErrm();
	Cmd_Forceoff(all_off);
	Cmd_Masksafe();
	set_fb_plus_target(0.1);//target+0.1V
	set_posfb_plus_target(0.1);//target+0.1V
	delay_ms(10);
	F_ROT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	C_FXVI_ROT_Connect;
	delay_ms(1);
	//set_vsx(6.0);
	F_ROT.Set(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_ROT.Set(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	A_QUC.MeasureVI(20,10);
	F_ROT.MeasureVI(20,10);
	Get_Result(A_QUC, Vquc, MVRET);
	Get_Result(F_ROT, Vrot, MVRET);
	Get_Result(F_ROT, Irot, MIRET);
	SERIAL Rpu[SITE] = ((Vquc[SITE]-Vrot[SITE])/abs(Irot[SITE]))/1000.0;//kohm
	SERIAL if ((Rpu[SITE] > invalid_value) || (Rpu[SITE] < -invalid_value)) { Rpu[SITE] = invalid_value; }
	SERIAL results1[SITE] = Irot[SITE]*1000000.0;//ua
	Ms_LogData(funcindex, "ROT_Ipu", results1);
	Ms_LogData(funcindex, "ROT_Rpu", Rpu);
	F_ROT.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	F_ROT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_ROT_DisConnect;
	delay_ms(1);
	C_ACM_VCI_Connect;
	delay_ms(1);
	A_VCI.Set(FV, 0.8, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_VCI.Set(FV, 0.8, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
	delay_ms(1);
	A_VCI.MeasureVI(20,10);
	Get_Result(A_VCI, results1, MIRET);
	SERIAL results1[SITE] = -(results1[SITE]*1000000000.0);//na
	Ms_LogData(funcindex, "VCI_Ipu", results1);
	A_VCI.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	C_ACM_VCI_DisConnect;
	A_VCI.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);

	if (PINarray[31].pin_valid)//evc
	{
		A_EVC2.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_ACM_EVC2_Connect;
		delay_ms(1);
		double Vevc=PN_QUC_Output-1.0;
		A_EVC2.Set(FV, Vevc, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_EVC2.MeasureVI(20,10);
		Get_Result(A_EVC2, results1, MIRET);
		SERIAL results2[SITE] = -1.0/results1[SITE];
		SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
		Ms_LogData(funcindex, "EVC_Rpu", results2);
		A_EVC2.Set(FI, Ih, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_EVC2.MeasureVI(20,10);
		Get_Result(A_EVC2, results1, MVRET);
		if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "EVC_Voh1", results1);}
		if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "EVC_Voh2", results1);}
		A_EVC2.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_ACM_EVC2_DisConnect;
		delay_ms(1);
		A_EVC2.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	}
	if (PINarray[28].pin_valid)
	{
		A_SYN.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_ACM_SYN_Connect;
		delay_ms(1);
		double Vsyn=PN_QUC_Output-1.0;
		A_SYN.Set(FV, Vsyn, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_SYN.MeasureVI(20,10);
		Get_Result(A_SYN, results1, MIRET);
		SERIAL results2[SITE] = -1.0/results1[SITE];
		SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
		Ms_LogData(funcindex, "SYN_Rpu", results2);
		A_SYN.Set(FI, Ih, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_SYN.MeasureVI(20,10);
		Get_Result(A_SYN, results1, MVRET);
		if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SYN_Voh1", results1);}
		if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SYN_Voh2", results1);}
		A_SYN.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		C_ACM_SYN_DisConnect;
		delay_ms(1);
		A_SYN.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	}

	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_Connect;
	//delay_ms(1);
	//Cmd_Bank0(true);
	//Cmd_Go2_Standby();
	//Cmd_ReadState(reg3);//4?
	//delay_ms(1);
	//F_INT.Set(FI, Il, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_INT.MeasureVI(20,10);
	//Get_Result(F_INT, results1, MVRET);
	//Ms_LogData(funcindex, "INT_Vol", results1);
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_DisConnect;
	//delay_ms(1);
	
	C_ACM_SECPOSFRE_DisConnect;
	set_fb(false);
	set_posfb(false);
	Poweroff_tm();

	//SPI
	Ih = -5.0 mA;
	Il = 5.0 mA;
	C_FRE_PU_Connect;
	C_DBUF_Bypass;
	C_DBUFI_FRE;
	C_ACM_DBUFO_Connect;
	//scs
	Poweron_tm();
	set_vsx(6.0);
	set_fb(5.5);
	set_quc(5.0);
	//set_quc_target();
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq(1 MHz);
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Cmd_Forceoff(all_off);
	C_FXVI_SCS_Connect;
	delay_ms(1);
	Cmd_Dmuxset_Main(66);
	Cmd_TMSel(0x0048000002000100);
	set_quc_target();
	dcm.Disconnect("D_CS");
	vstart = 1.4;
	vstop = 3.7;
	step = calc_step(vstart,vstop,100);
	F_SCS.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	awg.rampvmv(F_SCS, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "scs_thres1", vstart, vstop, step, 20, 2.5, TRIG_FALLING, rise);
	vstart = 0.7;
	vstop = 3.1;
	step = calc_step(vstart,vstop,100);
	awg.rampvmv(F_SCS, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "scs_thres2", vstop, vstart, step, 20, 2.5, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SCS_Vih1", rise);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SCS_Vih2", rise);}
	Ms_LogData(funcindex, "SCS_Vil", fall);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SCS_Hys1", hys);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SCS_Hys2", hys);}
	F_SCS.Set(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SCS.Set(FV, 0.5, FXVIe_PLUS_10V, FXVIe_PLUS_100UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SCS.MeasureVI(20,10);
	Get_Result(F_SCS, results1, MIRET);
	//SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	SERIAL results2[SITE] = ((0.5-PN_QUC_Output)/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
	Ms_LogData(funcindex, "SCS_Rpu", results2);
	F_SCS.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	F_SCS.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_SCS_DisConnect;
	delay_ms(1);
	//Poweroff_tm();
	////scl
	//Poweron_tm();
	//set_vsx(6.0);
	//set_fb(5.5);
	//set_quc(5.0);
	set_quc_target();
	DUT_SPI_Connect(PN_QUC_Output);
	//Cmd_Set_Freq(10 MHz);
	//Cmd_TestMode(true, in_tm);
	//Cmd_Masksafe();
	//Cmd_Bank1(true);
	//Nvm_PreviewFs(-1);
	//Cmd_Forceoff(all_off);
	C_FXVI_SCL_Connect;
	delay_ms(1);
	Cmd_Dmuxset_Main(67);
	Cmd_TMSel(0x0048000002000100);
	dcm.Disconnect("D_SCK");
	vstart = 1.4;
	vstop = 3.7;
	step = calc_step(vstart,vstop,100);
	F_SCL.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	awg.rampvmv(F_SCL, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "scl_thres1", vstart, vstop, step, 20, 2.5, TRIG_FALLING, rise);
	vstart = 0.7;
	vstop = 3.1;
	step = calc_step(vstart,vstop,100);
	awg.rampvmv(F_SCL, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "scl_thres2", vstop, vstart, step, 20, 2.5, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SCL_Vih1", rise);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SCL_Vih2", rise);}
	Ms_LogData(funcindex, "SCL_Vil", fall);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SCL_Hys1", hys);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SCL_Hys2", hys);}
	F_SCL.Set(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SCL.MeasureVI(20,10);
	Get_Result(F_SCL, results1, MIRET);
	//SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	SERIAL results2[SITE] = (2.0/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
	Ms_LogData(funcindex, "SCL_Rpd", results2);
	F_SCL.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	F_SCL.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_SCL_DisConnect;
	delay_ms(1);
	//Poweroff_tm();
	////sdi
	//Poweron_tm();
	//set_vsx(6.0);
	//set_fb(5.5);
	//set_quc(5.0);
	set_quc_target();
	DUT_SPI_Connect(PN_QUC_Output);
	Cmd_Set_Freq(1 MHz);
	//Cmd_TestMode(true, in_tm);
	//Cmd_Masksafe();
	//Cmd_Bank1(true);
	//Nvm_PreviewFs(-1);
	//Cmd_Forceoff(all_off);
	C_FXVI_SDI_Connect;
	delay_ms(1);
	Cmd_Dmuxset_Main(68);
	Cmd_TMSel(0x0048000000000000);
	dcm.Disconnect("D_SDI");
	//dcm.Connect("D_CS");
	//dcm.InitPPMU("D_CS");
	//dcm.SetPPMU("D_CS", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	delay_ms(1);
	vstart = 1.4;
	vstop = 3.7;
	step = calc_step(vstart,vstop,100);
	F_SDI.Set(FV, 0.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	awg.rampvmv(F_SDI, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "SDI_thres1", vstart, vstop, step, 20, 2.5, TRIG_FALLING, rise);
	vstart = 0.7;
	vstop = 3.1;
	step = calc_step(vstart,vstop,100);
	awg.rampvmv(F_SDI, A_DBUFO, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, "SDI_thres2", vstop, vstart, step, 20, 2.5, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SDI_Vih1", rise);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SDI_Vih2", rise);}
	Ms_LogData(funcindex, "SDI_Vil", fall);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SDI_Hys1", hys);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SDI_Hys2", hys);}
	F_SDI.Set(FV, 2.0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SDI.MeasureVI(20,10);
	Get_Result(F_SDI, results1, MIRET);
	//SERIAL results2[SITE] = results1[SITE]*1000000.0;//ua
	SERIAL results2[SITE] = (2.0/results1[SITE])/1000.0;//kohm
	SERIAL if ((results2[SITE] > invalid_value) || (results2[SITE] < -invalid_value)) { results2[SITE] = invalid_value; }
	Ms_LogData(funcindex, "SDI_Rpd", results2);
	F_SDI.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	F_SDI.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	C_FXVI_SDI_DisConnect;
	delay_ms(1);
	//Poweroff_tm();
	////sdo
	//Poweron_tm();
	//set_vsx(6.0);
	//set_fb(5.5);
	//set_quc(5.0);
	//DUT_SPI_Connect(PN_QUC_Output);
	//Cmd_Set_Freq(10 MHz);
	//Cmd_TestMode(true, in_tm);
	//Cmd_Masksafe();
	//Cmd_Bank1(true);
	//Nvm_PreviewFs(-1);
	//Cmd_Forceoff(all_off);
	dcm.Disconnect("DCM_ALL");
	//delay_ms(1);
	dcm.Connect("D_SDI");
	dcm.Connect("D_CS");
	dcm.Connect("D_SCK");
	//dcm.InitPPMU("D_SDI");
	//dcm.InitPPMU("D_CS");
	C_FXVI_SDO_Connect;
	delay_ms(1);
	set_quc_target();
	Ih = -5.0 mA;
	Il = 5.0 mA;
	//force sdi 1
	dcm.SetPPMU("D_SDI", DCM_PPMU_FVMV, PN_QUC_Output, DCM_PPMUIRANGE_2MA);
	dcm.SetPPMU("D_CS", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	delay_ms(1);
	F_SDO.Set(FI, Ih, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SDO.MeasureVI(20,10);
	Get_Result(F_SDO, results1, MVRET);
	F_SDO.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "SDO_Voh1", results1);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "SDO_Voh2", results1);}
	//tri,force scs 1
	dcm.SetPPMU("D_SDI", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	dcm.SetPPMU("D_CS", DCM_PPMU_FVMV, PN_QUC_Output, DCM_PPMUIRANGE_2MA);
	delay_ms(1);
	F_SDO.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SDO.Set(FV, 1.0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SDO.MeasureVI(20,10);
	Get_Result(F_SDO, results1, MIRET);
	SERIAL results1[SITE] = results1[SITE]*1000000.0;//ua
	Ms_LogData(funcindex, "SDO_LkTri", results1);
	F_SDO.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	F_SDO.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	//force sdi 0 ?
	dcm.SetPPMU("D_SDI", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	dcm.SetPPMU("D_CS", DCM_PPMU_FVMV, PN_QUC_Output, DCM_PPMUIRANGE_2MA);
	delay_us(1);//1M
	dcm.SetPPMU("D_CS", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	delay_us(1);
	dcm.SetPPMU("D_SDI", DCM_PPMU_FVMV, PN_QUC_Output, DCM_PPMUIRANGE_2MA);
	//delay_us(1);
	dcm.SetPPMU("D_SCK", DCM_PPMU_FVMV, PN_QUC_Output, DCM_PPMUIRANGE_2MA);
	delay_us(1);
	dcm.SetPPMU("D_SCK", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	//delay_us(1);
	dcm.SetPPMU("D_SDI", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	delay_us(1);
	//dcm.SetPPMU("D_SCK", DCM_PPMU_FVMV, 3PN_QUC_Output5, DCM_PPMUIRANGE_2MA);
	//delay_us(1);
	//dcm.SetPPMU("D_SCK", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	//delay_us(1);
	F_SDO.Set(FI, Il, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_SDO.MeasureVI(20,10);
	Get_Result(F_SDO, results1, MVRET);
	F_SDO.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	Ms_LogData(funcindex, "SDO_Vol", results1);
	dcm.SetPPMU("D_SDI", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	dcm.SetPPMU("D_CS", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	dcm.SetPPMU("D_SCK", DCM_PPMU_FVMV, 0.0, DCM_PPMUIRANGE_2MA);
	C_FXVI_SDO_DisConnect;
	dcm.Disconnect("DCM_ALL");
	delay_ms(1);
	F_SDO.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	A_DBUFO.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	Poweroff_tm();
	C_FRE_PU_DisConnect;
	C_DBUF_Bypass;
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T46_Diag(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	double results1[SITE_NUM];
	double results2[SITE_NUM];
	double results3[SITE_NUM];
	double results4[SITE_NUM];
	double results5[SITE_NUM];
	double results6[SITE_NUM];
	double results7[SITE_NUM];
	double results8[SITE_NUM];
	double results9[SITE_NUM];
	double results10[SITE_NUM];

	int state0[SITE_NUM];
	int state1[SITE_NUM];
	int state2[SITE_NUM];
	int state3[SITE_NUM];
	int state4[SITE_NUM];
	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];

	double tss[SITE_NUM];

	double vstart = 0;
	double vstop = 0;
	double step = 0;

	double rise[SITE_NUM];
	double fall[SITE_NUM];
	double hys[SITE_NUM];

	double riseV[SITE_NUM];
	double fallV[SITE_NUM];
	double hysV[SITE_NUM];

	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	C_POSG_GND_Connect;
	F_RSH.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	C_VST_VS1_Connect;
	C_DBUFI_DRG;
	C_ACM_DBUFO_Connect;
	C_RSL_PD_Connect;
	C_FXVI_RSH_Connect;
	F_RSH.Set(FV, 0.1, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	test_tss(tss);
	int LBIST_EN = dut.sel("LBIST_EN").get_working(0);
	if(LBIST_EN==1){Ms_LogData(funcindex, "VS_Tstart", tss);}
	else{Ms_LogData(funcindex, "VS_Tstart2", tss);}
	set_vsx(0.0);
	F_RSH.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	F_RSH.Set(FV, 0.0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	C_DBUFI_DisConnect;
	C_RSL_PD_DisConnect;
	C_FXVI_RSH_DisConnect;

	Poweron_tm_hc();
	set_fb_hc(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	//Cmd_Forceoff(all_off);
	//Cmd_Bank0(true);
	//Cmd_Dis_ERR_WD();
	//Cmd_ReadState(state0);
	//Cmd_Go2_Normal();
	//Cmd_ReadState(state1);
	//Cmd_Bank1(true);
	
	//vs1////////////////////////////////////////////////////////////////////////////////
	C_FRE_PU_Connect;
	C_DBUF_Bypass;
	C_DBUFI_FRE;//vs start
	C_ACM_SECPOSFRE_Connect;//vs start stg,acm9
	C_ACM_DBUFO_Connect;
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);

	////vstart
	//Cmd_Dmuxset_Main(11);
	//Cmd_Dmuxset_Fs0(73);
	//Cmd_Dmuxset_Fs1(73);
	//Cmd_TMSel(0x0048000000800121);
	//delay_ms(1);//acm9
	//C_VS1_CAP_DisConnect;
	//C_VST_CAP_DisConnect;
	//delay_ms(1);
	//vstart = 4.0;
	//vstop = 6.5;
	//step = calc_step(vstart,vstop,100);
	//awg.rampvmif(F_VST, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_Vstartstg1", vstart, vstop, step, 20, 5 mA, TRIG_RISING, rise);//acm9
	//awg.rampvmif(F_VST, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_Vstartstg2", vstop, vstart, step, 20, 5 mA, TRIG_FALLING, fall);
	//SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	//Ms_LogData(funcindex, "VS_Vstartstg", rise);//acm10
	//awg.rampvmvf(F_VST, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_Vstar1", vstart, vstop, step, 20, 2.5 V, TRIG_FALLING, rise);//acm10
	//awg.rampvmvf(F_VST, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_Vstar2", vstop, vstart, step, 20, 2.5 V, TRIG_RISING, fall);//fre L>H
	//SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	//Ms_LogData(funcindex, "VS_Vstart", rise);
	//delay_ms(1);
	//set_vsx(6.0);
	//Cmd_Dmuxset_Main(0);
	//Cmd_Dmuxset_Fs0(0);
	//Cmd_Dmuxset_Fs1(0);
	////Cmd_TMSel(0x0049030000000021);


	//quc ov uv////////////////////////////////////////////////////////////////////////////////
	Cmd_Dmuxset_Fs0(21);//ov_quc
	Cmd_TMSel(0x0049030000000021);
	set_fb_hc(6.0);
	vstart = PN_QUC_Output;
	vstop = PN_QUC_Output+1;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(A_QUC, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "quc_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(A_QUC, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "quc_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "QUC_OVrise1", rise);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "QUC_OVrise2", rise);}
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "QUC_OVfall1", fall);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "QUC_OVfall2", fall);}
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "QUC_OVhys1", hys);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "QUC_OVhys2", hys);}
	Cmd_Dmuxset_Fs0(23);//uv_quc
	//set_fb_hc(7.0);
	//vstart = 6;
	//vstop = 4;
	//step = calc_step(vstart,vstop,100);
	//awg.rampvmi(A_QUC, F_FB, ACM200_10V, ACM200_100MA, "quc_uv_rise", vstart, vstop V, step, 30, 5 mA, TRIG_RISING, fall);
	vstart = PN_QUC_Output;
	vstop = PN_QUC_Output-1;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(A_QUC, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "quc_uv_rise", vstart, vstop V, step, 30, 5 mA, TRIG_RISING, fall);
	awg.rampvmi(A_QUC, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "quc_uv_fall", vstop V, vstart, step, 30, 5 mA, TRIG_FALLING, rise);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "QUC_UVrise1", rise);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "QUC_UVrise2", rise);}
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "QUC_UVfall1", fall);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "QUC_UVfall2", fall);}
	if(PN_QUC_Output==5.0){Ms_LogData(funcindex, "QUC_UVhys1", hys);}
	if(PN_QUC_Output==3.3){Ms_LogData(funcindex, "QUC_UVhys2", hys);}
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	//qvr ov uv////////////////////////////////////////////////////////////////////////////////
	Cmd_Dmuxset_Fs0(37);//ov_qvr
	delay_ms(1);
	vstart = PN_QVR_Output-0.5;
	vstop = PN_QVR_Output+1.5;
	step = calc_step(vstart,vstop,150);
	awg.rampvmi(A_QVR, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qvr_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise, vstart, vstop);
	awg.rampvmi(A_QVR, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qvr_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall, vstop, vstart);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_OVrise1", rise);}
	if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_OVrise2", rise);}
	if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_OVfall1", fall);}
	if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_OVfall2", fall);}
	if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_OVhys1", hys);}
	if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_OVhys2", hys);}
	Cmd_Dmuxset_Fs0(39);//uv_qvr
	delay_ms(1);
	vstart = PN_QVR_Output;
	vstop = PN_QVR_Output-2;
	step = calc_step(vstart,vstop,150);
	awg.rampvmi(A_QVR, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qvr_uv_rise", vstart V, vstop V, step, 30, 5 mA, TRIG_RISING, fall, vstart, vstop);
	awg.rampvmi(A_QVR, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qvr_uv_fall", vstop V, vstart V, step, 30, 5 mA, TRIG_FALLING, rise, vstop, vstart);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_LOW_UV)//low uv enable
	{
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_UVrise2", rise);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_UVrise4", rise);}
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_UVfall2", fall);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_UVfall4", fall);}
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_UVhys2", hys);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_UVhys4", hys);}
	}
	else//low uv disable
	{
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_UVrise1", rise);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_UVrise3", rise);}
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_UVfall1", fall);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_UVfall3", fall);}
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QVR_UVhys1", hys);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QVR_UVhys3", hys);}
	}
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	set_vsx(6.0);
	C_VS1_CAP_DisConnect;
	C_VST_CAP_DisConnect;
	delay_ms(1);
	//ov uv////////////////////////////////////////////////////////////////////////////////
	set_fb_plus_target_hc(0.1);
	Cmd_TMSel(0x0049030000000021);
	//qst ov uv////////////////////////////////////////////////////////////////////////////////
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	Cmd_Dmuxset_Fs0(16);//ov_qst
	//C_QST_CAP_DisConnect;
	vstart = PN_QST_Output;
	vstop = PN_QST_Output+1;//acm0,acm9
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(A_QST, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qst_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(A_QST, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qst_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_OVrise1", rise);}
	if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_OVrise2", rise);}
	if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_OVfall1", fall);}
	if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_OVfall2", fall);}
	if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_OVhys1", hys);}
	if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_OVhys2", hys);}
	Cmd_Dmuxset_Fs0(18);//uv_qst
	vstart = PN_QST_Output-1;
	vstop = PN_QST_Output;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(A_QST, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qst_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
	awg.rampvmi(A_QST, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qst_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_UVrise1", rise);}
	if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_UVrise2", rise);}
	if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_UVfall1", fall);}
	if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_UVfall2", fall);}
	if(PN_QST_Output==5.0){Ms_LogData(funcindex, "QST_UVhys1", hys);}
	if(PN_QST_Output==3.3){Ms_LogData(funcindex, "QST_UVhys2", hys);}
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);

	//bg ov uv////////////////////////////////////////////////////////////////////////////////
	A_VCIVMON.Set(FI, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	C_ACM_VCIVMON_Connect;
	delay_ms(1);
	//vci
	Cmd_Dmuxset_Fs0(35);//ov_vci
	Cmd_TMSel(0x0049030000000021);
	vstart = 0.78;
	vstop = 0.92;
	step = calc_step(vstart, vstop, 150);
	A_VCIVMON.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	A_VCIVMON.Set(FV, vstart, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "vci_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "vci_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	SERIAL rise[SITE] = rise[SITE]*1000;
	SERIAL fall[SITE] = fall[SITE]*1000;
	Ms_LogData(funcindex, "VCI_OVrise", rise);
	Ms_LogData(funcindex, "VCI_OVfall", fall);
	Ms_LogData(funcindex, "VCI_OVhys", hys);
	Cmd_Dmuxset_Fs0(33);//uv_vci
	vstart = 0.66;
	vstop = 0.80;
	step = calc_step(vstart, vstop, 150);
	A_VCIVMON.Set(FV, vstart, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "vci_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "vci_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	SERIAL rise[SITE] = rise[SITE]*1000;
	SERIAL fall[SITE] = fall[SITE]*1000;
	Ms_LogData(funcindex, "VCI_UVrise", rise);
	Ms_LogData(funcindex, "VCI_UVfall", fall);
	Ms_LogData(funcindex, "VCI_UVhys", hys);
	//bg
	Cmd_Dmuxset_Fs0(63);//ov
	Cmd_TMSel(0x0049030000000061);
	vstart = 0.7;
	vstop = 1.0;
	step = calc_step(vstart,vstop,150);
	A_VCIVMON.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);//acm8,acm9
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "bg_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "bg_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	SERIAL rise[SITE] = rise[SITE]*1000;
	SERIAL fall[SITE] = fall[SITE]*1000;
	Ms_LogData(funcindex, "BG_OVrise", rise);
	Ms_LogData(funcindex, "BG_OVfall", fall);
	Ms_LogData(funcindex, "BG_OVhys", hys);
	Cmd_Dmuxset_Fs0(65);//uv
	vstart = 0.6;
	vstop = 0.9;
	step = calc_step(vstart,vstop,150);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "bg_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "bg_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	SERIAL rise[SITE] = rise[SITE]*1000;
	SERIAL fall[SITE] = fall[SITE]*1000;
	Ms_LogData(funcindex, "BG_UVrise", rise);
	Ms_LogData(funcindex, "BG_UVfall", fall);
	Ms_LogData(funcindex, "BG_UVhys", hys);
	//bias
	Cmd_Dmuxset_Fs0(67);//ov
	Cmd_TMSel(0x0049030000000081);
	vstart = 0.85;
	vstop = 1.1;
	step = calc_step(vstart,vstop,100);
	A_VCIVMON.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);//acm8,acm9
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "bias_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "bias_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	SERIAL rise[SITE] = rise[SITE]*1000;
	SERIAL fall[SITE] = fall[SITE]*1000;
	Ms_LogData(funcindex, "Bias_OVrise", rise);
	Ms_LogData(funcindex, "Bias_OVfall", fall);
	Ms_LogData(funcindex, "Bias_OVhys", hys);
	Cmd_Dmuxset_Fs0(69);//uv
	vstart = 0.3;
	vstop = 0.55;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "bias_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
	awg.rampvmi(A_VCIVMON, A_SECPOSFRE, ACM200_3p6V, ACM200_100MA, "bias_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	SERIAL rise[SITE] = rise[SITE]*1000;
	SERIAL fall[SITE] = fall[SITE]*1000;
	Ms_LogData(funcindex, "Bias_UVrise", rise);
	Ms_LogData(funcindex, "Bias_UVfall", fall);
	Ms_LogData(funcindex, "Bias_UVhys", hys);
	A_VCIVMON.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	A_VCIVMON.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	delay_ms(1);
	C_ACM_VCIVMON_DisConnect;
	delay_ms(1);
	//vco ov uv////////////////////////////////////////////////////////////////////////////////
	Cmd_TMSel(0x0049030000000021);
	if(PN_Posbk_Available)
	{
		Cmd_Dmuxset_Fs0(27);//ov_vco
		//vstart = 0;
		//vstop = 2.0;
		vstart = PN_Posbk_Output-0.5;
		vstop = PN_Posbk_Output+1.0;
		step = calc_step(vstart,vstop,150);
		awg.rampvmi(A_POSFB, A_SECPOSFRE, ACM200_10V, ACM200_10MA, "vco_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
		awg.rampvmi(A_POSFB, A_SECPOSFRE, ACM200_10V, ACM200_10MA, "vco_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
		SERIAL riseV[SITE]=rise[SITE];
		SERIAL fallV[SITE]=fall[SITE];
		SERIAL hysV[SITE]=abs(riseV[SITE] - fallV[SITE]);
		SERIAL rise[SITE]=(rise[SITE]/PN_Posbk_Output)*100.0;
		SERIAL fall[SITE]=(fall[SITE]/PN_Posbk_Output)*100.0;
		SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
		Ms_LogData(funcindex, "VCO_OutV", PN_Posbk_Output);
		Ms_LogData(funcindex, "VCO_OVriseV", riseV);
		Ms_LogData(funcindex, "VCO_OVfallV", fallV);
		Ms_LogData(funcindex, "VCO_OVhysV", hysV);
		if(!PN_LOW_UV)//low uv disable
		{
			Ms_LogData(funcindex, "VCO_OVrise1", rise);
			Ms_LogData(funcindex, "VCO_OVfall1", fall);
			Ms_LogData(funcindex, "VCO_OVhys1", hys);
		}
		else
		{
			Ms_LogData(funcindex, "VCO_OVrise2", rise);
			Ms_LogData(funcindex, "VCO_OVfall2", fall);
			Ms_LogData(funcindex, "VCO_OVhys2", hys);
		}
		Cmd_Dmuxset_Fs0(29);//uv_vco
		//vstart = 0;
		//vstop = 2.0;
		vstart = PN_Posbk_Output-1.0;
		vstop = PN_Posbk_Output+0.5;
		step = calc_step(vstart,vstop,150);
		awg.rampvmi(A_POSFB, A_SECPOSFRE, ACM200_10V, ACM200_10MA, "vco_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
		awg.rampvmi(A_POSFB, A_SECPOSFRE, ACM200_10V, ACM200_10MA, "vco_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
		SERIAL riseV[SITE]=rise[SITE];
		SERIAL fallV[SITE]=fall[SITE];
		SERIAL hysV[SITE]=abs(riseV[SITE] - fallV[SITE]);
		SERIAL rise[SITE]=(rise[SITE]/PN_Posbk_Output)*100.0;
		SERIAL fall[SITE]=(fall[SITE]/PN_Posbk_Output)*100.0;
		SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
		Ms_LogData(funcindex, "VCO_UVriseV", riseV);
		Ms_LogData(funcindex, "VCO_UVfallV", fallV);
		Ms_LogData(funcindex, "VCO_UVhysV", hysV);
		if(!PN_LOW_UV)//low uv disable
		{
			Ms_LogData(funcindex, "VCO_UVrise1", rise);
			Ms_LogData(funcindex, "VCO_UVfall1", fall);
			Ms_LogData(funcindex, "VCO_UVhys1", hys);
		}
		else
		{
			Ms_LogData(funcindex, "VCO_UVrise2", rise);
			Ms_LogData(funcindex, "VCO_UVfall2", fall);
			Ms_LogData(funcindex, "VCO_UVhys2", hys);
		}
		A_POSFB.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
	}
	//prebk ov uv////////////////////////////////////////////////////////////////////////////////
	//C_FB_CAP_DisConnect;
	delay_ms(1);
	Cmd_Dmuxset_Fs0(10);//ov_prebk
	vstart = PN_Prebk_Output;
	vstop = PN_Prebk_Output+1.0;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(F_FB, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(F_FB, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_Prebk_Output==5.8){Ms_LogData(funcindex, "PreBK_OVrise1", rise);}
	if(PN_Prebk_Output==5.65){Ms_LogData(funcindex, "PreBK_OVrise2", rise);}
	if(PN_Prebk_Output==3.9){Ms_LogData(funcindex, "PreBK_OVrise3", rise);}
	if(PN_Prebk_Output==5.8){Ms_LogData(funcindex, "PreBK_OVfall1", fall);}
	if(PN_Prebk_Output==5.65){Ms_LogData(funcindex, "PreBK_OVfall2", fall);}
	if(PN_Prebk_Output==3.9){Ms_LogData(funcindex, "PreBK_OVfall3", fall);}
	if(PN_Prebk_Output==5.8){Ms_LogData(funcindex, "PreBK_OVhys1", hys);}
	if(PN_Prebk_Output==5.65){Ms_LogData(funcindex, "PreBK_OVhys2", hys);}
	if(PN_Prebk_Output==3.9){Ms_LogData(funcindex, "PreBK_OVhys3", hys);}
	Cmd_Dmuxset_Fs0(12);//uv_prebk
	vstart = PN_Prebk_Output-0.8;
	vstop = PN_Prebk_Output-0.2;
	step = calc_step(vstart,vstop,100);
	awg.rampvmi(F_FB, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
	awg.rampvmi(F_FB, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "prebk_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_Prebk_Output==5.8){Ms_LogData(funcindex, "PreBK_UVrise1", rise);}
	if(PN_Prebk_Output==5.65){Ms_LogData(funcindex, "PreBK_UVrise2", rise);}
	if(PN_Prebk_Output==3.9){Ms_LogData(funcindex, "PreBK_UVrise3", rise);}
	if(PN_Prebk_Output==5.8){Ms_LogData(funcindex, "PreBK_UVfall1", fall);}
	if(PN_Prebk_Output==5.65){Ms_LogData(funcindex, "PreBK_UVfall2", fall);}
	if(PN_Prebk_Output==3.9){Ms_LogData(funcindex, "PreBK_UVfall3", fall);}
	if(PN_Prebk_Output==5.8){Ms_LogData(funcindex, "PreBK_UVhys1", hys);}
	if(PN_Prebk_Output==5.65){Ms_LogData(funcindex, "PreBK_UVhys2", hys);}
	if(PN_Prebk_Output==3.9){Ms_LogData(funcindex, "PreBK_UVhys3", hys);}
	F_FB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	//qco ov uv////////////////////////////////////////////////////////////////////////////////
	set_fb_plus_target_hc(0.1);
	delay_ms(2);
	C_FB_CAP_Connect;
	Cmd_Dmuxset_Fs0(42);//ov_qco
	vstart = PN_QCO_Output;
	vstop = PN_QCO_Output+1.0;
	//qcolmt=1
	Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_700mA, QUCLMT_600mA, PDDLY_0ms);
	delay_ms(1);
	awg.rampvmi(A_QCO, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qco_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(A_QCO, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qco_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_OVrise2", rise);}
	if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_OVrise4", rise);}
	if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_OVfall2", fall);}
	if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_OVfall4", fall);}
	if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_OVhys2", hys);}
	if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_OVhys4", hys);}
	//qcolmt=0
	Cmd_LMTCFG(CORELMT_2A, PREBKLMT_2A, QCOLMT_200mA, QUCLMT_600mA, PDDLY_0ms);
	delay_ms(1);
	step = calc_step(vstart,vstop,150);
	awg.rampvmi(A_QCO, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qco_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(A_QCO, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qco_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_OVrise1", rise);}
	if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_OVrise3", rise);}
	if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_OVrise5", rise);}
	if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_OVfall1", fall);}
	if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_OVfall3", fall);}
	if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_OVfall5", fall);}
	if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_OVhys1", hys);}
	if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_OVhys3", hys);}
	if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_OVhys5", hys);}
	Cmd_Dmuxset_Fs0(44);//uv_qco
	vstart = PN_QCO_Output-2;
	vstop = PN_QCO_Output;
	step = calc_step(vstart,vstop,150);
	awg.rampvmi(A_QCO, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qco_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
	awg.rampvmi(A_QCO, A_SECPOSFRE, ACM200_10V, ACM200_100MA, "qco_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_LOW_UV)//low uv enable
	{
		if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_UVrise2", rise);}
		if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_UVrise4", rise);}
		if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_UVrise5", rise);}
		if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_UVfall2", fall);}
		if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_UVfall4", fall);}
		if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_UVfall5", fall);}
		if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_UVhys2", hys);}
		if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_UVhys4", hys);}
		if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_UVhys5", hys);}
	}
	else//low uv disable
	{
		if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_UVrise1", rise);}
		if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_UVrise3", rise);}
		if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_UVrise5", rise);}
		if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_UVfall1", fall);}
		if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_UVfall3", fall);}
		if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_UVfall5", fall);}
		if(PN_QCO_Output==5.0){Ms_LogData(funcindex, "QCO_UVhys1", hys);}
		if(PN_QCO_Output==3.3){Ms_LogData(funcindex, "QCO_UVhys3", hys);}
		if(PN_QCO_Output==1.8){Ms_LogData(funcindex, "QCO_UVhys5", hys);}
	}
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	//qt1 ov uv////////////////////////////////////////////////////////////////////////////////
	Cmd_Dmuxset_Fs0(48);//ov_qt1
	if(PN_QT1_Output==0.0)
	{
		vstart = PN_QVR_Output;
		vstop = PN_QVR_Output+1;
	}
	else
	{
		vstart = PN_QT1_Output;
		vstop = PN_QT1_Output+1;
	}
	//qt1lmt=0
	step = calc_step(vstart,vstop,120);
	awg.rampvmi(F_QT1, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt1_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(F_QT1, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt1_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QT1_Output==0.0)
	{
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT1_OVrise1", rise);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT1_OVrise2", rise);}
		if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT1_OVrise3", rise);}
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT1_OVfall1", fall);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT1_OVfall2", fall);}
		if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT1_OVfall3", fall);}
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT1_OVhys1", hys);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT1_OVhys2", hys);}
		if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT1_OVhys3", hys);}
	}
	else
	{
		if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_OVrise1", rise);}
		if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_OVrise2", rise);}
		if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_OVrise3", rise);}
		if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_OVfall1", fall);}
		if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_OVfall2", fall);}
		if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_OVfall3", fall);}
		if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_OVhys1", hys);}
		if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_OVhys2", hys);}
		if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_OVhys3", hys);}
	}
	Cmd_Dmuxset_Fs0(50);//uv_qt1
	if(PN_QT1_Output==0.0)
	{
		vstart = PN_QVR_Output-1;
		vstop = PN_QVR_Output;
	}
	else
	{
		vstart = PN_QT1_Output-1;
		vstop = PN_QT1_Output;
	}
	step = calc_step(vstart,vstop,120);
	awg.rampvmi(F_QT1, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt1_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
	awg.rampvmi(F_QT1, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt1_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_LOW_UV)//low uv enable
	{
		if(PN_QT1_Output==0.0)
		{
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT1_UVrise2", rise);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT1_UVrise3", rise);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT1_UVrise4", rise);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT1_UVfall2", fall);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT1_UVfall3", fall);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT1_UVfall4", fall);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT1_UVhys2", hys);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT1_UVhys3", hys);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT1_UVhys4", hys);}
		}
		else
		{
			if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_UVrise2", rise);}
			if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_UVrise3", rise);}
			if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_UVrise4", rise);}
			if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_UVfall2", fall);}
			if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_UVfall3", fall);}
			if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_UVfall4", fall);}
			if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_UVhys2", hys);}
			if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_UVhys3", hys);}
			if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_UVhys4", hys);}
		}
	}
	else//low uv disable
	{
		if(PN_QT1_Output==0.0)
		{
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT1_UVrise1", rise);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT1_UVrise3", rise);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT1_UVrise4", rise);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT1_UVfall1", fall);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT1_UVfall3", fall);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT1_UVfall4", fall);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT1_UVhys1", hys);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT1_UVhys3", hys);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT1_UVhys4", hys);}
		}
		else
		{
			if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_UVrise1", rise);}
			if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_UVrise3", rise);}
			if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_UVrise4", rise);}
			if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_UVfall1", fall);}
			if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_UVfall3", fall);}
			if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_UVfall4", fall);}
			if(PN_QT1_Output==5.0){Ms_LogData(funcindex, "QT1_UVhys1", hys);}
			if(PN_QT1_Output==3.3){Ms_LogData(funcindex, "QT1_UVhys3", hys);}
			if(PN_QT1_Output==1.8){Ms_LogData(funcindex, "QT1_UVhys4", hys);}
		}
	}
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	//qt2 ov uv////////////////////////////////////////////////////////////////////////////////
	Cmd_Dmuxset_Fs0(52);//ov_qt2
	if(PN_QT2_Output==0.0)
	{
		vstart = PN_QVR_Output;
		vstop = PN_QVR_Output+1;
	}
	else
	{
		vstart = PN_QT2_Output;
		vstop = PN_QT2_Output+1;
	}
	//qt2lmt=0
	step = calc_step(vstart,vstop,120);
	awg.rampvmi(F_QT2, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt2_ov_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(F_QT2, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt2_ov_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_QT2_Output==0.0)
	{
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT2_OVrise1", rise);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT2_OVrise2", rise);}
		if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT2_OVrise3", rise);}
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT2_OVfall1", fall);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT2_OVfall2", fall);}
		if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT2_OVfall3", fall);}
		if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT2_OVhys1", hys);}
		if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT2_OVhys2", hys);}
		if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT2_OVhys3", hys);}
	}
	else
	{
		if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_OVrise1", rise);}
		if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_OVrise2", rise);}
		if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_OVrise3", rise);}
		if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_OVfall1", fall);}
		if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_OVfall2", fall);}
		if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_OVfall3", fall);}
		if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_OVhys1", hys);}
		if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_OVhys2", hys);}
		if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_OVhys3", hys);}
	}
	Cmd_Dmuxset_Fs0(54);//uv_qt2
	if(PN_QT2_Output==0.0)
	{
		vstart = PN_QVR_Output-1;
		vstop = PN_QVR_Output;
	}
	else
	{
		vstart = PN_QT2_Output-1;
		vstop = PN_QT2_Output;
	}
	step = calc_step(vstart,vstop,120);
	awg.rampvmi(F_QT2, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt2_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
	awg.rampvmi(F_QT2, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt2_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
	if(PN_LOW_UV)//low uv enable
	{
		if(PN_QT2_Output==0.0)
		{
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT2_UVrise2", rise);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT2_UVrise3", rise);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT2_UVrise4", rise);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT2_UVfall2", fall);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT2_UVfall3", fall);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT2_UVfall4", fall);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT2_UVhys2", hys);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT2_UVhys3", hys);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT2_UVhys4", hys);}
		}
		else
		{
			if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_UVrise2", rise);}
			if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_UVrise3", rise);}
			if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_UVrise4", rise);}
			if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_UVfall2", fall);}
			if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_UVfall3", fall);}
			if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_UVfall4", fall);}
			if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_UVhys2", hys);}
			if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_UVhys3", hys);}
			if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_UVhys4", hys);}
		}
	}
	else//low uv disable
	{
		if(PN_QT2_Output==0.0)
		{
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT2_UVrise1", rise);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT2_UVrise3", rise);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT2_UVrise4", rise);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT2_UVfall1", fall);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT2_UVfall3", fall);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT2_UVfall4", fall);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT2_UVhys1", hys);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT2_UVhys3", hys);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT2_UVhys4", hys);}
		}
		else
		{
			if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_UVrise1", rise);}
			if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_UVrise3", rise);}
			if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_UVrise4", rise);}
			if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_UVfall1", fall);}
			if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_UVfall3", fall);}
			if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_UVfall4", fall);}
			if(PN_QT2_Output==5.0){Ms_LogData(funcindex, "QT2_UVhys1", hys);}
			if(PN_QT2_Output==3.3){Ms_LogData(funcindex, "QT2_UVhys3", hys);}
			if(PN_QT2_Output==1.8){Ms_LogData(funcindex, "QT2_UVhys4", hys);}
		}
	}
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(1);
	//qt3 ov uv////////////////////////////////////////////////////////////////////////////////
	if(PN_Tracker_Num==3)
	{
		Cmd_Dmuxset_Fs0(56);//ov_qt3
		if(PN_QT3_Output==0.0)
		{
			vstart = PN_QVR_Output;
			vstop = PN_QVR_Output+1;
		}
		else
		{
			vstart = PN_QT3_Output;
			vstop = PN_QT3_Output+1;
		}
		//qt3lmt=0
		step = calc_step(vstart,vstop,120);
		awg.rampvmi(F_QT3, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt3_ov_rise", vstart, vstop, step, 20, 5 mA, TRIG_RISING, rise);
		awg.rampvmi(F_QT3, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt3_ov_fall", vstop, vstart, step, 20, 5 mA, TRIG_FALLING, fall);
		SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
		if(PN_QT3_Output==0.0)
		{
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT3_OVrise1", rise);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT3_OVrise2", rise);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT3_OVrise3", rise);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT3_OVfall1", fall);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT3_OVfall2", fall);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT3_OVfall3", fall);}
			if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT3_OVhys1", hys);}
			if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT3_OVhys2", hys);}
			if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT3_OVhys3", hys);}
		}
		else
		{
			if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_OVrise1", rise);}
			if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_OVrise2", rise);}
			if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_OVrise3", rise);}
			if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_OVfall1", fall);}
			if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_OVfall2", fall);}
			if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_OVfall3", fall);}
			if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_OVhys1", hys);}
			if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_OVhys2", hys);}
			if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_OVhys3", hys);}
		}
		Cmd_Dmuxset_Fs0(58);//uv_qt3
		if(PN_QT3_Output==0.0)
		{
			vstart = PN_QVR_Output-1;
			vstop = PN_QVR_Output;
		}
		else
		{
			vstart = PN_QT3_Output-1;
			vstop = PN_QT3_Output;
		}
		step = calc_step(vstart,vstop,120);
		awg.rampvmi(F_QT3, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt3_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_FALLING, rise);
		awg.rampvmi(F_QT3, A_SECPOSFRE, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, "qt3_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_RISING, fall);
		SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE])*1000.0;
		if(PN_LOW_UV)//low uv enable
		{
			if(PN_QT3_Output==0.0)
			{
				if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT3_UVrise2", rise);}
				if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT3_UVrise3", rise);}
				if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT3_UVrise4", rise);}
				if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT3_UVfall2", fall);}
				if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT3_UVfall3", fall);}
				if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT3_UVfall4", fall);}
				if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT3_UVhys2", hys);}
				if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT3_UVhys3", hys);}
				if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT3_UVhys4", hys);}
			}
			else
			{
				if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_UVrise2", rise);}
				if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_UVrise3", rise);}
				if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_UVrise4", rise);}
				if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_UVfall2", fall);}
				if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_UVfall3", fall);}
				if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_UVfall4", fall);}
				if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_UVhys2", hys);}
				if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_UVhys3", hys);}
				if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_UVhys4", hys);}
			}
		}
		else//low uv disable
		{
			if(PN_QT3_Output==0.0)
			{
				if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT3_UVrise1", rise);}
				if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT3_UVrise3", rise);}
				if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT3_UVrise4", rise);}
				if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT3_UVfall1", fall);}
				if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT3_UVfall3", fall);}
				if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT3_UVfall4", fall);}
				if(PN_QVR_Output==5.0){Ms_LogData(funcindex, "QT3_UVhys1", hys);}
				if(PN_QVR_Output==3.3){Ms_LogData(funcindex, "QT3_UVhys3", hys);}
				if(PN_QVR_Output==1.8){Ms_LogData(funcindex, "QT3_UVhys4", hys);}
			}
			else
			{
				if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_UVrise1", rise);}
				if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_UVrise3", rise);}
				if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_UVrise4", rise);}
				if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_UVfall1", fall);}
				if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_UVfall3", fall);}
				if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_UVfall4", fall);}
				if(PN_QT3_Output==5.0){Ms_LogData(funcindex, "QT3_UVhys1", hys);}
				if(PN_QT3_Output==3.3){Ms_LogData(funcindex, "QT3_UVhys3", hys);}
				if(PN_QT3_Output==1.8){Ms_LogData(funcindex, "QT3_UVhys4", hys);}
			}
		}
		F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(1);
	}

	//vstart
	Cmd_Dmuxset_Main(11);
	Cmd_Dmuxset_Fs0(73);
	Cmd_Dmuxset_Fs1(73);
	Cmd_TMSel(0x0048000000800121);
	delay_ms(1);//acm9
	C_VS1_CAP_DisConnect;
	C_VST_CAP_DisConnect;
	delay_ms(1);
	bool vmon_stgth = false;
	if(DIE_VER()==0) {vmon_stgth = false;}
	else
	{
		if(dut.sel("Vmon_STGTH_SEL").get_working(0)==1){vmon_stgth = true;}
		else{vmon_stgth = false;}
	}
	if(vmon_stgth)
	{
		vstart = 7.2;
		vstop = 7.8;
	}
	else
	{
		vstart = 5.3;
		vstop = 5.9;
	}
	step = calc_step(vstart,vstop,120);
	F_VST.Set(FV, 4.0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(1);
	awg.rampvmif(F_VST, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_Vstartstg1", vstart, vstop, step, 20, 5 mA, TRIG_RISING, rise);//acm9
	//awg.rampvmif(F_VST, A_SECPOSFRE, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_Vstartstg2", vstop, vstart, step, 20, 5 mA, TRIG_FALLING, fall);
	F_VST.Set(FV, 4.0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(1);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	if(vmon_stgth) { Ms_LogData(funcindex, "VS_Vstartstg2", rise);}
	else { Ms_LogData(funcindex, "VS_Vstartstg", rise);}
	vstart = 4.7;
	vstop = 5.3;
	step = calc_step(vstart,vstop,120);
	//F_VST.Set(FV, 4.0, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	//delay_ms(1);
	awg.rampvmvf(F_VST, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_Vstar1", vstart, vstop, step, 20, 2.5 V, TRIG_FALLING, rise);//acm10
	//awg.rampvmvf(F_VST, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_Vstar2", vstop, vstart, step, 20, 2.5 V, TRIG_RISING, fall);//fre L>H
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "VS_Vstart", rise);
	delay_ms(1);
	set_vsx(6.0);
	Cmd_Dmuxset_Main(0);
	Cmd_Dmuxset_Fs0(0);
	Cmd_Dmuxset_Fs1(0);
	Cmd_TMSel(0x0049030000000021);


	Cmd_Dmuxset_Fs0(0);
	Cmd_Dmuxset_Main(3);
	vstart = 4;
	vstop = 0;
	step = calc_step(vstart,vstop,100);
	awg.rampvmvf(F_VST, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_VPDfall1", vstart, vstop, step, 20, 2.5 V, TRIG_RISING, rise);
	awg.rampvmif(F_VST, A_DBUFO, FXVIe_PLUS_20V, FXVIe_PLUS_100MA, "VS_VPDfall2", vstop, vstart, step, 20, 25 nA, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "VS_VPDfall", rise);
	Cmd_Dmuxset_Fs0(0);
	Cmd_Dmuxset_Main(0);
	C_FRE_PU_DisConnect;
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	C_ACM_SECPOSFRE_DisConnect;
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	Poweroff_tm_hc();
	
	//otw,tsd////////////////////////////////////////////////////////////////////////////////
	Poweron_tm_hc();
	set_fb_hc(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	//Cmd_Bank1(true);
	//Nvm_PreviewFs(-1);
	//Cmd_Forceoff(all_off);
	set_vsx(6.0);
	//Cmd_Bank0(true);
	//Cmd_Dis_ERR_WD();
	//Cmd_ReadState(state0);
	//Cmd_Go2_Normal();
	//Cmd_ReadState(state1);
	set_fb_plus_target_hc(0.1);

	double vstu1[SITE_NUM];
	double vstu2[SITE_NUM];
	C_FRE_PU_Connect;
	C_DBUFI_FRE;//vs start
	//C_ACM_SECPOSFRE_Connect;//vs start stg,acm9
	C_ACM_DBUFO_Connect;
	//set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	//delay_ms(1);//acm9
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_ON);
	C_ACM_STU_Connect;
	delay_ms(1);
	Cmd_Bank1(true);
	Cmd_Dmuxset_Fs0(76);//otw,tm119
	Cmd_TMSel(0x00510300000000C9);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_SENSE_ON);
	delay_ms(1);
	A_STU.MeasureVI(50,10);
	Get_Result(A_STU, vstu1, MVRET);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	vstart = 0;
	vstop = 2;//acm1,acm10
	step = calc_step(vstart,vstop,100);
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_100MA, "otw_rise", vstart, vstop, step, 20, 2.5 V, TRIG_RISING, rise);
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_100MA, "otw_fall", vstop, vstart, step, 20, 2.5 V, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "T_OTWV0", vstu1);
	Ms_LogData(funcindex, "T_OTWriseV", rise);
	Ms_LogData(funcindex, "T_OTWfallV", fall);
	Ms_LogData(funcindex, "T_OTWhysV", hys);
	SERIAL rise[SITE]=(vstu1[SITE]-rise[SITE])/0.0039+25;
	SERIAL fall[SITE]=(vstu1[SITE]-fall[SITE])/0.0039+25;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "T_OTWrise", rise);
	Ms_LogData(funcindex, "T_OTWfall", fall);
	Ms_LogData(funcindex, "T_OTWhys", hys);
	Cmd_Dmuxset_Fs0(75);//tsd,tm119
	Cmd_TMSel(0x00510300000000A9);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_10UA, ACM200_RELAY_SENSE_ON);
	delay_ms(1);
	A_STU.MeasureVI(50,10);
	Get_Result(A_STU, vstu2, MVRET);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	vstart = 0;
	vstop = 2;
	step = calc_step(vstart,vstop,100);
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_100MA, "tsd_rise", vstart, 2, step, 20, 2.5 V, TRIG_RISING, rise);
	awg.rampvmv(A_STU, A_DBUFO, ACM200_3p6V, ACM200_100MA, "tsd_fall", 2, vstart, step, 20, 2.5 V, TRIG_FALLING, fall);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "T_TSDV0", vstu2);
	Ms_LogData(funcindex, "T_TSDriseV", rise);
	Ms_LogData(funcindex, "T_TSDfallV", fall);
	Ms_LogData(funcindex, "T_TSDhysV", hys);
	SERIAL rise[SITE]=(vstu2[SITE]-rise[SITE])/0.0039+25;
	SERIAL fall[SITE]=(vstu2[SITE]-fall[SITE])/0.0039+25;
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "T_TSDrise", rise);
	Ms_LogData(funcindex, "T_TSDfall", fall);
	Ms_LogData(funcindex, "T_TSDhys", hys);
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(1);
	C_ACM_STU_DisConnect;
	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	delay_ms(1);
	Cmd_Dmuxset_Fs0(0);
	Cmd_TMSel(0);

	C_FRE_PU_DisConnect;
	C_DBUFI_DisConnect;
	C_ACM_DBUFO_DisConnect;
	C_ACM_SECPOSFRE_DisConnect;

	//amux////////////////////////////////////////////////////////////////////////////////
	if(PN_AMUX_Available)//has AMUX pin
	{
		double Vin[SITE_NUM];
		double Vout[SITE_NUM];
		double Vos[SITE_NUM];
		double Imax[SITE_NUM];
		double Ilk[SITE_NUM];
		double Rpd[SITE_NUM];
		double Vtemp[SITE_NUM];
		double Vmon_Ilk[SITE_NUM];
		double Ratio1P0[SITE_NUM];
		double Ratio2P0[SITE_NUM];
		double Ratio2P5[SITE_NUM];
		double Ratio7P5[SITE_NUM];
		double Ratio14[SITE_NUM];
		
		double Amux_00_HZ[SITE_NUM];//
		double Amux_01_BG1[SITE_NUM];//
		double Amux_02_BG2[SITE_NUM];//
		double Amux_03_IV1[SITE_NUM];//
		double Amux_04_IV2[SITE_NUM];//
		double Amux_05_Vcor[SITE_NUM];//
		double Amux_06_Vprebk[SITE_NUM];//
		double Amux_07_Vquc[SITE_NUM];//
		double Amux_08_Vqst[SITE_NUM];//
		double Amux_09_Vqvr[SITE_NUM];//
		double Amux_0A_Vqco[SITE_NUM];//
		double Amux_0B_Vqt1[SITE_NUM];//
		double Amux_0C_Vqt2[SITE_NUM];//
		double Amux_0D_Vqt3[SITE_NUM];//
		double Amux_0E_Vsx[SITE_NUM];//
		double Amux_0F_Vst[SITE_NUM];//
		double Amux_10_Vsns1[SITE_NUM];//
		double Amux_11_Vsns2[SITE_NUM];//
		double Amux_12_Vmon[SITE_NUM];//
		double Amux_13_Vtmp[SITE_NUM];//
		double Amux_14_Vevs[SITE_NUM];//
		double Vvmon[SITE_NUM];//

		//set_posfb(1.25);
		set_posfb_plus_target(0.0);
		set_vsx(6.0);
		set_fb_hc(5.0);
		set_qst(5.1);
		//set_quc(5.0);
		A_VMON.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		A_AMUX.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		A_EVS.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
		A_VMON.Set(FV, 0.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		//C_VMON_PD_Connect;
		C_ACM_AMUX_Connect;
		C_ACM_VMON_Connect;
		C_ACM_EVS_Connect;
		C_VS1_BATSNS1_Connect;
		C_VS1_BATSNS2_Connect;
		delay_ms(2);
		Cmd_Bank1(true);
		Cmd_TMSel(0x4000000000000000);
		Cmd_Bank0(true);
		////Cmd_Dis_ERR_WD();
		Cmd_ReadState(state2);
		//Cmd_Go2_Normal();
		//Cmd_ReadState(state3);
		//Cmd_AmuxEn(true);
		Cmd_AmuxEn_Stb(true, true,true);
		Cmd_AmuxCfg(0x00);//14
		Cmd_AmuxSel(AMUX_Vmon);//div 1.0
		delay_ms(1);
		A_VMON.Set(FV, 1.0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);//acm9
		A_VMON.MeasureVI(20,10);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_VMON, Vvmon, MVRET);
		Get_Result(A_AMUX, Vos, MVRET);
		SERIAL Vos[SITE]=(Vos[SITE]-Vvmon[SITE])*1000.0;//mV
		Ms_LogData(funcindex, "AMUX_Vos", Vos);
		//C_VMON_PD_DisConnect;
		delay_ms(1);
		A_VMON.Set(FV, 0.5, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_VMON.MeasureVI(20,10);
		Get_Result(A_VMON, Amux_12_Vmon, MVRET);
		A_VMON.Set(FV, 1.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);//acm9
		Get_Result(A_AMUX, Vout, MVRET);
		SERIAL Ratio1P0[SITE]=1.0/Vout[SITE];
		Ms_LogData(funcindex, "AMUX_Ratio1P0", Ratio1P0);
		A_VMON.Set(FV, 0.8, ACM200_10V, ACM200_10UA, ACM200_RELAY_ON);
		delay_ms(1);
		A_VMON.MeasureVI(20,10);//acm8
		Get_Result(A_VMON, Vmon_Ilk, MIRET);
		SERIAL Vmon_Ilk[SITE]=-Vmon_Ilk[SITE]*1000000000.0;//nA
		Ms_LogData(funcindex, "VMON_Ilk", Vmon_Ilk);
		A_VMON.Set(FV, 4.5, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);//acm9
		Get_Result(A_AMUX, Vout, MVRET);
		Ms_LogData(funcindex, "AMUX_Vmax2", Vout);
		A_VMON.Set(FV, 0.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_VMON.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		Cmd_AmuxSel(AMUX_HZ);
		delay_ms(1);
		A_AMUX.Set(FI, 0.0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_00_HZ, MVRET);
		A_AMUX.Set(FV, 0.5, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Ilk, MIRET);
		SERIAL Rpd[SITE]=(0.5/Ilk[SITE])/1000.0;//kohm
		Ms_LogData(funcindex, "AMUX_Rpd", Rpd);
		A_AMUX.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		Cmd_AmuxSel(AMUX_BG1);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_01_BG1, MVRET);

		A_AMUX.Set(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Imax, MIRET);
		SERIAL Imax[SITE]=-Imax[SITE]*1000.0;
		Ms_LogData(funcindex, "AMUX_ImaxSrc", Imax);
		A_AMUX.Set(FV, 4.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Imax, MIRET);
		SERIAL Imax[SITE]=-Imax[SITE]*1000.0;
		Ms_LogData(funcindex, "AMUX_ImaxSnk", Imax);
		A_AMUX.Set(FI, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);

		Cmd_AmuxSel(AMUX_BG2);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_02_BG2, MVRET);
		Cmd_AmuxSel(AMUX_IV1);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_03_IV1, MVRET);
		Cmd_AmuxSel(AMUX_IV2);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_04_IV2, MVRET);
		Cmd_AmuxSel(AMUX_Vcor);//div 1.5
		delay_ms(2);
		A_AMUX.MeasureVI(20,10);
		A_POSFB.MeasureVI(20,10);
		Get_Result(A_AMUX, Vout, MVRET);
		Get_Result(A_POSFB, Vin, MVRET);
		Copy_Array(Amux_05_Vcor,Vout);
		SERIAL Amux_05_Vcor[SITE]=Amux_05_Vcor[SITE]*2.0;
		SERIAL Ratio2P0[SITE]=Vin[SITE]/Vout[SITE];
		Ms_LogData(funcindex, "AMUX_Ratio2P0", Ratio2P0);
		Cmd_AmuxSel(AMUX_Vpbk);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_06_Vprebk, MVRET);
		SERIAL Amux_06_Vprebk[SITE]=Amux_06_Vprebk[SITE]*2.5;
		Cmd_AmuxSel(AMUX_Vquc);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_07_Vquc, MVRET);
		SERIAL Amux_07_Vquc[SITE]=Amux_07_Vquc[SITE]*2.5;
		Cmd_AmuxSel(AMUX_Vqst);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_08_Vqst, MVRET);
		SERIAL Amux_08_Vqst[SITE]=Amux_08_Vqst[SITE]*2.5;
		Cmd_AmuxSel(AMUX_Vqvr);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_09_Vqvr, MVRET);
		SERIAL Amux_09_Vqvr[SITE]=Amux_09_Vqvr[SITE]*2.5;
		Cmd_AmuxSel(AMUX_Vqco);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_0A_Vqco, MVRET);
		SERIAL Amux_0A_Vqco[SITE]=Amux_0A_Vqco[SITE]*2.5;
		Cmd_AmuxSel(AMUX_Vqt1);//div 2.5
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		F_QT1.MeasureVI(20,10);
		Get_Result(A_AMUX, Vout, MVRET);
		Get_Result(F_QT1, Vin, MVRET);
		Copy_Array(Amux_0B_Vqt1,Vout);
		SERIAL Amux_0B_Vqt1[SITE]=Amux_0B_Vqt1[SITE]*2.5;
		SERIAL Ratio2P5[SITE]=Vin[SITE]/Vout[SITE];
		Ms_LogData(funcindex, "AMUX_Ratio2P5", Ratio2P5);
		Cmd_AmuxSel(AMUX_Vqt2);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_0C_Vqt2, MVRET);
		SERIAL Amux_0C_Vqt2[SITE]=Amux_0C_Vqt2[SITE]*2.5;
		Cmd_AmuxSel(AMUX_Vqt3);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_0D_Vqt3, MVRET);
		SERIAL Amux_0D_Vqt3[SITE]=Amux_0D_Vqt3[SITE]*2.5;
		Cmd_AmuxSel(AMUX_Vsx);
		Cmd_AmuxCfg(0x00);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_0E_Vsx, MVRET);
		SERIAL Amux_0E_Vsx[SITE]=Amux_0E_Vsx[SITE]*14;
		Cmd_AmuxSel(AMUX_Vst);//div 7.5
		Cmd_AmuxCfg(0x08);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		F_VST.MeasureVI(20,10);
		Get_Result(A_AMUX, Vout, MVRET);
		Get_Result(F_VST, Vin, MVRET);
		Copy_Array(Amux_0F_Vst,Vout);
		SERIAL Amux_0F_Vst[SITE]=Amux_0F_Vst[SITE]*7.5;
		SERIAL Ratio7P5[SITE]=Vin[SITE]/Vout[SITE];
		Ms_LogData(funcindex, "AMUX_Ratio7P5", Ratio7P5);
		Cmd_AmuxSel(AMUX_Vst);//div 14
		Cmd_AmuxCfg(0x00);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		F_VST.MeasureVI(20,10);
		Get_Result(A_AMUX, Vout, MVRET);
		Get_Result(F_VST, Vin, MVRET);
		SERIAL Ratio14[SITE]=Vin[SITE]/Vout[SITE];
		Ms_LogData(funcindex, "AMUX_Ratio14", Ratio14);
		Cmd_AmuxSel(AMUX_Vsns1);
		Cmd_AmuxCfg(0x00);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_10_Vsns1, MVRET);
		SERIAL Amux_10_Vsns1[SITE]=Amux_10_Vsns1[SITE]*14;
		Cmd_AmuxSel(AMUX_Vsns2);
		Cmd_AmuxCfg(0x00);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Amux_11_Vsns2, MVRET);
		SERIAL Amux_11_Vsns2[SITE]=Amux_11_Vsns2[SITE]*14;
		Cmd_AmuxSel(AMUX_Vtemp);
		delay_ms(1);
		A_AMUX.MeasureVI(20,10);
		Get_Result(A_AMUX, Vtemp, MVRET);
		Copy_Array(Amux_13_Vtmp,Vtemp);
		Ms_LogData(funcindex, "VTEMP_25", Vtemp);
		if (PINarray[27].pin_valid)
		{
			Cmd_AmuxSel(AMUX_Vevs);
			delay_ms(1);
			A_EVS.Set(FV, 1.5, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
			A_AMUX.MeasureVI(20,10);
			Get_Result(A_AMUX, Amux_14_Vevs, MVRET);
			SERIAL Amux_14_Vevs[SITE]=Amux_14_Vevs[SITE]*14;
			A_AMUX.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
			A_VMON.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
			A_EVS.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
		}
		C_ACM_AMUX_DisConnect;
		C_ACM_VMON_DisConnect;
		C_ACM_EVS_DisConnect;
		C_VS1_BATSNS1_DisConnect;
		C_VS1_BATSNS2_DisConnect;
		delay_ms(2);
		A_AMUX.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		A_VMON.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		A_EVS.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
		F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
		F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
		F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

		Ms_LogData(funcindex, "AMUX_00_HZ", Amux_00_HZ);
		Ms_LogData(funcindex, "AMUX_01_BG1", Amux_01_BG1);
		Ms_LogData(funcindex, "AMUX_02_BG2", Amux_02_BG2);
		Ms_LogData(funcindex, "AMUX_03_IV1", Amux_03_IV1);
		Ms_LogData(funcindex, "AMUX_04_IV2", Amux_04_IV2);
		Ms_LogData(funcindex, "AMUX_05_Vcor", Amux_05_Vcor);
		Ms_LogData(funcindex, "AMUX_06_Vprebk", Amux_06_Vprebk);
		Ms_LogData(funcindex, "AMUX_07_Vquc", Amux_07_Vquc);
		Ms_LogData(funcindex, "AMUX_08_Vqst", Amux_08_Vqst);
		Ms_LogData(funcindex, "AMUX_09_Vqvr", Amux_09_Vqvr);
		Ms_LogData(funcindex, "AMUX_0A_Vqco", Amux_0A_Vqco);
		Ms_LogData(funcindex, "AMUX_0B_Vqt1", Amux_0B_Vqt1);
		Ms_LogData(funcindex, "AMUX_0C_Vqt2", Amux_0C_Vqt2);
		if(PN_Tracker_Num==3){Ms_LogData(funcindex, "AMUX_0D_Vqt3", Amux_0D_Vqt3);}
		Ms_LogData(funcindex, "AMUX_0E_Vsx", Amux_0E_Vsx);
		Ms_LogData(funcindex, "AMUX_0F_Vst", Amux_0F_Vst);
		Ms_LogData(funcindex, "AMUX_10_Vsns1", Amux_10_Vsns1);
		Ms_LogData(funcindex, "AMUX_11_Vsns2", Amux_11_Vsns2);
		Ms_LogData(funcindex, "AMUX_12_Vmon", Amux_12_Vmon);
		Ms_LogData(funcindex, "AMUX_13_Vtmp", Amux_13_Vtmp);
		if (PINarray[27].pin_valid){Ms_LogData(funcindex, "AMUX_14_Vevs", Amux_14_Vevs);}
	}
	set_posfb(false);
	Poweroff_tm_hc();

	//vs ov uv////////////////////////////////////////////////////////////////////////////////
	C_FPVIH_DisConnect;
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	A_POSIN.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	A_POSSW.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	//F_QT3.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	C_MPS_PU_Connect;
	//C_VST_CAP_Connect;
	//C_VS1_CAP_Connect;
	C_QST_CAP_Connect;
	C_FB_CAP_Connect;
	C_QUC_CAP_Connect;
	C_QCO_CAP_Connect;
	C_QVR_CAP_Connect;
	C_QT1_CAP_Connect;
	C_QT2_CAP_Connect;
	C_QT3_CAP_Connect;

	//C_VST_VS1_Connect;
	C_FPVIH_VS1_Connect;
	C_FPVIH_VST_Connect;
	C_FPVIL_AG_Connect;
	C_FXVI_FB_Connect;
	C_QUC_SQUC_Connect;
	C_QT1_SQT1_Connect;
	C_QT2_SQT2_Connect;
	delay_ms(2);
	fpvi0.Set(FV,4.0,FPVIe_100V,FPVIe_100MA,FPVIe_RELAY_ON);
	set_fb_hc(4.5);
	set_quc(4.5);
	delay_ms(2);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	fpvi0.Set(FV,6.0,FPVIe_100V,FPVIe_100MA,FPVIe_RELAY_ON);
	delay_ms(2);
	//vs1////////////////////////////////////////////////////////////////////////////////
	C_ACM_SECPOSFRE_Connect;//vs start stg,acm9
	set_sec_posfre(FV, 5.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(1);
	Cmd_Dmuxset_Fs0(60);//ov_vs
	Cmd_TMSel(0x0049030000000021);
	vstart = 40;
	vstop = 44;
	step = calc_step(vstart,vstop,200);
	fpvi0.Set(FV,vstart,FPVIe_100V,FPVIe_100MA,FPVIe_RELAY_ON,2);
	awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_100V, FPVIe_100MA, "vs_ov_rise", vstart V, vstop V, step, 25, 5 mA, TRIG_RISING, rise);
	vstart = 39;
	vstop = 43;
	step = calc_step(vstart,vstop,200);
	fpvi0.Set(FV,vstop,FPVIe_100V,FPVIe_100MA,FPVIe_RELAY_ON,2);
	awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_100V, FPVIe_100MA, "vs_ov_fall", vstop V, vstart V, step, 25, 5 mA, TRIG_FALLING, fall);
	fpvi0.Set(FV,6.0,FPVIe_100V,FPVIe_100MA,FPVIe_RELAY_ON,3);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "VS_OVrise", rise);
	Ms_LogData(funcindex, "VS_OVfall", fall);
	Ms_LogData(funcindex, "VS_OVhys", hys);
	Cmd_Dmuxset_Fs0(61);//ov_vs
	Cmd_TMSel(0x0049030000000021);
	vstart = 4.0;
	vstop = 2.4;
	step = calc_step(vstart,vstop,100);
	fpvi0.Set(FV, vstart, FPVIe_100V, FPVIe_100MA, FPVIe_RELAY_ON, 2);
	awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_100V, FPVIe_100MA, "vs_uv_rise", vstart V, vstop V, step, 20, 5 mA, TRIG_RISING, rise);
	awg.rampvmi(fpvi0, A_SECPOSFRE, FPVIe_100V, FPVIe_100MA, "vs_uv_fall", vstop V, vstart V, step, 20, 5 mA, TRIG_FALLING, fall);
	fpvi0.Set(FV,6.0,FPVIe_100V,FPVIe_100MA,FPVIe_RELAY_ON,5);
	SERIAL hys[SITE] = abs(rise[SITE] - fall[SITE]);
	Ms_LogData(funcindex, "VS_UVrise", rise);
	Ms_LogData(funcindex, "VS_UVfall", fall);
	Ms_LogData(funcindex, "VS_UVhys", hys);
	C_ACM_SECPOSFRE_DisConnect;
	delay_ms(1);
	set_sec_posfre(FV, 0.0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	set_quc(false);
	fpvi0.Set(FV,0.0,FPVIe_100V,FPVIe_100MA,FPVIe_RELAY_ON);
	delay_ms(2);
	set_quc(0.0);
	set_qst(false);
	fpvi0.Set(FV,0.0,FPVIe_100V,FPVIe_100MA,FPVIe_RELAY_OFF);
	set_quc(false);
	set_fb_hc(false);
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	C_FB_CAP_DisConnect;
	C_QUC_CAP_DisConnect;
	C_QCO_CAP_DisConnect;
	C_QVR_CAP_DisConnect;
	C_QT1_CAP_DisConnect;
	C_QT2_CAP_DisConnect;
	C_QT3_CAP_DisConnect;
	//C_VST_VS1_DisConnect;
	C_FPVIH_VS1_DisConnect;
	C_FPVIH_VST_DisConnect;
	C_FPVIL_AG_DisConnect;
	C_FXVI_FB_DisConnect;
	C_QUC_SQUC_DisConnect;
	C_QT1_SQT1_DisConnect;
	C_QT2_SQT2_DisConnect;
	C_MPS_PU_DisConnect;

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T51_Scan(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	all_resource_off();
	C_All_Open;

	double vboxl = 2.0;//2.0
	double vboxn = 5.0;
	double vboxh = 8.0;
	float freq_m = 20 MHz;
	float freq_fs = 20 MHz;//from 5M to 15M, 1.87s to 1.41s for 2 site

	int fail_flag[SITE_NUM];
	int fail_count[SITE_NUM];
	int star_point = 0;
	int stop_point = 0;
	string start;
	string stop;
	string paraname;
	string paradelta;
	int failcount_iddq[SITE_NUM];
	double iddq_pre[15][SITE_NUM];
	double iddq_pos[15][SITE_NUM];
	double iddq_delt[15][SITE_NUM];
	double Ivdd_before1[SITE_NUM];
	double Ivdd_scan1[SITE_NUM];
	double Ivdd_before2[SITE_NUM];
	double Ivdd_scan2[SITE_NUM];

	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	Ms_LogData(funcindex, "VBOXL_V", vboxl);
	Ms_LogData(funcindex, "VBOX_V", vboxn);
	Ms_LogData(funcindex, "VBOXH_V", vboxh);
	Ms_LogData(funcindex, "SCAN_M_FREQ", (freq_m/1000000.0));
	Ms_LogData(funcindex, "SCAN_FS_FREQ", (freq_fs/1000000.0));

	bool test_vboxl = false;
	if (max_temp < 50){ test_vboxl = true; }

	test_vboxl = true;
	C_ACM_SECPOSFRE_Connect;
	Poweron_tm_hc();
	set_fb_hc(5.5);
	set_quc(5.0);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Cmd_TestMode(true);
	set_vsx(8.0);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	A_SECPOSFRE.MeasureVI(20, 10);
	Get_Result(A_SECPOSFRE, Ivdd_before1, MIRET);
	SERIAL Ivdd_before1[SITE] = Ivdd_before1[SITE] * 1000.0;
	Cmd_Bank1();
	CmdReadData(0x31,data1);//2
	Cmd_Scan_Main();
	CmdReadData(0x31,data2);//0
	delay_ms(2);
	Scan_Connect(vboxn);
	Cmd_Set_Freq_Scan(freq_m);
	A_SECPOSFRE.MeasureVI(20, 10);
	Get_Result(A_SECPOSFRE, Ivdd_scan1, MIRET);
	SERIAL Ivdd_scan1[SITE] = Ivdd_scan1[SITE] * 1000.0;
	Ms_LogData(funcindex, "Ivdd_before1", Ivdd_before1);
	Ms_LogData(funcindex, "Ivdd_scan1", Ivdd_scan1);

	string iddq_m_point[] = { "IQ_M_Start", "IQ_M0", "IQ_M1", "IQ_M2", "IQ_M3", "IQ_M4", "IQ_M5", "IQ_M6", "IQ_M7", "IQ_M8", "IQ_M9", "IQ_M_Stop" };
	int size = sizeof(iddq_m_point) / sizeof(iddq_m_point[0]);
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	Iddq_Run(iddq_m_point, size, fail_flag, fail_count, iddq_pre);
	Ms_LogData(funcindex, "IDDQ_M_Pre_FailFlag", fail_flag); 
	Ms_LogData(funcindex, "IDDQ_M_Pre_FailCount", fail_count);
	for (int i = 0; i <= size - 2; i++)
	{
		string Parm = "IDDQ_M" + to_string(i) + "_Pre";
		Ms_LogData(funcindex, Parm, iddq_pre[i]);
	}
	//vboxl
	set_sec_posfre(FV, vboxl, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Scan_SetLevle(vboxn);
	if (test_vboxl)
	{
		Scan_Run("SCAN", "SA_M1_Start", "SA_M1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXL_SA_M1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXL_SA_M1_FailCount", fail_count);
		Scan_Run("SCAN", "SA_M2_Start", "SA_M2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXL_SA_M2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXL_SA_M2_FailCount", fail_count);
		Scan_Run("SCAN", "TR_M1_Start", "TR_M1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXL_TR_M1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXL_TR_M1_FailCount", fail_count);
		Scan_Run("SCAN", "TR_M2_Start", "TR_M2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXL_TR_M2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXL_TR_M2_FailCount", fail_count);
	}
	//vboxnor
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Scan_SetLevle(vboxn);
	Scan_Run("SCAN", "SA_M1_Start", "SA_M1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOX_SA_M1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOX_SA_M1_FailCount", fail_count);
	Scan_Run("SCAN", "SA_M2_Start", "SA_M2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOX_SA_M2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOX_SA_M2_FailCount", fail_count);
	Scan_Run("SCAN", "TR_M1_Start", "TR_M1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOX_TR_M1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOX_TR_M1_FailCount", fail_count);
	Scan_Run("SCAN", "TR_M2_Start", "TR_M2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOX_TR_M2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOX_TR_M2_FailCount", fail_count);
	//vboxh
	set_sec_posfre(FV, vboxh, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Scan_SetLevle(vboxn);
	Scan_Run("SCAN", "SA_M1_Start", "SA_M1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXH_SA_M1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXH_SA_M1_FailCount", fail_count);
	Scan_Run("SCAN", "SA_M2_Start", "SA_M2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXH_SA_M2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXH_SA_M2_FailCount", fail_count);
	Scan_Run("SCAN", "TR_M1_Start", "TR_M1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXH_TR_M1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXH_TR_M1_FailCount", fail_count);
	Scan_Run("SCAN", "TR_M2_Start", "TR_M2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXH_TR_M2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXH_TR_M2_FailCount", fail_count);
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Scan_SetLevle(vboxn);
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	Iddq_Run(iddq_m_point, size, fail_flag, fail_count, iddq_pos);
	Ms_LogData(funcindex, "IDDQ_M_Pos_FailFlag", fail_flag);
	Ms_LogData(funcindex, "IDDQ_M_Pos_FailCount", fail_count);
	for (int i = 0; i <= size - 2; i++)
	{
		string Parm = "IDDQ_M" + to_string(i) + "_Pos";
		Ms_LogData(funcindex, Parm, iddq_pos[i]);
		string Parm2 = "IDDQ_M" + to_string(i) + "_Delt";
		SERIAL iddq_delt[i][SITE] = iddq_pos[i][SITE] - iddq_pre[i][SITE];
		Ms_LogData(funcindex, Parm2, iddq_delt[i]);
	}
	dcm.InitPPMU("DCM_ALL");
	dcm.Disconnect("DCM_ALL");
	Poweroff_tm_hc();
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	C_All_Open;
	//delay_ms(20);

	C_ACM_SECPOSFRE_Connect;
	Poweron_tm_hc();
	set_fb_hc(5.5);
	set_quc(5.0);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Cmd_TestMode(true);
	set_vsx(8.0);
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	A_SECPOSFRE.MeasureVI(20, 10);
	Get_Result(A_SECPOSFRE, Ivdd_before2, MIRET);
	SERIAL Ivdd_before2[SITE] = Ivdd_before2[SITE] * 1000.0;
	Cmd_Bank1();
	Cmd_Scan_Fs();
	delay_ms(2);
	Scan_Connect(vboxn);
	Cmd_Set_Freq_Scan(freq_fs);
	A_SECPOSFRE.MeasureVI(20, 10);
	Get_Result(A_SECPOSFRE, Ivdd_scan2, MIRET);
	SERIAL Ivdd_scan2[SITE] = Ivdd_scan2[SITE] * 1000.0;
	Ms_LogData(funcindex, "Ivdd_before2", Ivdd_before2);
	Ms_LogData(funcindex, "Ivdd_scan2", Ivdd_scan2);

	string iddq_fs_point[] = { "IQ_FS_Start", "IQ_F0", "IQ_F1", "IQ_F2", "IQ_F3", "IQ_F4", "IQ_F5", "IQ_F6", "IQ_F7", "IQ_F8", "IQ_F9", "IQ_FS_Stop" };
	size = sizeof(iddq_fs_point) / sizeof(iddq_fs_point[0]);
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	Iddq_Run(iddq_fs_point, size, fail_flag, fail_count, iddq_pre);
	Ms_LogData(funcindex, "IDDQ_FS_Pre_FailFlag", fail_flag);
	Ms_LogData(funcindex, "IDDQ_FS_Pre_FailCount", fail_count);
	for (int i = 0; i <= size - 2; i++)
	{
		string ParFS = "IDDQ_FS" + to_string(i) + "_Pre";
		Ms_LogData(funcindex, ParFS, iddq_pre[i]);
	}
	//vboxl
	set_sec_posfre(FV, vboxl, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Scan_SetLevle(vboxn);
	if (test_vboxl)
	{
		Scan_Run("SCAN", "SA_FS1_Start", "SA_FS1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXL_SA_FS1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXL_SA_FS1_FailCount", fail_count);
		Scan_Run("SCAN", "SA_FS2_Start", "SA_FS2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXL_SA_FS2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXL_SA_FS2_FailCount", fail_count);
		Scan_Run("SCAN", "TR_FS1_Start", "TR_FS1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXL_TR_FS1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXL_TR_FS1_FailCount", fail_count);
		Scan_Run("SCAN", "TR_FS2_Start", "TR_FS2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXL_TR_FS2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXL_TR_FS2_FailCount", fail_count);
	}
	//vboxnor
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Scan_SetLevle(vboxn);
	Scan_Run("SCAN", "SA_FS1_Start", "SA_FS1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOX_SA_FS1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOX_SA_FS1_FailCount", fail_count);
	Scan_Run("SCAN", "SA_FS2_Start", "SA_FS2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOX_SA_FS2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOX_SA_FS2_FailCount", fail_count);
	Scan_Run("SCAN", "TR_FS1_Start", "TR_FS1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOX_TR_FS1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOX_TR_FS1_FailCount", fail_count);
	Scan_Run("SCAN", "TR_FS2_Start", "TR_FS2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOX_TR_FS2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOX_TR_FS2_FailCount", fail_count);
	//vboxh
	set_sec_posfre(FV, vboxh, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Scan_SetLevle(vboxn);
	Scan_Run("SCAN", "SA_FS1_Start", "SA_FS1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXH_SA_FS1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXH_SA_FS1_FailCount", fail_count);
	Scan_Run("SCAN", "SA_FS2_Start", "SA_FS2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXH_SA_FS2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXH_SA_FS2_FailCount", fail_count);
	Scan_Run("SCAN", "TR_FS1_Start", "TR_FS1_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXH_TR_FS1_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXH_TR_FS1_FailCount", fail_count);
	Scan_Run("SCAN", "TR_FS2_Start", "TR_FS2_Stop", fail_flag, fail_count); Ms_LogData(funcindex, "VBOXH_TR_FS2_FailFlag", fail_flag); Ms_LogData(funcindex, "VBOXH_TR_FS2_FailCount", fail_count);
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(2);
	Scan_SetLevle(vboxn);
	set_sec_posfre(FV, vboxn, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	Iddq_Run(iddq_fs_point, size, fail_flag, fail_count, iddq_pos);
	Ms_LogData(funcindex, "IDDQ_FS_Pos_FailFlag", fail_flag);
	Ms_LogData(funcindex, "IDDQ_FS_Pos_FailCount", fail_count);
	for (int i = 0; i <= size - 2; i++)
	{
		string ParFS = "IDDQ_FS" + to_string(i) + "_Pos";
		Ms_LogData(funcindex, ParFS, iddq_pos[i]);
		string ParFS2 = "IDDQ_FS" + to_string(i) + "_Delt";
		SERIAL iddq_delt[i][SITE] = iddq_pos[i][SITE] - iddq_pre[i][SITE];
		Ms_LogData(funcindex, ParFS2, iddq_delt[i]);
	}
	dcm.InitPPMU("DCM_ALL");
	dcm.Disconnect("DCM_ALL");
	Poweroff_tm_hc();
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	set_sec_posfre(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	C_All_Open;

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T60_PowerSeq(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	return true;

	double result[SITE_NUM];
	double v_qst[SITE_NUM];
	double v_fb[SITE_NUM];
	double v_posfb[SITE_NUM];
	double v_quc[SITE_NUM];
	double v_qco[SITE_NUM];
	double v_qvr[SITE_NUM];
	double v_qt1[SITE_NUM];
	double v_qt2[SITE_NUM];
	double v_qt3[SITE_NUM];

	double i_vsx[SITE_NUM];

	int reg0[SITE_NUM];
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int reg3[SITE_NUM];
	int reg4[SITE_NUM];
	int reg5[SITE_NUM];
	int reg6[SITE_NUM];


	C_All_Open;
	all_resource_off();
	set_wak(false);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	if(PN_Posbk_Available){A_POSFB.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON);}
	//C_FXVI_ENA_Connect;
	C_FB_POSIN_Connect;
	set_ena_off();
	delay_ms(2);
	Poweron_tm_hc();
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Masksafe();
	//Cmd_Bank1(true);
	//Nvm_PreviewFs(-1);
	Cmd_Bank0(true);
	set_vsx(6.0);
	set_fb_plus_target_hc(0.1);//target+0.1V
	//set_posfb_plus_target(0.1);//target+0.1V
	// 
	//A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//Cmd_Bank0();
	Cmd_Dis_ERR_WD();
	Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	CmdReadData(0x00, reg6);
	//F_FB.MeasureVI(1000,10);
	delay_ms(1);
	Cmd_ReadState(reg0);//1
	Ms_LogData(funcindex, "SM_INIT", reg0);
	delay_ms(1);
	Cmd_Go2_Normal();
	delay_ms(1);
	Cmd_ReadState(reg1);//2
	Ms_LogData(funcindex, "SM_NORMAL", reg1);
	delay_ms(1);
	CmdReadData(0x33,reg6);
	CmdWriteData(BCK_FRE_SPREAD,0x00);//no spsp
	CmdWriteData(BCK_FREQ_CHANGE,0x04);//0%

	//set_vsx(7.0);
	//set_vsx(8.0);
	//set_vsx(9.0);
	//set_vsx(10.0);
	//set_vsx(11.0);
	set_vsx(12.0);
	delay_ms(2);
	//set_fb_hc(5.0);


	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_FB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	prebk_load_connect();
	if(PN_Posbk_Available){posbk_load_connect();}

	F_VST.MeasureVI(20,10);
	Get_Result(F_VST, i_vsx, MIRET);
	SERIAL i_vsx[SITE]=i_vsx[SITE]*1000.0;
	Ms_LogData(funcindex, "I_VSX", i_vsx);

	F_FB.Set(FI, -10 mA, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Posbk_Available){A_POSFB.Set(FI, -10 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);}
	A_QST.Set(FI, -10 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FI, -10 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, -10 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, -10 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, -10 mA, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, -10 mA, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, -1 mA, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	delay_ms(2);
	Cmd_En_Stb(true, true);
	Cmd_En_Trk();
	delay_ms(2);

	A_QST.MeasureVI(20,10);
	Get_Result(A_QST, v_qst, MVRET);
	F_FB.MeasureVI(20,10);
	Get_Result(F_FB, v_fb, MVRET);
	A_POSFB.MeasureVI(20,10);//acm7
	Get_Result(A_POSFB, v_posfb, MVRET);
	A_QUC.MeasureVI(20,10);
	Get_Result(A_QUC, v_quc, MVRET);
	A_QCO.MeasureVI(20,10);
	Get_Result(A_QCO, v_qco, MVRET);
	A_QVR.MeasureVI(20,10);
	Get_Result(A_QVR, v_qvr, MVRET);
	F_QT1.MeasureVI(20,10);
	Get_Result(F_QT1, v_qt1, MVRET);
	F_QT2.MeasureVI(20,10);
	Get_Result(F_QT2, v_qt2, MVRET);
	if(PN_Tracker_Num==3)
	{
		F_QT3.MeasureVI(20,10);
		Get_Result(F_QT3, v_qt3, MVRET);
	}
	
	Ms_LogData(funcindex, "V_QST", v_qst);
	Ms_LogData(funcindex, "V_FB", v_fb);
	if(PN_Posbk_Available){Ms_LogData(funcindex, "V_POSFB", v_posfb);}
	Ms_LogData(funcindex, "V_QUC", v_quc);
	Ms_LogData(funcindex, "V_QCO", v_qco);
	Ms_LogData(funcindex, "V_QVR", v_qvr);
	Ms_LogData(funcindex, "V_QT1", v_qt1);
	Ms_LogData(funcindex, "V_QT2", v_qt2);
	if(PN_Tracker_Num==3){Ms_LogData(funcindex, "V_QT3", v_qt3);}

	set_vsx(8.0);
	//switching
	double freq[SITE_NUM];
	//double duty[SITE_NUM];
	//double ton[SITE_NUM];
	//double toff[SITE_NUM];
	C_DBUF_Bypass;
	C_DCM_DBUFO_Connect;
	C_SW_PD_Connect;
	C_DBUFI_SW1;
	delay_ms(2);
	measure_freq_duty_set("DCM5",8.0);
	dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
	delay_ms(1);
	measure_freq_get("DCM5",freq);
	Ms_LogData(funcindex, "PreBK_Fsw", freq);
	C_SW_PD_DisConnect;
	C_DBUFI_DisConnect;
	delay_ms(2);
	if(PN_Posbk_Available)
	{
		C_DBUF_Usage;
		C_DBUFI_POSSW;
		delay_ms(2);
		measure_freq_duty_set("DCM5",5.0);
		dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
		delay_ms(1);
		measure_freq_get("DCM5",freq);
		Ms_LogData(funcindex, "PosBK_Fsw", freq);
		C_DBUFI_DisConnect;
	}
	C_DBUF_Bypass;
	C_DCM_DBUFO_DisConnect;
	delay_ms(2);
	set_vsx(6.0);
	delay_ms(2);
	//double freq[SITE_NUM];
	//double results1[SITE_NUM];
	//if(1)
	//{
	//	//ssd_clk
	//	C_FRE_PU_Connect;
	//	C_DCM_FRE_Connect;//dcm7
	//	Cmd_Bank1(true);
	//	//Cmd_Forceoff(except_prebk);
	//	Cmd_Dmuxset_Main(254);
	//	Cmd_TMSel(0x3048000000002100); 
	//	delay_ms(2);
	//	set_vsx(6.0);
	//	measure_freq_duty_set("DCM7",0.8);
	//	measure_freq_get("DCM7",freq);
	//	SERIAL freq[SITE]=freq[SITE]/1000.0;
	//	//Ms_LogData(funcindex, "SSD_Clk", freq);
	//	C_FRE_PU_DisConnect;
	//	C_DCM_FRE_DisConnect;//dcm7
	//	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_SENSE_ON);
	//	C_ACM_STU_Connect;
	//	delay_ms(2);
	//	Cmd_Dmuxset_Main(254);
	//	Cmd_TMSel(0x3058000000002100); 
	//	delay_ms(2);
	//	A_STU.MeasureVI(20,10);
	//	Get_Result(A_STU, results1, MVRET);
	//	//Ms_LogData(funcindex, "SSD_Vout", results1);
	//	C_ACM_STU_DisConnect;
	//	A_STU.Set(FI, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_OFF);
	//	Cmd_Dmuxset_Main(0);
	//	Cmd_TMSel(0x00); 
	//}


	Cmd_Bank0(true);
	Cmd_Go2_Sleep();
	delay_ms(2);
	Cmd_Go2_Sleep();
	delay_ms(2);
	Cmd_ReadState(reg2);//3
	Ms_LogData(funcindex, "SM_SLEEP", reg2);
	delay_ms(1);
	CmdReadData(0x1C,reg6);//0x0A,0x08
	Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	Cmd_Go2_Wake();
	delay_ms(1);
	Cmd_ReadState(reg3);//5
	Ms_LogData(funcindex, "SM_WAKE", reg3);

	delay_ms(1);
	Cmd_Go2_Standby();
	delay_ms(1);
	Cmd_ReadState(reg4);//4?
	Ms_LogData(funcindex, "SM_STANDBY", reg4);
	delay_ms(1);

	//F_ROT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_ROT_Connect;
	//delay_ms(1);
	//F_ROT.MeasureVI(20,10);//fxvi5
	//F_ROT.Set(FI, 5 mA, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_ROT.MeasureVI(20,10);
	////Get_Result(F_ROT, results1, MVRET);
	////Ms_LogData(funcindex, "ROT_Vol", results1);
	//F_ROT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_ROT_DisConnect;
	//delay_ms(1);

	//double results1[SITE_NUM];
	////Cmd_Dmuxset_Fs0(87);
	////Cmd_TMSel(0x0048000002000000);
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_Connect;
	//delay_ms(1);
	//F_INT.Set(FV, 1, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(1);
	//F_INT.MeasureVI(20,10);
	//Get_Result(F_INT, results1, MIRET);//0.4mA,2.5kohm
	////Ms_LogData(funcindex, "INT_Vol", results1);
	//F_INT.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	//C_FXVI_INT_DisConnect;
	//delay_ms(1);


	set_ena_pulse();
	Cmd_ReadState(reg5);//1
	Ms_LogData(funcindex, "SM_INIT2", reg5);

	F_FB.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Posbk_Available){A_POSFB.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);}
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}


	set_ena_off();
	set_wak_off();
	Poweroff_tm_hc();
	//C_FXVI_ENA_DisConnect;
	C_FB_POSIN_DisConnect;

	prebk_load_disconnect();
	if(PN_Posbk_Available){posbk_load_disconnect();}

	if(PN_Posbk_Available){A_POSFB.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);}
	A_QST.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);}

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T62_PSRR(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES

	if(QC){return 0;}

	//return true;
	int freq = 100 KHz;
	int reg[64][SITE_NUM];
	int reg0[SITE_NUM];
	int tempd[SITE_NUM];
	//double min[SITE_NUM];
	//double max[SITE_NUM];
	//double vpp[SITE_NUM];
	double psrr[SITE_NUM];
	all_resource_off();
	C_All_Open;
	QVM_Init();
	//QVM_Connect();

	//QST
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	Poweron_tm_psrr();
	set_fb_hc(5.5);
	set_quc(5.0);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Dis_WwdFwdErrm();
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Cmd_Forceoff(none_off);
	delay_ms(1);
	PSRR_SetDc(6.0);
	set_fb_plus_target_hc(0.1);//target+0.1V
	Cmd_Bank0(true);
	//for (int i = 0; i<64; i++)
	//{
	//	CmdReadData(i, reg[i]);
	//}
	//for (int i = 0; i<64; i++)
	//{
	//	Copy_Array(reg0, reg[i]);
	//	string Parm = "R" + to_string(i);
	//	//Ms_LogData(funcindex, Parm, reg0);
	//}

	PSRR_SetDc(6.0);
	Cmd_Bank0(true);
	//Cmd_Dis_WwdFwdErrm();
	Cmd_Dis_ERR_WD();
	//Cmd_ReadState(state0);
	Cmd_Go2_Normal();
	Cmd_ReadState(tempd);//2
	Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	Cmd_En_Stb(true, true);
	Cmd_En_Trk();
	Cmd_ReadState(reg0);
	Ms_LogData(funcindex, "State0", reg0);
	delay_ms(2);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	delay_ms(2);
	PSRR_Connect();
	PSRR_SetDc(8.0);
	//PSRR_SetFreq(freq);
	PSRR_SetAc();
	PSRR_SetGain(3);
	C_VST_CAP_DisConnect;
	C_VS1_CAP_DisConnect;
	C_QST_CAP_DisConnect;
	//Cmd_En_Stb(true, true);
	//A_QST.MeasureVI(1000, 10);//acm0
	//F_VST.MeasureVI(1000, 10);//fxvi4
	//A_ABUFO.MeasureVI(1000, 1);//acm9
	
	C_PWRX_QST_Connect;
	C_QVMH_DUTSO_Connect;
	C_QVMH_ABUFO_Connect;
	C_QVML_GND_Connect;
	C_ACM_ABUFO_Connect;
	delay_ms(2);

	double amp_duto[SITE_NUM];
	int psrr_point = 0;
	psrr_point = PSRR_MeasAmp2(2048, freq, amp_duto);
	int psrr_freq = PSRR_GetFreq()/1000.0;
	PSRR_CalcRsrr(amp_duto, psrr);
	Ms_LogData(funcindex, "PSRR_Point", psrr_point);
	Ms_LogData(funcindex, "PSRR_FREQ", psrr_freq);
	Ms_LogData(funcindex, "PSRR_QST", psrr);

	PSRR_Connect();
	PSRR_SetAcOff();
	PSRR_SetDc(0.0);
	PSRR_OutEna(false);
	C_PWRX_DisConnect;
	C_LSI_DUTO_PWRX_DisConnect;
	C_LSI_DUTI_DisConnect;
	C_FXVI_PSRR_DisConnect;
	C_QVMH_DisConnect;
	C_QVML_DisConnect;
	C_ACM_ABUFO_DisConnect;
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	Poweroff_tm_psrr();

	//LDO
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	Poweron_tm_psrr_ldo();
	PSRR_SetDc(5.5);
	set_quc(5.0);
	DUT_SPI_Connect(5.0);
	Cmd_Set_Freq();
	Cmd_TestMode(true);
	Cmd_Dis_WwdFwdErrm();
	Cmd_Masksafe();
	Cmd_Bank1(true);
	Nvm_PreviewFs(-1);
	Cmd_Forceoff(none_off);
	delay_ms(1);
	set_vsx(6.0);
	PSRR_SetDc(PN_Prebk_Output+0.1);
	//set_fb_plus_target_hc(0.1);//target+0.1V
	Cmd_Bank0(true);
	//for (int i = 0; i<64; i++)
	//{
	//	CmdReadData(i, reg[i]);
	//}
	//for (int i = 0; i<64; i++)
	//{
	//	Copy_Array(reg0, reg[i]);
	//	string Parm = "R" + to_string(i);
	//	Ms_LogData(funcindex, Parm, reg0);
	//}

	Cmd_Bank0(true);
	//Cmd_Dis_WwdFwdErrm();
	Cmd_Dis_ERR_WD();
	//Cmd_ReadState(state0);
	Cmd_Go2_Normal();
	Cmd_ReadState(tempd);//2
	Cmd_ReadError(data_1A, data_1E, data_20, data_21, data_22, data_23);
	Cmd_En_Stb(true, true);
	Cmd_En_Trk();
	Cmd_ReadState(reg0);
	Ms_LogData(funcindex, "State1", reg0);
	delay_ms(2);
	//A_VCI.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_ON);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}
	//Cmd_Bank0(true);
	//Cmd_En_Stb(true, true);
	//delay_ms(10);
	delay_ms(2);
	PSRR_Connect();
	PSRR_SetDc(PN_Prebk_Output+1.0);
	//PSRR_SetFreq(freq);
	PSRR_SetAc();
	PSRR_SetGain(3);
	C_FB_CAP_DisConnect;
	//C_QT1_CAP_DisConnect;
	////Cmd_En_Stb(true, true);

	//C_PWRX_QT1_Connect;
	C_QVMH_DUTSO_Connect;
	C_QVMH_ABUFO_Connect;
	C_QVML_GND_Connect;
	C_ACM_ABUFO_Connect;
	delay_ms(2);

	//PSRR_SetDc(8.0);
	//A_FB1.MeasureVI(1000, 10);//acm11`
	//F_QT1.MeasureVI(1000, 10);//fxvi1
	//A_ABUFO.MeasureVI(1000, 1);//acm9

	//PSRR_SetFreq(freq);
	//PSRR_SetAc();
	//PSRR_SetGain(3);
	//C_QST_CAP_DisConnect;
	//delay_ms(2);

	//DUT_SPI_Connect(5.0);
	//Cmd_Set_Freq(10 MHz);
	//A_QST.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//A_QUC.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//A_QCO.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//A_QVR.Set(FI, -1 mA, ACM200_10V, ACM200_100MA, ACM200_RELAY_ON);
	//F_QT1.Set(FI, -1 mA, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//F_QT2.Set(FI, -1 mA, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	//if(PN_Tracker_Num==3){F_QT3.Set(FI, -1 mA, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);}


	//double amp_duto[SITE_NUM];
	//int psrr_point = 0;
	C_PWRX_QT1_Connect;
	C_QT1_CAP_DisConnect;
	delay_ms(2);
	psrr_point = PSRR_MeasAmp2(2048, freq, amp_duto);
	PSRR_CalcRsrr(amp_duto, psrr);
	Ms_LogData(funcindex, "PSRR_QT1", psrr);
	C_QT1_CAP_Connect;
	C_PWRX_QT1_DisConnect;
	delay_ms(2);
	C_PWRX_QT2_Connect;
	C_QT2_CAP_DisConnect;
	delay_ms(2);
	psrr_point = PSRR_MeasAmp2(2048, freq, amp_duto);
	PSRR_CalcRsrr(amp_duto, psrr);
	Ms_LogData(funcindex, "PSRR_QT2", psrr);
	C_QT2_CAP_Connect;
	C_PWRX_QT2_DisConnect;
	delay_ms(2);
	C_PWRX_QT3_Connect;
	C_QT3_CAP_DisConnect;
	delay_ms(2);
	psrr_point = PSRR_MeasAmp2(2048, freq, amp_duto);
	PSRR_CalcRsrr(amp_duto, psrr);
	Ms_LogData(funcindex, "PSRR_QT3", psrr);
	C_QT3_CAP_Connect;
	C_PWRX_QT3_DisConnect;
	delay_ms(2);
	C_PWRX_QVR_Connect;
	C_QVR_CAP_DisConnect;
	delay_ms(2);
	psrr_point = PSRR_MeasAmp2(2048, freq, amp_duto);
	PSRR_CalcRsrr(amp_duto, psrr);
	Ms_LogData(funcindex, "PSRR_QVR", psrr);
	C_QVR_CAP_Connect;
	C_PWRX_QVR_DisConnect;
	delay_ms(2);
	C_PWRX_QCO_Connect;
	C_QCO_CAP_DisConnect;
	delay_ms(2);
	psrr_point = PSRR_MeasAmp2(2048, freq, amp_duto);
	PSRR_CalcRsrr(amp_duto, psrr);
	Ms_LogData(funcindex, "PSRR_QCO", psrr);
	C_QCO_CAP_Connect;
	C_PWRX_QCO_DisConnect;
	delay_ms(2);
	C_PWRX_QUC_Connect;
	C_QUC_CAP_DisConnect;
	delay_ms(2);
	psrr_point = PSRR_MeasAmp2(2048, freq, amp_duto);
	PSRR_CalcRsrr(amp_duto, psrr);
	Ms_LogData(funcindex, "PSRR_QUC", psrr);
	C_QUC_CAP_Connect;
	C_PWRX_QUC_DisConnect;
	delay_ms(2);

	PSRR_Connect();
	PSRR_SetAcOff();
	PSRR_SetDc(0.0);
	PSRR_OutEna(false);
	C_PWRX_DisConnect;
	C_LSI_DUTO_PWRX_DisConnect;
	C_LSI_DUTI_DisConnect;
	C_FXVI_PSRR_DisConnect;
	C_QVMH_DisConnect;
	C_QVML_DisConnect;
	C_ACM_ABUFO_DisConnect;
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_QST.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_QUC.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_QCO.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	A_QVR.Set(FI, 0, ACM200_10V, ACM200_100MA, ACM200_RELAY_OFF);
	F_QT1.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	F_QT2.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
	if(PN_Tracker_Num==3){F_QT3.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);}
	Poweroff_tm_psrr_ldo();
	QVM_DisConnect();
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T70_NVM_Read2(short funcindex, LPCTSTR funclabel)
{
	//{{AFX_STS_PARAM_PROTOTYPES
	//}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here

	//int reg[64][SITE_NUM];
	//int reg0[SITE_NUM];
	int wvr_f[SITE_NUM];
	int wvr[SITE_NUM];
	
	dcm.Connect("SPI_DUT");//Connect all channel's relay
	dcm.InitMCU("SPI_DUT");//Initialize MCU.
	Poweron_tm();
	set_fb(4.5);
	set_quc(4.5);
	DUT_SPI_Connect(4.5);
	Cmd_Set_Freq();
	Cmd_TestMode(true);

	//User Reg
	User_Read(funcindex, true);

	//read otp
	NVM_Read2(wvr_f, wvr);

	//datalog
	Ms_LogData(funcindex, "CRC_OPT_Treg", crc_opt);
	Ms_LogData(funcindex, "CRC_OPT_Read", crc_read);
	Ms_LogData(funcindex, "CRC_OPT_Pass", crc_pass);
	Ms_LogData(funcindex, "Work_Vs_Read_F", wvr_f);
	Ms_LogData(funcindex, "Work_Vs_Read", wvr);
	NVM_Read2_datalog(funcindex);

	Poweroff_tm();

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T80_SupplyIq_Post(short funcindex, LPCTSTR funclabel)
{
	//return true;

	double Iq_LFmin[SITE_NUM];
	double Iq_LFmax[SITE_NUM];
	double Iq_HF[SITE_NUM];
	double Iq_Slp1[SITE_NUM];
	double Iq_Slp2[SITE_NUM];
	double Iq_Stb1[SITE_NUM];
	double Iq_Stb2[SITE_NUM];
	double Iq_Stb3[SITE_NUM];
	double Iq_FS[SITE_NUM];
	double Vsw[SITE_NUM];

	Test_Iq2( false, Iq_LFmin, Iq_LFmax, Iq_HF, Iq_Slp1, Iq_Slp2, Iq_Stb1, Iq_Stb2, Iq_Stb3, Iq_FS, Vsw);
	Copy_Array(iq1_pos,Iq_LFmin);
	Copy_Array(iq2_pos,Iq_LFmax);
	SERIAL iq1_delt[SITE]=iq1_pos[SITE]-iq1_pre[SITE];
	SERIAL iq2_delt[SITE]=iq2_pos[SITE]-iq2_pre[SITE];
	Ms_LogData(funcindex, "VS_IQlfmin_Pos", Iq_LFmin);
	Ms_LogData(funcindex, "VS_IQlfmax_Pos", Iq_LFmax);
	Ms_LogData(funcindex, "VS_IQlfmin_Delt", iq1_delt);
	Ms_LogData(funcindex, "VS_IQlfmax_Delt", iq2_delt);
	
	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T81_Leakage_Post(short funcindex, LPCTSTR funclabel)
{
	double result_leak[PIN_Count][SITE_NUM] = { 0 };

	//leak_test0(result_leak);
	leak_test(result_leak);
	leak_getdata(result_leak, false);
	leak_datalog(funcindex, false);

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T90_P2P_Post(short funcindex, LPCTSTR funclabel)
{
	double result_lvl[PIN_Count][SITE_NUM] = { 0 };

	lvl_test(result_lvl, false);
	lvl_getdata(result_lvl);
	lvl_datalog(funcindex, false);

	efmea.fmea_checking(funcindex);
	return 0;
}

DUT_API int T91_OS_Post(short funcindex, LPCTSTR funclabel)
{
	double result_os[PIN_Count][SITE_NUM] = { 0 };

	conty_test(result_os);
	conty_getdata(result_os);
	conty_datalog(funcindex, false);

	//double results1[SITE_NUM];
	//C_FXVI_ACM_GND_Connect;
	//C_AGS_BSG_PG_POSG_GND_Connect;
	//C_FXVI_SW_Connect;
	//delay_ms(2);
	//F_SW.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//fxvi4.Set(FI, -1 mA, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//delay_ms(2);
	//fxvi4.MeasureVI(20, 10);
	//Get_Result(fxvi4, results1, MVRET);
	//Ms_LogData(funcindex, "OS_SW_VS1", results1);
	//fxvi4.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	//F_SW.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	//fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	//C_FXVI_ACM_GND_DisConnect;
	//C_AGS_BSG_PG_POSG_GND_DisConnect;
	//C_FXVI_SW_DisConnect;
	//delay_ms(2);

	//efmea.fmea_checking(funcindex);
	return 0;
}
