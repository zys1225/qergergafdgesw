#include "stdafx.h"
#include "lsi.h"
#include "spi.h"
#include "cfg.h"
#include "sub.h"

SPI_Class lsi;
extern CBITe cbit;
bool LSI_I2C_EN = false;

int HasLsi[SITE_NUM];

#define Hz  *1.0
#define KHz  *1000.0
#define MHz  *1000000.0

double LSI_VER = 3.0;

int DDS_WAVE = DDS_SIN;
double LSI_GAIN = 0;
bool enable_dc = false;
int DDS_FREQ = 0;

//#define AD8400_VR1	0x00
//#define AD8400_VR2	0x01
//#define AD8400_VR3	0x02
//#define AD8400_VR4	0x03
#define AD8400_ADR	0x00


#define TMP126_TMP		0x00
#define TMP126_STA		0x02
#define TMP126_CFG		0x03
#define TMP126_ALT		0x04

#define ADDR_TCA6408	0x40
#define ADDR_AT24C08	0xA8
#define ADDR_TMP117		0x90

BYTE TCA6408_state[1] = { 0x00};//
BYTE TCA6408_CFG[1] = { 0x00};//
BYTE TCA6408_DFT[1] = { 0x00};//
BYTE TCA6408_DATA[1] = { 0x00};//

BYTE KK_EN_SPI;
BYTE KK_EN_OUT;
BYTE KK_SEL_SPI;
BYTE KK_EN_EXSI;
BYTE KK_GAIN0;
BYTE KK_GAIN1;
BYTE KK_EN_LDO;

#define C_EN_SPI	cbit.SetCbiteOn(KK_EN_SPI)
#define C_DIS_SPI	cbit.SetCbiteOff(KK_EN_SPI)
#define C_DIS_I2C	cbit.SetCbiteOn(KK_EN_SPI)
#define C_EN_I2C	cbit.SetCbiteOff(KK_EN_SPI)
#define C_SPI_DDS	cbit.SetCbiteOff(KK_SEL_SPI)
#define C_SPI_AD8400	cbit.SetCbiteOn(KK_SEL_SPI)
#define C_EN_LDO	cbit.SetCbiteOn(KK_EN_LDO)
#define C_DIS_LDO	cbit.SetCbiteOff(KK_EN_LDO)

#define C_EN_OUT	if(LSI_VER==3.0){C_IO5_H;}else{cbit.SetCbiteOn(KK_EN_OUT);}
#define C_DIS_OUT	if(LSI_VER==3.0){C_IO5_L;}else{cbit.SetCbiteOff(KK_EN_OUT);}
#define C_EN_EXSI	if(LSI_VER==3.0){C_IO3_H;}else{cbit.SetCbiteOn(KK_EN_EXSI);}
#define C_DIS_EXSI	if(LSI_VER==3.0){C_IO3_L;}else{cbit.SetCbiteOff(KK_EN_EXSI);}
#define C_GAIN0		if(LSI_VER==3.0){C_IO1_L;C_IO0_L;}else{cbit.SetCbiteOff(KK_GAIN1);delay_ms(1);cbit.SetCbiteOff(KK_GAIN0);}
#define C_GAIN1		if(LSI_VER==3.0){C_IO1_L;C_IO0_H;}else{cbit.SetCbiteOff(KK_GAIN1);delay_ms(1);cbit.SetCbiteOn(KK_GAIN0);}
#define C_GAIN2		if(LSI_VER==3.0){C_IO1_H;C_IO0_L;}else{cbit.SetCbiteOff(KK_GAIN0);delay_ms(1);cbit.SetCbiteOn(KK_GAIN1);}
#define C_GAIN3		if(LSI_VER==3.0){C_IO1_H;C_IO0_H;}else{cbit.SetCbiteOn(KK_GAIN1);delay_ms(1);cbit.SetCbiteOn(KK_GAIN0);}
#define C_EN_G2		C_IO2_H
#define C_DIS_G2	C_IO2_L
#define C_EN_LOOP	C_IO4_H
#define C_DIS_LOOP	C_IO4_L
#define C_EN_DC		C_IO6_H
#define C_DIS_DC	C_IO6_L
#define C_VLDO_HV	C_IO7_H
#define C_VLDO_LV	C_IO7_L

ULONG Read_Data[SITE_NUM];
int success[SITE_NUM];
int result_i2c[SITE_NUM];
bool i2c_manual = false;

void I2C_read(int SAddress[SITE_NUM], int RegAddress)
{
	char Data_label[2][13] = { "I2C_Address1", "I2C_Address2" };

	BYTE SAddressdata[SITE_NUM], RegAddressdata[SITE_NUM];
	for (USHORT usSiteNo = 0; usSiteNo < SITE_NUM; ++usSiteNo)
	{
		SAddressdata[usSiteNo] = SAddress[usSiteNo];
		RegAddressdata[usSiteNo] = RegAddress;
	}
	for (int ii = 0; ii < 2; ii++)
	{
		dcm.SetWaveDataParam("D_SDI", Data_label[ii], 0, 7);//Set the label to be modified
		for (USHORT usSiteNo = 0; usSiteNo < SITE_NUM; ++usSiteNo)
			dcm.SetSiteWaveData(usSiteNo, SAddressdata);
		dcm.WriteWaveData();
	}
	dcm.SetWaveDataParam("D_SDI", "I2C_reg", 0, 8);//Set the label to be modified
	for (USHORT usSiteNo = 0; usSiteNo < SITE_NUM; ++usSiteNo)
		dcm.SetSiteWaveData(usSiteNo, RegAddressdata);
	dcm.WriteWaveData();

	dcm.RunVectorWithGroup("DCM_I2C", "I2C_Read_S", "I2C_Read_P");//Run Vector
	delay_us(100);

	dcm.SetCapture("D_SDI", "read_Data", DCM_ALLSITE, 0, 8);//Get tLoad Value
	for (USHORT nSiteIndex = 0; nSiteIndex < SITE_NUM; ++nSiteIndex)
	{
		dcm.GetCaptureData("D_SDI", "read_Data", nSiteIndex, 0, 8, Read_Data[nSiteIndex]);
	}

	char ACK_label[4][5] = { "ACK1", "ACK2", "ACK3", "ACK4" };
	ULONG AckCheck[SITE_NUM];
	for (int ii = 0; ii < 4; ii++)
	{
		dcm.SetCapture("D_SDI", ACK_label[ii], DCM_ALLSITE, 0, 1);//Get tLoad Value
		for (USHORT nSiteIndex = 0; nSiteIndex < SITE_NUM; ++nSiteIndex)
		{
			dcm.GetCaptureData("D_SDI", ACK_label[ii], nSiteIndex, 0, 1, AckCheck[nSiteIndex]);
			success[nSiteIndex] += AckCheck[nSiteIndex];
			result_i2c[nSiteIndex] = success[nSiteIndex];
		}
	}
}
void I2C_read(int SAddress, int RegAddress)
{
	int Address[SITE_NUM];
	for (USHORT usSiteNo = 0; usSiteNo < SITE_NUM; ++usSiteNo)
		Address[usSiteNo] = SAddress;
	I2C_read(Address, RegAddress);
	delay_us(100);
}
void I2C_write(int SAddress[SITE_NUM], int RegAddress, int WriteData[SITE_NUM])
{
	char Data_label[3][6] = { "WACK1", "WACK2", "WACK3" };
	ULONG AckCheck[SITE_NUM];
	int AckNum[SITE_NUM] = { 0 };

	BYTE SAddressdata[SITE_NUM][1] = { 0 }, RegAddressdata[SITE_NUM][1] = { 0 }, WRITE_DATA[SITE_NUM][1] = { 0 };
	for (USHORT usSiteNo = 0; usSiteNo < SITE_NUM; ++usSiteNo)
	{
		SAddressdata[usSiteNo][0] = SAddress[usSiteNo];
		RegAddressdata[usSiteNo][0] = RegAddress;
		WRITE_DATA[usSiteNo][0] = WriteData[usSiteNo];
	}
	dcm.SetWaveDataParam("D_SDI", "I2CW_Address", 0, 7);//Set the label to be modified
	for (USHORT usSiteNo = 0; usSiteNo < SITE_NUM; ++usSiteNo)
		dcm.SetSiteWaveData(usSiteNo, SAddressdata[usSiteNo]);
	dcm.WriteWaveData();

	dcm.SetWaveDataParam("D_SDI", "WI2C_reg", 0, 8);//Set the label to be modified
	for (USHORT usSiteNo = 0; usSiteNo < SITE_NUM; ++usSiteNo)
		dcm.SetSiteWaveData(usSiteNo, RegAddressdata[usSiteNo]);
	dcm.WriteWaveData();

	dcm.SetWaveDataParam("D_SDI", "WI2C_Data", 0, 8);//Set the label to be modified
	for (USHORT usSiteNo = 0; usSiteNo < SITE_NUM; ++usSiteNo)
		dcm.SetSiteWaveData(usSiteNo, WRITE_DATA[usSiteNo]);
	dcm.WriteWaveData();

	dcm.RunVectorWithGroup("DCM_I2C", "I2CW_S", "WI2C_P");//Run Vector
	delay_us(100);

	for (int ii = 0; ii < 3; ii++)
	{
		dcm.SetCapture("D_SDI", Data_label[ii], DCM_ALLSITE, 0, 1);//Get tLoad Value
		for (USHORT nSiteIndex = 0; nSiteIndex < SITE_NUM; ++nSiteIndex)
		{
			dcm.GetCaptureData("D_SDI", Data_label[ii], nSiteIndex, 0, 1, AckCheck[nSiteIndex]);
			success[nSiteIndex] += AckCheck[nSiteIndex];
			result_i2c[nSiteIndex] = success[nSiteIndex];
		}
	}
}

void I2C_write(int SAddress, int RegAddress, int WriteData[SITE_NUM])
{
	int Address[SITE_NUM];
	for (int nSiteIndex = 0; nSiteIndex< SITE_NUM; ++nSiteIndex)
	{
		Address[nSiteIndex] = SAddress;
	}
	I2C_write(Address, RegAddress, WriteData);
}
void I2C_write(int SAddress, int RegAddress, int ulWriteData)
{
	int Address[SITE_NUM], WRITE_DATA[SITE_NUM];
	for (int nSiteIndex = 0; nSiteIndex< SITE_NUM; ++nSiteIndex)
	{
		Address[nSiteIndex] = SAddress;
		WRITE_DATA[nSiteIndex] = ulWriteData;
	}
	I2C_write(Address, RegAddress, WRITE_DATA);
}

void LSI_LDO(bool enable)
{
	if(enable){C_EN_LDO;}
	else C_DIS_LDO;
}

void LSI_I2C_Connect(void)
{
	if(i2c_manual)
	{
		double period = 10000;
		double vdd = 3.3;
		double dVIH = 1.0 * vdd;
		double dVIL = 0.0 * vdd;
		double dVOH = 0.7 * vdd;
		double dVOL = 0.3 * vdd;
		dcm.Connect("DCM_I2C");
		dcm.I2CSetPinLevel(dVIH, dVIL, dVOH, dVOL);
		dcm.SetDynamicLoad("DCM_I2C", true, 0.5 mA, 0.5 mA, vdd);
	}
	else
	{
		//dcm.Disconnect("DCM_ALL");
		//if(!LSI_I2C_EN)
		//{
			double period = 10000;
			double vdd = 3.3;
			double dVIH = 1.0 * vdd;
			double dVIL = 0.0 * vdd;
			double dVOH = 0.6 * vdd;
			double dVOL = 0.4 * vdd;
			int status0 = dcm.I2CSet(period,SITE_NUM,DCM_REG8,"S24_1,S24_17,S24_41,S24_57,S24_9,S24_25,S24_33,S24_49","S24_0,S24_16,S24_40,S24_56,S24_8,S24_24,S24_32,S24_48");
			//int status0 = dcm.I2CSet(10000,1,DCM_REG8,"S24_1","S24_0");
			int status1 = dcm.I2CConnect();
			int status2 = dcm.I2CSetPinLevel(dVIH, dVIL, dVOH, dVOL);
			//int status3 = dcm.I2CSetSCLEdge(period*0.0, period*0.5);
			//int status4 = dcm.I2CSetSDAEdge(period*0.25, period*0.75, period*0.25, period*0.25);
			//dcm.I2CSetStopStatus(true);
			LSI_I2C_EN = true;
		//}
	}
	
	C_EN_I2C;
	//C_SPI_DDS;
	delay_ms(1);
}

int N_data(int target) 
{
	//int�������ֵΪ(2^31)-1������Ŀ����ȡ�������ֵΪ2^30
	int MAXIMUM = 1 << 30;
	if (target >= MAXIMUM) {
		return MAXIMUM;
	}
	int temp = target - 1;
	temp |= temp >> 1;
	temp |= temp >> 2;
	temp |= temp >> 4;
	temp |= temp >> 8;
	temp |= temp >> 16;
	return (temp < 0) ? 1 : temp + 1;
}


void Sensor_Connect(void)
{
	C_SNS_Connect;
	//delay_ms(1);
	double vdd = 5.0;
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	int status;
	status = dcm.Connect("SPI_TMP126");//Connect all channel's relay
	status = dcm.InitMCU("SPI_TMP126");//Initialize MCU.
	//status = dcm.SetPinLevel("SPI_TMP126", dVIH, dVIL, 0.5, 0.3);
	status = dcm.SetPinLevel("SPI_TMP126", dVIH, dVIL, dVOH, dVOL);
	//status = dcm.SetDynamicLoad("D_SDO", true, 0.00001, 0.00001, 2.5);
	//status = dcm.SetEdge("SPI_OUT", "TMP126", DCM_DTFT_NRZ, DCM_IO_NRZ, 100, 900, 100, 900, 300);
	//status = dcm.SetVT("SPI_OUT", 2.5, DCM_VT_REALTIME);
}

void Sensor_DisConnect(void)
{
	C_SNS_DisConnect;;
	//delay_ms(1);
	dcm.Disconnect("SPI_TMP126");
}

void Sensor_Start(void)
{
	int Reg = TMP126_CFG;
	int Data = 0x00A0;
	//lsi.tmp126_write_x1(TMP126_CFG, 0x0100);
	//delay_ms(1);
	//lsi.tmp126_write_x1(TMP126_CFG, 0x00A1);
	//lsi.tmp126_write_x1(TMP126_ALT, 0x0000);
	//delay_ms(2);
	lsi.tmp126_write_x1(TMP126_CFG, Data);
}

void Sensor_Stop(void)
{
	int Reg = TMP126_CFG;
	int Data = 0x00A8;
	lsi.tmp126_write_x1(Reg, Data);
	cbitopen(K117, K119, K120, K121);
	delay_ms(1);
}

void Sensor_Read(double Temperature[])
{
	int Temp0[SITE_NUM];
	int Temp1[SITE_NUM];
	int Reg = TMP126_TMP;
	//int Data = 0x00A8;
	lsi.tmp126_read_x1(Reg, Temp0);
	SERIAL
	{
		Temp1[globalsite] = (Temp0[globalsite] >> 2) & 0x3FFF;
		if (Temp1[globalsite] > 0x2FFF){ Temp1[globalsite] = Temp1[globalsite] - 0x3FFF; }
		Temperature[globalsite] = 0.03125 * Temp1[globalsite];
		//Temperature[globalsite] = 0.0078125 * Temp0[globalsite];
		//Temperature[globalsite] = Temp0[globalsite];
	}
}

void Sensor_ReadID(int *ID)
{
	int ID1[SITE_NUM];
	int ID2[SITE_NUM];
	int ID3[SITE_NUM];
	//int ID[SITE_NUM];
	lsi.tmp126_read_x1(0x09, ID1);
	lsi.tmp126_read_x1(0x0A, ID2);
	lsi.tmp126_read_x1(0x0B, ID3);
	lsi.tmp126_read_x1(0x0C, ID);//8486
}

void TCA6408_Init(void)
{
	int status1 = dcm.I2CWriteData(ADDR_TCA6408, 0x03, 1, TCA6408_CFG);//
    delay_ms(2);
	TCA6408_state[0]=0x00;
	int status2 = dcm.I2CWriteData(ADDR_TCA6408, 0x01, 1, TCA6408_DFT);//write same data
	delay_ms(2);
}

void TCA6408_Write(BYTE xbit, BYTE state)
{
	if(state==0){TCA6408_DATA[0] = (TCA6408_state[0] & ~xbit);}
	else{TCA6408_DATA[0] = (TCA6408_state[0] | xbit);}
	TCA6408_state[0]=TCA6408_DATA[0];

	int status1 = dcm.I2CWriteData(ADDR_TCA6408, 0x01, 1, TCA6408_DATA);
}

void EEP_Write(DWORD dwRegAddress, DWORD dwDataArray[])
{
	int status = dcm.I2CWriteData(ADDR_AT24C08, dwRegAddress, 1, dwDataArray);
}

void EEP_Read(DWORD dwRegAddress, DWORD dwDataArray[])
{
	int status = dcm.I2CReadData(ADDR_AT24C08, dwRegAddress, 1);
	SERIAL dwDataArray[SITE] = dcm.I2CGetReadData(SITE, 0);
}

void TMP117_Write(DWORD dwRegAddress, DWORD data)
{
	BYTE wdata[2]={0,0};
	wdata[0]=(data>>8)&0xFF;
	wdata[1]=data&0xFF;
	dcm.I2CWriteData(ADDR_TMP117, dwRegAddress, 2, wdata);
}

void TMP117_Write2(DWORD dwRegAddress, DWORD data)
{
	DWORD wdata[SITE_NUM]={0};
	SERIAL wdata[SITE]=data&0xFFFF;
	dcm.I2CWriteData(ADDR_TMP117, dwRegAddress, 1, wdata);
}

void TMP117_Init(void)
{
	DWORD wdata = 0x0002;
	TMP117_Write(0x01,wdata);
	delay_ms(5);
	TMP117_Write(0x01,0x0000);
	delay_ms(5);
}

void TMP117_Read(DWORD dwRegAddress, DWORD dwDataArray[])
{
	DWORD dwDataArray0[SITE_NUM];
	DWORD dwDataArray1[SITE_NUM];
	dcm.I2CReadData(ADDR_TMP117, dwRegAddress, 2);
	SERIAL 
	{
		dwDataArray0[SITE] = dcm.I2CGetReadData(SITE, 0);
		dwDataArray1[SITE] = dcm.I2CGetReadData(SITE, 1);
		dwDataArray[SITE] = (dwDataArray0[SITE]<<8)+dwDataArray1[SITE];
	}
}

void TMP117_Read2(DWORD dwRegAddress, DWORD dwDataArray[])
{
	DWORD dwDataArray0[SITE_NUM];
	DWORD dwDataArray1[SITE_NUM];
	dcm.I2CReadData(ADDR_TMP117, dwRegAddress, 1);
	SERIAL dwDataArray0[SITE] = dcm.I2CGetReadData(SITE, 0);
	SERIAL dwDataArray[SITE] = dwDataArray0[SITE];
}

void TMP117_Read(double temp[])
{
	DWORD dwDataArray[SITE_NUM];
	int dwDataArray2[SITE_NUM];
	TMP117_Read(0x00, dwDataArray);
	SERIAL
	{
		if(dwDataArray[SITE]>=0x8000){dwDataArray2[SITE]=dwDataArray[SITE]-0x10000;}
		else{dwDataArray2[SITE]=dwDataArray[SITE];}
		temp[SITE] = dwDataArray2[SITE]*7.8125/1000.0;
	}
}

void TMP117_Read2(double temp[])
{
	DWORD dwDataArray[SITE_NUM];
	int dwDataArray2[SITE_NUM];
	TMP117_Read2(0x00, dwDataArray);
	SERIAL
	{
		if(dwDataArray[SITE]>=0x8000){dwDataArray2[SITE]=dwDataArray[SITE]-0x10000;}
		else{dwDataArray2[SITE]=dwDataArray[SITE];}
		temp[SITE] = dwDataArray2[SITE]*7.8125/1000.0;
	}
}

void AD8400_Connect(void)
{
	C_EN_SPI;
	C_SPI_AD8400;
	double vdd = 3.3;
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	int status;
	status = dcm.Connect("SPI_AD8400");//Connect all channel's relay
	status = dcm.InitMCU("SPI_AD8400");//Initialize MCU.
	status = dcm.SetPinLevel("SPI_AD8400", dVIH, dVIL, dVOH, dVOL);
	//delay_ms(2);
	LSI_I2C_EN = false;
}

void AD8400_DisConnect(void)
{
	//C_LSI_SPI_DFT;
	//delay_ms(1);
	dcm.Disconnect("SPI_AD8400");
}

void AD8400_SetResDiv(int div)
{
	if(div>255){div=255;}
	div = div & 0xFF;
	lsi.ad8400_write_x1(AD8400_ADR, div);
}

void AD9833_Connect(void)
{
	C_EN_SPI;
	C_SPI_DDS;
	double vdd = 3.3;
	double dVIH = 1.0 * vdd;
	double dVIL = 0.0 * vdd;
	double dVOH = 0.6 * vdd;
	double dVOL = 0.4 * vdd;
	int status;
	status = dcm.Connect("SPI_DDS");//Connect all channel's relay
	status = dcm.InitMCU("SPI_DDS");//Initialize MCU.
	status = dcm.SetPinLevel("SPI_DDS", dVIH, dVIL, dVOH, dVOL);
	//delay_ms(2);
	LSI_I2C_EN = false;
}

void AD9833_DisConnect(void)
{
	//C_LSI_SPI_DFT;
	//delay_ms(1);
	dcm.Disconnect("SPI_DDS");
}

void AD9833_Init(void)
{
	lsi.dds_write_x1(0x0100);
	DDS_WAVE = DDS_SIN;
}

void AD9833_Set_Wave(int type)
{
	switch (type)
	{
	case 1:
		lsi.dds_write_x1(0x0000);//sin
		DDS_WAVE = DDS_SIN;
		break;
	case 2:
		lsi.dds_write_x1(0x0002);//tri
		DDS_WAVE = DDS_TRI;
		break;
	case 3:
		lsi.dds_write_x1(0x0028);//rec
		DDS_WAVE = DDS_REC;
		break;
	case 4:
		lsi.dds_write_x1(0x0020);//rec/2
		DDS_WAVE = DDS_REC2;
		break;
	default:
		break;
	}
}

int AD9833_Set_Freq(int freq)
{
	if (freq > 12.5 MHz){ freq = 12.5 MHz; }
	int reg1 = 0;
	int reg2 = 0;
	int reg3 = 0;
	int regfreq = 0x4000;
	double frequency = freq*10.73741842;
	int freq_tmp1 = int(frequency) & 0x00003FFF;
	int freq_tmp2 = int(frequency) & 0x0FFFC000;
	int freq_tmp3 = freq_tmp2 >> 14;

	if (DDS_WAVE == DDS_SIN){ reg1 = 0x2000; }
	if (DDS_WAVE == DDS_TRI){ reg1 = 0x2002; }
	if (DDS_WAVE == DDS_REC){ reg1 = 0x2028; }
	if (DDS_WAVE == DDS_REC2){ reg1 = 0x2020; }
	reg2 = regfreq | freq_tmp1;
	reg3 = regfreq | freq_tmp3;

	lsi.dds_write_x1(reg1);
	lsi.dds_write_x1(reg2);
	lsi.dds_write_x1(reg3);
	DDS_FREQ = freq;
	return freq;
}

void AD9833_Set_Freq(int freq[])
{
	SERIAL if (freq[SITE] > 12.5 MHz){ freq[SITE] = 12.5 MHz; }
	int reg1[SITE_NUM];
	int reg2[SITE_NUM];
	int reg3[SITE_NUM];
	int regfreq = 0x4000;
	double frequency[SITE_NUM];
	int freq_tmp1[SITE_NUM];
	int freq_tmp2[SITE_NUM];
	int freq_tmp3[SITE_NUM];

	SERIAL frequency[SITE] = freq[SITE]*10.73741842;
	SERIAL freq_tmp1[SITE] = int(frequency[SITE]) & 0x00003FFF;
	SERIAL freq_tmp2[SITE] = int(frequency[SITE]) & 0x0FFFC000;
	SERIAL freq_tmp3[SITE] = freq_tmp2[SITE] >> 14;

	SERIAL if (DDS_WAVE == DDS_SIN){ reg1[SITE] = 0x2000; }
	SERIAL if (DDS_WAVE == DDS_TRI){ reg1[SITE] = 0x2002; }
	SERIAL if (DDS_WAVE == DDS_REC){ reg1[SITE] = 0x2028; }
	SERIAL if (DDS_WAVE == DDS_REC2){ reg1[SITE] = 0x2020; }
	SERIAL reg2[SITE] = regfreq | freq_tmp1[SITE];
	SERIAL reg3[SITE] = regfreq | freq_tmp3[SITE];

	lsi.dds_write_x1(reg1);
	lsi.dds_write_x1(reg2);
	lsi.dds_write_x1(reg3);
}

void Amp_SetGain(int gain)
{
	if (LSI_VER == 2.5)
	{
		switch (gain)
		{
		case 0://2
			C_GAIN0;
			LSI_GAIN = 2;
			break;
		case 1://5
			C_GAIN1;
			LSI_GAIN = 5;
			break;
		case 2://10
			C_GAIN2;
			LSI_GAIN = 10;
			break;
		case 3://40
			C_GAIN3;
			LSI_GAIN = 40;
			break;
		default:
			C_GAIN0;
			break;
		}
	}
	if (LSI_VER == 2.6)
	{
		switch (gain)
		{
		case 0://6.1
			C_GAIN0;
			LSI_GAIN = 5.7;
			break;
		case 1://11
			C_GAIN1;
			LSI_GAIN = 10.2;
			break;
		case 2://61
			C_GAIN2;
			LSI_GAIN = 48;
			break;
		case 3://101
			C_GAIN3;
			LSI_GAIN = 83;
			break;
		default:
			C_GAIN0;
			break;
		}
	}
	if (LSI_VER == 3.0)
	{
		LSI_I2C_Connect();
		switch (gain)
		{
		case 0://6.1
			C_GAIN0;
			LSI_GAIN = 6.0;
			break;
		case 1://11
			C_GAIN1;
			LSI_GAIN = 10.8;
			break;
		case 2://61
			C_GAIN2;
			LSI_GAIN = 50.9;
			break;
		case 3://101
			C_GAIN3;
			LSI_GAIN = 83.3;
			break;
		default:
			C_GAIN0;
			break;
		}
	}
}

void LSI_Connect(void)
{
	C_LSI_Connect;
	LSI_I2C_EN = false;
	//C_EN_SPI;
	delay_ms(1);
}

void LSI_DisConnect(void)
{
	//C_DIS_SPI;
	C_LSI_DisConnect;
	C_DIS_SPI;
	LSI_I2C_EN = false;
	delay_ms(1);
}

void LSI_DC(bool on)
{
	if(LSI_VER >= 3.0)
	{
		if(on){C_EN_DC;enable_dc=true;}
		else{C_DIS_DC;enable_dc=false;}
	}
}

void LSI_Read_Temp(double temperature[])
{
	DWORD wdata = 0x0002;
	DWORD id[SITE_NUM];
	DWORD temp[SITE_NUM];
	DWORD reg[16][SITE_NUM];
	LSI_Connect();
	LSI_I2C_Connect();
	delay_ms(1);
	//TMP117_Write(0x01,wdata);
	//delay_ms(5);
	//TMP117_Write(0x01,0x0000);
	//delay_ms(5);
	//for(int i=0;i<9;i++){TMP117_Read(i,reg[i]);}
	//TMP117_Read(0x0F,reg[9]);
	//delay_ms(20);
	//TMP117_Read(0x0F,id);
	//TMP117_Read(0x01,temp);
	TMP117_Read(temperature);
}

void LSI_Read_EEP(int data[])
{
	DWORD wdata[SITE_NUM]={1,2,3,4,5,6,7,8};
	DWORD dwDataArray[SITE_NUM];
	LSI_Connect();
	LSI_I2C_Connect();
	delay_ms(1);
	//EEP_Write(0x01, wdata);
	delay_ms(1);
	EEP_Read(0x01, dwDataArray);
	SERIAL data[SITE]=dwDataArray[SITE];
}

void LSI_Init(BYTE EN_SPI, BYTE EN_OUT, BYTE SEL_SPI, BYTE EN_EXSI, BYTE GAIN0, BYTE GAIN1, BYTE EN_LDO)
{
	KK_EN_SPI = EN_SPI;
	KK_EN_OUT = EN_OUT;
	KK_SEL_SPI = SEL_SPI;
	KK_EN_EXSI = EN_EXSI;
	KK_GAIN0 = GAIN0;
	KK_GAIN1 = GAIN1;
	KK_EN_LDO = EN_LDO;

	//LSI_VER = 2.5;
	//LSI_VER = 2.6;
	int fx = 1 KHz;
	LSI_Connect();
	AD8400_Connect();
	AD8400_SetResDiv(0);
	AD8400_DisConnect();
	AD9833_Connect();
	AD9833_Init();
	delay_ms(1);
	LSI_I2C_Connect();
	delay_ms(1);
	TCA6408_Init();
	TMP117_Init();
	delay_ms(1);
	Amp_SetGain(LSI_GAIN_2);delay_ms(1);
	C_DIS_OUT;delay_ms(1);
	LSI_DC(true);delay_ms(1);
	C_VLDO_LV;delay_ms(1);
}

void LSI_Measure(QVMe qvm_cap, QVMe_HADC_VRANG v_range, unsigned int size, unsigned int fs, unsigned int fx, double amp[])
{
	double f0[SITE_NUM];
	double f1[SITE_NUM];
	double f2[SITE_NUM];
	double deltf = fs / size;
	int N = fx / deltf;
	if (fs > 10000000){ fs = 10000000; }
	if (size > 32768){ size = 32768; }
	if (size < 64){ size = 64; }
	double interval = 1000000.0 / fs;
	double result_t[SITE_NUM][8192];
	double result_f[SITE_NUM][8192];
	qvm_cap.MeasureHADC(size, interval, v_range, MEAS_NORMAL);
	for (int i = 0; i < SITE_NUM; i++)
	{
		qvm_cap.BlockRead(i, 0, size, result_t[i], QVMe_SAMPLE_DATA);
	}
	qvm_cap.MeasureHADC(size, interval, v_range, MEAS_NORMAL);
	qvm_cap.StartFFT(QVMe_DIRECT_FFT);
	for (int i = 0; i < SITE_NUM; i++)
	{
		f0[i] = qvm_cap.GetFFTResult(i, 0, TOTAL_HARM, 2);
		f1[i] = qvm_cap.GetFFTResult(i, 1, TOTAL_HARM, 2);
		f2[i] = qvm_cap.GetFFTResult(i, 2, TOTAL_HARM, 2);
	}
	for (int i = 0; i < SITE_NUM; i++)
	{
		qvm_cap.BlockRead(i, 0, size, result_f[i], QVMe_FFT_DATA);
		amp[i] = result_f[i][N];
		amp[i] = sqrt(amp[i]);
	}	
	float tmp;
	int site = 0;
	if (1)
	{
		FILE *fp2;
		fp2 = fopen("tdata.csv", "wb");
		for (unsigned int j = 0; j < size; j++)
		{
			tmp = result_t[site][j];
			fprintf(fp2, "%3.6f\n", tmp);
		}
		fclose(fp2);
		fp2 = fopen("fdata.csv", "wb");
		for (unsigned int j = 0; j < size; j++)
		{
			tmp = result_f[site][j];
			fprintf(fp2, "%3.6f\n", tmp);
		}
		fclose(fp2);
	}
}

void LSI_Calc_Ratio(double SinIn[], double SinOut[], double Gain, double Ratio[], double DB[])
{
	SERIAL Ratio[SITE] = (SinIn[SITE] / SinOut[SITE]) * Gain;
	SERIAL DB[SITE] = 20 * log10(Ratio[SITE]);
}




void Check_LSI_Exist(int has_lsi[], double res[])
{
	double current = 1 mA;
	double volt[SITE_NUM];
	double resistor[SITE_NUM];
	cbitclose(K10, K16, K100);
	delay_ms(2);
	fpvi0.Set(FI, current, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	delay_ms(1);
	fpvi0.MeasureVI(50, 10);
	SERIAL volt[SITE] = fpvi0.GetMeasResult(SITE, MVRET);
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_ON);
	delay_ms(1);
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_OFF);
	cbitopen(K10, K16, K100);
	delay_ms(1);
	SERIAL
	{
		res[SITE] = volt[SITE] / current;
		if (volt[SITE] > 0.5){ has_lsi[SITE] = 0; }
		else { has_lsi[SITE] = 1; }
		HasLsi[SITE] = has_lsi[SITE];
	}
}

void Check_DFI_Gain(double Gain[])
{
	double rsh[SITE_NUM];
	double rsl[SITE_NUM];
	double rs[SITE_NUM];
	double volt[SITE_NUM];
	double resistor[SITE_NUM];
	cbitclose(K10, K16, K100);
	cbitclose(K133_134);
	cbitclose(K93, K95);
	C_RSL_PD_Connect;
	delay_ms(2);
	double Ival = 10.0 mA;
	F_RSH.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_SENSE_ON);
	fpvi0.Set(FI, Ival, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON, 3);
	delay_ms(2);
	//fpvi0.MeasureVI(30, 10);
	//SERIAL volt[SITE] = fpvi0.GetMeasResult(SITE, MVRET);
	C_FXVI_RSH_Connect;
	delay_ms(2);
	F_RSH.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_SENSE_ON);
	delay_ms(2);
	F_RSH.MeasureVI(50, 10);
	SERIAL rsh[SITE] = F_RSH.GetMeasResult(SITE, MVRET);
	C_FXVI_RSH_DisConnect;
	delay_ms(2);
	C_FXVI_RSL_Connect;
	delay_ms(2);
	F_RSL.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_SENSE_ON);
	delay_ms(2);
	F_RSL.MeasureVI(50, 10);
	SERIAL rsl[SITE] = F_RSL.GetMeasResult(SITE, MVRET);
	SERIAL rs[SITE] = rsh[SITE] - rsl[SITE];
	C_FXVI_RSL_DisConnect;
	delay_ms(1);
	fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(1);
	fpvi0.Set(FV, 0, FPVIe_2V, FPVIe_10MA, FPVIe_RELAY_OFF);
	F_RSL.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	cbitopen(K10, K16, K100);
	cbitopen(K133_134);
	cbitopen(K93, K95);
	C_RSL_PD_DisConnect;
	delay_ms(1);
	SERIAL
	{
		//resistor[SITE] = volt[SITE] / Ival;
		Gain[SITE] = rs[SITE] / Ival;
		if (HasLsi[SITE] == 0){ Gain[SITE] = -99; }
	}
}

void Check_LDO_Vout(double voltage[])
{
	double temperature[SITE_NUM];
	DWORD dwDataArray1[SITE_NUM];
	DWORD dwDataArray2[SITE_NUM];
	DWORD dwData[1]={2};
	LSI_Connect();
	LSI_I2C_Connect();
	delay_ms(1);
	//TMP117_Read(0x01, dwDataArray1);
	//TMP117_Read(0x0F, dwDataArray2);//279
	//TMP117_Read(temperature);

	//EEP_Write(0x00,1,dwData);
	//EEP_Read(0x00,dwDataArray1);
	//EEP_Read(0x01,dwDataArray2);
	//EEP_DisConnect();

	//C_VLDO_HV;
	//TCA6408_DisConnect();
	cbitopen(K93, K95);
	acm9.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_SENSE_ON);
	delay_ms(1);
	C_QVMH_LDO_Connect;
	C_QVMH_ABUFO_Connect;
	C_ACM_ABUFO_Connect;
	LSI_LDO(true);
	delay_ms(5);
	acm9.MeasureVI(30, 10); //ACM200_1 measurement 
	Get_Result(acm9, voltage, MVRET, AVERAGE_RESULT);
	LSI_LDO(false);
	delay_ms(1);
	C_VLDO_LV;
	C_QVMH_DisConnect;
	C_ACM_ABUFO_DisConnect;
	acm9.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	SERIAL if (HasLsi[SITE] == 0){ voltage[SITE] = -99; }
	
	//double result0[SITE_NUM];
	//double result1[SITE_NUM];
	//C_QVMH_LDO_Connect;
	//C_QVML_GND_Connect;
	//C_LSI_LDO_Enable;
	//C_QVM_1357;
	//delay_ms(2);
	//qvm.MeasureLADC(20, 10, QVMe_LADC_20V, QVMe_LADC_400KHz, MEAS_NORMAL);
	//QVM_GetResult1357(result1);
	//C_QVM_2468;
	//delay_ms(2);
	//qvm.MeasureLADC(20, 10, QVMe_LADC_20V, QVMe_LADC_400KHz, MEAS_NORMAL);
	//QVM_GetResult2468(result1);
	//C_QVM_DisConnect;
	//C_LSI_LDO_Disable;
	//delay_ms(2);
	//SERIAL voltage[SITE] = result1[SITE];
	//C_QVM_1357;
	//SERIAL if (HasLsi[SITE] == 0){ voltage[SITE] = -99; }
}

void Check_LDO_Vout2(double voltage[])
{
	double temperature[SITE_NUM];
	DWORD dwDataArray1[SITE_NUM];
	DWORD dwDataArray2[SITE_NUM];
	DWORD dwData[1]={2};
	double result0[SITE_NUM];
	double result1[SITE_NUM];
	LSI_Connect();
	LSI_I2C_Connect();
	delay_ms(1);

	QVM_Connect();

	cbitopen(K93, K95);
	//cbitclose(K92, K94);
	//acm9.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_SENSE_ON);
	delay_ms(1);
	C_QVMH_LDO_Connect;
	C_QVML_GND_Connect;
	//C_QVMH_ABUFO_Connect;
	//C_ACM_ABUFO_Connect;
	LSI_LDO(true);
	delay_ms(5);
	QVM_Measure(20, 10, QVMe_LADC_10V, voltage);
	LSI_LDO(false);
	delay_ms(1);
	C_VLDO_LV;
	C_QVM_DisConnect;
	//C_ACM_ABUFO_DisConnect;
	//acm9.Set(FV, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	SERIAL if (HasLsi[SITE] == 0){ voltage[SITE] = -99; }
	//cbitopen(K92, K94);
	QVM_DisConnect();
}

void Check_DDS_DIV(double clk[], double vmax[], double vmin[])
{
	int fx = 100 KHz;
	int div = 1;
	A_ABUFO.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_SENSE_ON);
	cbitclose(K93, K95);
	C_QVMH_DRVSI_Connect;
	C_QVMH_ABUFO_Connect;
	C_ACM_ABUFO_Connect;
	C_DBUF_Bypass;
	C_DBUFI_DDSO;
	C_DCM_DBUFO_Connect;
	measure_freq_duty_set("DCM5", 3.0);
	dcm.SetTMUParam("DCM5", DCM_POS, 100, 0);
	LSI_Connect();
	AD9833_Connect();
	AD9833_Init();
	AD9833_Set_Wave(DDS_REC);//Max 3V
	AD9833_Set_Freq(fx);
	delay_ms(5);
	measure_freq_get("DCM5", clk);
	SERIAL clk[SITE] = clk[SITE];
	AD8400_Connect();
	AD8400_SetResDiv(0);
	delay_ms(2);
	A_ABUFO.MeasureVI(1000, 1);
	Get_Result(A_ABUFO, vmin, MVRET, MAX_RESULT);
	AD8400_SetResDiv(255);
	delay_ms(5);
	A_ABUFO.MeasureVI(1000, 1);
	Get_Result(A_ABUFO, vmax, MVRET, MAX_RESULT);
	AD8400_DisConnect();
	AD9833_Connect();
	AD9833_Init();
	AD9833_DisConnect();
	LSI_DisConnect();
	C_DCM_DBUFO_DisConnect;
	C_DBUFI_DisConnect;
	C_DBUF_Bypass;
	C_QVM_DisConnect;
	C_ACM_ABUFO_DisConnect;
	cbitopen(K93, K95);
	A_ABUFO.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	SERIAL if (HasLsi[SITE] == 0){ vmin[SITE] = -99; }
	SERIAL if (HasLsi[SITE] == 0){ vmax[SITE] = -99; }
	SERIAL if (HasLsi[SITE] == 0){ clk[SITE] = -99; }
}

void Check_LSI_Gain(double gain1[], double gain2[], double gain3[], double gain4[])
{
	//2/5/10/40
	double min[SITE_NUM];
	double max[SITE_NUM];
	double v0[SITE_NUM];
	cbitclose(K93, K95);
	C_LSI_DUTO_PWRX_Connect;
	C_QTMUB_PWRX_Connect;
	C_QTMUB_DBUFO_Connect;
	C_ACM_DBUFO_Connect;

	C_QVMH_DUTSO_Connect;
	C_QVMH_ABUFO_Connect;
	C_ACM_ABUFO_Connect;
	delay_ms(2);
	Amp_SetGain(LSI_GAIN_2);
	delay_ms(2);

	int AD_SAMPLE = 500;//sampling points 
	int sam = 100; //1KHz
	int interval = 10; // interval time of AWG pattern, unit is uS , min 0.02us
	double awg_pattern[1000] = { 0.0 };

	STSAWGCreateSineData(&awg_pattern[0], sam, 1, 0.1, 0, 0);
	acm10.AwgLoader("Sin_AWG", FV, ACM200_3p6V, ACM200_100MA, awg_pattern, sam);
	acm10.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_ON);
	acm10.AwgRun("Sin_AWG ", 0, (sam - 1), 0, interval, AWG_LOOP);
	delay_ms(1);
	acm9.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_SENSE_ON);
	delay_ms(2);
	acm9.MeasureVI(AD_SAMPLE, 20); //ACM200_1 measurement 
	delay_us(1);
	Get_Result(acm9, min, MVRET, MIN_RESULT);
	Get_Result(acm9, max, MVRET, MAX_RESULT);
	SERIAL gain1[SITE] = (max[SITE] - min[SITE]) / 0.1;
	Amp_SetGain(LSI_GAIN_5);
	delay_ms(2);
	acm9.MeasureVI(AD_SAMPLE, 20); //ACM200_1 measurement 
	delay_us(1);
	Get_Result(acm9, min, MVRET, MIN_RESULT);
	Get_Result(acm9, max, MVRET, MAX_RESULT);
	SERIAL gain2[SITE] = (max[SITE] - min[SITE]) / 0.1;
	Amp_SetGain(LSI_GAIN_10);
	delay_ms(2);
	acm9.MeasureVI(AD_SAMPLE, 20); //ACM200_1 measurement 
	delay_us(1);
	Get_Result(acm9, min, MVRET, MIN_RESULT);
	Get_Result(acm9, max, MVRET, MAX_RESULT);
	SERIAL gain3[SITE] = (max[SITE] - min[SITE]) / 0.1;
	Amp_SetGain(LSI_GAIN_40);
	delay_ms(2);
	acm9.MeasureVI(AD_SAMPLE, 20); //ACM200_1 measurement 
	delay_us(1);
	Get_Result(acm9, min, MVRET, MIN_RESULT);
	Get_Result(acm9, max, MVRET, MAX_RESULT);
	SERIAL gain4[SITE] = (max[SITE] - min[SITE]) / 0.1;

	acm9.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm10.AwgStop();//stop running AWG waveform of ACM200_0 
	acm10.Set(FV, 0, ACM200_3p6V, ACM200_100MA, ACM200_RELAY_OFF);
	Amp_SetGain(LSI_GAIN_2);
	C_LSI_DUTO_PWRX_DisConnect;
	C_QTMUB_DisConnect;
	C_ACM_DBUFO_DisConnect;

	C_QVMH_DisConnect;
	C_ACM_ABUFO_DisConnect;
	cbitopen(K93, K95);
	delay_ms(1);
	SERIAL if (HasLsi[SITE] == 0){ gain1[SITE] = -99; }
	SERIAL if (HasLsi[SITE] == 0){ gain2[SITE] = -99; }
	SERIAL if (HasLsi[SITE] == 0){ gain3[SITE] = -99; }
	SERIAL if (HasLsi[SITE] == 0){ gain4[SITE] = -99; }
}

void Check_LSI_DutIn(double dc, double ampdrvi[], double ampdrvac[], double ampdrvdc[], double ampdutsi[], double ampdutac[], double ampdutdc[])
{
	//DC = 0V, SinV	0.55		1.38	2.77	2.77	1.58
	//DC = 1V, Sin0	0.00		0.00	0.00	0.00	1.00

	//DC = 1V, SinV	0.55		1.38	2.72	2.77	2.58, has dut,1KHz
	//DC = 1V, SinV	0.55		1.38	2.76	2.77	2.58, has dut,10KHz
	//DC = 1V, SinV	0.50		1.10	2.55	2.56	2.58, has dut,100KHz
	//has 1.58V default DC
	double min[SITE_NUM];
	double max[SITE_NUM];
	double duto[SITE_NUM];
	//double dcin[SITE_NUM];
	//double ampdrvi[SITE_NUM];
	//double ampdrvo[SITE_NUM];
	//double ampduti[SITE_NUM];
	//double ampdutsi[SITE_NUM];
	int fx = 10 KHz;
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_SENSE_ON);
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_SENSE_ON);
	F_VST.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_SENSE_FANOUT_ON);
	F_LSI.Set(FI, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	cbitclose(K93, K95);
	C_FXVI_PSRR_Connect;
	C_QVMH_DRVSI_Connect;
	C_QVMH_ABUFO_Connect;
	C_ACM_ABUFO_Connect;

	C_QTMUB_PWRX_Connect;
	C_QTMUB_DBUFO_Connect;
	C_PWRX_VST_Connect;
	C_ACM_DBUFO_Connect;

	C_LSI_DUTI_VST_Connect;
	LSI_I2C_Connect();
	LSI_DC(true);;
	C_EN_OUT;

	delay_ms(2);
	if (dc < 2.0){ dc = 2.0; }
	F_LSI.Set(FV, dc-1.14, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	LSI_Connect();
	AD9833_Connect();
	AD9833_Init();
	AD9833_Set_Wave(DDS_SIN);
	AD9833_Set_Freq(fx);
	AD8400_Connect();
	//255-2.77
	//184-2.00
	AD8400_SetResDiv(184);
	delay_ms(2);
	A_ABUFO.MeasureVI(1000, 1);
	Get_Result(A_ABUFO, min, MVRET, MIN_RESULT);
	Get_Result(A_ABUFO, max, MVRET, MAX_RESULT);
	SERIAL ampdrvi[SITE] = max[SITE] - min[SITE];
	C_QVM_DisConnect;
	delay_ms(2);
	C_QVMH_DRVSO_Connect;
	C_QVMH_ABUFO_Connect;
	delay_ms(2);
	A_ABUFO.MeasureVI(1000, 1);
	Get_Result(A_ABUFO, ampdrvdc, MVRET, AVERAGE_RESULT);
	Get_Result(A_ABUFO, min, MVRET, MIN_RESULT);
	Get_Result(A_ABUFO, max, MVRET, MAX_RESULT);
	SERIAL ampdrvac[SITE] = max[SITE] - min[SITE];
	C_QVM_DisConnect;
	delay_ms(2);
	C_QVMH_DUTSI_Connect;
	C_QVMH_ABUFO_Connect;
	delay_ms(2);
	A_ABUFO.MeasureVI(1000, 1);
	Get_Result(A_ABUFO, min, MVRET, MIN_RESULT);
	Get_Result(A_ABUFO, max, MVRET, MAX_RESULT);
	SERIAL ampdutsi[SITE] = max[SITE] - min[SITE];
	A_DBUFO.MeasureVI(1000, 1);
	Get_Result(A_DBUFO, ampdutdc, MVRET, AVERAGE_RESULT);
	Get_Result(A_DBUFO, min, MVRET, MIN_RESULT);
	Get_Result(A_DBUFO, max, MVRET, MAX_RESULT);
	SERIAL ampdutac[SITE] = max[SITE] - min[SITE];
	AD8400_DisConnect();

	C_QTMUB_DisConnect;
	C_PWRX_VST_DisConnect;
	C_ACM_DBUFO_DisConnect;

	C_QVM_DisConnect;
	C_ACM_ABUFO_DisConnect;
	C_FXVI_PSRR_DisConnect;
	C_LSI_DUTI_VST_DisConnect;
	C_DIS_OUT;
	cbitopen(K93, K95);
	delay_ms(1);
	A_ABUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	A_DBUFO.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_OFF);
	F_VST.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	F_LSI.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	//SERIAL if (HasLsi[SITE] == 0){ ampdrvi[SITE] = -99; }
	LSI_DisConnect();
}

void PSRR_Test_ACM(double psrr[])
{
	int Datacount = 0;
	int AD_SAMPLE = 500;//sampling points 
	double sum[4] = { 0.0 };
	double temp[4] = { 0.0 }, temp2[4] = { 0.0 };
	int sam = 830; //data size of AWG pattern 
	int interval = 10; // interval time of AWG pattern, unit is uS 
	double awg_pattern[1000] = { 0.0 };
	double data[5000] = { 0.0 };
	double result[4] = { 0.0 };

	STSAWGCreateSineData(&awg_pattern[0], sam, 1, 0.66, 3.3, 0);
	// set waveform data array for Sin_AWG, Vpp=0.66, DC=3.3 

	acm10.AwgLoader("Sin_AWG", FV, ACM200_10V, ACM200_200MA, awg_pattern, sam);
	// pattern named as ��Sin_AWG, FV mode 

	acm10.Set(FV, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_ON);
	// Call ��Set()�� to make sure that the mode and ranges are exactly the same with ��Sin_AWG�� of its ��AwgLoader()��

	acm10.AwgRun("Sin_AWG ", 0, (sam - 1), 0, interval, AWG_LOOP);
	//Select pattern of ��Sin_AWG��, start step=0, stop=sam-1; loop=0; interval time=10uS,loop mode 
	delay_ms(1);

	acm9.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_SENSE_ON);
	//Vout FI mode, prepares to measure 
	delay_ms(2);
	acm9.MeasureVI(AD_SAMPLE, 20); //ACM200_1 measurement 

	SERIAL
	{
		for (Datacount = 0; Datacount < AD_SAMPLE; Datacount++)
		{
			data[Datacount] = acm9.GetMeasResult(SITE, MVRET, Datacount);
			//ACM200_1acquires every voltage values from 500 sampling points 
			result[SITE] = acm9.GetMeasResult(SITE, MVRET);
			//ACM200_1acquiresaverage voltage of 500 sampling points 
			sum[SITE] += (data[Datacount] - result[SITE])*(data[Datacount] - result[SITE]);
		}
		temp[SITE] = (sqrt(sum[SITE] / AD_SAMPLE))*2.828;
		//calculate peak to peak value of sine wave received from output 
		temp2[SITE] = -20 * log10((temp[SITE] + 1e-12) / 0.66);
		//calculate PSRR 
		sum[SITE] = 0;
	}

	SERIAL psrr[SITE] = temp2[SITE];

	acm9.Set(FI, 0, ACM200_40V, ACM200_1MA, ACM200_RELAY_OFF);
	acm10.AwgStop();//stop running AWG waveform of ACM200_0 
	acm10.Set(FV, 0, ACM200_10V, ACM200_200MA, ACM200_RELAY_OFF);
}

void PSRR_Test_LSI(ACM200 &cap, double ref, double psrr[])
{
	int AD_SAMPLE = 500;//sampling points 
	double sum[SITE_NUM] = { 0.0 };
	double temp[SITE_NUM] = { 0.0 }, temp2[4] = { 0.0 };
	int sam = 830; //data size of AWG pattern 
	double data[5000] = { 0.0 };
	double avg[SITE_NUM] = { 0.0 };

	//Initial
	int fx = 10 KHz;
	LSI_Connect();
	AD9833_Connect();
	AD9833_Init();

	//Setup dut in signal
	AD9833_Set_Wave(DDS_SIN);
	AD9833_Set_Freq(fx);
	delay_ms(2);
	AD8400_Connect();
	AD8400_SetResDiv(255);
	AD8400_DisConnect();
	//Measurement
	Amp_SetGain(LSI_GAIN_5);
	cap.Set(FI, 0, ACM200_10V, ACM200_1MA, ACM200_RELAY_SENSE_ON);
	
	//Vout FI mode, prepares to measure 
	delay_ms(2);
	cap.MeasureVI(AD_SAMPLE, 20); //ACM200_1 measurement 

	SERIAL
	{
		for (int Datacount = 0; Datacount < AD_SAMPLE; Datacount++)
		{
			data[Datacount] = cap.GetMeasResult(SITE, MVRET, Datacount);
			avg[SITE] = cap.GetMeasResult(SITE, MVRET);
			sum[SITE] += (data[Datacount] - avg[SITE])*(data[Datacount] - avg[SITE]);
		}
		temp[SITE] = (sqrt(sum[SITE] / AD_SAMPLE))*2.828;
		//calculate peak to peak value of sine wave received from output 
		temp2[SITE] = -20 * log10((temp[SITE] + 1e-12) / ref);
		//calculate PSRR 
		sum[SITE] = 0;
	}

	SERIAL psrr[SITE] = temp2[SITE];

	//Close
	AD9833_Connect();
	AD9833_Init();
	AD9833_DisConnect();
	LSI_DisConnect();
	cap.Set(FI, 0, ACM200_40V, ACM200_1MA, ACM200_RELAY_OFF);
}

void DDS_Connect(void)
{
	LSI_Connect();
	AD9833_Connect();
}

void DDS_DisConnect(void)
{
	AD9833_DisConnect();
	LSI_DisConnect();
}

void DDS_Initial(void)
{
	AD9833_Init();
	AD9833_Set_Wave(DDS_REC);
}

void DDS_SetFreq(int freq)
{
	AD9833_Set_Freq(freq);
}

void DDS_SetFreq(int freq[])
{
	AD9833_Set_Freq(freq);
}


//
//
void PSRR_OutEna(bool en)
{
	if (en) { C_EN_OUT; }
	else { C_DIS_OUT; }
}

void PSRR_SetDc(double voltage)
{
	if ((LSI_VER >= 3.0) && (enable_dc))
	{
		F_LSI.Set(FV, voltage, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	}
	else
	{
		if (voltage < 1.5){ voltage = 1.5; }
		F_LSI.Set(FV, voltage - 1.14, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	}
}

void PSRR_SetDcOff()
{
	F_LSI.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	F_LSI.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);
}

void PSRR_SetAc(void)
{
	AD8400_Connect();
	//255-2.77
	//184-2.00
	AD8400_SetResDiv(184);
	AD8400_DisConnect();
}

void PSRR_SetAcOff()
{
	AD8400_Connect();
	AD8400_SetResDiv(0);
	AD8400_DisConnect();
}

double PSRR_SetFreq(int freq)
{
	//1k,1000us
	//10k,100us
	//100k,10us
	//1M,1us
	//10M,0.1us
	double period = 0;
	AD9833_Set_Freq(freq);
	period = 1000000.0 / freq;
	return period;//us
}

void PSRR_SetGain(int gain)
{
	Amp_SetGain(gain);
}

int PSRR_MeasAmp(int size, int fx, double amp[])
{
	int size_data = size;
	if (size_data > 32768){ size_data = 32768; }
	if (size_data < 64){ size_data = 64; }
	double sin_period = 1000000.0 / fx;//us
	double sample_time = sin_period * 5;
	double interval = sample_time / size_data;
	int x = 0;
	if (interval < 0.1)
	{ 
		interval = 0.1; 
		x = sample_time / interval;
		if (x < 256){ x = 256; }
		x = N_data(x);
		size_data = x;
		interval = sample_time / size_data;
		if (interval < 0.1) { interval = 0.1; }
	}
	double fs = 1000000.0 / interval;
	double deltf = fs / size_data;
	int N = fx / deltf;
	int Cycle = (size_data * fx) / fs;
	int size_fft = size_data / 2;

	double f0[SITE_NUM];
	double f1[SITE_NUM];
	double f2[SITE_NUM];
	double amp0[SITE_NUM];
	double result_t[SITE_NUM][8192];
	double result_f[SITE_NUM][8192];

	C_QVM_1357;
	delay_ms(3);
	qvm0.MeasureHADC(size_data, interval, QVMe_HADC_2V, MEAS_NORMAL); qvm1.MeasureHADC(size_data, interval, QVMe_HADC_2V, MEAS_NORMAL); qvm2.MeasureHADC(size_data, interval, QVMe_HADC_2V, MEAS_NORMAL); qvm3.MeasureHADC(size_data, interval, QVMe_HADC_2V, MEAS_NORMAL);
	qvm0.BlockRead(0, 0, size_data, result_t[0], QVMe_SAMPLE_DATA); qvm1.BlockRead(0, 0, size_data, result_t[2], QVMe_SAMPLE_DATA); qvm2.BlockRead(0, 0, size_data, result_t[4], QVMe_SAMPLE_DATA); qvm3.BlockRead(0, 0, size_data, result_t[6], QVMe_SAMPLE_DATA);
	qvm0.StartFFT(QVMe_DIRECT_FFT); qvm1.StartFFT(QVMe_DIRECT_FFT); qvm2.StartFFT(QVMe_DIRECT_FFT); qvm3.StartFFT(QVMe_DIRECT_FFT);
	//f0[0] = qvm0.GetFFTResult(0, 0, TOTAL_HARM, 2); f0[2] = qvm1.GetFFTResult(0, 0, TOTAL_HARM, 2); f0[4] = qvm2.GetFFTResult(0, 0, TOTAL_HARM, 2); f0[6] = qvm3.GetFFTResult(0, 0, TOTAL_HARM, 2);
	//f1[0] = qvm0.GetFFTResult(0, 1, TOTAL_HARM, 2); f1[2] = qvm1.GetFFTResult(0, 1, TOTAL_HARM, 2); f1[4] = qvm2.GetFFTResult(0, 1, TOTAL_HARM, 2); f1[6] = qvm3.GetFFTResult(0, 1, TOTAL_HARM, 2);
	//f2[0] = qvm0.GetFFTResult(0, 2, TOTAL_HARM, 2); f2[2] = qvm1.GetFFTResult(0, 2, TOTAL_HARM, 2); f2[4] = qvm2.GetFFTResult(0, 2, TOTAL_HARM, 2); f2[6] = qvm3.GetFFTResult(0, 2, TOTAL_HARM, 2);
	qvm0.BlockRead(0, 0, size_fft, result_f[0], QVMe_FFT_DATA); qvm1.BlockRead(0, 0, size_fft, result_f[2], QVMe_FFT_DATA); qvm2.BlockRead(0, 0, size_fft, result_f[4], QVMe_FFT_DATA); qvm3.BlockRead(0, 0, size_fft, result_f[6], QVMe_FFT_DATA);
	C_QVM_2468;
	delay_ms(3);
	qvm0.MeasureHADC(size_data, interval, QVMe_HADC_2V, MEAS_NORMAL); qvm1.MeasureHADC(size_data, interval, QVMe_HADC_2V, MEAS_NORMAL); qvm2.MeasureHADC(size_data, interval, QVMe_HADC_2V, MEAS_NORMAL); qvm3.MeasureHADC(size_data, interval, QVMe_HADC_2V, MEAS_NORMAL);
	qvm0.BlockRead(0, 0, size_data, result_t[1], QVMe_SAMPLE_DATA); qvm1.BlockRead(0, 0, size_data, result_t[3], QVMe_SAMPLE_DATA); qvm2.BlockRead(0, 0, size_data, result_t[5], QVMe_SAMPLE_DATA); qvm3.BlockRead(0, 0, size_data, result_t[7], QVMe_SAMPLE_DATA);
	qvm0.StartFFT(QVMe_DIRECT_FFT); qvm1.StartFFT(QVMe_DIRECT_FFT); qvm2.StartFFT(QVMe_DIRECT_FFT); qvm3.StartFFT(QVMe_DIRECT_FFT);
	//f0[1] = qvm0.GetFFTResult(0, 0, TOTAL_HARM, 2); f0[3] = qvm1.GetFFTResult(0, 0, TOTAL_HARM, 2); f0[5] = qvm2.GetFFTResult(0, 0, TOTAL_HARM, 2); f0[7] = qvm3.GetFFTResult(0, 0, TOTAL_HARM, 2);
	//f1[1] = qvm0.GetFFTResult(0, 1, TOTAL_HARM, 2); f1[3] = qvm1.GetFFTResult(0, 1, TOTAL_HARM, 2); f1[5] = qvm2.GetFFTResult(0, 1, TOTAL_HARM, 2); f1[7] = qvm3.GetFFTResult(0, 1, TOTAL_HARM, 2);
	//f2[1] = qvm0.GetFFTResult(0, 2, TOTAL_HARM, 2); f2[3] = qvm1.GetFFTResult(0, 2, TOTAL_HARM, 2); f2[5] = qvm2.GetFFTResult(0, 2, TOTAL_HARM, 2); f2[7] = qvm3.GetFFTResult(0, 2, TOTAL_HARM, 2);
	qvm0.BlockRead(0, 0, size_fft, result_f[1], QVMe_FFT_DATA); qvm1.BlockRead(0, 0, size_fft, result_f[3], QVMe_FFT_DATA); qvm2.BlockRead(0, 0, size_fft, result_f[5], QVMe_FFT_DATA); qvm3.BlockRead(0, 0, size_fft, result_f[7], QVMe_FFT_DATA);
	C_QVM_1357;
	delay_ms(1);
	for (int i = 0; i < SITE_NUM; i++)
	{
		amp0[i] = result_f[i][N];
		//amp0[i] = sqrt(amp0[i]);
	}
	for (int i = 0; i < SITE_NUM; i++)
	{
		amp[i] = amp0[i];
	}
	
	int site = 0;
	if (1)
	{
		FILE *fp2;
		fp2 = fopen("tdata.csv", "wb");
		for (unsigned int j = 0; j < size_data; j++)
		{
			fprintf(fp2, "%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f\n", result_t[0][j], result_t[1][j], result_t[2][j], result_t[3][j], result_t[4][j], result_t[5][j], result_t[6][j], result_t[7][j]);
		}
		fclose(fp2);
		fp2 = fopen("fdata.csv", "wb");
		for (unsigned int j = 0; j < size_fft; j++)
		{
			fprintf(fp2, "%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f\n", result_f[0][j], result_f[1][j], result_f[2][j], result_f[3][j], result_f[4][j], result_f[5][j], result_f[6][j], result_f[7][j]);
		}
		fclose(fp2);
	}
	return size_data;
}

int PSRR_MeasAmp2(int size, int fx, double amp[])
{
	int size_data = size;
	if (size_data > 32768){ size_data = 32768; }
	if (size_data < 64){ size_data = 64; }
	double sin_period = 1000000.0 / fx;//us
	double sample_time = sin_period * 5;
	double interval = sample_time / size_data;
	int x = 0;
	if (interval < 1)
	{ 
		interval = 1; 
		x = sample_time / interval;
		if (x < 256){ x = 256; }
		x = N_data(x);
		size_data = x;
		interval = sample_time / size_data;
		if (interval < 1) { interval = 1; }
	}
	double fs = 1000000.0 / interval;
	double deltf = fs / size_data;
	int N = fx / deltf;
	int Cycle = (size_data * fx) / fs;
	int size_fft = size_data / 2;

	double f0[SITE_NUM];
	double f1[SITE_NUM];
	double f2[SITE_NUM];
	double amp0[SITE_NUM];
	double result_t[SITE_NUM][8192];
	double result_f[SITE_NUM][8192];
	double max[SITE_NUM];
	double min[SITE_NUM];

	delay_ms(3);
	//qvm0.MeasureLADC(size_data, interval,QVMe_LADC_10V,QVMe_LADC_400KHz,MEAS_NORMAL);
	//qvm1.MeasureLADC(size_data, interval,QVMe_LADC_10V,QVMe_LADC_400KHz,MEAS_NORMAL);
	//qvm2.MeasureLADC(size_data, interval,QVMe_LADC_10V,QVMe_LADC_400KHz,MEAS_NORMAL);
	//qvm3.MeasureLADC(size_data, interval,QVMe_LADC_10V,QVMe_LADC_400KHz,MEAS_NORMAL);
	A_ABUFO.MeasureVI(size_data, interval);
	Get_Result(A_ABUFO, max, MVRET, MAX_RESULT);
	Get_Result(A_ABUFO, min, MVRET, MIN_RESULT);
	SERIAL amp[SITE]=max[SITE]-min[SITE];
	int site = 0;
	if (0)
	{
		FILE *fp2;
		fp2 = fopen("tdata.csv", "wb");
		for (unsigned int j = 0; j < size_data; j++)
		{
			fprintf(fp2, "%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f\n", result_t[0][j], result_t[1][j], result_t[2][j], result_t[3][j], result_t[4][j], result_t[5][j], result_t[6][j], result_t[7][j]);
		}
		fclose(fp2);
		fp2 = fopen("fdata.csv", "wb");
		for (unsigned int j = 0; j < size_fft; j++)
		{
			fprintf(fp2, "%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f,%3.6f\n", result_f[0][j], result_f[1][j], result_f[2][j], result_f[3][j], result_f[4][j], result_f[5][j], result_f[6][j], result_f[7][j]);
		}
		fclose(fp2);
	}
	return size_data;
}

void PSRR_CalcRsrr(double dutout[], double psrr[])
{
	double VppRef = 2.0;
	SERIAL if (dutout[SITE] > 10.0){ dutout[SITE] = 10.0; }
	SERIAL if (dutout[SITE] < 0.0){ dutout[SITE] = 0.0; }
	SERIAL psrr[SITE] = 20 * log10((VppRef*LSI_GAIN) / (dutout[SITE] + 1e-12));
}

void PSRR_InitSignal(void)
{
	int fx = 100 KHz;
	PSRR_SetAcOff();
	PSRR_SetDc(0.0);
	AD9833_Connect();
	AD9833_Init();
	AD9833_Set_Wave(DDS_SIN);
	AD9833_Set_Freq(fx);
	Amp_SetGain(LSI_GAIN_2);
}

void PSRR_Connect(void)
{
	LSI_Connect();
}

void PSRR_DisConnect(void)
{
	LSI_DisConnect();
}

int PSRR_GetFreq(void)
{
	return DDS_FREQ;
}

