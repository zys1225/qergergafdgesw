//2025/1/22
//Hunter Liu

class SPI_Class
{
public:
	void dut_write_x1(int RegAddress, int WriteData);
	void dut_write_x1(int RegAddress, int *WriteData);
	void dut_read_x1(int RegAddress, int ReadData[], int Parity[]);
	void dut_read_x1(int RegAddress, int ReadData[]);

	void dds_write_x1(int WriteData);
	void dds_write_x1(int WriteData[]);

	void ad8400_write_x1(int RegAddress, int WriteData);

	void tmp126_write_x1(int RegAddress, int WriteData);
	void tmp126_read_x1(int RegAddress, int ReadData[]);
};