#include "stdafx.h"
#include "cmd.h"
#include "spi.h"
#include "i2c.h"
#include "cfg.h"

SPI_Class spi;
I2C_Class i2c;
extern float SPI_CLK;

int CURRENT_BANK_NUM = -1;

int FBANK_BURN[9][SITE_NUM];
int FBANK_READ0[9][SITE_NUM];
int FBANK_READ1[9][SITE_NUM];
int FBANK_READ2[9][SITE_NUM];
int BANK_BURN[23][SITE_NUM];
int BANK_READ0[23][SITE_NUM];
int BANK_READ1[23][SITE_NUM];
int BANK_READ2[23][SITE_NUM];

int FORCE_OFF_DATA = 0;

void print(const char * _Format)
{
	if(1){printf(_Format);}
}

void sleep(double t_s)
{
	delay_ms(t_s*1000.0);
}

void Cmd_Set_Freq(void)
{
	Cmd_Set_Freq(SPI_CLK);
}

void Cmd_Set_Freq(float Freq)
{
	//fs(hz)
	int vdd = 5.0;
	const char* TS = "SPI";
	double Period = 1000000000.0 / Freq;//ns
	//Period: 12ns-4ms/83.3M-250
	//const char* PIN = "D_SDO";
	dcm.SetPeriod(TS, Period);
	double dT1R = 0.1 * Period;
	double dT1F = 0.9 * Period;
	double dIOR = 0.1 * Period;
	double dIOF = 0.9 * Period;
	double dSTBR = 0.7 * Period;
	dcm.SetEdge("D_SDO", TS, DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dcm.SetEdge("D_SDI", TS, DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dcm.SetEdge("D_CS", TS, DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.25 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.25 * Period;
	dIOF = 0.75 * Period;
	dSTBR = 0.5 * Period;
	dcm.SetEdge("D_SCK", TS, DCM_DTFT_RZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
}

void Cmd_Set_Freq_Scan(float Freq)
{
	//fs(hz)
	int vdd = 5.0;
	double Period = 1000000000.0 / Freq;//ns
	//Period: 12ns-4ms/83.3M-250
	//const char* PIN = "D_SDO";
	dcm.SetPeriod("init_cycle", Period);
	double dT1R = 0.25 * Period;
	double dT1F = 0.75 * Period;
	double dIOR = 0.00 * Period;
	double dIOF = 0.25 * Period;
	double dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_CLK", "init_cycle", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.00 * Period;
	dcm.SetEdge("SCAN_IN", "init_cycle", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_OUT", "init_cycle", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);

	dcm.SetPeriod("scan_cycle_TM_1", Period);
	dT1R = 0.25 * Period;
	dT1F = 0.65 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.25 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_CLK", "scan_cycle_TM_1", DCM_DTFT_RZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.00 * Period;
	dcm.SetEdge("SCAN_IN", "scan_cycle_TM_1", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_OUT", "scan_cycle_TM_1", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);

	dcm.SetPeriod("test_cycle", Period);
	dT1R = 0.25 * Period;
	dT1F = 0.65 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.25 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_CLK", "test_cycle", DCM_DTFT_RZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.00 * Period;
	dcm.SetEdge("SCAN_IN", "test_cycle", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.90 * Period;//0.2 to 0.5
	dcm.SetEdge("SCAN_OUT", "test_cycle", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);

	dcm.SetPeriod("scan_cycle", Period);
	dT1R = 0.25 * Period;
	dT1F = 0.65 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.50 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_CLK", "scan_cycle", DCM_DTFT_RZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.00 * Period;
	dcm.SetEdge("SCAN_IN", "scan_cycle", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_OUT", "scan_cycle", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);

	dcm.SetPeriod("CAPTURE", Period);
	dT1R = 0.25 * Period;
	dT1F = 0.70 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.50 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_CLK", "CAPTURE", DCM_DTFT_RZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.00 * Period;
	dcm.SetEdge("SCAN_IN", "CAPTURE", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_OUT", "CAPTURE", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);

	dcm.SetPeriod("test_cycle2", Period);
	dT1R = 0.25 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.50 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_CLK", "test_cycle2", DCM_DTFT_RZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.00 * Period;
	dcm.SetEdge("SCAN_IN", "test_cycle2", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_OUT", "test_cycle2", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);

	dcm.SetPeriod("scan_cycle_TM_2", Period);
	dT1R = 0.25 * Period;
	dT1F = 0.65 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.50 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_CLK", "scan_cycle_TM_2", DCM_DTFT_RZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.00 * Period;
	dcm.SetEdge("SCAN_IN", "scan_cycle_TM_2", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
	dT1R = 0.00 * Period;
	dT1F = 0.75 * Period;
	dIOR = 0.00 * Period;
	dIOF = 0.99 * Period;
	dSTBR = 0.90 * Period;
	dcm.SetEdge("SCAN_OUT", "scan_cycle_TM_2", DCM_DTFT_NRZ, DCM_IO_NRZ, dT1R, dT1F, dIOR, dIOF, dSTBR);
}

void CmdWriteData(int RegAddress, int data0)
{
	spi.dut_write_x1(RegAddress, data0);
}

void CmdWriteData(int RegAddress, int* data0)  
{
	spi.dut_write_x1(RegAddress, data0);
}

void CmdReadData(int RegAddress, int data0[])    
{
	spi.dut_read_x1(RegAddress, data0);
}

void CmdReadData(int RegAddress, int data0[], int parity[])    
{
	spi.dut_read_x1(RegAddress, data0, parity);
}
//
void Cmd_TestMode(bool en)
{
	int rdata[SITE_NUM];
	if (en)
	{
		CmdWriteData(0x3E, 0x51);
		CmdWriteData(0x3E, 0x54);
		CmdWriteData(0x3E, 0x44);
		CmdWriteData(0x3E, 0x53);
	}
	else
	{
		CmdWriteData(0x3E, 0x53);
		CmdWriteData(0x3E, 0x44);
		CmdWriteData(0x3E, 0x54);
		CmdWriteData(0x3E, 0x51);
	}
	//CmdReadData(0x3E, rdata);
}

void Cmd_TestMode(bool en, int in_tm[])
{
	Cmd_TestMode(en);
	Cmd_TestModeCheck(in_tm);
}

void Cmd_TestModeCheck(int in_tm[])
{
	int data[SITE_NUM];
	CmdReadData(0x3E, data);
	SERIAL
	{
		if (data[SITE]==0xF1){in_tm[SITE]=1;}//enter
		else if (data[SITE]==0xF0){in_tm[SITE]=0;}//exit
		else {in_tm[SITE]=-1;}
	}
}

void Cmd_TMSel(unsigned __int64 tm_data)
{
	Cmd_Bank1();
	//Cmd_TMSel(0x2C08280000800100);
	//data64=0xFFFFFFFF;
	int reg_28 = (tm_data>>0) & 0xFF;
	int reg_29 = (tm_data>>8) & 0xFF;
	int reg_2A = (tm_data>>16) & 0xFF;
	int reg_2B = (tm_data>>24) & 0xFF;
	int reg_2C = (tm_data>>32) & 0xFF;
	int reg_2D = (tm_data>>40) & 0xFF;
	int reg_2E = (tm_data>>48) & 0xFF;
	int reg_2F = (tm_data>>56) & 0xFF;
	CmdWriteData(0x28, reg_28);
	CmdWriteData(0x29, reg_29);
	CmdWriteData(0x2A, reg_2A);
	CmdWriteData(0x2B, reg_2B);
	CmdWriteData(0x2C, reg_2C);
	CmdWriteData(0x2D, reg_2D);
	CmdWriteData(0x2E, reg_2E);
	CmdWriteData(0x2F, reg_2F);
	//CmdWriteData(0x2A, reg_2A);
	//CmdWriteData(0x2F, reg_2F);
	//CmdWriteData(0x2E, reg_2E);
	//CmdWriteData(0x2D, reg_2D);
	//CmdWriteData(0x2C, reg_2C);
	//CmdWriteData(0x2B, reg_2B);
	//CmdWriteData(0x2A, reg_2A);
	//CmdWriteData(0x29, reg_29);
	//CmdWriteData(0x28, reg_28);
}

void Cmd_TMSelCheck(unsigned __int64 TMSel[])
{
	Cmd_Bank1();
	//Cmd_TMSel(0x2C08280000800100);
	//data64=0xFFFFFFFF;
	int reg_28[SITE_NUM];
	int reg_29[SITE_NUM];
	int reg_2A[SITE_NUM];
	int reg_2B[SITE_NUM];
	int reg_2C[SITE_NUM];
	int reg_2D[SITE_NUM];
	int reg_2E[SITE_NUM];
	int reg_2F[SITE_NUM];
	CmdReadData(0x28, reg_28);
	CmdReadData(0x29, reg_29);
	CmdReadData(0x2A, reg_2A);
	CmdReadData(0x2B, reg_2B);
	CmdReadData(0x2C, reg_2C);
	CmdReadData(0x2D, reg_2D);
	CmdReadData(0x2E, reg_2E);
	CmdReadData(0x2F, reg_2F);
	SERIAL TMSel[SITE] = 0;
	SERIAL TMSel[SITE] = (TMSel[SITE] << 8) + reg_2F[SITE];
	SERIAL TMSel[SITE] = (TMSel[SITE] << 8) + reg_2E[SITE];
	SERIAL TMSel[SITE] = (TMSel[SITE] << 8) + reg_2D[SITE];
	SERIAL TMSel[SITE] = (TMSel[SITE] << 8) + reg_2C[SITE];
	SERIAL TMSel[SITE] = (TMSel[SITE] << 8) + reg_2B[SITE];
	SERIAL TMSel[SITE] = (TMSel[SITE] << 8) + reg_2A[SITE];
	SERIAL TMSel[SITE] = (TMSel[SITE] << 8) + reg_29[SITE];
	SERIAL TMSel[SITE] = (TMSel[SITE] << 8) + reg_28[SITE];
}

void Cmd_Masksafe(void)
{
	Cmd_Bank1(true);
	CmdWriteData(0x31, 0x02);
}

void Cmd_Masksafe_Exit(void)
{
	Cmd_Bank1(true);
	CmdWriteData(0x31, 0x00);
}

void Cmd_LDO_Comp(void)
{
	Cmd_TMSel(0x0000010000000001);
}

void En_LDO_Comp(void)
{
	Cmd_Bank1(true);
	Cmd_LDO_Comp();
}

void Cmd_Forceoff(int data)
{
	int data0[SITE_NUM];
	int data1[SITE_NUM];
	Cmd_Bank1();
	CmdReadData(0x31, data0);
	int reg_30 = data & 0xFF;
	int reg_31 = (data>>8) & 0x01;
	SERIAL{ data1[SITE] = data0[SITE] | reg_31; } 
	CmdWriteData(0x30, reg_30);
	CmdWriteData(0x31, data1);
	FORCE_OFF_DATA = data;
}

void Cmd_ForceoffCheck(int data[])
{
	Cmd_Bank1();
	int reg_30[SITE_NUM];
	int reg_31[SITE_NUM];
	int reg[SITE_NUM];
	CmdReadData(0x30, reg_30);
	CmdReadData(0x31, reg_31);
	SERIAL{ reg_31[SITE] = reg_31[SITE] & 0x01; } 
	SERIAL { reg[SITE] = (reg_31[SITE] << 8) + reg_30[SITE];}
	SERIAL
	{
		if (reg[SITE] == FORCE_OFF_DATA) { data[SITE] = 1; }
		else { data[SITE] = 0; }
	}
}

void Cmd_Bank0(void)
{
	Cmd_Bank0(false);
}

void Cmd_Bank1(void)
{
	Cmd_Bank1(false);
}

void Cmd_Bank0(bool force_write)
{
	if (force_write)
	{
		CmdWriteData(0x3F, 0x00);
		CURRENT_BANK_NUM = 0;
	}
	else
	{
		if (CURRENT_BANK_NUM != 0) { CmdWriteData(0x3F, 0x00); }
		CURRENT_BANK_NUM = 0;
	}
}

void Cmd_Bank1(bool force_write)
{
	if (force_write)
	{
		CmdWriteData(0x3F, 0x01);
		CURRENT_BANK_NUM = 1;
	}
	else
	{
		if (CURRENT_BANK_NUM != 1) { CmdWriteData(0x3F, 0x01); }
		CURRENT_BANK_NUM = 1;
	}
}

void Cmd_BankCheck(int bank[])
{
	int data[SITE_NUM];
	CmdReadData(0x3F, data);
	SERIAL
	{
		if (data[SITE] == 0x01){ bank[SITE] = 1; }//bank1
		else if (data[SITE] == 0x00){ bank[SITE] = 0; }//bank0
		else { bank[SITE] = -1; }
	}
}

void Cmd_SpeedupMode(bool en)
{
	Cmd_Bank1();
	if (en)
	{
		CmdWriteData(0x22, 0x02);
	}
	else
	{
		CmdWriteData(0x22, 0x00);
	}
}

void Cmd_Scan_Main(void)
{
	CmdWriteData(0x25, 0x01);
}

void Cmd_Scan_Fs(void)
{
	CmdWriteData(0x25, 0x02);
}

void Cmd_Dmuxset_Main(int index)
{
	//FRE OUTPUT
	Cmd_Bank1();
	//CmdWriteData(0x2E, 0x40);//ena pad
	CmdWriteData(0x26, index);
}

void Cmd_Dmuxset_MainRead(int index[])
{
	//FRE OUTPUT
	Cmd_Bank1();
	CmdReadData(0x26, index);
}

void Cmd_Dmuxset_Fs0(int index)
{
	//POSFRE/SEC OUTPUT
	Cmd_Bank1();
	//CmdWriteData(0x2E, 0x08);//ena pad
	//CmdWriteData(0x2E, 0x40);//ena pad
	CmdWriteData(0x24, index);
}

void Cmd_Dmuxset_Fs0Read(int index[])
{
	//POSFRE/SEC OUTPUT
	Cmd_Bank1();
	CmdReadData(0x24, index);
}

void Cmd_Dmuxset_Fs1(int index)
{
	//POSFRE/SEC OUTPUT
	Cmd_Bank1();
	//CmdWriteData(0x2E, 0x08);//ena pad
	//CmdWriteData(0x2E, 0x40);//ena pad
	CmdWriteData(0x36, index);
}

void Cmd_Dmuxset_Fs1Read(int index[])
{
	//POSFRE/SEC OUTPUT
	Cmd_Bank1();
	CmdReadData(0x36, index);
}

void Cmd_Dis_WwdFwdErrm(void)
{
	Cmd_Bank0();
	Cmd_Dis_ERR_WD();
}

//void Cmd_Abus(int index)
//{
//	Cmd_Bank0();
//	Cmd_Unlock();
//	CmdWriteData(SYSPCFG0, 0x04);
//	CmdWriteData(AMUX_SELECT, index);
//	Cmd_Lock();
//}

void Cmd_ReadState(int state[])
{
	//0: none
	//1: init
	//2: normal
	//3: sleep
	//4: standby
	//5: wake
	//6: 
	//7: fs
	int data[SITE_NUM];
	Cmd_Bank0();
	CmdReadData(DEVSTAT, data);
	SERIAL state[SITE] = data[SITE] & 0x07;
}

void Cmd_ReadError(int data_1A[], int data_1E[], int data_20[], int data_21[], int data_22[], int data_23[])
{
	CmdReadData(0x1A, data_1A);
	CmdReadData(0x1E, data_1E);
	CmdReadData(0x20, data_20);
	CmdReadData(0x21, data_21);
	CmdReadData(0x22, data_22);
	CmdReadData(0x23, data_23);
}

//void Cmd_AbusAmux(void)
//{
//
//}
//
//void Cmd_AbusStu(void)
//{
//
//}

void Cmd_MaskError(bool en)
{
	if (en)
	{
		Cmd_Bank1();
		CmdWriteData(0x31, 0x02);
	}
}

//void Cmd_Nvm_Burn(bool globalen, bool* siteen)
//{
//	Cmd_Bank1();
//	int data1[SITE_NUM];
//	int data2[SITE_NUM];
//	int data1r[SITE_NUM];
//	int data2r[SITE_NUM];
//	int rdata0[SITE_NUM];
//	int rdata1[SITE_NUM];
//	int finish[SITE_NUM];
//	for (int site = 0; site<SITE_NUM; site++)
//	{
//		if (siteen){ data1[site] = 0x01; data2[site] = 0x01; }
//		else{ data1[site] = 0x00; data2[site] = 0x00; }
//	}
//	if (globalen)
//	{
//		CmdReadData(0x35, rdata0);
//		CmdWriteData(0x21, data1);
//		CmdReadData(0x21, data1r);
//		delay_us(100);//100us
//		CmdWriteData(0x20, data2);
//		CmdReadData(0x20, data2r);
//		Prog_Clk_Connect();
//		Prog_Clk_Run();
//		//delay_ms(10);//7.7ms+600us
//		Prog_Clk_DisConnect();
//		CmdReadData(0x35, rdata1);
//		SERIAL 
//		{
//			if (rdata1[SITE] == 0){ finish[SITE] = 1; }
//			else{ finish[SITE] = 0; }
//		}
//	}
//}

void Cmd_Nvm_ReadFs(int index, int data[])
{
	int addr = index;
	CmdReadData(addr, data);
}

void Cmd_Nvm_WriteFs(int index, int* data)
{
	int addr = index;
	CmdWriteData(addr, data);
}

void Cmd_Nvm_Read(int index, int data[])
{
	int addr = index + 9;
	CmdReadData(addr, data);
}

void Cmd_Nvm_Write(int index, int* data)
{
	int addr = index + 9;
	CmdWriteData(addr, data);
}

void Cmd_Set_State(int state)
{
	Cmd_Bank0();
	switch (state)
	{
		case STATE_FS:
			//CmdWriteData(0x00, 0x00);
			break;
		case STATE_INI:
			Cmd_Go2_Initial();
			break;
		case STATE_PWD:
			//CmdWriteData(0x00, 0x00);
			break;
		case STATE_SLP:
			Cmd_Go2_Sleep();
			break;
		case STATE_NOR:
			Cmd_Go2_Normal();
			break;
		case STATE_STB:
			Cmd_Go2_Standby();
			break;
		case STATE_WAK:
			Cmd_Go2_Wake();
			break;
		default:
			break;
	}
}

void Cmd_Write_DevCfg0(int data)
{
	Cmd_Bank0();
	CmdWriteData(DEVCFG0, data);
}

void Cmd_Write_DevCfg1(int data)
{
	Cmd_Bank0();
	CmdWriteData(DEVCFG1, data);
}

void Cmd_Write_DevCfg2(int data)
{
	Cmd_Bank0();
	CmdWriteData(DEVCFG2, data);
}

void Cmd_Read_LBIST(int pass[])
{
	int data[SITE_NUM];
	CmdReadData(DEVSTAT2, data);
	SERIAL
	{
		data[SITE]=data[SITE]|0x04;
		if(data[SITE]==0){pass[SITE]=1;}
		else{pass[SITE]=0;}
	}
}

void Cmd_EnSyn(bool en)
{
	int data0[SITE_NUM];
	CmdReadData(DEVCFG2,data0);
	if(en){ SERIAL data0[SITE]=data0[SITE]|0x01; }
	else{ SERIAL data0[SITE]=data0[SITE]&0xFE; }
	CmdWriteData(DEVCFG2,data0);
}

void Cmd_Get_OTFAIL(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int VREF[SITE_NUM];
	int COM[SITE_NUM];
	int UC[SITE_NUM];
	int PREG[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(OTFAIL, flag);
	CmdWriteData(OTFAIL, 0xFF);

	SERIAL
	{
		VREF[SITE] = flag[SITE] & 0x80;
		if(VREF[SITE] != 0)
			print("        ->Monitoring overtemperature.");
		COM[SITE] = flag[SITE] & 0x10;
		if(COM[SITE] != 0)
			print("        ->QCO overtemperature.");
		UC[SITE] = flag[SITE] & 0x02;
		if(UC[SITE] != 0)
			print("        ->QUC overtemperature.");
		PREG[SITE] = flag[SITE] & 0x01;
		if(PREG[SITE] != 0)
			print("        ->PreBuck overtemperature.");
		CmdReadData(OTFAIL, flag_new);
		if(flag_new[SITE] != 0)
			print("        ->More Overtemperature Interrupt Exist!");
		else
			print("        ->All Overtemperature Interrupt is Conformed");
	}
}

void Cmd_Get_OTWRNSF(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int VREF[SITE_NUM];
	int COM[SITE_NUM];
	int UC[SITE_NUM];
	int PREG[SITE_NUM];
	int STBY[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(OTWRNSF, flag);
	CmdWriteData(OTWRNSF, 0xFF);

	SERIAL
	{
		VREF[SITE] = flag[SITE] & 0x20;
		if(VREF[SITE] != 0)
			print("        ->QVR overload.");
		COM[SITE] = flag[SITE] & 0x10;
		if(COM[SITE] != 0)
			print("        ->QCO overtemperature warning.");
		STBY[SITE] = flag[SITE] & 0x04;
		if(STBY != 0)
			print("        ->QST overload.");
		UC[SITE] = flag[SITE] & 0x02;
		if(UC[SITE] != 0)
			print("        ->QUC overtemperature warning.");
		PREG[SITE] = flag[SITE] & 0x01;
		if(PREG[SITE] != 0)
			print("        ->PreBuck overtemperature warning.");
		CmdReadData(OTWRNSF, flag_new);
		if(flag_new[SITE] != 0)
			print("        ->More Overtemperature warning / overload Interrupt Exist!");
		else
			print("        ->All Overtemperature warning / overload Interrupt is Conformed");
	}
}

void Cmd_Get_MONSF0(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(MONSF0, flag);
	
	SERIAL
	{
		if(flag[SITE] != 0)
		{
			CmdWriteData(MONSF0, 0xFF);
			if(flag[SITE] & 0x80)
				print("        ->QT2 short to ground");
			if(flag[SITE] & 0x40)
				print("        ->QT1 short to ground");
			if(flag[SITE] & 0x20)
				print("        ->QVR short to ground");
			if(flag[SITE] & 0x10)
				print("        ->QCO short to ground");
			if(flag[SITE] & 0x08)
				print("        ->VCore short to ground");
			if(flag[SITE] & 0x04)
				print("        ->QST short to ground");
			if(flag[SITE] & 0x02)
				print("        ->QUC short to ground");
			if(flag[SITE] & 0x01)
				print("        ->FBx short to ground");
			CmdReadData(MONSF0, flag_new);
			if(flag_new[SITE] != 0)
				print("        ->More StG Error Exist!");
			else
				print("        ->All StG Error is Conformed");
		}
	}
}

void Cmd_Get_MONSF1(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(MONSF1, flag);

	SERIAL
	{
		if(flag[SITE] != 0)
		{
			CmdWriteData(MONSF1, 0xFF);
			if(flag[SITE] & 0x80)
				print("        ->QT2 overvoltage");
			if(flag[SITE] & 0x40)
				print("        ->QT1 overvoltage");
			if(flag[SITE] & 0x20)
				print("        ->QVR overvoltage");
			if(flag[SITE] & 0x10)
				print("        ->QCO overvoltage");
			if(flag[SITE] & 0x08)
				print("        ->VCore overvoltage");
			if(flag[SITE] & 0x04)
				print("        ->QST overvoltage");
			if(flag[SITE] & 0x02)
				print("        ->QUC overvoltage");
			if(flag[SITE] & 0x01)
				print("        ->FBx overvoltage");
			CmdReadData(MONSF1, flag_new);
			if(flag_new[SITE] != 0)
				print("        ->More OV Error Exist!");
			else
				print("        ->All OV Error is Conformed");
		}
	}
}

void Cmd_Get_MONSF2(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(MONSF2, flag);

	SERIAL
	{
		if(flag[SITE] != 0)
		{
			CmdWriteData(MONSF2, 0xFF);
			if(flag[SITE] & 0x80)
				print("        ->QT2 undervoltage");
			if(flag[SITE] & 0x40)
				print("        ->QT1 undervoltage");
			if(flag[SITE] & 0x20)
				print("        ->QVR undervoltage");
			if(flag[SITE] & 0x10)
				print("        ->QCO undervoltage");
			if(flag[SITE] & 0x08)
				print("        ->VCore undervoltage");
			if(flag[SITE] & 0x04)
				print("        ->QST undervoltage");
			if(flag[SITE] & 0x02)
				print("        ->QUC undervoltage");
			if(flag[SITE] & 0x01)
				print("        ->FBx undervoltage");
			CmdReadData(MONSF2, flag_new);
			if(flag_new[SITE] != 0)
				print("        ->More UV Error Exist!");
			else
				print("        ->All UV Error is Conformed");
		}
	}
}

void Cmd_Get_MONSF3(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(MONSF3, flag);

	SERIAL
	{
		if(flag[SITE] != 0)
		{
			CmdWriteData(MONSF3, 0xFF);
			if(flag[SITE] & 0x80)
				print("        ->Bias current too high");
			if(flag[SITE] & 0x40)
				print("        ->Bias current too low");
			if(flag[SITE] & 0x20)
				print("        ->Bandgap comparator overvoltage: BG1 > BG2*104%");
			if(flag[SITE] & 0x10)
				print("        ->Bandgap comparator undervoltage: BG1 < BG2*96%");
			if(flag[SITE] & 0x02)
				print("        ->Step up regulator short to ground");
			if(flag[SITE] & 0x01)
				print("        ->Supply voltage VSx overvoltage");
			CmdReadData(MONSF3, flag_new);
			if(flag_new[SITE] != 0)
				print("        ->More Monitoring Bank3 Error Exist!");
			else
				print("        ->All Monitoring Bank3 Error is Conformed");
		}
	}
}

void Cmd_Get_SPISF(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(SPISF, flag);
    CmdWriteData(SPISF, 0xFF);

	SERIAL
	{
		if(flag[SITE] & 0x10)
			print("        ->LOCK or UNLOCK procedure error");
		if(flag[SITE] & 0x08)
			print("        ->SPI frame duration error, e.g. SCS low for more than 2 ms");
		if(flag[SITE] & 0x04)
			print("        ->SPI address invalid");
		if(flag[SITE] & 0x02)
			print("        ->SPI frame length invalid, e.g. Number of detected SPI clock cycles different than 16");
		if(flag[SITE] & 0x01)
			print("        ->SPI frame parity error");
		CmdReadData(SPISF, flag_new);
		if(flag_new[SITE] != 0)
			print("        ->More SPI Error Exist!");
		else
			print("        ->All SPI Error is Conformed");
	}
}

void Cmd_Get_WKSF(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(WKSF, flag);
    CmdWriteData(WKSF, 0xFF);

	SERIAL
	{
		if(flag[SITE] == 0)
			print("No Wake Event Occurs");
		else
		{
			print("!!! Wake Event Occurs");
			if(flag[SITE] & 0x80)
				print("        ->WAK is High!");
			if(flag[SITE] & 0x40)
				print("        ->ENA is High!");
			if(flag[SITE] & 0x10)
				print("        ->Wake-up from SLEEP by SPI command");
			if(flag[SITE] & 0x08)
				print("        ->Wake-up by wake-up timer expiry, include STANDBY->INIT");
			if(flag[SITE] & 0x04)
				print("        ->QUC current large than threshold");
			if(flag[SITE] & 0x02)
				print("        ->Wake-up by ENA, include STANDBY/FAILSAFE->INIT");
			if(flag[SITE] & 0x01)
				print("        ->Wake-up by WAK, include STANDBY/FAILSAFE->INIT");
			CmdReadData(WKSF, flag_new);
			//# print(hex(flag_new))
			if((flag_new[SITE]&0x3f) != 0)
				print("        ->More Wake-Up Interrupt Exist!");
		}
	}
}

void Cmd_Get_SYSSF(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int flag_new[SITE_NUM];
	int NO_OP[SITE_NUM];
	int TRFAIL[SITE_NUM];
	int ERRMISS[SITE_NUM];
	int FWDE[SITE_NUM];
	int WWDE[SITE_NUM];
	int CFGE[SITE_NUM];

	CmdReadData(SYSSF, flag);
    CmdWriteData(SYSSF, 0xFF);

	SERIAL
	{
		if(flag[SITE] == 0)
			print("No System Status Abnormal");
		else
		{
			print("!!! System Status Abnormal");
			NO_OP[SITE] = flag[SITE] & 0x20;
			if(NO_OP[SITE])
				print("        ->State transition request failure (other write command in between DEVCTRL & DEVCTRLN).");
			TRFAIL[SITE] = flag[SITE] & 0x10;
			if(TRFAIL[SITE])
				print("        ->Transition to low power failed");
				Cmd_Get_WKSF();
			ERRMISS[SITE] = flag[SITE] & 0x08;
			if(ERRMISS[SITE])
				print("        ->MCU ERR monitoring error interrupt");
			FWDE[SITE] = flag[SITE] & 0x04;
			if(FWDE[SITE])
				print("        ->Functional watchdog error interrupt");
			WWDE[SITE] = flag[SITE] & 0x02;
			if(WWDE[SITE])
				print("        ->Window watchdog error interrupt");
			CFGE[SITE] = flag[SITE] & 0x01;
			if(CFGE[SITE])
				print("        ->Double bit error occurred on protected configuration register. Status registers shall be read in order to determine which configuration has changed.");
			CmdReadData(SYSSF, flag_new);
			if(flag_new[SITE] != 0)
				print("        ->More System Failure Exist!");
			else
				print("        ->All System Failure is Conformed");
		}
	}
}

void Cmd_Chk_Error(void)
{
	Cmd_Bank0();
    Cmd_Get_FailStatus();
    Cmd_Get_InitErrStatus();
    Cmd_Get_InterruptStatus();
    Cmd_Get_SYSSF();
    Cmd_Get_WKSF();
}

void Cmd_Get_windows_watchdog_configuration_status(void)
{
	Cmd_Bank0();
	int status[SITE_NUM];
	int status2[SITE_NUM];
	int status3[SITE_NUM];
	int status4[SITE_NUM];
	int WWDEN[SITE_NUM];
	int WDSLPEN[SITE_NUM];
	int WDCYC[SITE_NUM];
	int WDCYCDIV[SITE_NUM];
	int WWDETHR[SITE_NUM];
	int WWDTSEL[SITE_NUM];

	CmdReadData(RWDCFG0, status);
	CmdReadData(RWDCFG1, status2);
	CmdReadData(RWWDCFG0, status3);
	CmdReadData(RWWDCFG1, status4);

	SERIAL{ WWDEN[SITE] = status[SITE] & 0x08; } 
	SERIAL
	{
		if(WWDEN[SITE] != 0)
		{
			print("Window watchdog is enable");
			WDSLPEN[SITE] = status2[SITE] & 0x10;
			if(WDSLPEN[SITE] != 0)
				print("Watchdog is enable in SLEEP state");
			else
				print("Watchdog is disable in SLEEP state");
			WWDETHR[SITE] = status[SITE]>>4;
			print("    ->Window watchdog error counter thershold is {WWDETHR}");
			WWDTSEL[SITE] = status[SITE] & 0x02;
			if(WWDTSEL[SITE] != 0)
				print("    ->WWD is triggered by SPI write to WWDSCMD register");
			else
				print("    ->WWD is triggered by external WDI input");
			WDCYC[SITE] = status[SITE] & 0x01;
			WDCYCDIV[SITE] = status2[SITE] & 0x40;
			if((WDCYC[SITE] == 0) & (WDCYCDIV[SITE] == 0))
				print("    ->Watchdog clock is 0.1ms");
			else if((WDCYC[SITE] == 0) & (WDCYCDIV[SITE] == 0x40))
				print("    ->Watchdog clock is 10us");
			else if((WDCYC[SITE] == 1) & (WDCYCDIV[SITE] == 0))
				print("    ->Watchdog clock is 1ms");
			else if((WDCYC[SITE] == 1) & (WDCYCDIV[SITE] == 0x40))
				print("    ->Watchdog clock is 100us");
			print("    ->Window Watchdog close window is {(status3+1)*50} cycles");
			print("    ->Window Watchdog open window is {(status4+1)*50} cycles");
		}
		else
		{
			print("Window watchdog is disable");
		}
	}
}

void Cmd_Get_functional_watchdog_configuration_status(void)
{
	Cmd_Bank0();
	int status[SITE_NUM];
	int status2[SITE_NUM];
	int status3[SITE_NUM];
	int WWDEN[SITE_NUM];
	int WDSLPEN[SITE_NUM];
	int WDCYC[SITE_NUM];
	int WDCYCDIV[SITE_NUM];
	int WWDETHR[SITE_NUM];
	int WWDTSEL[SITE_NUM];
	int FWDETHR[SITE_NUM];
	int FWDEN[SITE_NUM];

	CmdReadData(RWDCFG0, status);
	CmdReadData(RWDCFG1, status2);
	CmdReadData(RFWDCFG, status3);

	SERIAL{ FWDEN[SITE] = status[SITE] & 0x04; } 

	SERIAL
	{
		if(FWDEN != 0)
		{
			print("Functional watchdog is enable");
			WDSLPEN[SITE] = status2[SITE] & 0x10;
			if(WDSLPEN[SITE] != 0)
				print("Watchdog is enable in SLEEP state");
			else
				print("Watchdog is disable in SLEEP state");
			FWDETHR[SITE] = status2[SITE] & 0x0F;
			print("    ->Functional watchdog error counter thershold is {FWDETHR}");
			WDCYC[SITE] = status[SITE] & 0x01;
			WDCYCDIV[SITE] = (status2[SITE] & 0x40);
			if((WDCYC[SITE] == 0) & (WDCYCDIV[SITE] == 0))
				print("    ->Watchdog clock is 0.1ms");
			else if((WDCYC[SITE] == 0) & (WDCYCDIV[SITE] == 0x40))
				print("    ->Watchdog clock is 10us");
			else if((WDCYC[SITE] == 1) & (WDCYCDIV[SITE] == 0))
				print("    ->Watchdog clock is 1ms");
			else if((WDCYC[SITE] == 1) & (WDCYCDIV[SITE] == 0x40))
				print("    ->Watchdog clock is 100us");
			print("    ->Functional Watchdog heartbeat counter is {(status3+1)*50} cycles");
		}
		else
		{
			print("Functional watchdog is disable");
		}
	}
}

void Cmd_Get_err_monitoring_configuration_status(void)
{
	Cmd_Bank0();
	int status[SITE_NUM];
	int SS2DEL[SITE_NUM];
	int ERREN[SITE_NUM];
	int ERRSLPEN[SITE_NUM];
	int ERRRECEN[SITE_NUM];
	int ERRREC[SITE_NUM];

	int WWDTSEL[SITE_NUM];
	int FWDETHR[SITE_NUM];
	int FWDEN[SITE_NUM];

	CmdReadData(RSYSPCFG1, status);

    print("status is {hex(self.read(0x0C))}");
	SERIAL{ SS2DEL[SITE] = status[SITE] & 0xE0; } 
	SERIAL{ ERREN[SITE] = status[SITE] & 0x08; } 

	SERIAL
	{
		if(ERREN[SITE] != 0)
		{
			print("ERR pin monitor is enable");
			ERRSLPEN[SITE] = status[SITE] & 0x10;
			if(ERRSLPEN[SITE] != 0)
				print("ERR pin monitor is enable in SLEEP mode");
			else
				print("ERR pin monitor is disable in SLEEP mode");
			ERRRECEN[SITE] = status[SITE] & 0x04;
			if(ERRRECEN[SITE] != 0)
			{
				print("ERR pin monitor in recovery mode");
				ERRREC[SITE] = status[SITE] & 0x03;
				if(ERRREC[SITE] == 0)
					print("recovery time is 1ms");
				else if(ERRREC[SITE] == 1)
					print("recovery time is 2.5ms");
				else if(ERRREC[SITE] == 2)
					print("recovery time is 5ms");
				else
					print("recovery time is 10ms");
			}
			else
				print("ERR pin monitor is immediate mode");
		}
		else
		{
			print("ERR pin monitor is disable");
		}
	}
}

void Cmd_Get_windows_watchdog_error_counter(void)
{
	Cmd_Bank0();
	int status[SITE_NUM];
	int WWDECNT[SITE_NUM];

	CmdReadData(WWDSTAT, status);
	SERIAL{ WWDECNT[SITE] = status[SITE] & 0x01; } 
    print("Window watchdog error counter is {WWDECNT}.");
}

void Cmd_Get_functional_watchdog_error_counter(void)
{
	Cmd_Bank0();
	int status1[SITE_NUM];
	int status2[SITE_NUM];
	int FWDRSPOK[SITE_NUM];
	int FWDRSPC[SITE_NUM];
	int FWDQUEST[SITE_NUM];
	int FWDECNT[SITE_NUM];

	CmdReadData(FWDSTAT0, status1);
	CmdReadData(FTDSTAT1, status2);
	SERIAL{ FWDRSPOK[SITE] = status1[SITE] & 0x40; } 

	SERIAL
	{
		if(FWDRSPOK[SITE] == 0)
			print("Response message is wrong");
		else
			print("All received bytes in response message are correct");
		FWDRSPC[SITE] = (status1[SITE] & 0x30)>>4;
		print("Functional watchdog response counter is {FWDRSPC}.");
		FWDQUEST[SITE] = status1[SITE] & 0x0F;
		print("Functional watchdog question is {FWDQUEST}.");
		FWDECNT[SITE] = status2[SITE];
		print("Functional watchdog error counter is {FWDECNT}.");
	}
}

void Cmd_Get_FailStatus(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int INITF[SITE_NUM];
	int ABISTERR[SITE_NUM];
	int BUCKHS[SITE_NUM];
	int VMONF[SITE_NUM];
	int OTF[SITE_NUM];
	int VOLTSELERR[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(SYSFAIL, flag);
	CmdWriteData(SYSFAIL, flag);

	SERIAL
	{
		if(flag[SITE] == 0)
			print("No System Failure");
		else
		{
			print("!!! System Failure(s) Occur(s)");
			INITF[SITE] = flag[SITE] & 0x80;
			if(INITF[SITE] != 0)
				print("    ->INIT failure due to the third INIT failure in row. i.e. The device restarts INIT phase from FAILSAFE.");
			ABISTERR[SITE] = flag[SITE] & 0x40;
			if(ABISTERR[SITE] != 0)
				print("    ->ABIST interrupted by any fault/event which is not part of ABIST.");
			BUCKHS[SITE] = flag[SITE] & 0x08;
			if(BUCKHS[SITE] != 0)
				print("    ->Buck converter failure occurred which lead to FAILSAFE.");
			VMONF[SITE] = flag[SITE] & 0x04;
			if(VMONF[SITE] != 0)
				print("    ->Voltage monitor failure occured which lead to FAILSAFE. Read MONSF0, MONSF1 and MONSF3 for details.");
				Cmd_Get_MONSF0();
				Cmd_Get_MONSF1();
				Cmd_Get_MONSF3();
			OTF[SITE] = flag[SITE] & 0x02;
			if(OTF[SITE] != 0)
				print("    ->Over temperature failure. Read OTFAIL for details.");
				Cmd_Get_OTFAIL();
			VOLTSELERR[SITE] = flag[SITE] & 0x01;
			if(VOLTSELERR[SITE] != 0)
				print("    ->Device entered FAILSAFE state due to internal voltage selection failure.");
			CmdReadData(0x1A, flag_new);
			if(flag_new[SITE] != 0)
				print("    ->More Failure Exist");
			else
				print("    ->All System Failure is Conformed");
		}
	}
}

void Cmd_Get_InitErrStatus(void)
{
	Cmd_Bank0();
	int flag[SITE_NUM];
	int HARDRES[SITE_NUM];
	int SOFTRES[SITE_NUM];
	int ERRF[SITE_NUM];
	int FWDF[SITE_NUM];
	int WWDF[SITE_NUM];
	int VMONF[SITE_NUM];
	int flag_new[SITE_NUM];

	CmdReadData(INITERR, flag);
	CmdWriteData(INITERR, flag);

	SERIAL
	{
		if(flag[SITE] == 0)
			print("No Initial Error");
		else
		{
			print("!!! Initial Error(s) Occur(s)");
			HARDRES[SITE] = flag[SITE] & 0x80;
			if(HARDRES[SITE] != 0)
				print("    ->Hard reset has been generated due to the second INIT failure in row. i.e. The device restarts INIT phase for the 3rd time.");
			SOFTRES[SITE] = flag[SITE] & 0x40;
			if(SOFTRES[SITE] != 0)
				print("    ->Soft reset has been generated due to the first INIT failure. i.e. The device restarts INIT phase for the 2nd time.");
			ERRF[SITE] = flag[SITE] & 0x20;
			if(ERRF != 0)
				print("    ->MCU error monitor failure.");
			FWDF[SITE] = flag[SITE] & 0x10;
			if(FWDF[SITE] != 0)
				print("    ->Functional watchdog error counter reached the error threshold.");
			WWDF[SITE] = flag[SITE] & 0x08;
			if(WWDF[SITE] != 0)
				print("    ->Window watchdog error counter reached the error threshold.");
			VMONF[SITE] = flag[SITE] & 0x04;
			if(VMONF[SITE] != 0)
				print("    ->Voltage monitor failure occured which lead to INIT.");
				Cmd_Get_MONSF2();
			CmdReadData(0x1B, flag_new);
			if(flag_new[SITE] != 0)
				print("    ->More Error Exist");
			else
				print("    ->All Initial Error is Conformed");
		}
	}
}

void Cmd_Get_InterruptStatus(void)
{
	Cmd_Bank0();
	int flag1[SITE_NUM];
	int flag2[SITE_NUM];
	int flag1_new[SITE_NUM];
	int flag2_new[SITE_NUM];
	int INTMISS[SITE_NUM];
	int ABIST[SITE_NUM];
	int OTF[SITE_NUM];
	int OTW[SITE_NUM];
	int MON[SITE_NUM];
	int SPI[SITE_NUM];
	int WK[SITE_NUM];
	int SYS[SITE_NUM];
	int STUOC[SITE_NUM];
	int CEFU3[SITE_NUM];
	int CEFU2[SITE_NUM];
	int CEFU1[SITE_NUM];
	int CEFU0[SITE_NUM];

	CmdReadData(IF, flag1);
	CmdWriteData(IF, 0xFF);

	SERIAL
	{
		if(flag1[SITE] == 0)
			print("No Interrupt");
		else
		{
			print("!!! Interrupt(s) Occur(s)");
			INTMISS[SITE] = flag1[SITE] & 0x80;
			if(INTMISS[SITE] != 0)
				print("    ->Interrupt timeout happened, cleared by hardware when all other flags in IF are cleared.");
			ABIST[SITE] = flag1[SITE] & 0x40;
			if(ABIST[SITE] != 0)
				print("    ->Requested ABIST operation performed.");
			OTF[SITE] = flag1[SITE] & 0x20;
			if(OTF[SITE] != 0)
				print("    ->Over temperature failure, read OTFAIL for details.");
				Cmd_Get_OTFAIL();
			OTW[SITE] = flag1[SITE] & 0x10;
			if(OTW[SITE] != 0)
				print("    ->Over temperature warning, read OTWRNSF for details.");
				Cmd_Get_OTWRNSF();
			MON[SITE] = flag1[SITE] & 0x08;
			if(MON[SITE] != 0)
				print("    ->Monitor interrupt, read MONSF0, MONSF1, MONSF2 and MONSF3 for details.");
				Cmd_Get_MONSF0();
				Cmd_Get_MONSF1();
				Cmd_Get_MONSF2();
				Cmd_Get_MONSF3();
			SPI[SITE] = flag1[SITE] & 0x04;
			if(SPI[SITE] != 0)
				print("    ->SPI interrupt, read SPISF for details.");
				Cmd_Get_SPISF();
			WK[SITE] = flag1[SITE] & 0x02;
			if(WK[SITE] != 0)
				print("    ->Wake interrupt, read WKSF for details.");
				Cmd_Get_WKSF();
			SYS[SITE] = flag1[SITE] & 0x01;
			if(SYS[SITE] != 0)
				print("    ->System interrupt, read SYSSF for details.");
				Cmd_Get_SYSSF();
			CmdReadData(0x1C, flag1_new);
			if(flag1_new[SITE] != 0)
				print("    ->More Interrupt Exist!");
			else
				print("    ->All Interrupt is Conformed");
		}
	}
	CmdReadData(CEFUMON, flag2);
	CmdWriteData(CEFUMON, 0xFF);

	SERIAL
	{
		if(flag2[SITE] == 0)
			print("No CEFUMON Reg Interrupt");
		else
		{
			print("!!! CEFUMON Reg Interrupt(s) Occur(s)");
			STUOC[SITE] = flag2[SITE] & 0x80;
			if(STUOC[SITE] != 0)
				print("    ->Step up pre regulator over current pre warning. This diagnostic will re-trigger an INT event raising the flag repetitively every 500 ��s as long as the over current pre warning condition is reached.");
			CEFU3[SITE] = flag2[SITE] & 0x08;
			if(CEFU3[SITE] != 0)
				print("    ->Internal regulator backup for switchable power domain failure.");
			CEFU2[SITE] = flag2[SITE] & 0x04;
			if(CEFU2[SITE] != 0)
				print("    ->Internal regulator for switchable power domain failure.");
			CEFU1[SITE] = flag2[SITE] & 0x02;
			if(CEFU1[SITE] != 0)
				print("    ->Internal regulator backup for always on power domain failure.");
			CEFU0[SITE] = flag2[SITE] & 0x01;
			if(CEFU0[SITE] != 0)
				print("    ->Internal regulator for always on power domain failure.");
			CmdReadData(0x3B, flag2_new);
			if(flag2_new[SITE] != 0)
				print("    ->More CEFUMON Reg Interrupt Exist!");
			else
				print("    ->All CEFUMON Reg Interrupt is Conformed");
		}
	}
}

void Cmd_Get_VoltMonStatus(void)
{
	Cmd_Bank0();
	int status[SITE_NUM];
	int TRK2ST[SITE_NUM];
	int TRK1ST[SITE_NUM];
	int VREFST[SITE_NUM];
	int COMST[SITE_NUM];
	int VCOREST[SITE_NUM];
	int STBYST[SITE_NUM];
	int PREGST[SITE_NUM];

	CmdReadData(0x26, status);
	SERIAL{ TRK2ST[SITE] = status[SITE] & 0x80; } 

	SERIAL
	{
		if(TRK2ST[SITE] != 0)
			print("Tracker2 Voltage is OK");
		else
			print("Tracker2 Voltage is NOT OK");
		TRK1ST[SITE] = status[SITE] & 0x40;
		if(TRK1ST[SITE] != 0)
			print("Tracker1 Voltage is OK");
		else
			print("Tracker1 Voltage is NOT OK");
		VREFST[SITE] = status[SITE] & 0x20;
		if(VREFST[SITE] != 0)
			print("Reference Voltage is OK");
		else
			print("Reference Voltage is NOT OK");
		COMST[SITE] = status[SITE] & 0x10;
		if(COMST[SITE] != 0)
			print("Communication Voltage is OK");
		else
			print("Communication Voltage is NOT OK");
		VCOREST[SITE] = status[SITE] & 0x08;
		if(VCOREST[SITE] != 0)
			print("Core Voltage is OK");
		else
			print("Core Voltage is NOT OK");
		STBYST[SITE] = status[SITE] & 0x04;
		if(STBYST[SITE] != 0)
			print("Standby Voltage is OK");
		else
			print("Standby Voltage is NOT OK");
		PREGST[SITE] = status[SITE] & 0x01;
		if(PREGST[SITE] != 0)
			print("Pre regulator (FB) Voltage is OK");
		else
			print("Pre regulator (FB) Voltage is NOT OK");
	}
}

void Cmd_Get_DeviceStatus(void)
{
	Cmd_Bank0();
	int status[SITE_NUM];
	int TRK2EN[SITE_NUM];
	int TRK1EN[SITE_NUM];
	int COMEN[SITE_NUM];
	int STBYEN[SITE_NUM];
	int VREFEN[SITE_NUM];
	int STATE[SITE_NUM];

	CmdReadData(0x27, status);
	SERIAL{ TRK2EN[SITE] = status[SITE] & 0x80; } 

	SERIAL
	{
		if(TRK2EN[SITE] != 0)
			print("Tracker2 is enable");
		else
			print("Tracker2 is disable");
		TRK1EN[SITE] = status[SITE] & 0x40;
		if(TRK1EN[SITE] != 0)
			print("Tracker1 is enable");
		else
			print("Tracker1 is disable");
		COMEN[SITE] = status[SITE] & 0x20;
		if(COMEN[SITE] != 0)
			print("Communication LDO is enable");
		else
			print("Communication LDO is disable");
		STBYEN[SITE] = status[SITE] & 0x10;
		if(STBYEN[SITE] != 0)
			print("Standby LDO is enable");
		else
			print("Standby LDO is disable");
		VREFEN[SITE] = status[SITE] & 0x08;
		if(VREFEN[SITE] != 0)
			print("Reference LDO is enable");
		else
			print("Reference LDO is disable");
		STATE[SITE] = status[SITE] & 0x07;
		if((STATE[SITE] == 0) | (STATE[SITE] == 6) | (STATE[SITE] == 7))
			print("Device state is NA");
		else if(STATE[SITE] == 1)
			print("Device state is INIT");
		else if(STATE[SITE] == 2)
			print("Device state is NORMAL");
		else if(STATE[SITE] == 3)
			print("Device state is SLEEP");
		else if(STATE[SITE] == 4)
			print("Device state is STANDBY");
		else if(STATE[SITE] == 5)
			print("Device state is WAKE");
	}
}

void Cmd_Get_ProtectStatus(void)
{
	Cmd_Bank0();
	int status[SITE_NUM];
	int key4ok[SITE_NUM];
	int key3ok[SITE_NUM];
	int key2ok[SITE_NUM];
	int key1ok[SITE_NUM];
	int lock[SITE_NUM];

	CmdReadData(0x28, status);

	SERIAL
	{
		//key4ok[SITE] = status[SITE] & 0x80;
		//if(key4ok[SITE] != 0)
		//    print("Key4 is ok.");
		//else
		//    print("Key4 is not ok.");
		//key3ok[SITE] = status[SITE] & 0x40;
		//if(key3ok[SITE] != 0)
		//    print("Key3 is ok.");
		//else
		//    print("Key3 is not ok.");
		//key2ok[SITE] = status[SITE] & 0x20;
		//if(key2ok != 0)
		//    print("Key2 is ok.");
		//else
		//    print("Key2 is not ok.");
		//key1ok[SITE] = status[SITE] & 0x10;
		//if(key1ok[SITE] != 0)
		//    print("Key1 is ok.");
		//else
		//    print("Key1 is not ok.");
		lock[SITE] = status[SITE] & 0x01;
		if(lock[SITE] != 0)
			print("Access is locked.");
		else
			print("Access is unlocked.");
	}
}

void Cmd_Get_WakeTimerStatus(void)
{
	Cmd_Bank0();
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int status1[SITE_NUM];
	int status2[SITE_NUM];
	int WKTIMEN[SITE_NUM];
	int WKTIMCYC[SITE_NUM];

	CmdReadData(DEVCFG0, status1);
	CmdReadData(WKTIMCFG2, data1);
	CmdReadData(WKTIMCFG1, data2);
	CmdReadData(WKTIMCFG0, data3);
	SERIAL{ status2[SITE] = data1[SITE]<<16 + data2[SITE]<<8 + data3[SITE]; } 
	SERIAL{ WKTIMEN[SITE] = status1[SITE] & 0x80; } 

	SERIAL
	{
		if(WKTIMEN[SITE])
			print("Wake timer enabled in SLEEP or STANDBY-state");
		else
			print("Wake timer disabled");

		WKTIMCYC[SITE] = (status1[SITE] & 0x60) >> 5;
		if(WKTIMCYC[SITE] == 0)
			print("Wake timer cycle = 10us");
		else if(WKTIMCYC[SITE] == 1)
			print("Wake timer cycle = 1ms");
		else if(WKTIMCYC[SITE] == 2)
			print("Wake timer cycle = 10ms");
		else
			print("Wake timer cycle = 1s");
		print("Waker up timer = {status2}cycles");
	}
}

void Cmd_Get_tRD(void)
{
	Cmd_Bank0();
	int status[SITE_NUM];
	int RESDEL[SITE_NUM];

	CmdReadData(DEVCFG1, status);
	SERIAL{ RESDEL[SITE] = status[SITE]; } 

	SERIAL
	{
		if(RESDEL[SITE] == 0)
			print("tRD = 200us");
		else if(RESDEL[SITE] == 1)
			print("tRD = 400us");
		else if(RESDEL[SITE] == 2)
			print("tRD = 800us");
		else if(RESDEL[SITE] == 3)
			print("tRD = 1ms");
		else if(RESDEL[SITE] == 4)
			print("tRD = 2ms");
		else if(RESDEL[SITE] == 5)
			print("tRD = 4ms");
		else if(RESDEL[SITE] == 6)
			print("tRD = 10ms");
		else if(RESDEL[SITE] == 7)
			print("tRD = 15ms");
	}
}

void Cmd_Get_DcdcCfg(void)
{
	Cmd_Bank0();
	int status[SITE_NUM];
	int EVCEN[SITE_NUM];

	CmdReadData(DEVCFG2, status);
	SERIAL{ EVCEN[SITE] = status[SITE] & 0x80; } 
    //# if EVCEN
}

void Cmd_Chk_Status(void)
{
	Cmd_Bank0();
    Cmd_Get_VoltMonStatus();
    Cmd_Get_DeviceStatus();
    Cmd_Get_ProtectStatus();
    Cmd_Get_windows_watchdog_configuration_status();
    Cmd_Get_functional_watchdog_configuration_status();
}

void Cmd_Unlock(void)
{
	Cmd_Bank0();
	CmdWriteData(PROTCFG, 0xAB);
	CmdWriteData(PROTCFG, 0xEF);
	CmdWriteData(PROTCFG, 0x56);
	CmdWriteData(PROTCFG, 0x12);
	int data[SITE_NUM];
	CmdReadData(PROTSTAT, data);
}

void Cmd_Lock(void)
{
	Cmd_Bank0();
	CmdWriteData(PROTCFG, 0xDF);
	CmdWriteData(PROTCFG, 0x34);
	CmdWriteData(PROTCFG, 0xBE);
	CmdWriteData(PROTCFG, 0xCA);
	int data[SITE_NUM];
	CmdReadData(PROTSTAT, data);
}

void Cmd_En_WD(bool en_WWD, bool en_FWD, bool en_in_sleep)
{
	Cmd_Bank0();
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	CmdReadData(RWDCFG0, data1);
    if( en_WWD)
		SERIAL{ data1[SITE] = data1[SITE] | 0x08; } 
    else
		SERIAL{ data1[SITE] = data1[SITE] & 0xF7; } 
    if( en_FWD)
		SERIAL{ data1[SITE] = data1[SITE] | 0x04; } 
    else
		SERIAL{ data1[SITE] = data1[SITE] & 0xFB; } 
	CmdReadData(RWDCFG1, data2);
    if( en_in_sleep)
		SERIAL{ data2[SITE] = data2[SITE] | 0x10; } 
    else
		SERIAL{ data1[SITE] = data1[SITE] & 0xEF; } 
    Cmd_Unlock();
    CmdWriteData(WDCFG0, data1);
    CmdWriteData(WGCFG1, data2);
    Cmd_Lock();
	//Cmd_Get_windows_watchdog_configuration_status();
	//Cmd_Get_functional_watchdog_configuration_status();
}

void Cmd_En_ERR(bool en, bool en_in_sleep)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	CmdReadData(RSYSPCFG1, data);
    if( en == 0)
		SERIAL{ data[SITE] = data[SITE] & 0xF7; } 
    else
	{
        if( en_in_sleep == 0)
			SERIAL{ data[SITE] = data[SITE] | 0x08 & 0xEF; } 
        else
			SERIAL{ data[SITE] = data[SITE] | 0x18; } 
	}
    Cmd_Unlock();
    CmdWriteData(SYSPCFG1, data);
    Cmd_Lock();
    //Cmd_Get_err_monitoring_configuration_status()
}

void Cmd_Dis_ERR(void)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	CmdReadData(SYSPCFG1, data);
	SERIAL{ data[SITE] = data[SITE] & 0xFF; } 
	CmdWriteData(SYSPCFG1, 0x00);
}

void Cmd_Dis_WD(void)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	//CmdReadData(WDCFG0, data);
	CmdWriteData(WDCFG0, 0x93);
	//CmdReadData(WDCFG0, data);
}

void Cmd_Dis_ERR_WD(void)
{
	Cmd_Bank0();
	int data0[SITE_NUM];
	int data1[SITE_NUM];
	int data2[SITE_NUM];

	CmdReadData(RSYSPCFG1, data0);
	CmdReadData(RWDCFG0, data1);
	CmdReadData(RWDCFG1, data2);

	SERIAL{ data0[SITE] = data0[SITE] & 0xe7; } 
	SERIAL{ data1[SITE] = data1[SITE] & 0xf3; } 
	SERIAL{ data2[SITE] = data2[SITE] & 0xef; } 

    Cmd_Unlock();
    CmdWriteData(SYSPCFG1, data0);
    CmdWriteData(WDCFG0, data1);
    CmdWriteData(WGCFG1, data2);
    Cmd_Lock();
    //Cmd_Get_err_monitoring_configuration_status();
    //Cmd_Get_windows_watchdog_configuration_status();
    //Cmd_Get_functional_watchdog_configuration_status();
}

void Cmd_Go2_Initial(void)
{
	Cmd_Bank0(true);
	int data[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	SERIAL{ data[SITE] = data[SITE] | 0x01; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
}

void Cmd_Go2_Normal(void)
{
	Cmd_Bank0(true);
	int data[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	SERIAL{ data[SITE] = data[SITE] & 0xE8 | 0x02; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
}

void Cmd_Go2_Sleep(void)
{
	Cmd_Bank0(true);
	int data[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	SERIAL{ data[SITE] = data[SITE] & 0xE8 | 0x03; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
}

void Cmd_Go2_Standby(void)
{
	Cmd_Bank0(true);
	int data[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	SERIAL{ data[SITE] = data[SITE] & 0xE8 | 0x04; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
}

void Cmd_Go2_Wake(void)
{
	Cmd_Bank0(true);
	int data[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	SERIAL{ data[SITE] = data[SITE] & 0xE8 | 0x05; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
}

void Cmd_En_Trk1(bool en)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int data1[SITE_NUM];
	int status[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	CmdReadData(DEVSTAT2, data1);
	if(en)
		SERIAL{ data[SITE] = data[SITE] | 0x40; } 
	else
		SERIAL{ data[SITE] = data[SITE] & 0xBF; } 
	if((data1[SITE]&0x02)>0)
		SERIAL{ data[SITE] = data[SITE] | 0x10; } 
	else
		SERIAL{ data[SITE] = data[SITE] & 0xEF; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
	//CmdReadData(DEVSTAT, status);
	//SERIAL{ status[SITE] = status[SITE] & 0x40; } 
}

void Cmd_En_Trk2(bool en)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int data1[SITE_NUM];
	int status[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	CmdReadData(DEVSTAT2, data1);
	if(en)
		SERIAL{ data[SITE] = data[SITE] | 0x80; } 
	else
		SERIAL{ data[SITE] = data[SITE] & 0x7F; } 
	if((data1[SITE]&0x02)>0)
		SERIAL{ data[SITE] = data[SITE] | 0x10; } 
	else
		SERIAL{ data[SITE] = data[SITE] & 0xEF; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
	//CmdReadData(DEVSTAT, status);
	//SERIAL{ status[SITE] = status[SITE] & 0x80; } 
}

void Cmd_En_Trk3(bool en)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int status[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	if (en)
		SERIAL{ data[SITE] = data[SITE] | 0x10; }
	else
	SERIAL{ data[SITE] = data[SITE] & 0xEF; }
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; }
	CmdWriteData(DEVCTRLN, data);
	//CmdReadData(DEVSTAT, status);
	//SERIAL{ status[SITE] = status[SITE] & 0x80; }
}

void Cmd_En_Trk(void)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int status[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	SERIAL{ data[SITE] = data[SITE] & 0x07 | 0xF8; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
	//CmdReadData(DEVSTAT, status);
	//SERIAL{ status[SITE] = status[SITE] & 0x80; } 
}

void Cmd_En_Com(bool en)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int data1[SITE_NUM];
	int status[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	CmdReadData(DEVSTAT2, data1);
	if(en)
		SERIAL{ data[SITE] = data[SITE] | 0x20; } 
	else
		SERIAL{ data[SITE] = data[SITE] & 0xDF; } 
	if((data1[SITE]&0x02)>0)
		SERIAL{ data[SITE] = data[SITE] | 0x10; } 
	else
		SERIAL{ data[SITE] = data[SITE] & 0xEF; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
	//CmdReadData(DEVSTAT, status);
	//SERIAL{ status[SITE] = status[SITE] & 0x20; } 
}

void Cmd_En_Ref(bool en)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int data1[SITE_NUM];
	int status[SITE_NUM];
	CmdReadData(DEVSTAT, data);
	CmdReadData(DEVSTAT2, data1);
	if(en)
		SERIAL{ data[SITE] = data[SITE] | 0x08; } 
	else
		SERIAL{ data[SITE] = data[SITE] & 0xF7; } 
	if((data1[SITE]&0x02)>0)
		SERIAL{ data[SITE] = data[SITE] | 0x10; } 
	else
		SERIAL{ data[SITE] = data[SITE] & 0xEF; } 
	CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
	CmdWriteData(DEVCTRLN, data);
	//CmdReadData(DEVSTAT, status);
	//SERIAL{ status[SITE] = status[SITE] & 0x08; } 
}

void Cmd_En_Stb(bool en, bool dis_os)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int status[SITE_NUM];
	SERIAL{ data[SITE] = en | dis_os<<7; } 
	Cmd_Unlock();
    CmdWriteData(SYSPCFG0, data);
    Cmd_Lock();
	//CmdReadData(DEVSTAT, status);
	//SERIAL{ status[SITE] = status[SITE] & 0x10; } 
}

void Cmd_En_Posbk(bool en)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int status[SITE_NUM];
	CmdReadData(RASFCFG, data);
	if(en)
		SERIAL{ data[SITE] = data[SITE] | 0x01; } 
	else
		SERIAL{ data[SITE] = data[SITE] & 0xFE; }
	Cmd_Unlock();
    CmdWriteData(ASFCFG, data);
    Cmd_Lock();
	CmdReadData(DEVSTAT, status);
	SERIAL{ status[SITE] = status[SITE] & 0x10; } 
}

void Cmd_En_WakeupTimer(bool en)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	CmdReadData(DEVCFG0, data);
	if(en)
	{SERIAL{ data[SITE] = data[SITE] | 0x80; } }
	else
	{SERIAL{ data[SITE] = data[SITE] & 0x7F; } }
	CmdWriteData(DEVCFG0, data);
}

void Cmd_En_AllVout(void)
{
	Cmd_Bank0();
	Cmd_En_Stb(1,1);
	Cmd_En_Com(1);
	Cmd_En_Ref(1);
	Cmd_En_Trk1(1);
	Cmd_En_Trk2(1);
}

void Cmd_Dis_AllVout(void)
{
	Cmd_Bank0();
	Cmd_En_Trk2(0);
	Cmd_En_Trk1(0);
	Cmd_En_Ref(0);
	Cmd_En_Com(0);
	Cmd_En_Stb(0,0);
}

void Cmd_DisOS(bool en)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int status[SITE_NUM];
	SERIAL{ data[SITE] = en<<7; } 
	Cmd_Unlock();
    CmdWriteData(SYSPCFG0, data);
    Cmd_Lock();
	//CmdReadData(0x27, status);
	//SERIAL{ status[SITE] = status[SITE] & 0x10; } 
}

void Cmd_AmuxEn(bool en)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int status[SITE_NUM];
	SERIAL{ data[SITE] = en << 1; }
	Cmd_Unlock();
	CmdWriteData(SYSPCFG0, data);
	Cmd_Lock();
	//CmdReadData(0x27, status);
	//SERIAL{ status[SITE] = status[SITE] & 0x10; }
}

void Cmd_AmuxEn_Stb(bool amux, bool stb, bool os)
{
	int data[SITE_NUM];
	int status[SITE_NUM];
	SERIAL{ data[SITE] = (amux << 1) + (stb) + (os << 7); } 
	Cmd_Unlock();
	CmdWriteData(SYSPCFG0, 0x83);//ena amux and qst
	Cmd_Lock();
}

void Cmd_AmuxSel(int amux)
{
	CmdWriteData(AMUX_SELECT,amux);
}

void Cmd_AmuxCfg(int cfg)
{
	CmdWriteData(AMUXCFG,cfg);
}

void Cmd_LMTCFG(int CORELMT, int PREBKLMT, int QCOLMT, int QUCLMT, int PDDLY)
{
	Cmd_Bank0();
	int data = (CORELMT<<7) + (PREBKLMT<<6) + (QCOLMT<<5) + (QUCLMT<<4) + PDDLY;
    CmdWriteData(LMT_PD_CFG, data);
}

void Cmd_WWD_Cfg(string wd_clk, string wwd_src, int wwd_ethr, int wwd_cw_cyc, int wwd_ow_cyc)
{
	Cmd_Bank0();
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];

	int data_wd_clk;
	int data_wwd_src;
	int wd_clk_div;

	//Cmd_Feed_WWD_UseSPI();
    if(wd_clk == "0.1ms")
	{
        data_wd_clk = 0x00;
        wd_clk_div = 0x00;
	}
    else if(wd_clk == "1ms")
	{
        wd_clk = 0x01;
        wd_clk_div = 0x00;
	}
    else if(wd_clk == "10us")
	{
        data_wd_clk = 0x00;
        wd_clk_div = 0x40;
	}
    else if(wd_clk == "100us")
	{
        data_wd_clk = 0x01;
        wd_clk_div = 0x40;
	}
    else
        print("Watchdog clock setting error");
    if(wwd_src == "SPI")
        data_wwd_src = 0x02;
    else if(wwd_src == "WDI")
        data_wwd_src = 0x00;
    wwd_ethr = (wwd_ethr << 4) & 0xff;
	CmdReadData(RWDCFG0, data1);
	SERIAL{ data1[SITE] = data1[SITE] & 0x0C; } 
	SERIAL{ data1[SITE] = (data1[SITE] | wwd_ethr | data_wwd_src | data_wd_clk) & 0xff; } 
	CmdReadData(RWDCFG1, data2);
	SERIAL{ data2[SITE] = data2[SITE] & 0x1F; } 
	SERIAL{ data2[SITE] = (data2[SITE] | wd_clk_div) & 0xff; } 

	SERIAL{ data3[SITE] = int(wwd_cw_cyc/50 - 1) & 0xff; } 
	SERIAL{ data4[SITE] = int(wwd_ow_cyc/50 - 1) & 0xff; } 

    Cmd_Unlock();
    CmdWriteData(WDCFG0, data1);
    CmdWriteData(WGCFG1, data2);
    CmdWriteData(WWDCFG0, data3);
    CmdWriteData(WWDCFG1, data4);
    Cmd_Lock();
    Cmd_Get_windows_watchdog_configuration_status();
}
void Cmd_FWD_Cfg(string wd_clk, int fwd_ethr, int heart_beat)
{
	Cmd_Bank0();
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];

	int data_wd_clk;
	int wd_clk_div;

	if(wd_clk == "0.1ms")
	{
        data_wd_clk = 0x00;
        wd_clk_div = 0x00;
	}
    else if(wd_clk == "1ms")
	{
        data_wd_clk = 0x01;
        wd_clk_div = 0x00;
	}
    else if(wd_clk == "10us")
	{
        data_wd_clk = 0x00;
        wd_clk_div = 0x40;
	}
    else if(wd_clk == "100us")
	{
        data_wd_clk = 0x01;
        wd_clk_div = 0x40;
	}
    else
        print("Watchdog clock setting error");
	CmdReadData(RWDCFG0, data1);
	SERIAL{ data1[SITE] = data1[SITE] & 0xFE; } 
	SERIAL{ data1[SITE] = (data1[SITE] | data_wd_clk) & 0xff; } 
	CmdReadData(RWDCFG1, data2);
	SERIAL{ data2[SITE] = data2[SITE] & 0xB0; } 
	SERIAL{ data2[SITE] = (data2[SITE] | wd_clk_div | fwd_ethr) & 0xff; } 
	SERIAL{ data3[SITE] = int(heart_beat/50 - 1) & 0xff; } 

    Cmd_Unlock();
    CmdWriteData(WDCFG0, data1);
    CmdWriteData(WGCFG1, data2);
    CmdWriteData(FWDCFG, data3);
    Cmd_Lock();
    Cmd_Get_functional_watchdog_configuration_status();
}
void Cmd_Feed_WWD_UseSPI(void)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int trg_cmd[SITE_NUM];

	CmdReadData(WWDSCMD, data);
    //print(data)

	SERIAL
	{
		if(data[SITE] & 0x80)
			trg_cmd[SITE] = 0;
		else
			trg_cmd[SITE] = 1;
		//print(trg_cmd)
	}
    CmdWriteData(WWDSCMD, trg_cmd);
    //trg_cmd = (~self.read(0x17))>>7#���Ѵ�Լ10ms
    //CmdWriteData(0x17, trg_cmd)
}
void Cmd_WakeTimer_Cfg(string wut_clk, int wut_cyc)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int data1[SITE_NUM];

	if(wut_clk == "10us")
		SERIAL{ data1[SITE] = 0x00 << 5; } 
    else if(wut_clk == "1ms")
		SERIAL{ data1[SITE] = 0x01 << 5; } 
    else if(wut_clk == "10ms")
		SERIAL{ data1[SITE] = 0x02 << 5; } 
    else if(wut_clk == "1s")
		SERIAL{ data1[SITE] = 0x03 << 5; } 

	CmdReadData(DEVCFG0, data);
	SERIAL{ data[SITE] = data[SITE] & 0x8F | data1[SITE]; } 

    CmdWriteData(DEVCFG0, data);
    int wuk_cyc_lower = (wut_cyc) & 0xff;
    int wuk_cyc_middle = (wut_cyc >> 8) & 0xff;
    int wuk_cyc_higher = (wut_cyc >> 16) & 0xff;
    CmdWriteData(WKTIMCFG0, wuk_cyc_lower);
    CmdWriteData(WKTIMCFG1, wuk_cyc_middle);
    CmdWriteData(WKTIMCFG2, wuk_cyc_higher);
}
void Cmd_ErrMon_Cfg(string mode, string trec)
{
	Cmd_Bank0();
	int data[SITE_NUM];

	CmdReadData(RSYSPCFG1, data);

    if(mode == "immediate")
		SERIAL{ data[SITE] = data[SITE] & 0xFB; } 
    else if(mode == "recovery")
	{
		SERIAL{ data[SITE] = data[SITE] & 0xF8 | 0x04; } 
        if(trec == "1ms")
			SERIAL{ data[SITE] = data[SITE] | 0x00; } 
        else if(trec == "2.5ms")
			SERIAL{ data[SITE] = data[SITE] | 0x01; } 
        else if(trec == "5ms")
			SERIAL{ data[SITE] = data[SITE] | 0x02; } 
        else if(trec == "10ms")
			SERIAL{ data[SITE] = data[SITE] | 0x03; } 
	}
    Cmd_Unlock();
    CmdWriteData(SYSPCFG1, data);
    Cmd_Lock();
    Cmd_Get_err_monitoring_configuration_status();
}
void Cmd_Device_Ctl(int qvr, int qco, int qt1, int qt2)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	int stat[SITE_NUM];

	CmdReadData(DEVSTAT, data);
	SERIAL{ stat[SITE] = data[SITE] & 0x07; } 
	SERIAL{ data[SITE] = stat[SITE] | qvr<<3 | qco<<5 | qt1<<6 | qt2<<7; } 
    CmdWriteData(DEVCTRL, data);
	SERIAL{ data[SITE] = (~data[SITE]) & 0xff; } 
    CmdWriteData(DEVCTRLN, data);
    sleep(0.1);
    Cmd_Get_DeviceStatus();
}
void Cmd_Abist_ClkOv(bool CLK_EN, bool OV_TRIG)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	SERIAL{ data[SITE] = (CLK_EN<<1 | OV_TRIG) & 0xff; } 
    CmdWriteData(0x2D, data);
}
void Cmd_Abist_Start(bool INT, bool SINGLE, bool PATH, bool START)
{
	Cmd_Bank0();
	int data[SITE_NUM];
	SERIAL{ data[SITE] = (INT<<3 | SINGLE<<2 | PATH<<1 | START) & 0xff; } 
    CmdWriteData(ABIST_CTRL0, data);
}
void Cmd_Abist_Sel0(int select0)
{
	Cmd_Bank0();
	CmdWriteData(ABIST_SELCT0, select0);
}
void Cmd_Abist_Sel1(int select1)
{
	Cmd_Bank0();
	CmdWriteData(ABIST_SELCT1, select1);
}
void Cmd_Abist_Sel2(int select2)
{
	Cmd_Bank0();
	CmdWriteData(ABIST_SELCT2, select2);
}
void Cmd_Chk_Abist(void)
{
	Cmd_Bank0();
	int data1[SITE_NUM];
	int data2[SITE_NUM];
	int data3[SITE_NUM];
	int data4[SITE_NUM];
	int data5[SITE_NUM];

	CmdReadData(ABIST_CTRL0, data1);
	CmdReadData(0x2D, data2);
	CmdReadData(ABIST_SELCT0, data3);
	CmdReadData(ABIST_SELCT1, data4);
	CmdReadData(ABIST_SELCT2, data5);

 //   print(bin(self.read(0x2C)));
 //   print(bin(self.read(0x2D)));
 //   print(bin(self.read(0x2E)));
 //   print(bin(self.read(0x2F)));
 //   print(bin(self.read(0x30)));
    Cmd_Get_DeviceStatus();
    Cmd_Chk_Error();
}
void Cmd_Feed_FWD(void)
{
	Cmd_Bank0();
	int STAT[SITE_NUM];
	int QQ[SITE_NUM];
	int RSPC[SITE_NUM];

	CmdReadData(FWDSTAT0, STAT);

	SERIAL{ QQ[SITE] = STAT[SITE] & 0x0F; } 
    print("Question is {QQ}");

    //while(1)
    //    //sleep(0.1)
    //    RSPC[SITE] = self.read(0x2A)>>4 & 0x03
    //    A = Answer[Q][counter[RSPC]]
    //    if(RSPC[SITE] == 0)
    //        self.write(0x19, A)
    //        //print('Answer {RSPC}, {hex(A)}');
    //        break
    //    else
    //        self.write(0x18, A)
    //        //print('Answer {RSPC}, {hex(A)}');
}

