#ifndef __CFG_H_
#define __CFG_H_

#include "stdafx.h"
#define FT_FLOW

//
#define C_All_Open				cbit.SetOn(-1)


	#ifdef FT_FLOW

	////Relay
	//#define K_FPVIH_QVR					K1
	//#define K_FPVIH_QCO					K2
	//#define K_FPVIH_QUC					K3
	//#define K_FPVIH_POSSW				K4
	//#define K_FPVIH_POSIN				K5
	//#define K_FPVIH_FB					K6
	//#define K_FPVIH_SW					K7
	//#define K_FPVIH_VST					K8
	//#define K_FPVIH_VS1					K9
	//#define K_FPVIH_RSH					K10
	//#define K_FPVIL_POSG				K11
	//#define K_FPVIL_POSSW				K12
	//#define K_FPVIL_FB					K13
	//#define K_FPVIL_PG					K14
	//#define K_FPVIL_SW					K15
	//#define K_FPVIL_RSL					K16
	//#define K_FPVIL_BSG					K17
	//#define K_FPVIL_AG					K18

	//#define K_FXVI_FB					K19
	//#define K_FXVI_SW					K20
	//#define K_FXVI_RSH					K21
	//#define K_FXVI_RSL					K22
	//#define K_FXVI_ENA					K30
	//#define K_FXVI_WAK					K31
	//#define K_FXVI_SS2					K32
	//#define K_FXVI_SS1					K33
	//#define K_FXVI_SDI					K34
	//#define K_FXVI_SDO					K35
	//#define K_FXVI_SCL					K36
	//#define K_FXVI_SCS					K37
	//#define K_FXVI_WDI					K38
	//#define K_FXVI_ROT					K39
	//#define K_FXVI_INT					K40
	//#define K_FXVI_SYN					K41
	//#define K_FXVI_SSD					K41
	//#define K_FXVI_EVS					K41
	//#define K_FXVI_ERR					K42
	//#define K_FXVI_DRG					K43

	//#define K_ACM_STU						K78
	//#define K_ACM_DBUFO					K74

	//#define K_DCM_FRE						K103

	//Cap
	#define C_VST_CAP_Connect		cbitclose(K122)
	#define C_VST_CAP_DisConnect	cbitopen(K122)
	#define C_VS1_CAP_Connect		cbitclose(K126)
	#define C_VS1_CAP_DisConnect	cbitopen(K126)
	#define C_QST_CAP_Connect		cbitclose(K149)
	#define C_QST_CAP_DisConnect	cbitopen(K149)
	#define C_FB_CAP_Connect		cbitclose(K153)
	#define C_FB_CAP_DisConnect		cbitopen(K153)
	#define C_POSIN_CAP_Connect		cbitclose(K158)
	#define C_POSIN_CAP_DisConnect	cbitopen(K158)
	#define C_QUC_CAP_Connect		cbitclose(K161)
	#define C_QUC_CAP_DisConnect	cbitopen(K161)
	#define C_QVR_CAP_Connect		cbitclose(K164)
	#define C_QVR_CAP_DisConnect	cbitopen(K164)
	#define C_QCO_CAP_Connect		cbitclose(K165)
	#define C_QCO_CAP_DisConnect	cbitopen(K165)
	#define C_QT1_CAP_Connect		cbitclose(K167)
	#define C_QT1_CAP_DisConnect	cbitopen(K167)
	#define C_QT2_CAP_Connect		cbitclose(K169)
	#define C_QT2_CAP_DisConnect	cbitopen(K169)
	#define C_QT3_CAP_Connect		cbitclose(K170)
	#define C_QT3_CAP_DisConnect	cbitopen(K170)

	//GND
	#define C_AGS_BSG_PG_POSG_GND_Connect			cbitclose(K143,K144,K145,K146,K147)
	#define C_AGS_BSG_PG_POSG_GND_DisConnect		cbitopen(K143,K144,K145,K146,K147)
	#define C_AGS_BSG_PG_GND_Connect		cbitclose(K143,K144,K145,K146)
	#define C_AGS_BSG_PG_GND_DisConnect		cbitopen(K143,K144,K145,K146)
	#define C_POSG_GND_Connect				cbitclose(K147)
	#define C_POSG_GND_DisConnect			cbitopen(K147)
	#define C_PG_GND_Connect				cbitclose(K146)
	#define C_PG_GND_DisConnect				cbitopen(K146)
	#define C_TP_GND_Connect				cbitclose(K145)
	#define C_TP_GND_DisConnect				cbitopen(K145)
	#define C_AGS_GND_Connect				cbitclose(K143)
	#define C_AGS_GND_DisConnect			cbitopen(K143)
	#define C_FXVI_ACM_GND_Connect			cbitopen(K93,K95,K96,K97);delay_ms(2);cbitclose(K92,K94)
	#define C_FXVI_ACM_GND_DisConnect		cbitopen(K92,K93,K94,K95,K96,K97)
	#define C_FXVI_ACM_LDO_Connect			cbitopen(K92,K94,K96,K97);delay_ms(2);cbitclose(K93,K95)
	#define C_FXVI_ACM_LDO_DisConnect		cbitopen(K92,K93,K94,K95,K96,K97)
	#define C_FXVI_ACM_L_Connect			cbitclose(K93,K95)
	#define C_FXVI_ACM_L_DisConnect			cbitopen(K93,K95)

	//FPVI
	#define C_FPVIH_DisConnect		cbitopen(K1,K2,K3,K4,K5,K6,K7,K8,K9,K10)
	#define C_FPVIH_QVR_Connect		cbitclose(K1)
	#define C_FPVIH_QVR_DisConnect	cbitopen(K1)
	#define C_FPVIH_QCO_Connect		cbitclose(K2)
	#define C_FPVIH_QCO_DisConnect	cbitopen(K2)
	#define C_FPVIH_QUC_Connect		cbitclose(K3)
	#define C_FPVIH_QUC_DisConnect	cbitopen(K3)
	#define C_FPVIH_POSSW_Connect	cbitclose(K4)
	#define C_FPVIH_POSSW_DisConnect cbitopen(K4)
	#define C_FPVIH_POSIN_Connect	cbitclose(K5)
	#define C_FPVIH_POSIN_DisConnect cbitopen(K5)
	#define C_FPVIH_FB_Connect		cbitclose(K6)
	#define C_FPVIH_FB_DisConnect	cbitopen(K6)
	#define C_FPVIH_SW_Connect		cbitclose(K7)
	#define C_FPVIH_SW_DisConnect	cbitopen(K7)
	#define C_FPVIH_VST_Connect		cbitclose(K8)
	#define C_FPVIH_VST_DisConnect	cbitopen(K8)
	#define C_FPVIH_VS1_Connect		cbitclose(K9)
	#define C_FPVIH_VS1_DisConnect	cbitopen(K9)
	#define C_FPVIH_RSH_Connect		cbitclose(K10)
	#define C_FPVIH_RSH_DisConnect	cbitopen(K10)

	#define C_FPVIL_DisConnect		cbitopen(K11,K12,K13,K14,K15,K16,K17,K18)
	#define C_FPVIL_POSG_Connect	cbitclose(K11)
	#define C_FPVIL_POSG_DisConnect	cbitopen(K11)
	#define C_FPVIL_POSSW_Connect	cbitclose(K12)
	#define C_FPVIL_POSSW_DisConnect cbitopen(K12)
	#define C_FPVIL_FB_Connect		cbitclose(K13)
	#define C_FPVIL_FB_DisConnect	cbitopen(K13)
	#define C_FPVIL_PG_Connect		cbitclose(K14)
	#define C_FPVIL_PG_DisConnect	cbitopen(K14)
	#define C_FPVIL_SW_Connect		cbitclose(K15)
	#define C_FPVIL_SW_DisConnect	cbitopen(K15)
	#define C_FPVIL_RSL_Connect		cbitclose(K16)
	#define C_FPVIL_RSL_DisConnect	cbitopen(K16)
	#define C_FPVIL_BSG_Connect		cbitclose(K17)
	#define C_FPVIL_BSG_DisConnect	cbitopen(K17)
	#define C_FPVIL_AG_Connect		cbitclose(K18)
	#define C_FPVIL_AG_DisConnect	cbitopen(K18)

	//FXVI
	#define C_FXVIL_GND_Connect		cbitopen(K95,K96);delay_ms(2);cbitclose(K94)
	#define C_FXVIL_LDO_Connect		cbitopen(K94,K96);delay_ms(2);cbitclose(K95)
	#define C_FXVIL_FB_Connect		cbitopen(K94,K95);delay_ms(2);cbitclose(K96)
	#define C_FXVI_FB_Connect		cbitclose(K19)
	#define C_FXVI_FB_DisConnect	cbitopen(K19)
	#define C_FXVI_SW_Connect		cbitclose(K20)
	#define C_FXVI_SW_DisConnect	cbitopen(K20)
	#define C_FXVI_RSH_Connect		cbitclose(K21)
	#define C_FXVI_RSH_DisConnect	cbitopen(K21)
	#define C_FXVI_RSL_Connect		cbitclose(K22)
	#define C_FXVI_RSL_DisConnect	cbitopen(K22)
	#define C_FXVI_ENA_Connect		cbitclose(K30)
	#define C_FXVI_ENA_DisConnect	cbitopen(K30)
	#define C_FXVI_WAK_Connect		cbitclose(K31)
	#define C_FXVI_WAK_DisConnect	cbitopen(K31)
	#define C_FXVI_SS2_Connect		cbitclose(K32)
	#define C_FXVI_SS2_DisConnect	cbitopen(K32)
	#define C_FXVI_SS1_Connect		cbitclose(K33)
	#define C_FXVI_SS1_DisConnect	cbitopen(K33)
	#define C_FXVI_SDI_Connect		cbitclose(K34)
	#define C_FXVI_SDI_DisConnect	cbitopen(K34)
	#define C_FXVI_SDO_Connect		cbitclose(K35)
	#define C_FXVI_SDO_DisConnect	cbitopen(K35)
	#define C_FXVI_SCL_Connect		cbitclose(K36)
	#define C_FXVI_SCL_DisConnect	cbitopen(K36)
	#define C_FXVI_SCS_Connect		cbitclose(K37)
	#define C_FXVI_SCS_DisConnect	cbitopen(K37)
	#define C_FXVI_WDI_Connect		cbitclose(K38)
	#define C_FXVI_WDI_DisConnect	cbitopen(K38)
	#define C_FXVI_ROT_Connect		cbitclose(K39)
	#define C_FXVI_ROT_DisConnect	cbitopen(K39)
	#define C_FXVI_INT_Connect		cbitclose(K40)
	#define C_FXVI_INT_DisConnect	cbitopen(K40)
	#define C_FXVI_SYN_Connect		cbitclose(K41)
	#define C_FXVI_SYN_DisConnect	cbitopen(K41)
	#define C_FXVI_SSD_Connect		cbitclose(K41)
	#define C_FXVI_SSD_DisConnect	cbitopen(K41)
	#define C_FXVI_EVS_Connect		cbitclose(K41)
	#define C_FXVI_EVS_DisConnect	cbitopen(K41)
	#define C_FXVI_ERR_Connect		cbitclose(K42)
	#define C_FXVI_ERR_DisConnect	cbitopen(K42)
	#define C_FXVI_DRG_Connect		cbitclose(K43)
	#define C_FXVI_DRG_DisConnect	cbitopen(K43)
	#define C_FXVI_BATSNS1_Connect		cbitclose(K50)
	#define C_FXVI_BATSNS1_DisConnect	cbitopen(K50)
	#define C_FXVI_BATSNS2_Connect		cbitclose(K51)
	#define C_FXVI_BATSNS2_DisConnect	cbitopen(K51)
	#define C_FXVI_SQT2_Connect		cbitclose(K52)
	#define C_FXVI_SQT2_DisConnect	cbitopen(K52)
	#define C_FXVI_SQT1_Connect		cbitclose(K53)
	#define C_FXVI_SQT1_DisConnect	cbitopen(K53)
	#define C_FXVI_SW2_Connect		cbitclose(K54)
	#define C_FXVI_SW2_DisConnect	cbitopen(K54)
	#define C_FXVI_VS2_Connect		cbitclose(K55)
	#define C_FXVI_VS2_DisConnect	cbitopen(K55)
	#define C_FXVI_BSG_Connect		cbitclose(K56)
	#define C_FXVI_BSG_DisConnect	cbitopen(K56)
	#define C_FXVI_AGS_Connect		cbitclose(K57)
	#define C_FXVI_AGS_DisConnect	cbitopen(K57)
	#define C_FXVI_PSRR_Connect		cbitclose(K58)
	#define C_FXVI_PSRR_DisConnect	cbitopen(K58)
	#define C_FXVI_TPAD_Connect		cbitclose(K59)
	#define C_FXVI_TPAD_DisConnect	cbitopen(K59)
	#define C_FXVI_RSL2_Connect		cbitclose(K60)
	#define C_FXVI_RSL2_DisConnect	cbitopen(K60)

	//ACM
	#define C_ACML_GND_Connect		cbitopen(K93,K97);delay_ms(2);cbitclose(K92)
	#define C_ACML_GND_DisConnect	cbitopen(K92)
	#define C_ACML_LDO_Connect		cbitopen(K92,K97);delay_ms(2);cbitclose(K93)
	#define C_ACML_LDO_DisConnect	cbitopen(K93)
	#define C_ACML_FB_Connect		cbitopen(K92,K93);delay_ms(2);cbitclose(K97)
	#define C_ACM_EXSI_Connect		cbitclose(K61)
	#define C_ACM_EXSI_DisConnect	cbitopen(K61)
	#define C_ACM_VCI_Connect		cbitclose(K62)
	#define C_ACM_VCI_DisConnect	cbitopen(K62)
	#define C_ACM_VMON_Connect		cbitclose(K62)
	#define C_ACM_VMON_DisConnect	cbitopen(K62)
	#define C_ACM_SEC_Connect		cbitclose(K63)
	#define C_ACM_SEC_DisConnect	cbitopen(K63)
	#define C_ACM_AMUX_Connect		cbitclose(K63)
	#define C_ACM_AMUX_DisConnect	cbitopen(K63)
	#define C_ACM_ABUFO_Connect		cbitclose(K64)
	#define C_ACM_ABUFO_DisConnect	cbitopen(K64)
	#define C_ACM_EVC_Connect		cbitclose(K65)
	#define C_ACM_EVC_DisConnect	cbitopen(K65)
	#define C_ACM_POSFRE_Connect	cbitclose(K65)
	#define C_ACM_POSFRE_DisConnect	cbitopen(K65)
	#define C_ACM_EVC2_Connect		cbitclose(K70)
	#define C_ACM_EVC2_DisConnect	cbitopen(K70)
	#define C_ACM_POSFRE2_Connect	cbitclose(K70)
	#define C_ACM_POSFRE2_DisConnect	cbitopen(K70)
	#define C_ACM_SEC2_Connect		cbitclose(K71)
	#define C_ACM_SEC2_DisConnect	cbitopen(K71)
	#define C_ACM_AMUX2_Connect		cbitclose(K71)
	#define C_ACM_AMUX2_DisConnect	cbitopen(K71)
	#define C_ACM_NC_Connect		cbitclose(K72)
	#define C_ACM_NC_DisConnect		cbitopen(K72)
	#define C_ACM_SYNEVSSSD_Connect		cbitclose(K73)
	#define C_ACM_SYNEVSSSD_DisConnect	cbitopen(K73)
	#define C_ACM_SYN_Connect		cbitclose(K73)
	#define C_ACM_SYN_DisConnect	cbitopen(K73)
	#define C_ACM_EVS_Connect		cbitclose(K73)
	#define C_ACM_EVS_DisConnect	cbitopen(K73)
	#define C_ACM_SSD_Connect		cbitclose(K73)
	#define C_ACM_SSD_DisConnect	cbitopen(K73)
	#define C_ACM_DBUFO_Connect		cbitclose(K74)
	#define C_ACM_DBUFO_DisConnect	cbitopen(K74)
	#define C_ACM_DIODE_Connect		cbitclose(K75)
	#define C_ACM_DIODE_DisConnect	cbitopen(K75)
	#define C_ACM_ABUFO2_Connect	cbitclose(K77)
	#define C_ACM_ABUFO2_DisConnect	cbitopen(K77)
	#define C_ACM_STU_Connect		cbitclose(K78)
	#define C_ACM_STU_DisConnect	cbitopen(K78)
	#define C_ACM_PG_Connect		cbitclose(K212)
	#define C_ACM_PG_DisConnect		cbitopen(K212)
	#define C_ACM_FB1_Connect		cbitclose(K213)
	#define C_ACM_FB1_DisConnect	cbitopen(K213)
	#define C_ACM_FB2_Connect		cbitclose(K214)
	#define C_ACM_FB2_DisConnect	cbitopen(K214)
	#define C_ACM_FB3_Connect		cbitclose(K215)
	#define C_ACM_FB3_DisConnect	cbitopen(K215)
	#define C_ACM_FB4_Connect		cbitclose(K216)
	#define C_ACM_FB4_DisConnect	cbitopen(K216)
	#define C_ACM_POSG_Connect		cbitclose(K217)
	#define C_ACM_POSG_DisConnect	cbitopen(K217)
	#define C_ACM_SQUC_Connect		cbitclose(K218)
	#define C_ACM_SQUC_DisConnect	cbitopen(K218)
	#define C_ACM_MPS_Connect		cbitclose(K219)
	#define C_ACM_MPS_DisConnect	cbitopen(K219)

	//DCM
	#define C_DCM_DBUFO_Connect		cbitclose(K79)
	#define C_DCM_DBUFO_DisConnect	cbitopen(K79)
	#define C_DCM_I2C_Connect		cbitclose(K76,K80)
	#define C_DCM_I2C_DisConnect	cbitopen(K76,K80)
	#define C_DCM_DRG_Connect		cbitclose(K99)
	#define C_DCM_DRG_DisConnect	cbitopen(K99)
	#define C_DCM_SEC_Connect		cbitclose(K102)
	#define C_DCM_SEC_DisConnect	cbitopen(K102)
	#define C_DCM_AMUX_Connect		cbitclose(K102)
	#define C_DCM_AMUX_DisConnect	cbitopen(K102)
	#define C_DCM_FRE_Connect		cbitclose(K103)
	#define C_DCM_FRE_DisConnect	cbitopen(K103)
	#define C_DCM_POSFRE_Connect	cbitclose(K104)
	#define C_DCM_POSFRE_DisConnect	cbitopen(K104)
	#define C_DCM_SYN_Connect		cbitclose(K105)
	#define C_DCM_SYN_DisConnect	cbitopen(K105)
	#define C_DCM_EVS_Connect		cbitclose(K105)
	#define C_DCM_EVS_DisConnect	cbitopen(K105)
	#define C_DCM_SSD_Connect		cbitclose(K105)
	#define C_DCM_SSD_DisConnect	cbitopen(K105)
	#define C_DCM_ENA_Connect		cbitclose(K106)
	#define C_DCM_ENA_DisConnect	cbitopen(K106)
	#define C_DCM_WAK_Connect		cbitclose(K107)
	#define C_DCM_WAK_DisConnect	cbitopen(K107)
	#define C_DCM_WDI_Connect		cbitclose(K108)
	#define C_DCM_WDI_DisConnect	cbitopen(K108)
	#define C_DCM_STU_Connect		cbitclose(K110)
	#define C_DCM_STU_DisConnect	cbitopen(K110)
	#define C_DCM_ROT_Connect		cbitclose(K111)
	#define C_DCM_ROT_DisConnect	cbitopen(K111)
	#define C_DCM_INT_Connect		cbitclose(K112)
	#define C_DCM_INT_DisConnect	cbitopen(K112)
	#define C_DCM_SS2_Connect		cbitclose(K113)
	#define C_DCM_SS2_DisConnect	cbitopen(K113)
	#define C_DCM_SS1_Connect		cbitclose(K114)
	#define C_DCM_SS1_DisConnect	cbitopen(K114)
	#define C_DCM_ERR_Connect		cbitclose(K115)
	#define C_DCM_ERR_DisConnect	cbitopen(K115)
	#define C_DCM_SNSCS_Connect		cbitclose(K117)
	#define C_DCM_SNSCS_DisConnect	cbitopen(K117)
	#define C_DCM_LSICS_Connect		cbitclose(K118)
	#define C_DCM_LSICS_DisConnect	cbitopen(K118)
	#define C_DCM_ESDO_Connect		cbitclose(K119)
	#define C_DCM_ESDO_DisConnect	cbitopen(K119)
	#define C_DCM_ESCK_Connect		cbitclose(K120)
	#define C_DCM_ESCK_DisConnect	cbitopen(K120)
	#define C_DCM_ESDI_Connect		cbitclose(K121)
	#define C_DCM_ESDI_DisConnect	cbitopen(K121)

	#define C_DDS_WDI_Connect		cbitclose(K109)
	#define C_DDS_WDI_DisConnect	cbitopen(K109)
	#define C_DDS_ERR_Connect		cbitclose(K116)
	#define C_DDS_ERR_DisConnect	cbitopen(K116)

	//QVM
	#define C_QVM_RESET				cbitopen(K_QVM)
	#define C_QVM_1357				cbitopen(K_QVM)
	#define C_QVM_2468				cbitclose(K_QVM)
	#define C_QVM_DisConnect		cbitopen(K81,K82,K83,K84,K85,K86,K87,K88,K89,K90,K91)
	#define C_QVMH_DisConnect		cbitopen(K81,K82,K83,K84,K85,K86,K87,K88,K89)
	#define C_QVML_DisConnect		cbitopen(K90,K91)
	#define C_QVMH_DUTSI_Connect	cbitclose(K81)
	#define C_QVMH_DUTSO_Connect	cbitclose(K82)
	#define C_QVMH_DRVSI_Connect	cbitclose(K83)
	#define C_QVMH_DRVSO_Connect	cbitclose(K84)
	#define C_QVMH_DDSO_Connect		cbitclose(K85)
	#define C_QVMH_ABUFO_Connect	cbitclose(K86)
	#define C_QVMH_STU_Connect		cbitclose(K87)
	#define C_QVMH_LDO_Connect		cbitclose(K88)
	#define C_QVMH_RSH_Connect		cbitclose(K89)
	#define C_QVML_RSL_Connect		cbitclose(K90)
	#define C_QVML_GND_Connect		cbitclose(K91)

	//QTMU_PLUS
	#define C_QTMU_1357				cbitopen(K_QTMU)
	#define C_QTMU_2468				cbitclose(K_QTMU)
	#define C_QTMU_DisConnect		cbitopen(K220,K221,K222,K223,K224,K225)
	#define C_QTMUA_DisConnect		cbitopen(K220,K221,K222)
	#define C_QTMUB_DisConnect		cbitopen(K223,K224,K225)
	#define C_QTMUA_DBUFO_Connect	cbitclose(K220)
	#define C_QTMUA_SPICS_Connect	cbitclose(K221)
	#define C_QTMUA_SS1_Connect		cbitclose(K222)
	#define C_QTMUB_DBUFO_Connect	cbitclose(K223)
	#define C_QTMUB_PWRX_Connect	cbitclose(K224)
	#define C_QTMUB_SS2_Connect		cbitclose(K225)

	//ABUF
	#define C_ABUF_Usage			cbitclose(K_EN_ABUF)
	#define C_ABUF_Bypass			cbitopen(K_EN_ABUF)
	#define C_ABUFI_DisConnect		cbitopen(K171,K172,K173,K174,K175,K176,K177,K178,K179,K180)
	#define C_ABUFI_STU				cbitclose(K171)
	#define C_ABUFI_POSFRE			cbitclose(K172)
	#define C_ABUFI_SECAMUX			cbitclose(K173)
	#define C_ABUFI_RSH				cbitclose(K174)
	#define C_ABUFI_SW1				cbitclose(K175)
	#define C_ABUFI_POSSW			cbitclose(K176)
	#define C_ABUFI_SYNSECEVS		cbitclose(K177)
	#define C_ABUFI_RCLDOUT1		cbitclose(K178)
	#define C_ABUFI_RCLDOUT2		cbitclose(K179)
	#define C_ABUFI_VCIVMON			cbitclose(K180)

	//DBUF
	#define C_DBUF_Usage			cbitclose(K_EN_DBUF)
	#define C_DBUF_Bypass			cbitopen(K_EN_DBUF)
	#define C_DBUFI_DisConnect		cbitopen(K181,K182,K183,K184,K185,K186,K187,K188,K189,K190,K191,K192,K193,K194,K195,K196,K197,K198,K199)
	#define C_DBUFI_STU				cbitclose(K181)
	#define C_DBUFI_FRE				cbitclose(K182)
	#define C_DBUFI_POSFRE			cbitclose(K183)
	#define C_DBUFI_SECAMUX			cbitclose(K184)
	#define C_DBUFI_DRG				cbitclose(K185)
	#define C_DBUFI_SW1				cbitclose(K186)
	#define C_DBUFI_POSSW			cbitclose(K187)
	#define C_DBUFI_DDSO			cbitclose(K188)
	#define C_DBUFI_ENA				cbitclose(K189)
	#define C_DBUFI_WAK				cbitclose(K190)
	#define C_DBUFI_SYNSSDEVS		cbitclose(K191)
	#define C_DBUFI_VCIVMON			cbitclose(K192)
	#define C_DBUFI_INT				cbitclose(K193)
	#define C_DBUFI_ROT				cbitclose(K194)
	#define C_DBUFI_ERR				cbitclose(K195)
	#define C_DBUFI_SS1				cbitclose(K196)
	#define C_DBUFI_SS2				cbitclose(K197)
	#define C_DBUFI_WDI				cbitclose(K198)
	#define C_DBUFI_ABUFO			cbitclose(K199)

	//SPI
	#define C_SPI_DUT				cbitopen(K117,K118,K119,K120,K121)
	#define C_SCAN_Connect			cbitopen(K117,K118,K119,K120,K121);delay_ms(2);cbitclose(K115);
	#define C_SCAN_DisConnect		cbitopen(K117,K118,K119,K120,K121,K115)
	#define C_SNS_Connect			cbitopen(K118);delay_ms(2);cbitclose(K117,K119,K120,K121)
	#define C_SNS_DisConnect		cbitopen(K117,K119,K120,K121)
	#define C_LSI_Connect			cbitopen(K117);delay_ms(2);cbitclose(K118,K120,K121)
	#define C_LSI_DisConnect		cbitopen(K118,K120,K121)

	//I2C
	#define C_I2C_Connect			cbitclose(K76,K80)
	#define C_I2C_DisConnect		cbitopen(K76,K80)

	//LSI
	#define C_PWRX_QST_Connect		cbitclose(K203)
	#define C_PWRX_QST_DisConnect	cbitopen(K203)
	#define C_PWRX_QUC_Connect		cbitclose(K204)
	#define C_PWRX_QUC_DisConnect	cbitopen(K204)
	#define C_PWRX_QCO_Connect		cbitclose(K205)
	#define C_PWRX_QCO_DisConnect	cbitopen(K205)
	#define C_PWRX_QVR_Connect		cbitclose(K206)
	#define C_PWRX_QVR_DisConnect	cbitopen(K206)
	#define C_PWRX_QT1_Connect		cbitclose(K207)
	#define C_PWRX_QT1_DisConnect	cbitopen(K207)
	#define C_PWRX_QT2_Connect		cbitclose(K208)
	#define C_PWRX_QT2_DisConnect	cbitopen(K208)
	#define C_PWRX_QT3_Connect		cbitclose(K209)
	#define C_PWRX_QT3_DisConnect	cbitopen(K209)
	#define C_PWRX_VST_Connect		cbitclose(K210)
	#define C_PWRX_VST_DisConnect	cbitopen(K210)
	#define C_PWRX_VS1_Connect		cbitclose(K211)
	#define C_PWRX_VS1_DisConnect	cbitopen(K211)
	#define C_PWRX_DisConnect		cbitopen(K203,K204,K205,K206,K207,K208,K209,K210,K211)

	#define C_LSI_RSH_RSL_Connect		cbitclose(K133_134)
	#define C_LSI_RSH_RSL_DisConnect	cbitopen(K133_134)
	#define C_LSI_DIFPN_Connect			cbitclose(K100)
	#define C_LSI_DIFPN_DisConnect		cbitopen(K100)
	#define C_LSI_DUTO_PWRX_Connect		cbitclose(K200)
	#define C_LSI_DUTO_PWRX_DisConnect	cbitopen(K200)
	#define C_LSI_DUTI_FB_Connect		cbitclose(K201)
	#define C_LSI_DUTI_FB_DisConnect	cbitopen(K201)
	#define C_LSI_DUTI_VST_Connect		cbitclose(K202)
	#define C_LSI_DUTI_VST_DisConnect	cbitopen(K202)
	#define C_LSI_DUTI_DisConnect		cbitopen(K201,K202)

	//#define C_LSI_LDO_Enable			cbitclose(K_EN_LDO)
	//#define C_LSI_LDO_Disable			cbitopen(K_EN_LDO)
	//#define C_LSI_OUT_Enable			cbitclose(K_EN_OUT)
	//#define C_LSI_OUT_Disable			cbitopen(K_EN_OUT)

	//#define C_LSI_SPI_Enable			cbitclose(K_EN_SPI)
	//#define C_LSI_SPI_Disable			cbitopen(K_EN_SPI)
	//#define C_LSI_I2C_Enable			cbitopen(K_EN_SPI)
	//#define C_LSI_I2C_Disable			cbitclose(K_EN_SPI)

	//#define C_LSI_EXSI_Enable			cbitclose(K_EN_EXSI)
	//#define C_LSI_EXSI_Disable			cbitopen(K_EN_EXSI)
	//#define C_LSI_SPI_DDS				cbitopen(K_SEL_SPI)
	//#define C_LSI_SPI_AD8400			cbitclose(K_SEL_SPI)
	//#define C_LSI_SPI_DFT				cbitopen(K_SEL_SPI)

	//PULL RES
	#define C_ACM_VCIVMON_Connect		if(PN_VCI_Available){C_ACM_VCI_Connect;}else{C_ACM_VMON_Connect;}
	#define C_ACM_VCIVMON_DisConnect	if(PN_VCI_Available){C_ACM_VCI_DisConnect;}else{C_ACM_VMON_DisConnect;}
	#define C_ACM_SECPOSFRE_Connect		if(PN_SEC_Available){C_ACM_SEC_Connect;}else{C_ACM_POSFRE_Connect;}
	#define C_ACM_SECPOSFRE_DisConnect	if(PN_SEC_Available){C_ACM_SEC_DisConnect;}else{C_ACM_POSFRE_DisConnect;}
	#define C_DCM_SECPOSFRE_Connect		if(PN_SEC_Available){C_DCM_SEC_Connect;}else{C_DCM_POSFRE_Connect;}
	#define C_DCM_SECPOSFRE_DisConnect	if(PN_SEC_Available){C_DCM_SEC_DisConnect;}else{C_DCM_POSFRE_DisConnect;}

	//CONNECTION
	#define C_VST_VS1_Connect			cbitclose(K123)
	#define C_VST_VS1_DisConnect		cbitopen(K123)
	#define C_VST_SEC_Connect			cbitclose(K124)
	#define C_VST_SEC_DisConnect		cbitopen(K124)
	#define C_VST_AMUX_Connect			cbitclose(K124)
	#define C_VST_AMUX_DisConnect		cbitopen(K124)
	#define C_VST_POSFRE_Connect		cbitclose(K125)
	#define C_VST_POSFRE_DisConnect		cbitopen(K125)
	#define C_VS1_VS2_Connect			cbitclose(K130)
	#define C_VS1_VS2_DisConnect		cbitopen(K130)
	#define C_VS1_BATSNS1_Connect		cbitclose(K131)
	#define C_VS1_BATSNS1_DisConnect	cbitopen(K131)
	#define C_VS1_BATSNS2_Connect		cbitclose(K132)
	#define C_VS1_BATSNS2_DisConnect	cbitopen(K132)
	#define C_RSX_LSI_Connect			cbitclose(K133_134)
	#define C_RSX_LSI_DisConnect		cbitopen(K133_134)
	#define C_RSL_PD_Connect			cbitclose(K135)
	#define C_RSL_PD_DisConnect			cbitopen(K135)
	#define C_VCI_PD_Connect			cbitclose(K136)
	#define C_VCI_PD_DisConnect			cbitopen(K136)
	#define C_VMON_PD_Connect			cbitclose(K136)
	#define C_VMON_PD_DisConnect		cbitopen(K136)
	#define C_FRE_PU_Connect			cbitclose(K137)
	#define C_FRE_PU_DisConnect			cbitopen(K137)
	#define C_FRE_PD_Connect			cbitclose(K138)
	#define C_FRE_PD_DisConnect			cbitopen(K138)
	#define C_EVC_PD_Connect			cbitclose(K139)
	#define C_EVC_PD_DisConnect			cbitopen(K139)
	#define C_POSFRE_PD_Connect			cbitclose(K139)
	#define C_POSFRE_PD_DisConnect		cbitopen(K139)
	#define C_SYN_PD_Connect			cbitclose(K140)
	#define C_SYN_PD_DisConnect			cbitopen(K140)
	#define C_EVS_PD_Connect			cbitclose(K140)
	#define C_EVS_PD_DisConnect			cbitopen(K140)
	#define C_SSD_PD_Connect			cbitclose(K140)
	#define C_SSD_PD_DisConnect			cbitopen(K140)
	#define C_ROT_PU_Connect			cbitclose(K141)
	#define C_ROT_PU_DisConnect			cbitopen(K141)
	#define C_ERR_PD_Connect			cbitclose(K142)
	#define C_ERR_PD_DisConnect			cbitopen(K142)
	#define C_SW_PD_Connect				cbitclose(K150)
	#define C_SW_PD_DisConnect			cbitopen(K150)
	#define C_SW1_SW2_Connect			cbitclose(K151)
	#define C_SW1_SW2_DisConnect		cbitopen(K151)
	#define C_FB1_FB2_Connect			cbitclose(K154)
	#define C_FB1_FB2_DisConnect		cbitopen(K154)
	#define C_FB1_FB3_Connect			cbitclose(K155)
	#define C_FB1_FB3_DisConnect		cbitopen(K155)
	#define C_FB1_FB4_Connect			cbitclose(K156)
	#define C_FB1_FB4_DisConnect		cbitopen(K156)
	#define C_FB_POSIN_Connect			cbitclose(K157)
	#define C_FB_POSIN_DisConnect		cbitopen(K157)
	#define C_QUC_SQUC_Connect			cbitclose(K160)
	#define C_QUC_SQUC_DisConnect		cbitopen(K160)
	#define C_MPS_PD_Connect			cbitclose(K162)
	#define C_MPS_PD_DisConnect			cbitopen(K162)
	#define C_MPS_PU_Connect			cbitclose(K163)
	#define C_MPS_PU_DisConnect			cbitopen(K163)
	#define C_QT1_SQT1_Connect			cbitclose(K166)
	#define C_QT1_SQT1_DisConnect		cbitopen(K166)
	#define C_QT2_SQT2_Connect			cbitclose(K168)
	#define C_QT2_SQT2_DisConnect		cbitopen(K168)


	//LOAD
	#define C_PREBK_LOAD1_Connect		cbitclose(K152)
	#define C_PREBK_LOAD1_DisConnect	cbitopen(K152)
	#define C_POSBK_LOAD2_Connect		cbitclose(K159)
	#define C_POSBK_LOAD2_DisConnect	cbitopen(K159)

	#define C_LOAD1_RC_Connect			cbitclose(K230)
	#define C_LOAD1_RC_DisConnect		cbitopen(K230)
	#define C_LOAD1_LC_Connect			cbitclose(K231)
	#define C_LOAD1_LC_DisConnect		cbitopen(K231)
	#define C_LOAD1_1K_Connect			cbitclose(K232)
	#define C_LOAD1_1K_DisConnect		cbitopen(K232)

	#define C_LOAD2_RC_Connect			cbitclose(K233)
	#define C_LOAD2_RC_DisConnect		cbitopen(K233)
	#define C_LOAD2_LC_Connect			cbitclose(K234)
	#define C_LOAD2_LC_DisConnect		cbitopen(K234)
	#define C_LOAD2_1K_Connect			cbitclose(K235)
	#define C_LOAD2_1K_DisConnect		cbitopen(K235)

	#define C_LOAD1_Connect				C_LOAD1_RC_Connect
	#define C_LOAD1_DisConnect			C_LOAD1_RC_DisConnect
	#define C_LOAD2_Connect				C_LOAD2_RC_Connect
	#define C_LOAD2_DisConnect			C_LOAD2_RC_DisConnect

	#define C_LOAD1_Discharge_Connect		cbitclose(K230,K231,K232)
	#define C_LOAD1_Discharge_DisConnect	cbitopen(K230,K231,K232)
	#define C_LOAD2_Discharge_Connect		cbitclose(K233,K234,K235)
	#define C_LOAD2_Discharge_DisConnect	cbitopen(K233,K234,K235)


	//Conty
	#define C_Conty_GroupA_Connect		cbitclose(K8,K18,K21,K50,K78,K62,K63,K218,K99,K105,K111,K114)
	#define C_Conty_GroupA_DisConnect	cbitopen(K8,K18,K21,K50,K78,K62,K63,K218,K99,K105,K111,K114)
	#define C_Conty_GroupB_Connect		cbitclose(K22,K51,K65,K72,K214,K103,K107,K112,K115)
	#define C_Conty_GroupB_DisConnect	cbitopen(K22,K51,K65,K72,K214,K103,K107,K112,K115)
	#define C_Conty_GroupC_Connect		cbitclose(K19,K54,K219,K106,K108,K113)
	#define C_Conty_GroupC_DisConnect	cbitopen(K19,K54,K219,K106,K108,K113)
	#define C_Conty_GroupD_Connect		cbitclose(K20,K53,K215)
	#define C_Conty_GroupD_DisConnect	cbitopen(K20,K53,K215)
	#define C_Conty_GroupE_Connect		cbitclose(K52,K216)
	#define C_Conty_GroupE_DisConnect	cbitopen(K52,K216)
	#define C_Conty_GroupF_Connect		cbitclose(K57,K212)
	#define C_Conty_GroupF_DisConnect	cbitopen(K57,K212)
	#define C_Conty_GroupG_Connect		cbitclose(K56,K217)
	#define C_Conty_GroupG_DisConnect	cbitopen(K56,K217)
	#define C_Conty_GroupH_Connect		cbitclose(K55)
	#define C_Conty_GroupH_DisConnect	cbitopen(K55)
	#define C_Conty_GroupI_Connect		cbitclose(K145)
	#define C_Conty_GroupI_DisConnect	cbitopen(K145)

	//P2P Leak
	#define C_P2P_Connect				cbit.SetOn(-1)
	#define C_P2P_DisConnect			cbit.SetOn(-1)
	#define C_P2P_GroupA_Connect		cbit.SetOn(-1)
	#define C_P2P_GroupA_DisConnect		cbit.SetOn(-1)
	#define C_P2P_GroupB_Connect		cbit.SetOn(-1)
	#define C_P2P_GroupB_DisConnect		cbit.SetOn(-1)
	#define C_P2P_GroupC_Connect		cbit.SetOn(-1)
	#define C_P2P_GroupC_DisConnect		cbit.SetOn(-1)

	//Leak
	#define C_Leak_Connect				cbit.SetOn(-1)
	#define C_Leak_DisConnect			cbit.SetOn(-1)



	#else


	#endif



#endif