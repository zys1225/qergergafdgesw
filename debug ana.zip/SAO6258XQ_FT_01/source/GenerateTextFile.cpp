#include "StdAfx.h"
#include "GenerateTextFile.h"
#include "SPEC.h"
#include "myConstant.h"

//// generate tcs analysis raw data
//BOOL CGenerateTextFile::generate_csv_tcs(map<string,CAccoCsvData> &acco_data, string& error){
//	string file;
//
//	if(acco_data.empty()){
//		error = "Error: acco_data is empty, when generate tcs csv...";
//		return FALSE;
//	}
//
//	// calculate site number
//	int site_num = 0;
//	map<string, DWORD> cnt_map;
//	for(map<string,CAccoCsvData>::iterator it_top = acco_data.begin(); it_top != acco_data.end(); ++it_top){
//		for(map<DWORD,string>::iterator it = it_top->second.site_map.begin(); it != it_top->second.site_map.end(); ++it){
//			cnt_map[it->second]++;
//		}
//	}
//	site_num = (int)cnt_map.size();
//
//	///////////////////////////////////////////////////
//	// generate partid map
//	map<DWORD, string> partid_map; // map<serial, partid>
//	list<int> list_site;
//	int off_set = 0;
//	int shift_cnt = 0;
//	DWORD serial = 1;
//
//	for(map<string,CAccoCsvData>::iterator it_top = acco_data.begin(); it_top != acco_data.end(); ++it_top){
//		for(map<DWORD,string>::iterator it = it_top->second.site_map.begin(); it != it_top->second.site_map.end(); ++it){
//			if((it->first - 1) % site_num == 0){
//				// init list
//				list_site.clear();
//				for(int site = 1; site <= site_num; ++site)
//					list_site.push_back(site);
//				// shift list
//				for(int i = 0; i < shift_cnt; ++i){
//					int temp = list_site.front();
//					list_site.pop_front();
//					list_site.push_back(temp);
//				}
//				// add offset to list
//				for(list<int>::iterator it_list = list_site.begin(); it_list != list_site.end(); ++it_list){
//					partid_map[serial++] = mylib.int2str((*it_list) + off_set);
//				}
//
//				if(shift_cnt == site_num - 1){	
//					shift_cnt = 0;
//				} else
//					shift_cnt++;
//
//				// can't be (serial - 1) / site_num, they are different
//				off_set = ((serial - 1) / (site_num * site_num)) * site_num;
//			}
//		}
//	}
//
//
//	size_t file_size = 10*1024*1024;
//
//	char *buf = NULL; 
//	buf = (char *)malloc(file_size * sizeof(char)); 
//	if (NULL == buf) 
//	{ 
//		error = "Error: malloc fail...";
//		free(buf); 
//		buf = NULL; 
//		return FALSE;
//	} 
//
//	DWORD size_final = 0;
//	DWORD row = 1;
//
//	string testname_str("Test Name");
//	string lolim_str("Low Limit");
//	string hilim_str("High Limit");
//	string unit_str("Units");
//
//	string sys_str("TestSystem");
//	string board_str("Board_A");
//	string dut_str("PartID");
//	string site_str("Site");
//	string string_str("String");
//	string integer_str("Integer");
//	string real_str("Real");
//
//	vector<string> test_vec;
//	map<string, string> lolim_map;
//	map<string, string> hilim_map;
//	map<string, string> unit_map;
//
//	map<string,CAccoCsvData>::iterator it = acco_data.begin();
//	test_vec = it->second.test_vec;
//	lolim_map = it->second.lolim_map;
//	hilim_map = it->second.hilim_map;
//	unit_map = it->second.unit_map;
//
//	file = it->first;
//	file = mylib.GetFileFolderPath(file) + "\\" + mylib.GetFileName(file) + "_tcs_data.csv";
//
//	//////////// row 1 //////////////////
//	// add test name
//	for(DWORD i = 0; i < testname_str.length(); ++i){
//		buf[size_final++] = testname_str[i];
//	}
//	buf[size_final++] = ',';
//
//	// add 3 empty cell
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//
//	// add test label
//	string temp_str;
//	for(vector<string>::iterator it = test_vec.begin(); it != test_vec.end(); ++it){
//		temp_str = (*it);
//		for(DWORD i = 0; i < temp_str.length(); ++i)
//			buf[size_final++] = temp_str[i];
//		buf[size_final++] = ',';
//	}
//	buf[size_final++] = '\r';
//	buf[size_final++] = '\n';
//	row++;
//
//	//////////// row 2 //////////////////
//	// add low limit string
//	for(DWORD i = 0; i < lolim_str.length(); ++i){
//		buf[size_final++] = lolim_str[i];
//	}
//	buf[size_final++] = ',';
//
//	// add 3 empty cell
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//
//	// add test low limit
//	for(vector<string>::iterator it = test_vec.begin(); it != test_vec.end(); ++it){
//		temp_str = lolim_map[*it];
//		for(DWORD i = 0; i < temp_str.length(); ++i)
//			buf[size_final++] = temp_str[i];
//		buf[size_final++] = ',';
//	}
//	buf[size_final++] = '\r';
//	buf[size_final++] = '\n';
//	row++;
//
//	//////////// row 3 //////////////////
//	// add high limit string
//	for(DWORD i = 0; i < hilim_str.length(); ++i){
//		buf[size_final++] = hilim_str[i];
//	}
//	buf[size_final++] = ',';
//
//	// add 3 empty cell
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//
//	// add test high limit
//	for(vector<string>::iterator it = test_vec.begin(); it != test_vec.end(); ++it){
//		temp_str = hilim_map[*it];
//		for(DWORD i = 0; i < temp_str.length(); ++i)
//			buf[size_final++] = temp_str[i];
//		buf[size_final++] = ',';
//	}
//	buf[size_final++] = '\r';
//	buf[size_final++] = '\n';
//	row++;
//
//	//////////// row 4 //////////////////
//	// add unit string
//	for(DWORD i = 0; i < unit_str.length(); ++i){
//		buf[size_final++] = unit_str[i];
//	}
//	buf[size_final++] = ',';
//
//	// add 3 empty cell
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//	buf[size_final++] = ' ';
//	buf[size_final++] = ',';
//
//	// add test unit
//	for(vector<string>::iterator it = test_vec.begin(); it != test_vec.end(); ++it){
//		temp_str = unit_map[*it];
//		for(DWORD i = 0; i < temp_str.length(); ++i)
//			buf[size_final++] = temp_str[i];
//		buf[size_final++] = ',';
//	}
//	buf[size_final++] = '\r';
//	buf[size_final++] = '\n';
//	row++;
//
//	// add sys board dutid site string
//	for(DWORD i = 0; i < sys_str.length(); ++i){
//		buf[size_final++] = sys_str[i];
//	}
//	buf[size_final++] = ',';
//
//	for(DWORD i = 0; i < board_str.length(); ++i){
//		buf[size_final++] = board_str[i];
//	}
//	buf[size_final++] = ',';
//
//	for(DWORD i = 0; i < dut_str.length(); ++i){
//		buf[size_final++] = dut_str[i];
//	}
//	buf[size_final++] = ',';
//
//	for(DWORD i = 0; i < site_str.length(); ++i){
//		buf[size_final++] = site_str[i];
//	}
//	buf[size_final++] = ',';
//
//	buf[size_final++] = '\r';
//	buf[size_final++] = '\n';
//	row++;
//
//	/////////////////////////////////
//	// add value table
//	for(map<string,CAccoCsvData>::iterator it_top = acco_data.begin(); it_top != acco_data.end(); ++it_top){
//		for(map<DWORD,string>::iterator it = it_top->second.site_map.begin(); it != it_top->second.site_map.end(); ++it){
//			// add sys
//			temp_str = mylib.GetFileName(it_top->first);
//			for(DWORD i = 0; i < temp_str.length(); ++i)
//				buf[size_final++] = temp_str[i];
//			buf[size_final++] = ',';
//			// add board
//			buf[size_final++] = ' ';
//			buf[size_final++] = ',';
//			// add dut id
//			temp_str = partid_map[it->first];
//			for(DWORD i = 0; i < temp_str.length(); ++i)
//				buf[size_final++] = temp_str[i];
//			buf[size_final++] = ',';
//			// add site
//			temp_str = it->second;
//			for(DWORD i = 0; i < temp_str.length(); ++i)
//				buf[size_final++] = temp_str[i];
//			buf[size_final++] = ',';
//
//			// add value
//			for(vector<string>::iterator test_it = it_top->second.test_vec.begin(); test_it != it_top->second.test_vec.end(); ++test_it){
//				temp_str = it_top->second.val_map[it->first][*test_it];
//				for(DWORD i = 0; i < temp_str.length(); ++i){
//					buf[size_final++] = temp_str[i];
//				}
//				buf[size_final++] = ',';	
//			}	
//
//			buf[size_final++] = '\r';
//			buf[size_final++] = '\n';
//			row++;
//			if(size_final == file_size - 1){
//				error = "Error: Out file size is too large...";
//				free(buf); 
//				buf = NULL; 
//				return FALSE;
//			}
//		}	
//	}
//
//	if(mylib.IsFileExist(file.c_str())){
//		if(mylib.IsFileOpen(file.c_str())){
//			error = "Error: File is open, " + file + ", Please close it...";
//			free(buf); 
//			buf = NULL; 
//			return FALSE;
//		}
//		else
//			DeleteFile(file.c_str());
//	}
//
//	CMapMemFile tcs_data_csv;
//	tcs_data_csv.create(file.c_str(), size_final);
//	tcs_data_csv.write(buf, size_final);
//	tcs_data_csv.CloseMapFile();
//
//
//	free(buf); 
//	buf = NULL; 
//
//
//	return TRUE;
//
//}
//
//// generate tcs report
//BOOL CGenerateTextFile::generate_csv_tcs(string file, map<DWORD, map<DWORD, string>>& data_map, map<string,string>& str_mgb_map, map<string,string>& str_grr_map, string& error){
//
//	size_t file_size = 10*1024*1024;
//
//	if(mylib.IsFileExist(file.c_str())){
//		if(mylib.IsFileOpen(file.c_str())){
//			error = "Error: File is open, " + file + ", Please close it...";
//			return FALSE;
//		}
//		else
//			DeleteFile(file.c_str());
//	}
//
//	char *buf = NULL; 
//	buf = (char *)malloc(file_size * sizeof(char)); 
//	if (NULL == buf) 
//	{ 
//		error = "Error: malloc fail...";
//		free(buf); 
//		buf = NULL; 
//		return FALSE;
//	} 
//
//	DWORD size_final = 0;
//
//	vector<string> vec;
//	vec.push_back("Test Number");
//	vec.push_back("Test Name");
//	vec.push_back("Low Limit");
//	vec.push_back("High Limit");
//	vec.push_back("Unit");
//	vec.push_back("MGB");
//	vec.push_back("GRR");
//
//	for(vector<string>::iterator it = vec.begin(); it != vec.end(); ++it){
//		for(DWORD i = 0; i < (*it).length(); ++i)
//			buf[size_final++] = (*it)[i];
//		buf[size_final++] = ',';
//	}
//	buf[size_final++] = '\r';
//	buf[size_final++] = '\n';
//
//	vec.clear();
//	int num = 1;
//	for(DWORD col = 5; col <= data_map[1].size(); ++col){
//		vec.push_back(mylib.int2str(num++));
//		vec.push_back(data_map[1][col]);
//		vec.push_back(data_map[2][col]);
//		vec.push_back(data_map[3][col]);
//		vec.push_back(data_map[4][col]);
//		vec.push_back(str_mgb_map[data_map[1][col]]);
//		vec.push_back(str_grr_map[data_map[1][col]]);
//		for(vector<string>::iterator it = vec.begin(); it != vec.end(); ++it){
//			for(DWORD i = 0; i < (*it).length(); ++i)
//				buf[size_final++] = (*it)[i];
//			buf[size_final++] = ',';
//		}
//
//		vec.clear();
//		buf[size_final++] = '\r';
//		buf[size_final++] = '\n';
//	}
//
//	CMapMemFile tcs_report;
//	tcs_report.create(file.c_str(), size_final);
//	tcs_report.write(buf, size_final);
//	tcs_report.CloseMapFile();
//
//
//	free(buf); 
//	buf = NULL; 
//
//
//	return TRUE;
//}
//
//// generate repeat analysis report
//BOOL CGenerateTextFile::generate_csv_repeat(string file, CAccoCsvData &acco_data, CTestStatisticStruct &statistic, string &error){
//
//	size_t file_size = 10*1024*1024;
//
//	if(mylib.IsFileExist(file.c_str())){
//		if(mylib.IsFileOpen(file.c_str())){
//			error = "Error: File is open, " + file + ", Please close it...";
//			return FALSE;
//		}
//		else
//			DeleteFile(file.c_str());
//	}
//
//	char *buf = NULL; 
//	buf = (char *)malloc(file_size * sizeof(char)); 
//	if (NULL == buf) 
//	{ 
//		error = "Error: malloc fail...";
//		free(buf); 
//		buf = NULL; 
//		return FALSE;
//	} 
//
//	DWORD size_final = 0;
//
//	vector<string> vec;
//	vec.push_back("Test Number");
//	vec.push_back("Test Name");
//	vec.push_back("Low Limit");
//	vec.push_back("High Limit");
//	vec.push_back("Unit");
//	vec.push_back("Stdev");
//	vec.push_back("Average");
//	vec.push_back("Min");
//	vec.push_back("Max");
//	vec.push_back("Cpl");
//	vec.push_back("Cpu");
//	vec.push_back("Cpk");
//	vec.push_back("GRR%");
//	vec.push_back("Count");
//
//	for(vector<string>::iterator it = vec.begin(); it != vec.end(); ++it){
//		for(DWORD i = 0; i < (*it).length(); ++i)
//			buf[size_final++] = (*it)[i];
//		buf[size_final++] = ',';
//	}
//	buf[size_final++] = '\r';
//	buf[size_final++] = '\n';
//
//	vec.clear();
//	int test_num = 1;
//	for(vector<string>::iterator it_test = acco_data.test_vec.begin(); it_test != acco_data.test_vec.end(); ++it_test){
//		string label("\"" + *it_test + "\"");
//		vec.push_back(mylib.int2str(test_num++));
//		vec.push_back(label);
//		vec.push_back(acco_data.lolim_map[*it_test]);
//		vec.push_back(acco_data.hilim_map[*it_test]);
//		vec.push_back(acco_data.unit_map[*it_test]);
//		vec.push_back(statistic.std_map[*it_test]);
//		vec.push_back(statistic.mean_map[*it_test]);
//		vec.push_back(statistic.min_map[*it_test]);
//		vec.push_back(statistic.max_map[*it_test]);
//		vec.push_back(statistic.cpl_map[*it_test]);
//		vec.push_back(statistic.cpu_map[*it_test]);
//		vec.push_back(statistic.cpk_map[*it_test]);
//		vec.push_back(statistic.grr_map[*it_test]);
//		vec.push_back(mylib.int2str((DWORD)statistic.count_map[*it_test]));
//
//		for(vector<string>::iterator it = vec.begin(); it != vec.end(); ++it){
//			for(DWORD i = 0; i < (*it).length(); ++i)
//				buf[size_final++] = (*it)[i];
//			buf[size_final++] = ',';
//		}
//
//		vec.clear();
//		buf[size_final++] = '\r';
//		buf[size_final++] = '\n';
//	}
//
//
//	CMapMemFile tcs_report;
//	tcs_report.create(file.c_str(), size_final);
//	tcs_report.write(buf, size_final);
//	tcs_report.CloseMapFile();
//
//
//	free(buf); 
//	buf = NULL; 
//
//
//	return TRUE;
//
//}
//
//// generate correlation analysis report
//// 1. If the test items is diff between golden and corr, report will include both items, and keep blank if no this item in golden data or corr data.
//// 2. The best way is use MGB to judge if the corr result is acceptable
//// 3. The sequence should be same
//BOOL CGenerateTextFile::generate_csv_correlation(string file, CAccoCsvData& golden_data, CAccoCsvData& corr_data, map<string,string>& mgb_map, string& error){
//
//	size_t file_size = 10*1024*1024;
//
//	if(mylib.IsFileExist(file.c_str())){
//		if(mylib.IsFileOpen(file.c_str())){
//			error = "Error: File is open, " + file + ", Please close it...";
//			return FALSE;
//		}
//		else
//			DeleteFile(file.c_str());
//	}
//
//	char *buf = NULL; 
//	buf = (char *)malloc(file_size * sizeof(char)); 
//	if (NULL == buf) 
//	{ 
//		error = "Error: malloc fail...";
//		free(buf); 
//		buf = NULL; 
//		return FALSE;
//	} 
//
//	DWORD size_final = 0;
//
//	// combine test items
//	vector<string> test_vec(golden_data.test_vec);
//	for(vector<string>::iterator it = corr_data.test_vec.begin(); it != corr_data.test_vec.end(); ++it){
//		if(find(test_vec.begin(), test_vec.end(), *it) == test_vec.end())
//			test_vec.push_back(*it);
//	}
//
//	// The first row
//	vector<string> vec;
//	vec.push_back("Test Number");
//	vec.push_back("Test Name");
//	vec.push_back("Low Limit");
//	vec.push_back("High Limit");
//	vec.push_back("Unit");
//	vec.push_back("MGB");
//	Cmylib mylib;
//	for(map<DWORD,string>::iterator it = corr_data.site_map.begin(); it != corr_data.site_map.end(); ++it){
//		string str;
//		str = "#" + mylib.int2str(it->first) + "_GD";
//		vec.push_back(str);
//		str = "#" + mylib.int2str(it->first) + "_CT";
//		vec.push_back(str);
//		str = "#" + mylib.int2str(it->first) + "_Delta";
//		vec.push_back(str);
//		str = "#" + mylib.int2str(it->first) + "_%Delta";
//		vec.push_back(str);
//
//		vec.push_back("");
//	}
//
//	for(vector<string>::iterator it = vec.begin(); it != vec.end(); ++it){
//		for(DWORD i = 0; i < (*it).length(); ++i)
//			buf[size_final++] = (*it)[i];
//		buf[size_final++] = ',';
//	}
//	buf[size_final++] = '\r';
//	buf[size_final++] = '\n';
//
//
//	vec.clear();
//	int num = 1;
//	// loop with test items
//	for(vector<string>::iterator it_test = test_vec.begin(); it_test != test_vec.end(); ++it_test){
//		vec.push_back(mylib.int2str(num++));
//		vec.push_back(*it_test);
//		if(find(golden_data.test_vec.begin(), golden_data.test_vec.end(), *it_test) != golden_data.test_vec.end()){
//			vec.push_back(golden_data.lolim_map[*it_test]);
//			vec.push_back(golden_data.hilim_map[*it_test]);
//			vec.push_back(golden_data.unit_map[*it_test]);
//		} else if (find(corr_data.test_vec.begin(), corr_data.test_vec.end(), *it_test) != corr_data.test_vec.end()){
//			vec.push_back(corr_data.lolim_map[*it_test]);
//			vec.push_back(corr_data.hilim_map[*it_test]);
//			vec.push_back(corr_data.unit_map[*it_test]);		
//		}
//
//		if(mgb_map.find(*it_test) != mgb_map.end())
//			vec.push_back(mgb_map[*it_test]);
//		else
//			vec.push_back("");
//
//		// loop with serial
//		for(map<DWORD,string>::iterator it = corr_data.site_map.begin(); it != corr_data.site_map.end(); ++it){
//			string gd_str;
//			string corr_str;
//			string delta_str;
//			string rate_str;
//
//			if(find(golden_data.test_vec.begin(), golden_data.test_vec.end(), *it_test) != golden_data.test_vec.end()){
//				gd_str = golden_data.val_map[it->first][*it_test];
//				vec.push_back(gd_str);
//			}
//			else
//				vec.push_back("");
//
//			if(find(corr_data.test_vec.begin(), corr_data.test_vec.end(), *it_test) != corr_data.test_vec.end()){
//				corr_str = corr_data.val_map[it->first][*it_test];
//				vec.push_back(corr_str);
//			}
//			else
//				vec.push_back("");
//
//			if((gd_str != "") && (corr_str != "")){
//				double gd = atof(gd_str.c_str());
//				double corr = atof(corr_str.c_str());
//				double delta = corr - gd;
//				double lolim = 0;
//				double hilim = 0;
//
//				delta_str = mylib.float2str(delta);
//
//				if((golden_data.lolim_map[*it_test] != "") && (golden_data.hilim_map[*it_test] != "")){
//					lolim = atof(golden_data.lolim_map[*it_test].c_str());
//					hilim = atof(golden_data.hilim_map[*it_test].c_str());
//				}
//
//				if(lolim < hilim){ // valid test limit
//					double rate = delta / (hilim - lolim) * 100;
//					rate_str = mylib.float2str(rate);
//				} else {
//					rate_str = "";
//				}	
//			} else {
//				delta_str = "";
//				rate_str = "";
//			}
//
//			vec.push_back(delta_str);
//			vec.push_back(rate_str);
//			vec.push_back("");
//		}
//
//
//
//		for(vector<string>::iterator it = vec.begin(); it != vec.end(); ++it){
//			for(DWORD i = 0; i < (*it).length(); ++i)
//				buf[size_final++] = (*it)[i];
//			buf[size_final++] = ',';
//		}
//
//		vec.clear();
//		buf[size_final++] = '\r';
//		buf[size_final++] = '\n';
//	}
//
//
//	CMapMemFile corr_report;
//	corr_report.create(file.c_str(), size_final);
//	corr_report.write(buf, size_final);
//	corr_report.CloseMapFile();
//
//
//	free(buf); 
//	buf = NULL; 
//
//
//	return TRUE;
//}


// generate general tcs from map<row, col>
BOOL CGenerateTextFile::generate_csv(string file, map<DWORD, map<DWORD, string>>& data_map, string& error){

	size_t file_size = 10*1024*1024;

	if(mylib.IsFileExist(file.c_str())){
		if(mylib.IsFileOpen(file.c_str())){
			error = "Error: File is open, " + file + ", Please close it...";
			return FALSE;
		}
		else
			DeleteFile(file.c_str());
	}

	char *buf = NULL; 
	buf = (char *)malloc(file_size * sizeof(char)); 
	if (NULL == buf) 
	{ 
		error = "Error: malloc fail...";
		free(buf); 
		buf = NULL; 
		return FALSE;
	} 

	DWORD size_final = 0;

	for(DWORD row = 1; row <= data_map.size(); ++row){
		for(DWORD col = 1; col <= data_map[row].size(); ++col){
			for(DWORD i = 0; i < data_map[row][col].length(); ++i)
				buf[size_final++] = data_map[row][col][i];
			buf[size_final++] = ',';
		}	
		buf[size_final++] = '\r';
		buf[size_final++] = '\n';
	}

	CMapMemFile out_file;
	out_file.create(file.c_str(), size_final);
	out_file.write(buf, size_final);
	out_file.CloseMapFile();


	free(buf); 
	buf = NULL; 


	return TRUE;
}


// generate general tcs from map<row, col>
BOOL CGenerateTextFile::generate_csv(string file, map<DWORD, map<DWORD, int>>& data_map, string& error){

	size_t file_size = 10*1024*1024;

	if(mylib.IsFileExist(file.c_str())){
		if(mylib.IsFileOpen(file.c_str())){
			error = "Error: File is open, " + file + ", Please close it...";
			return FALSE;
		}
		else
			DeleteFile(file.c_str());
	}

	char *buf = NULL; 
	buf = (char *)malloc(file_size * sizeof(char)); 
	if (NULL == buf) 
	{ 
		error = "Error: malloc fail...";
		free(buf); 
		buf = NULL; 
		return FALSE;
	} 

	DWORD size_final = 0;

	for(DWORD row = 1; row <= data_map.size(); ++row){
		for(DWORD col = 1; col <= data_map[row].size(); ++col){
			string cell_str = mylib.int2str(data_map[row][col]);
			for(DWORD i = 0; i < cell_str.length(); ++i)
				buf[size_final++] = cell_str[i];
			buf[size_final++] = ',';
		}	
		buf[size_final++] = '\r';
		buf[size_final++] = '\n';
	}

	CMapMemFile out_file;
	out_file.create(file.c_str(), size_final);
	out_file.write(buf, size_final);
	out_file.CloseMapFile();


	free(buf); 
	buf = NULL; 


	return TRUE;
}


// generate general tcs from map<row, col>
BOOL CGenerateTextFile::generate_csv(string file, map<DWORD, map<DWORD, double>>& data_map, string& error){

	size_t file_size = 10*1024*1024;

	if(mylib.IsFileExist(file.c_str())){
		if(mylib.IsFileOpen(file.c_str())){
			error = "Error: File is open, " + file + ", Please close it...";
			return FALSE;
		}
		else
			DeleteFile(file.c_str());
	}

	char *buf = NULL; 
	buf = (char *)malloc(file_size * sizeof(char)); 
	if (NULL == buf) 
	{ 
		error = "Error: malloc fail...";
		free(buf); 
		buf = NULL; 
		return FALSE;
	} 

	DWORD size_final = 0;

	for(DWORD row = 1; row <= data_map.size(); ++row){
		for(DWORD col = 1; col <= data_map[row].size(); ++col){
			string cell_str = mylib.float2str(data_map[row][col]);
			for(DWORD i = 0; i < cell_str.length(); ++i)
				buf[size_final++] = cell_str[i];
			buf[size_final++] = ',';
		}	
		buf[size_final++] = '\r';
		buf[size_final++] = '\n';
	}

	CMapMemFile out_file;
	out_file.create(file.c_str(), size_final);
	out_file.write(buf, size_final);
	out_file.CloseMapFile();


	free(buf); 
	buf = NULL; 


	return TRUE;
}
