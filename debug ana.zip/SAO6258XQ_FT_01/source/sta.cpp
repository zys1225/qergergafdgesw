/*****************************************************************************
*
*         Written by:   Hunter Liu
*   Last Modified by:   Hunter Liu
*               Date:   07/12/2024
*        Current Rev:   00
*
*        Description:    Site Trim Analysis
*
*****************************************************************************/
#include "stdafx.h"
#include "sta.h"
#include <algorithm.h>
//#include <afxtempl.h>
//#include "inireader.h"
//#pragma comment(lib, "User32.lib")

//STA_NODE T_BG;
//STA_NODE T_OSC;
//STA_NODE T_VDACH;
//STA_NODE T_FBDR;

bool comp_float(float v1, float v2) //����
{
	return v1 < v2;
}

bool comp_double(double v1, double v2) //����
{
	return v1 < v2;
}

double round_value(double r)//��������
{
	return (r > 0.0) ? floor(r + 0.5) : ceil(r - 0.5);
}

/*
getResult ��ȡ������
float * val ������ֵָ��
int count ������ֵ����
float * result ���ָ�룬newʱӦΪ4��float��
		result[0] ��ֵ
		result[1] ��ֵ
		result[2] ��׼��
		result[3] �ķ�λ��
*/
void  calc_qx(float* val, int count, float* result)
{
	//�������鲢����
	//CArray<float> valueArray;
	vector<float> valueData;
	for (int i = 0; i < count; i++)
	{
		//valueArray.Add(val[i]);
		valueData.insert(valueData.end(),val[i]);
	}
	//std::sort(valueArray.GetData(), valueArray.GetData() + valueArray.GetSize(), Comp_float);
	std::sort(valueData.begin(), valueData.end(), comp_float);


	//�����ֵ
	float allVals = 0;
	//int iValsCount = valueArray.GetCount();
	int iValsCount = valueData.size();
	//for (int i = 0; i < valueArray.GetCount(); i++)
	for (int i = 0; i < valueData.size(); i++)
	{
		//allVals += valueArray.GetAt(i);
		allVals += valueData[i];
	}
	result[0] = allVals / iValsCount;

	//������ֵ
	float iMedianIndex = (iValsCount + 1) / (float)2;
	//�����Ƿ�պÿ����м䣬�м�ʱȡǰ��ƽ����
	int iFirst = round_value(iMedianIndex - 0.5) - 1;
	if (iFirst < 0)
		iFirst = 0;
	int iNext = round_value(iMedianIndex + 0.4) - 1;
	if (iNext > iValsCount - 1)
		iNext = iValsCount - 1;
	if (iFirst == iNext)
	{
		//result[1] = valueArray.GetAt(iFirst);
		result[1] = valueData[0];
	}
	else
	{
		//result[1] = (valueArray.GetAt(iFirst) + valueArray.GetAt(iNext)) / 2;
		result[1] = (valueData[0] + valueData[1]) / 2;
	}

	// ���׼����
	double powAll = 0.0;
	for (int i = 0; i < iValsCount; i++)
	{
		//powAll += (double)pow((double)(valueArray.GetAt(i) - result[1]), 2);//�ۼ�
		powAll += (double)pow((double)(valueData[0] - result[1]), 2);//�ۼ�
	}
	result[2] = sqrt(powAll / (double)iValsCount);//���㷽��

	//�����ķֲ�
	//��ȡQ1
	float index_Q1 = (iValsCount + (float)1) / (float)4;
	iFirst = round_value(index_Q1 - 0.5) - 1;//��ȡλ��ǰindex
	if (iFirst < 0)
		iFirst = 0;
	iNext = round_value(index_Q1 + 0.4) - 1;//��ȡλ�ú�index
	if (iNext > iValsCount - 1)
		iNext = iValsCount - 1;
	//float value_Q1 = iFirst == iNext ? valueArray.GetAt(iNext) : (index_Q1 - 1 - (float)iFirst) * valueArray.GetAt(iNext) + ((float)iNext - index_Q1 + 1) * valueArray.GetAt(iFirst);//ע��index_Q1ָ����λ�ã���Ҫ��ȥ1���ܴ�����ż��㡣
	float value_Q1 = iFirst == iNext ? valueData[iNext] : (index_Q1 - 1 - (float)iFirst) * valueData[iNext] + ((float)iNext - index_Q1 + 1) * valueData[iFirst];//ע��index_Q1ָ����λ�ã���Ҫ��ȥ1���ܴ�����ż��㡣
	//��ȡQ2
	float index_Q3 = (float)3 * (iValsCount + (float)1) / (float)4;
	iFirst = round_value(index_Q3 - 0.5) - 1;
	if (iFirst < 0)
		iFirst = 0;
	iNext = round_value(index_Q3 + 0.4) - 1;
	if (iNext > iValsCount - 1)
		iNext = iValsCount - 1;
	//float value_Q3 = iFirst == iNext ? valueArray.GetAt(iNext) : (index_Q3 - 1 - (float)iFirst) * valueArray.GetAt(iNext) + ((float)iNext - index_Q3 + 1) * valueArray.GetAt(iFirst);
	float value_Q3 = iFirst == iNext ? valueData[iNext] : (index_Q3 - 1 - (float)iFirst) * valueData[iNext] + ((float)iNext - index_Q3 + 1) * valueData[iFirst];
	result[3] = value_Q3 - value_Q1;//Q=Q3-Q1
}

void test_fifo(void)
{
	//Fifo_Queue queue_data;
	//Fifo_Node node_array[MAX_NODE_LEN];
	//int node_array_idx = 0;

	//init_queue(&queue_data);

	//for (int i = 0; i < MAX_NODE_LEN; ++i)
	//{
	//	node_array[i].prev = NULL;
	//	node_array[i].next = NULL;
	//	node_array[i].data = 0;
	//}

	//// insert 0
	//node_array[0].data = 0;
	//in_queue(&queue_data, &(node_array[0]));

	//// insert 2
	//node_array[2].data = 2;
	//in_queue(&queue_data, &(node_array[2]));

	//// insert 4
	//node_array[4].data = 4;
	//in_queue(&queue_data, &(node_array[4]));

	//// insert 6
	//node_array[6].data = 6;
	//in_queue(&queue_data, &(node_array[6]));

	//// insert 8
	//node_array[8].data = 8;
	//in_queue(&queue_data, &(node_array[8]));

	//display(&(queue_data.head));
	//printf("node number = %d\n", queue_data.count);

	//// insert 10
	//node_array[10].data = 10;
	//in_queue(&queue_data, &(node_array[10]));
	//printf("\ninqueue data %d:\n", 10);

	//display(&(queue_data.head));
	//printf("node number = %d\n", queue_data.count);

	//for (int i = 0; i < 4; ++i) {
	//	Fifo_Node* node = out_queue(&queue_data);
	//	if (node != NULL)
	//	{
	//		printf("\noutqueue data = %d\n", node->data);
	//	}

	//	display(&(queue_data.head));
	//	printf("node number = %d\n", queue_data.count);
	//}

	//// insert 12
	//node_array[12].data = 12;
	//in_queue(&queue_data, &(node_array[12]));
	//printf("\ninqueue data %d:\n", 12);

	//display(&(queue_data.head));
	//printf("node number = %d\n", queue_data.count);

	//// insert 14
	//node_array[14].data = 14;
	//in_queue(&queue_data, &(node_array[14]));
	//printf("\ninqueue data %d:\n", 14);

	//display(&(queue_data.head));
	//printf("node number = %d\n", queue_data.count);

	//// insert 16
	//node_array[16].data = 16;
	//in_queue(&queue_data, &(node_array[16]));
	//printf("\ninqueue data %d:\n", 16);

	//display(&(queue_data.head));
	//printf("node number = %d\n", queue_data.count);

	//for (int i = 0; i < 2; ++i) {
	//	Fifo_Node* node = out_queue(&queue_data);
	//	if (node != NULL)
	//	{
	//		printf("\noutqueue data = %d\n", node->data);
	//	}

	//	display(&(queue_data.head));
	//	printf("node number = %d\n", queue_data.count);
	//}

	//// insert 18
	//node_array[18].data = 18;
	//in_queue(&queue_data, &(node_array[18]));
	//printf("\ninqueue data %d:\n", 18);

	//display(&(queue_data.head));
	//printf("node number = %d\n", queue_data.count);
}

static int getSetting(READER &r, const char *param, const char *setting, int default_value) {
	bool flag = false;
	int return_value = 0; // return 0 if it's not found anywhere

	if (r.getBoolean(param, setting, &flag)) // check for true/false on parameter
		flag ? return_value = default_value : return_value = 0;
	else if (!r.getInteger(param, setting, &return_value)) {     // check for integer on parameter
		if ((r.getSection(_DEFAULT))) {                          // check for _DEFAULT section
			if (r.getBoolean(_DEFAULT, setting, &flag))          // check for true/false on DEFAULT
				flag ? return_value = default_value : return_value = 0;
			else
				r.getInteger(_DEFAULT, setting, &return_value); // check for integer on DEFAULT
		}
	}
	return return_value;
}

void convertTable(string str, int table[], int *size) 
{
	int count = 0;
	char        *p;
	char sep[] = ",";
	char *next_token = NULL;

	char *cstr;
	cstr = new char[strlen(str.c_str()) + 1];
	strcpy_s(cstr, strlen(str.c_str()) + 1, str.c_str());
	p = strtok_s(cstr, sep, &next_token);

	while (p != NULL) 
	{
		int no, cread;
		no = sscanf_s(p, "%d%n", table + count, &cread);
		if (no != 1) break;
		p += cread;
		p = strtok_s(NULL, sep, &next_token);
		count++;
	};
	*size = count;
	delete[] cstr; cstr = NULL;
}

void getArray(int arrayin[], int arrayout[], int size)
{
	for (int i = 0; i < size; i++)
	{
		arrayout[i] = arrayin[i];
	}
}

void STA::Init_Variable(void)
{
	for (int i = 0; i<256; i++)
	{
		ITEM[i].Init();
	}
	ItemCount = 0;
	//STA_INIT();
}

void STA::Read_Cfg(const char *file_name)
{
	const char *p;
	int   table[256];
	int size = 0;
	READER	reader;
	SECTION  *section = NULL;
	ItemCount = 0;
	string fullpathini(file_name);
	int pos = fullpathini.find_last_of('\\');
	if (pos > -1) { pathofini = fullpathini.substr(0, pos + 1); }

	if (!reader.open(file_name)) {
		MessageBox(NULL, "sta.ini not found.", "STA Message", MB_OK);
	}
	else
	{
		while ((section = reader.getNextSection()))
		{
			p = section->getName();

			switch (*p) 
			{
				case '*': // ignore other section headers (SEL,ASSY,ASSY_GRP,TRIM_GRP)
				case '_':
				case '#':
				case '$':
				case '%':
				case '&':
					break;
				default: 
				{ //found
					if (_stricmp(p, "DEFAULT") != 0) // ignore default
					{
						ITEM[ItemCount].TYPE_CODE = getSetting(reader, p, "TYPE_CODE", 1);
						ITEM[ItemCount].STA_LMT_DIFF = getSetting(reader, p, "STA_LMT_DIFF", 4);
						ITEM[ItemCount].STA_LMT_SHIFT = getSetting(reader, p, "STA_LMT_SHIFT", 2);
						ITEM[ItemCount].Cvt_N = getSetting(reader, p, "STA_BITN", 1);
						ITEM[ItemCount].Cvt_BitSize = getSetting(reader, p, "STA_CVT_SIZE", 1);
						string str = reader.getString(p, "STA_CVT_ARRAY");
						convertTable(str, table, &size);
						strcpy(ITEM[ItemCount].NAME, p);
						getArray(table, ITEM[ItemCount].Cvt_Bit, ITEM[ItemCount].Cvt_BitSize);
						ItemCount++;
					}
				} break;
			}	
		}
	}
}

int  STA::Item(const char *item)
{
	int index = 0;
	int i = 0;
	for (i = 0; i < ItemCount; i++)
	{
		index = strcmp(item, ITEM[i].NAME);
		if (index == 0) break;
	}
	if (i == ItemCount) i = -1;
	return i;
}

void STA::Init(const char *file_name)
{
	if (!initialed)
	{
		STA::Init_Variable();
		STA::Read_Cfg(file_name);
		initialed = true;
		//BUF_NODE buf;
		//int buf_len;
		//double buf_avg;
		//double buf_std;
		//double buf_sum;
		//buf.Init(5);
		////buf.Empty();
		//for (int i = 0; i < 10; i++)
		//{
		//	buf.Add(i);
		//	buf_len=buf.GetLen();
		//	buf_sum=buf.GetSum();
		//	buf_avg=buf.GetAvg();
		//	buf_std=buf.GetStd();
		//}
		//test_fifo();
	}
}

void STA::Set_Zcode(const char *item, int ZCode[SITE_NUM])
{
	int index = STA::Item(item);
	if (index >= 0)
	{
		ITEM[index].Set_Zcode(ZCode);
	}
	else
	{
		MessageBox(NULL, "Item not found.", "STA Message", MB_OK);
	}
}

void STA::Get_Lcode(const char *item, int LCode[SITE_NUM])
{
	int index = STA::Item(item);
	if (index >= 0)
	{
		ITEM[index].Get_Lcode(LCode);
	}
	else
	{
		MessageBox(NULL, "Item not found.", "STA Message", MB_OK);
	}
}

void STA::Get_Count(const char* item, int Count[SITE_NUM])
{
	int index = STA::Item(item);
	if (index >= 0)
	{
		SERIAL Count[SITE] = ITEM[index].dut_count[SITE];
	}
	else
	{
		MessageBox(NULL, "Item not found.", "STA Message", MB_OK);
	}
}

void STA::Get_AvgSite(const char *item, double AvgSite[SITE_NUM])
{
	int index = STA::Item(item);
	if (index >= 0)
	{
		ITEM[index].Get_Avg(AvgSite);
	}
	else
	{
		MessageBox(NULL, "Item not found.", "STA Message", MB_OK);
	}
}

void STA::Get_AvgShift(const char *item, double AvgShift[SITE_NUM])
{
	int index = STA::Item(item);
	if (index >= 0)
	{
		ITEM[index].Get_Diff(AvgShift);
	}
	else
	{
		MessageBox(NULL, "Item not found.", "STA Message", MB_OK);
	}
}

double STA::Get_AvgAll(const char *item)
{
	int index = STA::Item(item);
	if (index >= 0)
	{
		return ITEM[index].lvalue_avg_all;
	}
	else
	{
		MessageBox(NULL, "Item not found.", "STA Message", MB_OK);
		return 0;
	}
}

//void STA_INIT(void)
//{
//	Trigger_Differ_Limit = false;
//	T_BG.Init();
//	T_OSC.Init();
//	T_VDACH.Init();
//	T_FBDR.Init();
//	T_BG.NAME = "Trim_BG";
//	T_BG.STA_LMT_DIFF = 4;
//	T_BG.STA_LMT_SHIFT = 2;
//	T_VDACH.NAME = "Trim_VDACH";
//	T_VDACH.STA_LMT_DIFF = 4;
//	T_VDACH.STA_LMT_SHIFT = 2;
//	T_FBDR.NAME = "Trim_FBDR";
//	T_FBDR.STA_LMT_DIFF = 4;
//	T_FBDR.STA_LMT_SHIFT = 2;
//	T_OSC.NAME = "Trim_OSC";
//	T_OSC.STA_LMT_DIFF = 4;
//	T_OSC.STA_LMT_SHIFT = 2;
//	int array1[4] = { 0, 1, 2, 3 };
//	T_BG.Set_Cvt_Info(5, array1, sizeof(array1) / sizeof(array1[0]));
//	int array2[1] = { 3 };
//	T_VDACH.Set_Cvt_Info(4, array2, sizeof(array2) / sizeof(array2[0]));
//	int array3[1] = { 3 };
//	T_FBDR.Set_Cvt_Info(4, array3, sizeof(array3) / sizeof(array3[0]));
//	int array4[1] = { 1 };
//	T_OSC.Set_Cvt_Info(2, array4, sizeof(array4) / sizeof(array4[0]));
//}

void STA::Update(void)
{
	for (int i = 0; i < ItemCount; i++)
	{
		ITEM[i].Run_Calc();
		int n = ITEM[i].dut_count[0];
	}
	//T_BG.Run_Calc();
	//T_VDACH.Run_Calc();
	//T_FBDR.Run_Calc();
	//T_OSC.Run_Calc();
}

void STA::Save_to_File(void)
{
	for (int i = 0; i < ItemCount; i++)
	{
		ITEM[i].Save_File(pathofini.c_str());
	}
	//T_BG.Save_File();
	//T_VDACH.Save_File();
	//T_FBDR.Save_File();
	//T_OSC.Save_File();
}

void STA::Result_Message(void)
{
	//if (BG.avg_diff){ Trigger_Differ_Limit = true; }
	//if (OSC.avg_diff){ Trigger_Differ_Limit = true; }
	//if (IREF.avg_diff){ Trigger_Differ_Limit = true; }
	Trigger_Diff_Limit = false;
	double lval[64];
	double lmt[64];
	for (int i = 0; i < ItemCount; i++)
	{
		lval[i]=ITEM[i].lvalue_avg_all_diff;
		lmt[i]=ITEM[i].STA_LMT_DIFF;
		if (ITEM[i].flag_avg_diff_trigger){ Trigger_Diff_Limit = true; }
	}
	//Trigger_Diff_Limit = true;
	//if (Trigger_Diff_Limit) { MessageBox(NULL, "Wrong Trim Parameter Name", "STA Message", MB_OK); }
	if (Trigger_Diff_Limit) 
	{ 
		//MessageBox(NULL, "TRIM Statistic Result Fail !! Probably has S2S issue, Please contact Engineer to check the data before release this lot !!", "STA Message", MB_OK); 
	}
}







