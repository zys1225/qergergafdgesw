#include "stdafx.h"
#include "i2c.h"

extern DCM dcm;
int dut_i2c_addr = 0;

void I2C_Class::initial(double freq, double vih, double vil, double voh, double vol)
{
	double period = 1000000000.0 / freq;
	dcm.I2CConnect();
	dcm.I2CSet(period, SITE_NUM, DCM_REG8, "S24_6,S24_22,S24_46,S24_62,S24_14,S24_30,S24_38,S24_54", "S24_5,S24_21,S24_45,S24_61,S24_13,S24_29,S24_37,S24_53");
	dcm.I2CSetPinLevel(vih, vil, voh, vol, DCM_I2C_BOTH);
}

void I2C_Class::dut_write_x1(int RegAddress, int WriteData)
{
	BYTE wdata[SITE_NUM];
	SERIAL
	{
		wdata[globalsite] = WriteData;
	}
	dcm.I2CWriteData(dut_i2c_addr, RegAddress, 1, wdata);
}

void I2C_Class::dut_write_x1(int RegAddress, int *WriteData)
{
	BYTE wdata[SITE_NUM];
	SERIAL
	{
		wdata[globalsite] = WriteData[globalsite];
	}
	dcm.I2CWriteData(dut_i2c_addr, RegAddress, 1, wdata);
}

void I2C_Class::dut_read_x1(int RegAddress, int ReadData1[])
{
	dcm.I2CReadData(dut_i2c_addr, RegAddress, 1);
	SERIAL
	{
		ReadData1[globalsite] = dcm.I2CGetReadData(globalsite, 0);
	}
}

