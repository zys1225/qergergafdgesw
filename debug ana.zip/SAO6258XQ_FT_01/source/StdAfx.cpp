// stdafx.cpp : source file that includes just the standard includes
//	DUT.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
#include "Pin_Channel_define.h"

/*The following code was created for STS PinPlanner,don't modify*/ 
/****STS_PINPLANNER_CODE_BEGIN****/
#define STS_SITE_NUM 8
/****PIN GROUP DEFINITION****/
ACM200 acm0(_PIN_CHANNEL_DEFINE_acm0_, "acm0");
ACM200 acm1(_PIN_CHANNEL_DEFINE_acm1_, "acm1");
ACM200 acm2(_PIN_CHANNEL_DEFINE_acm2_, "acm2");
ACM200 acm3(_PIN_CHANNEL_DEFINE_acm3_, "acm3");
ACM200 acm4(_PIN_CHANNEL_DEFINE_acm4_, "acm4");
ACM200 acm5(_PIN_CHANNEL_DEFINE_acm5_, "acm5");
ACM200 acm6(_PIN_CHANNEL_DEFINE_acm6_, "acm6");
ACM200 acm7(_PIN_CHANNEL_DEFINE_acm7_, "acm7");
ACM200 acm8(_PIN_CHANNEL_DEFINE_acm8_, "acm8");
ACM200 acm9(_PIN_CHANNEL_DEFINE_acm9_, "acm9");
ACM200 acm10(_PIN_CHANNEL_DEFINE_acm10_, "acm10");
ACM200 acm11(_PIN_CHANNEL_DEFINE_acm11_, "acm11");
FXVIe_PLUS fxvi0(_PIN_CHANNEL_DEFINE_fxvi0_, "fxvi0");
FXVIe_PLUS fxvi1(_PIN_CHANNEL_DEFINE_fxvi1_, "fxvi1");
FXVIe_PLUS fxvi2(_PIN_CHANNEL_DEFINE_fxvi2_, "fxvi2");
FXVIe_PLUS fxvi3(_PIN_CHANNEL_DEFINE_fxvi3_, "fxvi3");
FXVIe_PLUS fxvi4(_PIN_CHANNEL_DEFINE_fxvi4_, "fxvi4");
FXVIe_PLUS fxvi5(_PIN_CHANNEL_DEFINE_fxvi5_, "fxvi5");
FPVIe fpvi0(_PIN_CHANNEL_DEFINE_fpvi0_, "fpvi0");
QVMe qvm(_PIN_CHANNEL_DEFINE_qvm_, "qvm");
QTMUe qtmu(_PIN_CHANNEL_DEFINE_qtmu_, "qtmu");
QVMe qvm0(_PIN_CHANNEL_DEFINE_qvm0_, "qvm0");
QVMe qvm1(_PIN_CHANNEL_DEFINE_qvm1_, "qvm1");
QVMe qvm2(_PIN_CHANNEL_DEFINE_qvm2_, "qvm2");
QVMe qvm3(_PIN_CHANNEL_DEFINE_qvm3_, "qvm3");
QTMUe qtmu0(_PIN_CHANNEL_DEFINE_qtmu0_, "qtmu0");
QTMUe qtmu1(_PIN_CHANNEL_DEFINE_qtmu1_, "qtmu1");
QTMUe qtmu2(_PIN_CHANNEL_DEFINE_qtmu2_, "qtmu2");
QTMUe qtmu3(_PIN_CHANNEL_DEFINE_qtmu3_, "qtmu3");


//ACM
ACM200& A_EXSI = acm8;
ACM200& A_VCI = acm8;
ACM200& A_VMON = acm8;
ACM200& A_VCIVMON = acm8;

ACM200& A_SEC = acm9;
ACM200& A_AMUX = acm9;
ACM200& A_ABUFO = acm9;
ACM200& A_EVC = acm9;
ACM200& A_POSFRE = acm9;
ACM200& A_SECPOSFRE = acm9;

ACM200& A_EVC2 = acm10;
ACM200& A_POSFRE2 = acm10;
ACM200& A_SEC2 = acm10;
ACM200& A_AMUX2 = acm10;
ACM200& A_NC = acm10;
ACM200& A_SYN = acm10;
ACM200& A_EVS = acm10;
ACM200& A_SSD = acm10;
ACM200& A_DBUFO = acm10;
ACM200& A_DIODE = acm10;

ACM200& A_ABUFO2 = acm1;
ACM200& A_STU = acm1;

ACM200& A_QST = acm0;

ACM200& A_PG = acm11;
ACM200& A_FB1 = acm11;
ACM200& A_FB2 = acm11;
ACM200& A_FB3 = acm11;
ACM200& A_FB4 = acm11;
ACM200& A_POSG = acm11;
ACM200& A_SQUC = acm11;
ACM200& A_MPS = acm11;

ACM200& A_POSIN = acm5;

ACM200& A_POSSW = acm6;

ACM200& A_POSFB = acm7;

ACM200& A_QUC = acm2;

ACM200& A_QVR = acm3;

ACM200& A_QCO = acm4;

//FXVI
FXVIe_PLUS& F_FB = fxvi0;
FXVIe_PLUS& F_SW = fxvi0;
FXVIe_PLUS& F_RSH = fxvi0;
FXVIe_PLUS& F_RSL = fxvi0;

FXVIe_PLUS& F_VST = fxvi4;
FXVIe_PLUS& F_VS1 = fxvi4;
FXVIe_PLUS& F_VSX = fxvi4;

FXVIe_PLUS& F_ENA = fxvi5;
FXVIe_PLUS& F_WAK = fxvi5;
FXVIe_PLUS& F_SS2 = fxvi5;
FXVIe_PLUS& F_SS1 = fxvi5;
FXVIe_PLUS& F_SDI = fxvi5;
FXVIe_PLUS& F_SDO = fxvi5;
FXVIe_PLUS& F_SCL = fxvi5;
FXVIe_PLUS& F_SCS = fxvi5;
FXVIe_PLUS& F_WDI = fxvi5;
FXVIe_PLUS& F_ROT = fxvi5;
FXVIe_PLUS& F_INT = fxvi5;
FXVIe_PLUS& F_SYN = fxvi5;
FXVIe_PLUS& F_SSD = fxvi5;
FXVIe_PLUS& F_EVS = fxvi5;
FXVIe_PLUS& F_ERR = fxvi5;
FXVIe_PLUS& F_DRG = fxvi5;
FXVIe_PLUS& F_BATS1 = fxvi5;
FXVIe_PLUS& F_BATS2 = fxvi5;
FXVIe_PLUS& F_SQT2 = fxvi5;
FXVIe_PLUS& F_SQT1 = fxvi5;
FXVIe_PLUS& F_SW2 = fxvi5;
FXVIe_PLUS& F_VS2 = fxvi5;
FXVIe_PLUS& F_BSG = fxvi5;
FXVIe_PLUS& F_AGS = fxvi5;
FXVIe_PLUS& F_LSI = fxvi5;
FXVIe_PLUS& F_TPAD = fxvi5;
FXVIe_PLUS& F_RSL2 = fxvi5;

FXVIe_PLUS& F_QT1 = fxvi1;

FXVIe_PLUS& F_QT2 = fxvi2;

FXVIe_PLUS& F_QT3 = fxvi3;

//FPVI
FPVIe& FP_QVR = fpvi0;
FPVIe& FP_QCO = fpvi0;
FPVIe& FP_QUC = fpvi0;
FPVIe& FP_POSSW = fpvi0;
FPVIe& FP_POSIN = fpvi0;
FPVIe& FP_FB = fpvi0;
FPVIe& FP_SW = fpvi0;
FPVIe& FP_VST = fpvi0;
FPVIe& FP_VS1 = fpvi0;
FPVIe& FP_RSH = fpvi0;
FPVIe& FP_POSG = fpvi0;
FPVIe& FP_PG = fpvi0;
FPVIe& FP_RSL = fpvi0;
FPVIe& FP_BSG = fpvi0;
FPVIe& FP_AG = fpvi0;

//QVM

/****STS_PINPLANNER_CODE_END****/

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
BYTE cbitclose(BYTE k1, BYTE k2, BYTE k3, BYTE k4, BYTE k5, BYTE k6, BYTE k7, BYTE k8, BYTE k9, BYTE k10,
	BYTE k11, BYTE k12, BYTE k13, BYTE k14, BYTE k15, BYTE k16, BYTE k17, BYTE k18, BYTE k19, BYTE k20,
	BYTE k21, BYTE k22, BYTE k23, BYTE k24, BYTE k25, BYTE k26, BYTE k27, BYTE k28, BYTE k29, BYTE k30,
	BYTE k31, BYTE k32, BYTE k33, BYTE k34, BYTE k35, BYTE k36, BYTE k37, BYTE k38, BYTE k39, BYTE k40,
	BYTE k41, BYTE k42, BYTE k43, BYTE k44, BYTE k45, BYTE k46, BYTE k47, BYTE k48, BYTE k49, BYTE k50,
	BYTE k51, BYTE k52, BYTE k53, BYTE k54, BYTE k55, BYTE k56, BYTE k57, BYTE k58, BYTE k59, BYTE k60,
	BYTE k61, BYTE k62, BYTE k63, BYTE k64, BYTE k65, BYTE k66, BYTE k67, BYTE k68, BYTE k69, BYTE k70,
	BYTE k71, BYTE k72, BYTE k73, BYTE k74, BYTE k75, BYTE k76, BYTE k77, BYTE k78, BYTE k79, BYTE k80,
	BYTE k81, BYTE k82, BYTE k83, BYTE k84, BYTE k85, BYTE k86, BYTE k87, BYTE k88, BYTE k89, BYTE k90,
	BYTE k91, BYTE k92, BYTE k93, BYTE k94, BYTE k95, BYTE k96, BYTE k97, BYTE k98, BYTE k99, BYTE k100,
	BYTE k101, BYTE k102, BYTE k103, BYTE k104, BYTE k105, BYTE k106, BYTE k107, BYTE k108, BYTE k109, BYTE k110,
	BYTE k111, BYTE k112, BYTE k113, BYTE k114, BYTE k115, BYTE k116, BYTE k117, BYTE k118, BYTE k119, BYTE k120,
	BYTE k121, BYTE k122, BYTE k123, BYTE k124, BYTE k125, BYTE k126, BYTE k127, BYTE k128)
{
	BYTE relay = 0;
	va_list p;

	va_start(p, k1);//֧��128��
	relay = k1;
	//if (relay == 255) return -1;
	for (int i = 0; i < 128; i++)
	{
		cbit.SetCbiteOn(relay);
		relay=va_arg(p, BYTE);
		if (relay == 255) break;
	}
			 
	va_end(p);                 
	return 0;            

}

BYTE cbitopen(BYTE k1, BYTE k2, BYTE k3, BYTE k4, BYTE k5, BYTE k6, BYTE k7, BYTE k8, BYTE k9, BYTE k10,
	BYTE k11, BYTE k12, BYTE k13, BYTE k14, BYTE k15, BYTE k16, BYTE k17, BYTE k18, BYTE k19, BYTE k20,
	BYTE k21, BYTE k22, BYTE k23, BYTE k24, BYTE k25, BYTE k26, BYTE k27, BYTE k28, BYTE k29, BYTE k30,
	BYTE k31, BYTE k32, BYTE k33, BYTE k34, BYTE k35, BYTE k36, BYTE k37, BYTE k38, BYTE k39, BYTE k40,
	BYTE k41, BYTE k42, BYTE k43, BYTE k44, BYTE k45, BYTE k46, BYTE k47, BYTE k48, BYTE k49, BYTE k50,
	BYTE k51, BYTE k52, BYTE k53, BYTE k54, BYTE k55, BYTE k56, BYTE k57, BYTE k58, BYTE k59, BYTE k60,
	BYTE k61, BYTE k62, BYTE k63, BYTE k64, BYTE k65, BYTE k66, BYTE k67, BYTE k68, BYTE k69, BYTE k70,
	BYTE k71, BYTE k72, BYTE k73, BYTE k74, BYTE k75, BYTE k76, BYTE k77, BYTE k78, BYTE k79, BYTE k80,
	BYTE k81, BYTE k82, BYTE k83, BYTE k84, BYTE k85, BYTE k86, BYTE k87, BYTE k88, BYTE k89, BYTE k90,
	BYTE k91, BYTE k92, BYTE k93, BYTE k94, BYTE k95, BYTE k96, BYTE k97, BYTE k98, BYTE k99, BYTE k100,
	BYTE k101, BYTE k102, BYTE k103, BYTE k104, BYTE k105, BYTE k106, BYTE k107, BYTE k108, BYTE k109, BYTE k110,
	BYTE k111, BYTE k112, BYTE k113, BYTE k114, BYTE k115, BYTE k116, BYTE k117, BYTE k118, BYTE k119, BYTE k120,
	BYTE k121, BYTE k122, BYTE k123, BYTE k124, BYTE k125, BYTE k126, BYTE k127, BYTE k128)
{
	BYTE relay = 0;
	va_list p;

	va_start(p, k1);//֧��128��
	relay = k1;
	//if (relay == 255) return -1;
	for (int i = 0; i < 128; i++)
	{
		cbit.SetCbiteOff(relay);
		relay = va_arg(p, BYTE);
		if (relay == 255) break;
	}

	va_end(p);
	return 0;

}