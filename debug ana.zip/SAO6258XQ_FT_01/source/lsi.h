#include "stdafx.h"

#define DDS_SIN			1
#define DDS_TRI			2
#define DDS_REC			3
#define DDS_REC2		4

#define LSI_GAIN_2		0
#define LSI_GAIN_5		1
#define LSI_GAIN_10		2
#define LSI_GAIN_40		3

#define	C_IO0_L			TCA6408_Write(0x01, 0);delay_us(1000)
#define	C_IO0_H			TCA6408_Write(0x01, 1);delay_us(1000)
#define	C_IO1_L			TCA6408_Write(0x02, 0);delay_us(1000)
#define	C_IO1_H			TCA6408_Write(0x02, 1);delay_us(1000)
#define	C_IO2_L			TCA6408_Write(0x04, 0);delay_us(1000)
#define	C_IO2_H			TCA6408_Write(0x04, 1);delay_us(1000)
#define	C_IO3_L			TCA6408_Write(0x08, 0);delay_us(1000)
#define	C_IO3_H			TCA6408_Write(0x08, 1);delay_us(1000)
#define	C_IO4_L			TCA6408_Write(0x10, 0);delay_us(1000)
#define	C_IO4_H			TCA6408_Write(0x10, 1);delay_us(1000)
#define	C_IO5_L			TCA6408_Write(0x20, 0);delay_us(1000)
#define	C_IO5_H			TCA6408_Write(0x20, 1);delay_us(1000)
#define	C_IO6_L			TCA6408_Write(0x40, 0);delay_us(1000)
#define	C_IO6_H			TCA6408_Write(0x40, 1);delay_us(1000)
#define	C_IO7_L			TCA6408_Write(0x80, 0);delay_us(1000)
#define	C_IO7_H			TCA6408_Write(0x80, 1);delay_us(1000)

void LSI_LDO(bool enable);
void LSI_Read_Temp(double temperature[]);
void LSI_Read_EEP(int data[]);

void Sensor_Connect(void);
void Sensor_DisConnect(void);
void Sensor_Start(void);
void Sensor_Stop(void);
void Sensor_Read(double Temperature[]);
void Sensor_ReadID(int *ID);

void TCA6408_Init(void);
void TCA6408_Write(BYTE xbit, BYTE state);

void EEP_Write(DWORD dwRegAddress, DWORD dwDataArray[]);
void EEP_Read(DWORD dwRegAddress, DWORD dwDataArray[]);

void AD8400_Connect(void);
void AD8400_DisConnect(void);
void AD8400_SetResDiv(int div);

void AD9833_Connect(void);
void AD9833_DisConnect(void);
void AD9833_Init(void);
void AD9833_Set_Wave(int type);
int AD9833_Set_Freq(int freq);
void AD9833_Set_Freq(int freq[]);

void Amp_SetGain(int gain);

void LSI_Connect(void);
void LSI_DisConnect(void);
void LSI_I2C_Connect(void);
void LSI_DC(bool on);
void LSI_Init(BYTE EN_SPI, BYTE EN_OUT, BYTE SEL_SPI, BYTE EN_EXSI, BYTE GAIN0, BYTE GAIN1, BYTE EN_LDO);
void LSI_Measure(QVMe qvm_cap, QVMe_HADC_VRANG v_range, unsigned int size, unsigned int fs, unsigned int fx, double amp[]);
void LSI_Calc_Ratio(double SinIn[], double SinOut[], double Gain, double Ratio[], double DB[]);

void Check_LSI_Exist(int has_lsi[], double res[]);
void Check_DFI_Gain(double Gain[]);
void Check_LDO_Vout(double voltage[]);
void Check_LDO_Vout2(double voltage[]);
void Check_DDS_DIV(double clk[], double vmax[], double vmin[]);
void Check_LSI_Gain(double gain1[], double gain2[], double gain3[], double gain4[]);
void Check_LSI_DutIn(double dc, double ampdrvi[], double ampdrvac[], double ampdrvdc[], double ampdutsi[], double ampdutac[], double ampdutdc[]);
void PSRR_Test_ACM(double psrr[]);
void PSRR_Test_LSI(ACM200 &cap, double ref, double psrr[]);


//high level
void DDS_Connect(void);
void DDS_DisConnect(void);
void DDS_Initial(void);
void DDS_SetFreq(int freq);
void DDS_SetFreq(int freq[]);

void PSRR_OutEna(bool en);
void PSRR_SetDc(double voltage);
void PSRR_SetDcOff();
void PSRR_SetAc(void);
void PSRR_SetAcOff();
double PSRR_SetFreq(int freq);
void PSRR_SetGain(int gain);
int PSRR_MeasAmp(int size, int fx, double amp[]);
int PSRR_MeasAmp2(int size, int fx, double amp[]);
void PSRR_CalcRsrr(double dutout[], double psrr[]);
void PSRR_InitSignal(void);
void PSRR_Connect(void);
void PSRR_DisConnect(void);
int PSRR_GetFreq(void);
