// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_)
#define AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>
//#include <minwindef.h>
#define DUT_API extern "C" __declspec(dllexport)
#include <string>
using namespace std;
#include "usertype.h"
#include "userres.h"
#include "SPEC.h"
#include "treg.h"

#ifdef _DEBUG
#define DEBUG_MODE 1
#else
#define DEBUG_MODE 0
#endif
#define SITE_NUM 8

#define nA *0.000000001L
#define uA *0.000001L
#define mA *0.001L
#define A  *1.0

#define nV *0.000000001L
#define uV *0.000001L
#define mV *0.001L
#define V  *1.0

#define nS *0.000000001L
#define uS *0.000001L
#define mS *0.001L
#define S  *1.0

#define Hz *1
#define KHz *1000
#define MHz *1000000

extern bool DEBUG;


//default
//ACM*12
extern ACM200 acm0;
extern ACM200 acm1;
extern ACM200 acm2;
extern ACM200 acm3;
extern ACM200 acm4;
extern ACM200 acm5;
extern ACM200 acm6;
extern ACM200 acm7;
extern ACM200 acm8;
extern ACM200 acm9;
extern ACM200 acm10;
extern ACM200 acm11;
//FXVI*6
extern FXVIe_PLUS fxvi0;
extern FXVIe_PLUS fxvi1;
extern FXVIe_PLUS fxvi2;
extern FXVIe_PLUS fxvi3;
extern FXVIe_PLUS fxvi4;
extern FXVIe_PLUS fxvi5;
//
extern FPVIe fpvi0;
extern QVMe qvm;
extern QTMUe qtmu;
extern QVMe qvm0;
extern QVMe qvm1;
extern QVMe qvm2;
extern QVMe qvm3;
extern QTMUe qtmu0;
extern QTMUe qtmu1;
extern QTMUe qtmu2;
extern QTMUe qtmu3;

//ACM
extern ACM200& A_EXSI;
extern ACM200& A_VCI;
extern ACM200& A_VMON;
extern ACM200& A_VCIVMON;
extern ACM200& A_SEC;
extern ACM200& A_AMUX;
extern ACM200& A_ABUFO;
extern ACM200& A_EVC;
extern ACM200& A_POSFRE;
extern ACM200& A_SECPOSFRE;
extern ACM200& A_EVC2;
extern ACM200& A_POSFRE2;
extern ACM200& A_SEC2;
extern ACM200& A_AMUX2;
extern ACM200& A_NC;
extern ACM200& A_SYN;
extern ACM200& A_EVS;
extern ACM200& A_SSD;
extern ACM200& A_DBUFO;
extern ACM200& A_DIODE;
extern ACM200& A_ABUFO2;
extern ACM200& A_STU;
extern ACM200& A_QST;
extern ACM200& A_PG;
extern ACM200& A_FB1;
extern ACM200& A_FB2;
extern ACM200& A_FB3;
extern ACM200& A_FB4;
extern ACM200& A_POSG;
extern ACM200& A_SQUC;
extern ACM200& A_MPS;
extern ACM200& A_POSIN;
extern ACM200& A_POSSW;
extern ACM200& A_POSFB;
extern ACM200& A_QUC;
extern ACM200& A_QVR;
extern ACM200& A_QCO;

//FXVI
extern FXVIe_PLUS& F_FB;
extern FXVIe_PLUS& F_SW;
extern FXVIe_PLUS& F_RSH;
extern FXVIe_PLUS& F_RSL;
extern FXVIe_PLUS& F_VST;
extern FXVIe_PLUS& F_VS1;
extern FXVIe_PLUS& F_VSX;
extern FXVIe_PLUS& F_ENA;
extern FXVIe_PLUS& F_WAK;
extern FXVIe_PLUS& F_SS2;
extern FXVIe_PLUS& F_SS1;
extern FXVIe_PLUS& F_SDI;
extern FXVIe_PLUS& F_SDO;
extern FXVIe_PLUS& F_SCL;
extern FXVIe_PLUS& F_SCS;
extern FXVIe_PLUS& F_WDI;
extern FXVIe_PLUS& F_ROT;
extern FXVIe_PLUS& F_INT;
extern FXVIe_PLUS& F_SYN;
extern FXVIe_PLUS& F_SSD;
extern FXVIe_PLUS& F_EVS;
extern FXVIe_PLUS& F_ERR;
extern FXVIe_PLUS& F_DRG;
extern FXVIe_PLUS& F_BATS1;
extern FXVIe_PLUS& F_BATS2;
extern FXVIe_PLUS& F_SQT2;
extern FXVIe_PLUS& F_SQT1;
extern FXVIe_PLUS& F_SW2;
extern FXVIe_PLUS& F_VS2;
extern FXVIe_PLUS& F_BSG;
extern FXVIe_PLUS& F_AGS;
extern FXVIe_PLUS& F_LSI;
extern FXVIe_PLUS& F_TPAD;
extern FXVIe_PLUS& F_RSL2;
extern FXVIe_PLUS& F_QT1;
extern FXVIe_PLUS& F_QT2;
extern FXVIe_PLUS& F_QT3;

//FPVI
extern FPVIe& FP_QVR;
extern FPVIe& FP_QCO;
extern FPVIe& FP_QUC;
extern FPVIe& FP_POSSW;
extern FPVIe& FP_POSIN;
extern FPVIe& FP_FB;
extern FPVIe& FP_SW;
extern FPVIe& FP_VST;
extern FPVIe& FP_VS1;
extern FPVIe& FP_RSH;
extern FPVIe& FP_POSG;
extern FPVIe& FP_PG;
extern FPVIe& FP_RSL;
extern FPVIe& FP_BSG;
extern FPVIe& FP_AG;


//#include "BoardCheck.h"
extern DCM dcm;
extern CBITe cbit;
extern TREG dut;
extern SPEC spec;

// SERIAL for active site
extern int globalsite;
extern BYTE sitesta[SITE_NUM];
extern ULONG ulWriteData[SITE_NUM];
extern int nReadData[SITE_NUM];
#define SITE globalsite
#define SERIAL StsGetSiteStatus(sitesta, SITE_NUM); for(globalsite=0;globalsite<SITE_NUM;globalsite++)  if(sitesta[globalsite])
#define SERIAL_ALL for(globalsite=0;globalsite<SITE_NUM;globalsite++) 

extern bool DO_TRIM;
extern bool QC;
extern string int2str(DWORD n);

//cbitA,K1-K151
#define K1							0
#define K2							1
#define K3							2
#define K4							3
#define K5							4
#define K6							5
#define K7							6
#define K8							7
#define K9							8
#define K10							9
#define K11							10
#define K12							11
#define K13							12
#define K14							13
#define K15							14
#define K16							15
#define K17							16
#define K18							17
#define K19							18
#define K20							19
#define K21							20
#define K22							21

#define K30							22
#define K31							23
#define K32							24
#define K33							25
#define K34							26
#define K35							27
#define K36							28
#define K37							29
#define K38							30
#define K39							31
#define K40							32
#define K41							33
#define K42							34
#define K43							35

#define K50							36
#define K51							37
#define K52							38
#define K53							39
#define K54							40
#define K55							41
#define K56							42
#define K57							43
#define K58							44
#define K59							45
#define K60							46
#define K61							47
#define K62							48
#define K63							49
#define K64							50
#define K65							51

#define K70							52
#define K71							53
#define K72							54
#define K73							55
#define K74							56
#define K75							57
#define K76							58
#define K77							59
#define K78							60
#define K79							61
#define K80							62
#define K81							63

#define K82							64
#define K83							65
#define K84							66
#define K85							67
#define K86							68
#define K87							69
#define K88							70
#define K89							71
#define K90							72
#define K91							73
#define K92							74
#define K93							75
#define K94							76
#define K95							77
#define K96							78
#define K97							79

#define K99							80
#define K100						81
#define K101						82
#define K102						83
#define K103						84
#define K104						85
#define K105						86
#define K106						87
#define K107						88
#define K108						89
#define K109						90
#define K110						91
#define K111						92
#define K112						93
#define K113						94
#define K114						95
#define K115						96
#define K116						97
#define K117						98
#define K118						99
#define K119						100
#define K120						101
#define K121						102
#define K122						103
#define K123						104
#define K124						105
#define K125						106
#define K126						107

#define K130						108
#define K131						109
#define K132						110
#define K133_134					111
#define K135						112
#define K136						113
#define K137						114
#define K138						115
#define K139						116
#define K140						117
#define K141						118
#define K142						119
#define K143						120
#define K144						121
#define K145						122
#define K146						123
#define K147						124

#define K149						125
#define K150						126
#define K151						127

//cbitB,K152-
#define K152						128
#define K153						129
#define K154						130
#define K155						131
#define K156						132
#define K157						133
#define K158						134
#define K159						135
#define K160						136
#define K161						137
#define K162						138
#define K163						139
#define K164						140
#define K165						141
#define K166						142
#define K167						143
#define K168						144
#define K169						145
#define K170						146
#define K171						147
#define K172						148
#define K173						149
#define K174						150
#define K175						151
#define K176						152
#define K177						153
#define K178						154
#define K179						155
#define K180						156
#define K181						157
#define K182						158
#define K183						159
#define K184						160
#define K185						161
#define K186						162
#define K187						163
#define K188						164
#define K189						165
#define K190						166
#define K191						167
#define K192						168
#define K193						169
#define K194						170
#define K195						171
#define K196						172
#define K197						173
#define K198						174
#define K199						175
#define K200						176
#define K201						177
#define K202						178
#define K203						179
#define K204						180
#define K205						181
#define K206						182
#define K207						183
#define K208						184
#define K209						185
#define K210						186
#define K211						187
#define K212						188
#define K213						189
#define K214						190
#define K215						191
#define K216						192
#define K217						193
#define K218						194
#define K219						195
#define K220						196
#define K221						197
#define K222						198
#define K223						199
#define K224						200
#define K225						201

#define K230						202
#define K231						203
#define K232						204
#define K233						205
#define K234						206
#define K235						207

#define K_QTMU						245
#define K_QVM						246
#define K_EN_ABUF					247
#define K_EN_DBUF					248
#define K_EN_LDO					249
#define K_EN_OUT					250
#define K_EN_SPI					251
#define K_EN_EXSI					252
#define K_SEL_SPI					253
#define K_GAIN1						254
#define K_GAIN0						255

#define K_LSI_DUTI_FB				K201
#define K_LSI_DUTI_VST				K202
#define K_LSI_DUTO_QST				K203
#define K_LSI_DUTO_QUC				K204
#define K_LSI_DUTO_QCO				K205
#define K_LSI_DUTO_QVR				K206
#define K_LSI_DUTO_QT1				K207
#define K_LSI_DUTO_QT2				K208
#define K_LSI_DUTO_QT3				K209
#define K_LSI_DUTO_VST				K210
#define K_LSI_DUTO_VS1				K211


BYTE cbitclose(BYTE k1, BYTE k2 = -1, BYTE k3 = -1, BYTE k4 = -1, BYTE k5 = -1, BYTE k6 = -1, BYTE k7 = -1, BYTE k8 = -1, BYTE k9 = -1, BYTE k10 = -1,
	BYTE k11 = -1, BYTE k12 = -1, BYTE k13 = -1, BYTE k14 = -1, BYTE k15 = -1, BYTE k16 = -1, BYTE k17 = -1, BYTE k18 = -1, BYTE k19 = -1, BYTE k20 = -1,
	BYTE k21 = -1, BYTE k22 = -1, BYTE k23 = -1, BYTE k24 = -1, BYTE k25 = -1, BYTE k26 = -1, BYTE k27 = -1, BYTE k28 = -1, BYTE k29 = -1, BYTE k30 = -1,
	BYTE k31 = -1, BYTE k32 = -1, BYTE k33 = -1, BYTE k34 = -1, BYTE k35 = -1, BYTE k36 = -1, BYTE k37 = -1, BYTE k38 = -1, BYTE k39 = -1, BYTE k40 = -1,
	BYTE k41 = -1, BYTE k42 = -1, BYTE k43 = -1, BYTE k44 = -1, BYTE k45 = -1, BYTE k46 = -1, BYTE k47 = -1, BYTE k48 = -1, BYTE k49 = -1, BYTE k50 = -1,
	BYTE k51 = -1, BYTE k52 = -1, BYTE k53 = -1, BYTE k54 = -1, BYTE k55 = -1, BYTE k56 = -1, BYTE k57 = -1, BYTE k58 = -1, BYTE k59 = -1, BYTE k60 = -1,
	BYTE k61 = -1, BYTE k62 = -1, BYTE k63 = -1, BYTE k64 = -1, BYTE k65 = -1, BYTE k66 = -1, BYTE k67 = -1, BYTE k68 = -1, BYTE k69 = -1, BYTE k70 = -1,
	BYTE k71 = -1, BYTE k72 = -1, BYTE k73 = -1, BYTE k74 = -1, BYTE k75 = -1, BYTE k76 = -1, BYTE k77 = -1, BYTE k78 = -1, BYTE k79 = -1, BYTE k80 = -1,
	BYTE k81 = -1, BYTE k82 = -1, BYTE k83 = -1, BYTE k84 = -1, BYTE k85 = -1, BYTE k86 = -1, BYTE k87 = -1, BYTE k88 = -1, BYTE k89 = -1, BYTE k90 = -1,
	BYTE k91 = -1, BYTE k92 = -1, BYTE k93 = -1, BYTE k94 = -1, BYTE k95 = -1, BYTE k96 = -1, BYTE k97 = -1, BYTE k98 = -1, BYTE k99 = -1, BYTE k100 = -1,
	BYTE k101 = -1, BYTE k102 = -1, BYTE k103 = -1, BYTE k104 = -1, BYTE k105 = -1, BYTE k106 = -1, BYTE k107 = -1, BYTE k108 = -1, BYTE k109 = -1, BYTE k110 = -1,
	BYTE k111 = -1, BYTE k112 = -1, BYTE k113 = -1, BYTE k114 = -1, BYTE k115 = -1, BYTE k116 = -1, BYTE k117 = -1, BYTE k118 = -1, BYTE k119 = -1, BYTE k120 = -1,
	BYTE k121 = -1, BYTE k122 = -1, BYTE k123 = -1, BYTE k124 = -1, BYTE k125 = -1, BYTE k126 = -1, BYTE k127 = -1, BYTE k128 = -1);
BYTE cbitopen(BYTE k1, BYTE k2 = -1, BYTE k3 = -1, BYTE k4 = -1, BYTE k5 = -1, BYTE k6 = -1, BYTE k7 = -1, BYTE k8 = -1, BYTE k9 = -1, BYTE k10 = -1,
	BYTE k11 = -1, BYTE k12 = -1, BYTE k13 = -1, BYTE k14 = -1, BYTE k15 = -1, BYTE k16 = -1, BYTE k17 = -1, BYTE k18 = -1, BYTE k19 = -1, BYTE k20 = -1,
	BYTE k21 = -1, BYTE k22 = -1, BYTE k23 = -1, BYTE k24 = -1, BYTE k25 = -1, BYTE k26 = -1, BYTE k27 = -1, BYTE k28 = -1, BYTE k29 = -1, BYTE k30 = -1,
	BYTE k31 = -1, BYTE k32 = -1, BYTE k33 = -1, BYTE k34 = -1, BYTE k35 = -1, BYTE k36 = -1, BYTE k37 = -1, BYTE k38 = -1, BYTE k39 = -1, BYTE k40 = -1,
	BYTE k41 = -1, BYTE k42 = -1, BYTE k43 = -1, BYTE k44 = -1, BYTE k45 = -1, BYTE k46 = -1, BYTE k47 = -1, BYTE k48 = -1, BYTE k49 = -1, BYTE k50 = -1,
	BYTE k51 = -1, BYTE k52 = -1, BYTE k53 = -1, BYTE k54 = -1, BYTE k55 = -1, BYTE k56 = -1, BYTE k57 = -1, BYTE k58 = -1, BYTE k59 = -1, BYTE k60 = -1,
	BYTE k61 = -1, BYTE k62 = -1, BYTE k63 = -1, BYTE k64 = -1, BYTE k65 = -1, BYTE k66 = -1, BYTE k67 = -1, BYTE k68 = -1, BYTE k69 = -1, BYTE k70 = -1,
	BYTE k71 = -1, BYTE k72 = -1, BYTE k73 = -1, BYTE k74 = -1, BYTE k75 = -1, BYTE k76 = -1, BYTE k77 = -1, BYTE k78 = -1, BYTE k79 = -1, BYTE k80 = -1,
	BYTE k81 = -1, BYTE k82 = -1, BYTE k83 = -1, BYTE k84 = -1, BYTE k85 = -1, BYTE k86 = -1, BYTE k87 = -1, BYTE k88 = -1, BYTE k89 = -1, BYTE k90 = -1,
	BYTE k91 = -1, BYTE k92 = -1, BYTE k93 = -1, BYTE k94 = -1, BYTE k95 = -1, BYTE k96 = -1, BYTE k97 = -1, BYTE k98 = -1, BYTE k99 = -1, BYTE k100 = -1,
	BYTE k101 = -1, BYTE k102 = -1, BYTE k103 = -1, BYTE k104 = -1, BYTE k105 = -1, BYTE k106 = -1, BYTE k107 = -1, BYTE k108 = -1, BYTE k109 = -1, BYTE k110 = -1,
	BYTE k111 = -1, BYTE k112 = -1, BYTE k113 = -1, BYTE k114 = -1, BYTE k115 = -1, BYTE k116 = -1, BYTE k117 = -1, BYTE k118 = -1, BYTE k119 = -1, BYTE k120 = -1,
	BYTE k121 = -1, BYTE k122 = -1, BYTE k123 = -1, BYTE k124 = -1, BYTE k125 = -1, BYTE k126 = -1, BYTE k127 = -1, BYTE k128 = -1);

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__3811CD50_B7B0_42B9_9E73_805A91708537__INCLUDED_)
