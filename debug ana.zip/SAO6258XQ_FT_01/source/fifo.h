#pragma once

#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#define MAX_NODE_LEN 1024
#define NULL 0

#include <stdio.h>

typedef struct FIFO_NODE {
	int data;
	struct FIFO_NODE* prev;
	struct FIFO_NODE* next;
} Fifo_Node;

typedef struct FIFO_QUEUE {
	struct FIFO_NODE head;
	int count;
} Fifo_Queue;


void insert_first(Fifo_Node* head, Fifo_Node* node);

void delete_node(const Fifo_Node* node);

void delete_node_v1(const Fifo_Node* node);

void delete_node_v2(Fifo_Node* node);

void init_queue(Fifo_Queue* queue);

void in_queue(Fifo_Queue* queue, Fifo_Node* node);

Fifo_Node* out_queue(Fifo_Queue* queue);

void display(const Fifo_Node* head);

void display_v1(const Fifo_Node* head);



