#include "stdafx.h"
#include "part.h"
#include "cmd.h"
#include <iostream>
#include <fstream>



extern TREG dut;
const int Program_Version = 1;
const int Die_Version = 1;//0:1p0,1:1p1,2:2p2
PartNumberNode PNarray[PN_Count];
PartNumberNode PN_Sel;
int PN_Index=0;
int TrimTable_Sel;
PinNode PINarray[PIN_Count];
extern int G_INDEX;
extern int G_INDEX_PRE;
extern int NVM_OPTION_CACL_TREG(void);

double PN_Posbk_Output = 0;//0V,1,25V,0.8V
int PN_Tracker_Num = 2;//2,3
//bool PN_ASF = false;//true,false
bool PN_QST_Before_Prebk = false;//true,false
int PN_INIT_Timer = 600;//600ms,50ms
//int PN_INIT_Counter = 3;//1,3
double PN_Prebk_Output = 5.65;//5.65V
double PN_QST_Output = 5.0;//5V,3.3V
double PN_QUC_Output = 5.0;//5V,3.3V
double PN_QVR_Output = 5.0;//5V,3.3V
double PN_QVR_Output_Target = 5.0;
double PN_QT1_Output_Target = 5.0;
double PN_QT2_Output_Target = 5.0;
double PN_QT3_Output_Target = 5.0;
double PN_QCO_Output = 5.0;//5V
double PN_QT1_Output = 0.0;//follow ref
double PN_QT2_Output = 0.0;//follow ref
double PN_QT3_Output = -1.0;//NA,5.0V,3.3V
bool PN_LOW_UV = false;//qco,qvr,qtx
bool PN_SSD = false;
bool PN_EVS = false;
bool PN_SEC_Available = true;//SEC or POSFRE
bool PN_VCI_Available = true;
bool PN_AMUX_Available = true;
bool PN_Posbk_Available = true;
int PN_ECC = 0;

double PREBK_LSRDSON_QFN48=17.04;
double PREBK_LSRDSON_QFP48=26.07;
double PREBK_LSRDSON_QFP64=42.29;

double PREBK_HSRDSON_QFN48=32.19;
double PREBK_HSRDSON_QFP48=36.76;
double PREBK_HSRDSON_QFP64=0;
//double PREBK_HSRDSON_QFP64=44.68;

double POSBK_LSRDSON_QFN48=31.18;
double POSBK_LSRDSON_QFP48=0.0;
double POSBK_LSRDSON_QFP64=0.0;

double POSBK_HSRDSON_QFN48=34.72;
double POSBK_HSRDSON_QFP48=0.0;
double POSBK_HSRDSON_QFP64=0.0;

double PREBK_LSRDSON_OS=0.0;
double PREBK_HSRDSON_OS=0.0;
double POSBK_LSRDSON_OS=0.0;
double POSBK_HSRDSON_OS=0.0;

double PREBK_LSRDSON_OS_Q=89.9;
double PREBK_HSRDSON_OS_Q=177.5;
double POSBK_LSRDSON_OS_Q=75.6;
double POSBK_HSRDSON_OS_Q=153.8;


struct PinListNode PINlist[PIN_Count] =
{
	//							  0, 3, 5, 4, 6, 7, x, x, 6x
	{ "VS2",			true,	{ 1, 1, 0, 0, 0, 0, 0, 0, 0 } },//0
	{ "VS1",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SW1",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SW2",			true,	{ 1, 1, 0, 0, 0, 0, 0, 0, 0 } },
	{ "BATSNS1",		true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },
	{ "BATSNS2",		true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },//5
	{ "DRG",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "RSH",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "RSL",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "BSG",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "VST",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },//10
	{ "ENA",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "WAK",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "QST",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "AG1",			false,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "AG2",			false,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },//15
	{ "AGS1",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "AGS2",			false,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SS2",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SS1",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SDI",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },//20
	{ "SDO",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SCL",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SCS",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "WDI",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "ROT",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },//25
	{ "INT",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "EVS",			true,	{ 1, 0, 0, 0, 1, 0, 0, 0, 1 } },
	{ "SYN",			true,	{ 1, 1, 1, 1, 0, 0, 0, 0, 0 } },
	{ "SSD",			true,	{ 1, 0, 0, 0, 0, 1, 0, 0, 0 } },
	{ "ERR",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },//30
	{ "EVC",			true,	{ 1, 1, 1, 1, 0, 0, 0, 0, 0 } },
	{ "POSFRE",			true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },
	{ "FRE",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "MPS",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SEC",			true,	{ 1, 1, 1, 1, 0, 0, 0, 0, 0 } },//35
	{ "AMUX",			true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },
	{ "VCI",			true,	{ 1, 1, 1, 1, 0, 0, 0, 0, 0 } },
	{ "VMON",			true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },
	{ "STU",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "AG3",			false,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },//40
	{ "QVR",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "QUC",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SQUC",			true,	{ 1, 1, 0, 0, 0, 0, 0, 0, 0 } },
	{ "QCO",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "QT2",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },//45
	{ "SQT2",			true,	{ 1, 1, 0, 0, 0, 0, 0, 0, 0 } },
	{ "QT1",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "SQT1",			true,	{ 1, 1, 0, 0, 0, 0, 0, 0, 0 } },
	{ "QT3",			true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },
	{ "POSG",			true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },//50
	{ "POSSW",			true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },
	{ "POSIN",			true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },
	{ "POSFB",			true,	{ 1, 0, 0, 0, 1, 1, 0, 0, 1 } },
	{ "FB1",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "FB2",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },//55
	{ "FB3",			true,	{ 1, 1, 0, 0, 0, 0, 0, 0, 0 } },
	{ "FB4",			true,	{ 1, 1, 0, 0, 0, 0, 0, 0, 0 } },
	{ "AG4",			false,	{ 1, 1, 0, 0, 0, 0, 0, 0, 0 } },
	{ "PG2",			false,	{ 1, 1, 0, 0, 0, 0, 0, 0, 0 } },
	{ "PG1",			true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },//60
	{ "TP",				true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "NC",				true,	{ 1, 1, 1, 1, 1, 1, 0, 0, 1 } },
	{ "EN_PCTL",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Prebk_DrEn",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Prebk_LS",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Amux_Vdd",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Bst_PvddGt",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "ProbeGt_Cmn",	true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Posbk_PvddGt",	true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgate_Quc",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgate_Qvr",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vir_SS",			true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vref_AmuxVdd",	true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vref_Dvdd1",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vref_Dvdd2",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vref_IReg1",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vref_IReg2",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vref_IReg3",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vref_Val1",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vref_Val2",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "ProbeGt",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "ProbePad",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Pvss_F1",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Pvss_F2",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "SQCO",			true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "SQT3",			true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "SQVR",			true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "SSD_r",			true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgt_CtlQt1",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgt_CtlQt2",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgt_CtlQt3",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgt_NmsQt1",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgt_NmsQt2",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgt_NmsQt3",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgt_PmsQt1",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgt_PmsQt2",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "Vgt_PmsQt3",		true,	{ 1, 0, 0, 0, 0, 0, 0, 0, 0 } },//CP
	{ "SW_VS1",			true,	{ 1, 1, 1, 1, 1, 1, 1, 1, 1 } },//FT
};

//int find_ID = -1;

void set_rdson_os(void)
{
	int pt = PN_Sel.name_int;
	bool enable_os=true;
	if(enable_os)
	{
		PREBK_LSRDSON_OS=0.0;
		PREBK_HSRDSON_OS=0.0;
		POSBK_LSRDSON_OS=0.0;
		POSBK_HSRDSON_OS=0.0;
		switch(pt)
		{
			case 62584|62584|62587:
				PREBK_LSRDSON_OS=PREBK_LSRDSON_QFN48;
				PREBK_HSRDSON_OS=PREBK_HSRDSON_QFN48;
				POSBK_LSRDSON_OS=POSBK_LSRDSON_QFN48;
				POSBK_HSRDSON_OS=POSBK_HSRDSON_QFN48;
			break;
			case 62585:
				PREBK_LSRDSON_OS=PREBK_LSRDSON_QFP48;
				PREBK_HSRDSON_OS=PREBK_HSRDSON_QFP48;
				POSBK_LSRDSON_OS=POSBK_LSRDSON_QFP48;
				POSBK_HSRDSON_OS=POSBK_HSRDSON_QFP48;
			break;
			case 62583:
				PREBK_LSRDSON_OS=PREBK_LSRDSON_QFP64;
				PREBK_HSRDSON_OS=PREBK_HSRDSON_QFP64;
				POSBK_LSRDSON_OS=POSBK_LSRDSON_QFP64;
				POSBK_HSRDSON_OS=POSBK_HSRDSON_QFP64;
			break;
			default:
				PREBK_LSRDSON_OS=PREBK_LSRDSON_QFN48;
				PREBK_HSRDSON_OS=PREBK_HSRDSON_QFN48;
				POSBK_LSRDSON_OS=POSBK_LSRDSON_QFN48;
				POSBK_HSRDSON_OS=POSBK_HSRDSON_QFN48;
			break;
		}

	}
	else
	{
		PREBK_LSRDSON_OS=0.0;
		PREBK_HSRDSON_OS=0.0;
		POSBK_LSRDSON_OS=0.0;
		POSBK_HSRDSON_OS=0.0;
	}
	if (PN_Sel.name_str.find("QUAL") != -1)
	{ 
		PREBK_LSRDSON_OS=PREBK_LSRDSON_OS+PREBK_LSRDSON_OS_Q;
		PREBK_HSRDSON_OS=PREBK_HSRDSON_OS+PREBK_HSRDSON_OS_Q;
		POSBK_LSRDSON_OS=POSBK_LSRDSON_OS+POSBK_LSRDSON_OS_Q;
		POSBK_HSRDSON_OS=POSBK_HSRDSON_OS+POSBK_HSRDSON_OS_Q;
	}
}

//Trim Table
#define FS_REG_COUNT	30
//									 0000, 0001, 0002, 0003, 0004, 0005, 0006, 0007, 0008, 0009, 0010, 0011, 0012, 0013, 0014, 0015, 0016, 0017, 0018, 0019, 0020, 0021, 0022, 0023, 0024, 0025, 0026, 0027, 0028, 0029
//									 CPxx, 83A1, 83A2, 84A1, 84A2, 85A1, 86A1, 87A1, 86A2, 86A3, 84A3, 84A4, 85A2, 86A4, 83A3, 86A5, 86A7, 86A1, 86A1, 86A8, 86A9, 86B1, 86A6, 84A21,
const int T_FBANK8[FS_REG_COUNT] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
const int T_FBANK7[FS_REG_COUNT] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
const int T_FBANK6[FS_REG_COUNT] = { 0x00, 0x04, 0x07, 0x04, 0x03, 0x00, 0x01, 0x05, 0x05, 0x00, 0x04, 0x00, 0x01, 0x02, 0x00, 0x04, 0x06, 0x04, 0x04, 0x06, 0x00, 0x01, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
const int T_FBANK5[FS_REG_COUNT] = { 0x00, 0x31, 0x23, 0x31, 0x13, 0x01, 0xD1, 0x41, 0x43, 0xD3, 0xD3, 0xC3, 0x53, 0xB3, 0x21, 0x71, 0x03, 0x01, 0x41, 0x01, 0xD1, 0xB1, 0x91, 0x13, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
const int T_FBANK4[FS_REG_COUNT] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x44, 0xF5, 0x10, 0x0E, 0x0E, 0x0E, 0x02, 0xB1, 0x00, 0x00, 0xB2, 0x44, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
const int T_FBANK3[FS_REG_COUNT] = { 0x00, 0xB0, 0xB0, 0xB0, 0xB0, 0xB0, 0xB3, 0x5B, 0xB3, 0xB1, 0xB1, 0xB1, 0x80, 0xC8, 0xB0, 0xB3, 0xC8, 0xB3, 0xB0, 0xF3, 0xB0, 0xB0, 0xB3, 0xB0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
const int T_FBANK2[FS_REG_COUNT] = { 0x00, 0x21, 0x21, 0x21, 0x21, 0x21, 0x81, 0x81, 0x8B, 0x01, 0x21, 0x21, 0x20, 0x20, 0x21, 0xDF, 0x20, 0x01, 0x12, 0x01, 0x34, 0x01, 0x21, 0x21, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
const int T_FBANK1[FS_REG_COUNT] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0A, 0x6A, 0x28, 0x0A, 0x02, 0x02, 0x40, 0x60, 0x00, 0x68, 0x64, 0x0A, 0x60, 0x0A, 0x6B, 0x48, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
const int T_FBANK0[FS_REG_COUNT] = { 0x00, 0x31, 0x3D, 0x31, 0x3C, 0x30, 0x50, 0x52, 0x9D, 0x13, 0x33, 0x3F, 0x2C, 0x0F, 0x3D, 0x90, 0x4F, 0x50, 0x0F, 0x5C, 0x49, 0x91, 0x91, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

void init_partnumber(void)
{
	for (int i = 0; i < PN_Count; i++) 
	{ PNarray[i].name_str = "NULL";			PNarray[i].eng_device = true;   PNarray[i].trim_index = 0;	PNarray[i].name_int = 0;		PNarray[i].ver_int = 0;		PNarray[i].pin_cnt = 0; }
	PNarray[0].name_str =  "SC6258CPENG";	PNarray[0].eng_device = true;   PNarray[0].trim_index = 0;	PNarray[0].name_int = 62580;	PNarray[0].ver_int = 0;		PNarray[0].pin_cnt = 88;
	PNarray[1].name_str =  "SC6258CP";		PNarray[1].eng_device = true;   PNarray[1].trim_index = 0;	PNarray[1].name_int = 62580;	PNarray[1].ver_int = 0;		PNarray[1].pin_cnt = 88;
	PNarray[2].name_str =  "SC62583FT";		PNarray[2].eng_device = true;   PNarray[2].trim_index = 1;	PNarray[2].name_int = 62583;	PNarray[2].ver_int = 0;		PNarray[2].pin_cnt = 64;
	PNarray[3].name_str =  "SC62583QUAL";	PNarray[3].eng_device = true;   PNarray[3].trim_index = 1;	PNarray[3].name_int = 62583;	PNarray[3].ver_int = 0;		PNarray[3].pin_cnt = 64;
	PNarray[4].name_str =  "SC62584FT";		PNarray[4].eng_device = true;   PNarray[4].trim_index = 3;	PNarray[4].name_int = 62584;	PNarray[4].ver_int = 0;		PNarray[4].pin_cnt = 48;
	PNarray[5].name_str =  "SC62584QUAL";	PNarray[5].eng_device = true;   PNarray[5].trim_index = 3;	PNarray[5].name_int = 62584;	PNarray[5].ver_int = 0;		PNarray[5].pin_cnt = 48;
	PNarray[6].name_str =  "SC62585FT";		PNarray[6].eng_device = true;   PNarray[6].trim_index = 5;	PNarray[6].name_int = 62585;	PNarray[6].ver_int = 0;		PNarray[6].pin_cnt = 48;
	PNarray[7].name_str =  "SC62585QUAL";	PNarray[7].eng_device = true;   PNarray[7].trim_index = 5;	PNarray[7].name_int = 62585;	PNarray[7].ver_int = 0;		PNarray[7].pin_cnt = 48;
	PNarray[8].name_str =  "SC62583QA1";	PNarray[8].eng_device = false;  PNarray[8].trim_index = 1;	PNarray[8].name_int = 62583;	PNarray[8].ver_int = 1;		PNarray[8].pin_cnt = 64;
	PNarray[9].name_str =  "SC62583QA2";	PNarray[9].eng_device = false;  PNarray[9].trim_index = 2;	PNarray[9].name_int = 62583;	PNarray[9].ver_int = 2;		PNarray[9].pin_cnt = 64;
	PNarray[10].name_str = "SC62584QA1";	PNarray[10].eng_device = false; PNarray[10].trim_index = 3;	PNarray[10].name_int = 62584;	PNarray[10].ver_int = 1;	PNarray[10].pin_cnt = 48;
	PNarray[11].name_str = "SC62584QA2";	PNarray[11].eng_device = false; PNarray[11].trim_index = 4;	PNarray[11].name_int = 62584;	PNarray[11].ver_int = 2;	PNarray[11].pin_cnt = 48;
	PNarray[12].name_str = "SC62584QA3";	PNarray[12].eng_device = false; PNarray[12].trim_index = 10;PNarray[12].name_int = 62584;	PNarray[12].ver_int = 3;	PNarray[12].pin_cnt = 48;
	PNarray[13].name_str = "SC62585QA1";	PNarray[13].eng_device = false; PNarray[13].trim_index = 5;	PNarray[13].name_int = 62585;	PNarray[13].ver_int = 1;	PNarray[13].pin_cnt = 48;
	PNarray[14].name_str = "SC62586QA1";	PNarray[14].eng_device = false; PNarray[14].trim_index = 6;	PNarray[14].name_int = 62586;	PNarray[14].ver_int = 1;	PNarray[14].pin_cnt = 48;
	PNarray[15].name_str = "SC62586QA2";	PNarray[15].eng_device = false; PNarray[15].trim_index = 8;	PNarray[15].name_int = 62586;	PNarray[15].ver_int = 2;	PNarray[15].pin_cnt = 48;
	PNarray[16].name_str = "SC62586QA3";	PNarray[16].eng_device = false; PNarray[16].trim_index = 9;	PNarray[16].name_int = 62586;	PNarray[16].ver_int = 3;	PNarray[16].pin_cnt = 48;
	PNarray[17].name_str = "SC62587QA1";	PNarray[17].eng_device = false; PNarray[17].trim_index = 7;	PNarray[17].name_int = 62587;	PNarray[17].ver_int = 1;	PNarray[17].pin_cnt = 48;
	PNarray[18].name_str = "SC62586QUAL";	PNarray[18].eng_device = true;  PNarray[18].trim_index = 6;	PNarray[18].name_int = 62586;	PNarray[18].ver_int = 1;	PNarray[18].pin_cnt = 48;
	PNarray[19].name_str = "SC62584QA4";	PNarray[19].eng_device = false; PNarray[19].trim_index = 11;PNarray[19].name_int = 62584;	PNarray[19].ver_int = 4;	PNarray[19].pin_cnt = 48;
	PNarray[20].name_str = "SC62585QA2";	PNarray[20].eng_device = false; PNarray[20].trim_index = 12;PNarray[20].name_int = 62585;	PNarray[20].ver_int = 2;	PNarray[20].pin_cnt = 48;
	PNarray[21].name_str = "SC62586QA4";	PNarray[21].eng_device = false; PNarray[21].trim_index = 13;PNarray[21].name_int = 62586;	PNarray[21].ver_int = 4;	PNarray[21].pin_cnt = 48;
	PNarray[22].name_str = "SC62583QA3";	PNarray[22].eng_device = false; PNarray[22].trim_index = 14;PNarray[22].name_int = 62583;	PNarray[22].ver_int = 3;	PNarray[22].pin_cnt = 64;
	PNarray[23].name_str = "SC62586QA5";	PNarray[23].eng_device = false; PNarray[23].trim_index = 15;PNarray[23].name_int = 62586;	PNarray[23].ver_int = 5;	PNarray[23].pin_cnt = 48;
	PNarray[24].name_str = "SC62586QA7";	PNarray[24].eng_device = false; PNarray[24].trim_index = 16;PNarray[24].name_int = 62586;	PNarray[24].ver_int = 7;	PNarray[24].pin_cnt = 48;
	PNarray[25].name_str = "SC62586QA1_1";	PNarray[25].eng_device = true;  PNarray[25].trim_index = 17;PNarray[25].name_int = 62586;	PNarray[25].ver_int = 1;	PNarray[25].pin_cnt = 48;
	PNarray[26].name_str = "SC62586QA1_2";	PNarray[26].eng_device = true;  PNarray[26].trim_index = 18;PNarray[26].name_int = 62586;	PNarray[26].ver_int = 1;	PNarray[26].pin_cnt = 48;
	PNarray[27].name_str = "SC62586QA8";	PNarray[27].eng_device = false; PNarray[27].trim_index = 19;PNarray[27].name_int = 62586;	PNarray[27].ver_int = 8;	PNarray[27].pin_cnt = 48;
	PNarray[28].name_str = "SC62586QA9";	PNarray[28].eng_device = false; PNarray[28].trim_index = 20;PNarray[28].name_int = 62586;	PNarray[28].ver_int = 9;	PNarray[28].pin_cnt = 48;
	PNarray[29].name_str = "SC62586QB1";	PNarray[29].eng_device = false; PNarray[29].trim_index = 21;PNarray[29].name_int = 62586;	PNarray[29].ver_int = 10;	PNarray[29].pin_cnt = 48;
	PNarray[30].name_str = "SC62586QA6";	PNarray[30].eng_device = false; PNarray[30].trim_index = 22;PNarray[30].name_int = 62586;	PNarray[30].ver_int = 6;	PNarray[30].pin_cnt = 48;
	PNarray[31].name_str = "SC62584QA2_1";	PNarray[31].eng_device = true;  PNarray[31].trim_index = 23;PNarray[31].name_int = 62584;	PNarray[31].ver_int = 2;	PNarray[31].pin_cnt = 48;
	PNarray[32].name_str = "END";			PNarray[32].eng_device = true;  PNarray[32].trim_index = 0;	PNarray[32].name_int = 0000;	PNarray[32].ver_int = 0;	PNarray[32].pin_cnt = 48;
}

void set_trim_table_by_partnumber()
{
	int name = PN_Sel.name_int;
	if		(name == 62583)	{ PN_SEC_Available = true;  PN_AMUX_Available = false; PN_VCI_Available = true;}
	else if (name == 62584)	{ PN_SEC_Available = true;  PN_AMUX_Available = false; PN_VCI_Available = true;}
	else if (name == 62585)	{ PN_SEC_Available = true;  PN_AMUX_Available = false; PN_VCI_Available = true;}
	else if (name == 62586)	{ PN_SEC_Available = false; PN_AMUX_Available = true;  PN_VCI_Available = false;}
	else if (name == 62587)	{ PN_SEC_Available = false; PN_AMUX_Available = true;  PN_VCI_Available = false;}
	else					{ PN_SEC_Available = false; PN_AMUX_Available = false; PN_VCI_Available = false;}
	update_trim_table_and_target(PN_Sel.trim_index);
	set_rdson_os();
}

void export_partnumber_info(void)
{
	char *FileName = "PartNumber_Option.txt";
	time_t nowtime;
	struct tm *timeinfo = NULL;
	time(&nowtime);
	timeinfo = localtime(&nowtime);
	//localtime_s(timeinfo, &nowtime);
	int year, month, day, hour, minute, second;
	if (timeinfo != NULL)
	{
		year = timeinfo->tm_year + 1900;
		month = timeinfo->tm_mon + 1;
		day = timeinfo->tm_mday;
		hour = timeinfo->tm_hour;
		minute = timeinfo->tm_min;
		second = timeinfo->tm_sec;
	}
	else
	{
		year = 0;
		month = 0;
		day = 0;
		hour = 0;
		minute = 0;
		second = 0;
	}
	FILE *fp;
	fp = fopen(FileName, "w");
	if (fp != NULL)
	{
		fprintf(fp, "%d/%d/%d_%d:%d:%d\n", year, month, day, hour, minute, second);
		char Title[] = "PartNumber	Ver	Pin	ECC	CRC	FBANK0	FBANK1	FBANK2	FBANK3	FBANK4	FBANK5	FBANK6	FBANK7	FBANK8";
		fprintf(fp, "%s\n", Title);
	}

	for(int i=0;i<PN_Count;i++)
	{
		PN_Sel = PNarray[i];
		set_trim_table_by_partnumber();
		if((PN_Sel.name_str !="END")&&(PN_Sel.name_str !="NULL"))
		{
			int ecc = dut.sel("ECC_Code").get_working(0);
			int crc = NVM_OPTION_CACL_TREG();
			if (fp != NULL) { fprintf(fp, "%s	%02d	%02d	0x%02X	0x%02X	0x%02X	0x%02X	0x%02X	0x%02X	0x%02X	0x%02X	0x%02X	0x%02X	0x%02X\n", 
				PN_Sel.name_str.c_str(), PN_Sel.ver_int, PN_Sel.pin_cnt, ecc, crc,
				dut.assy("FBANK0").get_working(0),
				dut.assy("FBANK1").get_working(0),
				dut.assy("FBANK2").get_working(0),
				dut.assy("FBANK3").get_working(0),
				dut.assy("FBANK4").get_working(0),
				dut.assy("FBANK5").get_working(0),
				dut.assy("FBANK6").get_working(0),
				dut.assy("FBANK7").get_working(0),
				dut.assy("FBANK8").get_working(0)
			); }
		}

	}
	if (fp != NULL) { fclose(fp); }
	PN_Sel = PNarray[PN_Index];
	set_trim_table_by_partnumber();
	MessageBoxA(NULL, "PartNumber_Option.txt Export Finish !", "System Message", MB_OK);
}

void init_pinlist(void)
{
	int index = 0;
	switch (PN_Sel.name_int)
	{
		case 62580: index = 0; break;
		case 62583: index = 1; break;
		case 62584: index = 3; break;
		case 62585: index = 2; break;
		case 62586: index = 4; break;
		case 62587: index = 5; break;
		default: index = 0; break;
	}
	for (int i = 0; i < PIN_Count; i++) 
	{ 
		PINarray[i].name = PINlist[i].name;
		//PINarray[i].name_pre = PINlist[i].name + "_Pre";
		//PINarray[i].name_post = PINlist[i].name + "_Post";
		PINarray[i].name_os = "OS_" + PINlist[i].name;
		PINarray[i].name_lvl = "LVL_" + PINlist[i].name;
		PINarray[i].name_leak = "LEAK_" + PINlist[i].name;
		PINarray[i].name_leak_delt = "LEAK_" + PINlist[i].name + "_Delt";
		PINarray[i].name_abs = "ABS_" + PINlist[i].name;
		PINarray[i].diode = PINlist[i].diode;
		PINarray[i].pin_valid = PINlist[i].valid[index];
		SERIAL PINarray[i].pin_volt[SITE] = 0;
		SERIAL PINarray[i].pin_lvl[SITE] = 0;
		SERIAL PINarray[i].pin_leak[SITE] = 0;
		SERIAL PINarray[i].pin_abs[SITE] = 0;
		SERIAL PINarray[i].pin_leak_pre[SITE] = 0;
		SERIAL PINarray[i].pin_leak_post[SITE] = 0;
		SERIAL PINarray[i].pin_leak_delt[SITE] = 0;
	}
	if (PN_Sel.name_str.find("QUAL") != -1)
	{ 
		PINarray[9].pin_valid = false;//bsg
		PINarray[16].pin_valid = false;//ags
		PINarray[17].pin_valid = false;//ags
		PINarray[59].pin_valid = false;//pg
		PINarray[60].pin_valid = false;//pg
		PINarray[50].pin_valid = false;//posg
		PINarray[36].pin_valid = false;//amux
	}
	if (PN_Sel.name_str.find("FT") != -1)
	{
		PINarray[16].pin_valid = false;//ags
		PINarray[17].pin_valid = false;//ags
	}
}

void sel_partnumber(int defaultid)
{
	int find_ID = -1;
	char pDes1[] = "Device ID";
	char pData1[256] = { 0 };
	char*ppDes[] = { pDes1 };
	char *ppData[] = { pData1 };
	int OK = -1;
	int Double_OK = -1;
	int times = 3;
	string msgstr;
	string In_ID;
	if (defaultid==-1)
	{
		while (OK != 1 && times>0)
		{
			//OK = STSPopupStringDialog("�����Ϻ�����", ppDes, ppData, 1, "��ʹ��ɨ��ǹ�����Ϻţ�", DO_BoardCheck);//original
			OK = STSPopupStringDialog("�����Ϻ�����", ppDes, ppData, 1, "��ʹ��ɨ��ǹ�����Ϻţ�", false);
			if (OK == 2)
			{
				if (times == 3) MessageBoxA(NULL, "û�е��OK,ȷ�����뷽ʽ�Ƿ���ȷ,ʣ��2�λ��ᣡ", "������ʾ�Ի���", MB_OK);
				if (times == 2) MessageBoxA(NULL, "û�е��OK,ȷ�����뷽ʽ�Ƿ���ȷ,ʣ��1�λ��ᣡ", "������ʾ�Ի���", MB_OK);
				if (times == 1) MessageBoxA(NULL, "û�е��OK,ȷ�����뷽ʽ�Ƿ���ȷ,ʣ��0�λ��ᣡ", "������ʾ�Ի���", MB_OK);
			}
			if (OK == 1)
			{
				In_ID = pData1;
				for (int i = 0; i < PN_Count; i++)
				{
					if (PNarray[i].name_str == "END" || i == PN_Count)
					{
						OK = -1;
						if (times == 3) MessageBoxA(NULL, "û��ƥ�䵽��ȷDevice ID,ʣ��2�λ��ᣬ���������룡", "������ʾ�Ի���", MB_OK);
						if (times == 2) MessageBoxA(NULL, "û��ƥ�䵽��ȷDevice ID,ʣ��1�λ��ᣬ���������룡", "������ʾ�Ի���", MB_OK);
						if (times == 1) MessageBoxA(NULL, "û��ƥ�䵽��ȷDevice ID,ʣ��0�λ��ᣬ���������룡", "������ʾ�Ի���", MB_OK);

						break;
					}

					else if (In_ID.compare(0, PNarray[i].name_str.length(), PNarray[i].name_str, 0, PNarray[i].name_str.length()) == 0)
					{

						find_ID = i;
						msgstr = "�����Ѿ��ҵ����Ϻ�������:" + In_ID;
						Double_OK = MessageBoxA(NULL, msgstr.c_str(), "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
						break;
					}
				}
			}
			times--;
		}
	}
	else
	{
		find_ID = defaultid;//eng usage
	}

	if (find_ID == -1 || Double_OK == 7){ PostQuitMessage(0); }
	else 
	{
		PN_Sel = PNarray[find_ID];
		Check_Eng_Device();
	}
	PN_Index = find_ID;
	//return find_ID;
}

void Check_Eng_Device(void)
{
	if (PN_Sel.eng_device == true) { MessageBoxA(NULL, "���Ǹ������Ϻţ���ȷ��", "Error Message", MB_OK); }
}

int PART_NUM(void)
{
	return PN_Sel.name_int;
}

int PART_VER(void)
{
	return PN_Sel.ver_int;
}

int PIN_CNT(void)
{
	return PN_Sel.pin_cnt;
}

int PROG_VER(void)
{
	return Program_Version;
}

int DIE_VER(void)
{
	return Die_Version;
}

int PART_ENG(void)
{
	return PN_Sel.eng_device;
}

bool PART_QUAL(void)
{
	if (PN_Sel.name_str.find("QUAL") != -1) { return true; }
	else { return false; }
}

int calc_ecc(int data0,int data1,int data2,int data3,int data4,int data5)
{
	int p0 = 0;//0
	int p1 = 0;//1
	int p2 = 0;//0
	int p3 = 0;//0
	int p4 = 0;//1
	int p5 = 0;//1
	int pp = 0;//0

	int table[80] = {-1,-1,0,-1,1,2,3,-1,4,5,6,7,8,9,10,-1,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,-1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49};

	int data5b = data5 & 0x0F;
	int data = 0;

	for(int i=0;i<50;i++)
	{
		int index = table[i];
		int indexi = i+1;
		
		if(index!=-1)
		{
			if(index<8){data = (data0>>index)&0x01;}
			else if(index<16){index=index-8;data = (data1>>index)&0x01;}
			else if(index<24){index=index-16;data = (data2>>index)&0x01;}
			else if(index<32){index=index-24;data = (data3>>index)&0x01;}
			else if(index<40){index=index-32;data = (data4>>index)&0x01;}
			else{index=index-40;data = (data5b>>index)&0x01;}

			if(indexi & 0x01)
			{p0=p0^data;}
		}
	}
	for(int i=0;i<50;i++)
	{
		int index = table[i];
		int indexi = i+1;
		
		if(index!=-1)
		{
			if(index<8){data = (data0>>index)&0x01;}
			else if(index<16){index=index-8;data = (data1>>index)&0x01;}
			else if(index<24){index=index-16;data = (data2>>index)&0x01;}
			else if(index<32){index=index-24;data = (data3>>index)&0x01;}
			else if(index<40){index=index-32;data = (data4>>index)&0x01;}
			else{index=index-40;data = (data5b>>index)&0x01;}

			if(indexi & 0x02)
			{p1=p1^data;}
		}
	}
	for(int i=0;i<50;i++)
	{
		int index = table[i];
		int indexi = i+1;
		
		if(index!=-1)
		{
			if(index<8){data = (data0>>index)&0x01;}
			else if(index<16){index=index-8;data = (data1>>index)&0x01;}
			else if(index<24){index=index-16;data = (data2>>index)&0x01;}
			else if(index<32){index=index-24;data = (data3>>index)&0x01;}
			else if(index<40){index=index-32;data = (data4>>index)&0x01;}
			else{index=index-40;data = (data5b>>index)&0x01;}

			if(indexi & 0x04)
			{p2=p2^data;}
		}
	}
	for(int i=0;i<50;i++)
	{
		int index = table[i];
		int indexi = i+1;
		
		if(index!=-1)
		{
			if(index<8){data = (data0>>index)&0x01;}
			else if(index<16){index=index-8;data = (data1>>index)&0x01;}
			else if(index<24){index=index-16;data = (data2>>index)&0x01;}
			else if(index<32){index=index-24;data = (data3>>index)&0x01;}
			else if(index<40){index=index-32;data = (data4>>index)&0x01;}
			else{index=index-40;data = (data5b>>index)&0x01;}

			if(indexi & 0x08)
			{p3=p3^data;}
		}
	}
	for(int i=0;i<50;i++)
	{
		int index = table[i];
		int indexi = i+1;
		
		if(index!=-1)
		{
			if(index<8){data = (data0>>index)&0x01;}
			else if(index<16){index=index-8;data = (data1>>index)&0x01;}
			else if(index<24){index=index-16;data = (data2>>index)&0x01;}
			else if(index<32){index=index-24;data = (data3>>index)&0x01;}
			else if(index<40){index=index-32;data = (data4>>index)&0x01;}
			else{index=index-40;data = (data5b>>index)&0x01;}

			if(indexi & 0x10)
			{p4=p4^data;}
		}
	}
	for(int i=0;i<50;i++)
	{
		int index = table[i];
		int indexi = i+1;
		
		if(index!=-1)
		{
			if(index<8){data = (data0>>index)&0x01;}
			else if(index<16){index=index-8;data = (data1>>index)&0x01;}
			else if(index<24){index=index-16;data = (data2>>index)&0x01;}
			else if(index<32){index=index-24;data = (data3>>index)&0x01;}
			else if(index<40){index=index-32;data = (data4>>index)&0x01;}
			else{index=index-40;data = (data5b>>index)&0x01;}

			if(indexi & 0x20)
			{p5=p5^data;}
		}
	}
	for(int i=0;i<50;i++)
	{
		int index = table[i];
		int indexi = i+1;
		
		if(index!=-1)
		{
			if(index<8){data = (data0>>index)&0x01;}
			else if(index<16){index=index-8;data = (data1>>index)&0x01;}
			else if(index<24){index=index-16;data = (data2>>index)&0x01;}
			else if(index<32){index=index-24;data = (data3>>index)&0x01;}
			else if(index<40){index=index-32;data = (data4>>index)&0x01;}
			else{index=index-40;data = (data5b>>index)&0x01;}

			pp=pp^data;
		}
	}
	pp=pp^p0^p1^p2^p3^p4^p5;
	int ecc = (pp<<6)+(p5<<5)+(p4<<4)+(p3<<3)+(p2<<2)+(p1<<1)+(p0<<0);
	return ecc;
}

void update_trim_table_and_target(int index)
{
	int ecc = 0;
	//NF trim option**************************************************
	dut.sel("dis_intov12").set_working(0);
	//dut.sel("bst_voutsel").set_working(0);
	dut.sel("bst_pvdd").set_working(0);
	dut.sel("bst_gm").set_working(0);
	dut.sel("bst_drvH").set_working(0);
	dut.sel("bst_c").set_working(0);
	dut.sel("bst_ipfm").set_working(0);
	dut.sel("bst_slp").set_working(0);
	dut.sel("bst_r").set_working(0);
	dut.sel("amux_ts").set_working(0);
	dut.sel("prebck_c").set_working(0);
	dut.sel("prebk_drv").set_working(0);
	dut.sel("prebk_ipfm").set_working(0);
	dut.sel("prebk_r").set_working(0);
	dut.sel("prebk_slop").set_working(0);
	dut.sel("postbk_c_fh").set_working(0);
	dut.sel("postbk_drv").set_working(0);
	dut.sel("postbk_c_fl").set_working(0);
	dut.sel("postbk_gm_fh").set_working(0);
	dut.sel("postbk_gm_fl").set_working(0);
	dut.sel("postbk_ipfm").set_working(0);
	dut.sel("postbk_r_fh").set_working(0);
	dut.sel("postbk_slp_fh").set_working(0);

	if(DIE_VER()==0)
	{
		dut.sel("spsp_opt_cnt").set_working(0);//
		dut.sel("postbk_dis_csr").set_working(0);//

		dut.sel("prebk_drv").set_working(1);//2025/6/16 sean

		dut.sel("postbk_drv").set_working(1);//2025/9/12, xingyu
		dut.sel("postbk_c_fh").set_working(1);//2025/9/12, xingyu
		dut.sel("postbk_c_fl").set_working(2);//2025/9/12, xingyu
		dut.sel("postbk_gm_fh").set_working(1);//2025/9/12, xingyu
		dut.sel("postbk_gm_fl").set_working(1);//2025/9/12, xingyu
		dut.sel("postbk_r_fh").set_working(1);//2025/9/12, xingyu
		dut.trim("bst_ilos").set_target(0.1);//uA
		dut.trim("bst_ocp_stg_war").set_target(160);//mA
	}
	else
	{
		dut.sel("OVENFCCM").set_working(0);
		dut.sel("Vmon_STGTH_SEL").set_working(0);
		dut.trim("bst_ilos").set_target(0.0);//mV
		dut.sel("postbk_drv").set_working(1);//1p1, 2025_12_19
		dut.trim("bst_ocp_stg_war").set_target(210);//mA
		dut.trim("prebk_minpk").set_target(0.29);//2026_1_4

		dut.sel("postbk_c_fh").set_working(1);//1p1, 2026_1_6
		dut.sel("postbk_c_fl").set_working(2);//1p1, 2026_1_6
		dut.sel("postbk_gm_fh").set_working(1);//1p1, 2026_1_6
		dut.sel("postbk_gm_fl").set_working(1);//1p1, 2026_1_6
	}
	
	//manual over-write option


	//FS trim option**************************************************
	dut.assy("FBANK0").set_working(T_FBANK0[index]);
	dut.assy("FBANK1").set_working(T_FBANK1[index]);
	dut.assy("FBANK2").set_working(T_FBANK2[index]);
	dut.assy("FBANK3").set_working(T_FBANK3[index]);
	dut.assy("FBANK4").set_working(T_FBANK4[index]);
	dut.assy("FBANK5").set_working(T_FBANK5[index]);
	dut.assy("FBANK6").set_working(T_FBANK6[index]);
	dut.assy("FBANK7").set_working(T_FBANK7[index]);
	dut.assy("FBANK8").set_working(T_FBANK8[index]);

	//manual over-write option
	// 
	//dut.sel("LBIST_EN").set_working(0);
	//dut.sel("PREBK_SS").set_working(1);
	//dut.sel("SS_HIGH").set_working(0);
	//dut.sel("POSBK_VOUT").set_working(0);
	//dut.sel("PREBK_LMT").set_working(1);
	//dut.sel("POSTBK_LMT").set_working(1);
	//dut.sel("postbk_c_fl").set_working(1);
	//dut.sel("postbk_gm_fl").set_working(2);
	//dut.sel("postbk_r_fh").set_working(2);
	//dut.sel("postbk_slp_fh").set_working(3);
	//dut.trim("postbk_ss").set_working(4);
	//dut.sel("QVR_VOUT").set_working(1);
	//dut.trim("prebk_minpk").set_working(6);
	//dut.sel("QT1_VOUT").set_working(2);
	//dut.sel("POSBK_VOUT").set_working(7);
	//dut.sel("PREBK_VOUT").set_working(1);
	//int i = dut.sel("POSBK_VOUT").get_working(0);
	//int j = dut.sel("PREBK_VOUT").get_working(0);
	//dut.sel("postbk_c_fh").set_working(2);
	//dut.sel("postbk_c_fl").set_working(1);
	//dut.sel("postbk_gm_fh").set_working(2);
	//dut.sel("postbk_gm_fl").set_working(2);
	//dut.sel("postbk_r_fh").set_working(2);
	//dut.sel("postbk_slp_fh").set_working(1);
	//dut.sel("TIMER_INIT").set_working(3);
	//dut.sel("QST_SLOT").set_working(0);
	//dut.sel("QVROVFS").set_working(0);
	//dut.sel("QCO_LMT").set_working(0);
	//dut.sel("QUC_LMT").set_working(0);

	//dut.assy("FBANK0").set_working(0x50);
	//dut.assy("FBANK1").set_working(0x0A);
	//dut.assy("FBANK2").set_working(0x81);
	//dut.assy("FBANK3").set_working(0xB3);
	//dut.assy("FBANK4").set_working(0x44);//

	//dut.sel("QVROVFS").set_working(0);
	//dut.sel("POSTBK_SS").set_working(0);
	//dut.sel("PREBK_SS").set_working(0);
	//dut.sel("ERR_FREQ").set_working(1);


	int bk0 = dut.assy("FBANK0").get_working(0);
	int bk1 = dut.assy("FBANK1").get_working(0);
	int bk2 = dut.assy("FBANK2").get_working(0);
	int bk3 = dut.assy("FBANK3").get_working(0);
	int bk4 = dut.assy("FBANK4").get_working(0);
	int bk5 = dut.assy("FBANK5").get_working(0);
	int bk6 = dut.assy("FBANK6").get_working(0);
	int bk7 = dut.assy("FBANK7").get_working(0);
	int bk8 = dut.assy("FBANK8").get_working(0);
	//ecc0 = calc_ecc(80,10,129,179,68,32);
	int ecc0 = dut.sel("ECC_Code").get_working(0);
	ecc = calc_ecc(bk0, bk1, bk2, bk3, bk4, bk5);
	dut.sel("ECC_Code").set_working(ecc,MS_ALL);//re-calc ECC code
	PN_ECC = ecc;

	int bk0_new = dut.assy("FBANK0").get_working(0);
	int bk1_new = dut.assy("FBANK1").get_working(0);
	int bk2_new = dut.assy("FBANK2").get_working(0);
	int bk3_new = dut.assy("FBANK3").get_working(0);
	int bk4_new = dut.assy("FBANK4").get_working(0);
	int bk5_new = dut.assy("FBANK5").get_working(0);
	int bk6_new = dut.assy("FBANK6").get_working(0);
	int bk7_new = dut.assy("FBANK7").get_working(0);
	int bk8_new = dut.assy("FBANK8").get_working(0);

	//int init_time = dut.sel("TIMER_INIT").get_working(0);

	if(bk0!=bk0_new){MessageBoxA(NULL, "FBANK0 need update", "Error Message", MB_OK);}
	if(bk1!=bk1_new){MessageBoxA(NULL, "FBANK1 need update", "Error Message", MB_OK);}
	if(bk2!=bk2_new){MessageBoxA(NULL, "FBANK2 need update", "Error Message", MB_OK);}
	if(bk3!=bk3_new){MessageBoxA(NULL, "FBANK3 need update", "Error Message", MB_OK);}
	if(bk4!=bk4_new){MessageBoxA(NULL, "FBANK4 need update", "Error Message", MB_OK);}
	if(bk5!=bk5_new){MessageBoxA(NULL, "FBANK5 need update", "Error Message", MB_OK);}
	if(bk6!=bk6_new){MessageBoxA(NULL, "FBANK6 need update", "Error Message", MB_OK);}
	if(bk7!=bk7_new){MessageBoxA(NULL, "FBANK7 need update", "Error Message", MB_OK);}
	if(bk8!=bk8_new){MessageBoxA(NULL, "FBANK8 need update", "Error Message", MB_OK);}

	int code = 0;
	//bank0
	code = dut.sel("QST_SLOT").get_working(0);
	if(code == 0){PN_QST_Before_Prebk = true;}
	else PN_QST_Before_Prebk = false;

	code = dut.sel("QST_VOUT").get_working(0);
	if(code == 0){PN_QST_Output = 5.0; }
	else { PN_QST_Output = 3.3; }
	dut.trim("qst_vref1").set_target(PN_QST_Output);

	code = dut.sel("QUC_VOUT").get_working(0);
	if(code == 0){PN_QUC_Output = 5.0;}
	else { PN_QUC_Output = 3.3; }

	code = dut.sel("POSBK_DIS").get_working(0);
	if(code == 0){PN_Posbk_Available = true;}
	else {PN_Posbk_Available = false;}

	//bank0,1
	code = dut.sel("POSBK_VOUT").get_working(0);
	if((code>=0)&&(code<=12)){PN_Posbk_Output = 0.8+code*0.05;}
	else if(code == 13){PN_Posbk_Output = 1.50;}
	else if(code == 14){PN_Posbk_Output = 1.60;}
	else if(code == 15){PN_Posbk_Output = 1.80;}
	else if(code == 16){PN_Posbk_Output = 2.50;}
	else if(code == 17){PN_Posbk_Output = 3.30;}
	else PN_Posbk_Output = 0.8;
	if(DIE_VER()==0)
	{
		dut.trim("postbk_ea").set_target(PN_Posbk_Output+0.01);
	}
	else
	{
		dut.trim("postbk_ea").set_target(PN_Posbk_Output);
		//2026_1_6
		//posbk v > 1V, set 1, else set 2
		if (PN_Posbk_Output > 1.0) { dut.sel("postbk_r_fh").set_working(1); }
		else { dut.sel("postbk_r_fh").set_working(2); }
	}

	code = dut.sel("PREBK_VOUT").get_working(0);
	if(code == 0){PN_Prebk_Output = 5.8;}
	else if(code == 1){PN_Prebk_Output = 5.65;}
	else if(code == 2){PN_Prebk_Output = 3.9;}
	else {PN_Prebk_Output = 3.9;}
	dut.trim("prebk_ea").set_target(PN_Prebk_Output);

	code = dut.sel("QVR_VOUT").get_working(0);
	if(code == 0){PN_QVR_Output = 5.0;}
	else { PN_QVR_Output = 3.3;}
	//PN_QVR_Output=PN_QVR_Output+0.011;//2025/10/30 SCA li wei
	PN_QVR_Output_Target = PN_QVR_Output+0.011;
	dut.trim("qvr_vref").set_target(PN_QVR_Output_Target);

	code = dut.sel("QCO_VOUT").get_working(0);
	if(code == 0){PN_QCO_Output = 5.0;}
	else if(code == 1){PN_QCO_Output = 3.3;}
	else if(code == 2){PN_QCO_Output = 3.3;}
	else {PN_QCO_Output = 1.8;}
	dut.trim("qco_ea").set_target(PN_QCO_Output);

	//bank2
	code = dut.sel("QT1_VOUT").get_working(0);
	if(code == 0){PN_QT1_Output = PN_QVR_Output;}
	else if(code == 1){PN_QT1_Output = 5.0;}
	else if(code == 2){PN_QT1_Output = 3.3;}
	else {PN_QT1_Output = 1.8;}
	if(code == 0){PN_QT1_Output_Target = PN_QVR_Output_Target;}
	else{PN_QT1_Output_Target = PN_QT1_Output;}
	dut.trim("qt1_vref").set_target(PN_QT1_Output_Target);

	code = dut.sel("QT2_VOUT").get_working(0);
	if(code == 0){PN_QT2_Output = PN_QVR_Output;}
	else if(code == 1){PN_QT2_Output = 5.0;}
	else if(code == 2){PN_QT2_Output = 3.3;}
	else {PN_QT2_Output = 1.8;}
	if(code == 0){PN_QT2_Output_Target = PN_QVR_Output_Target;}
	else{PN_QT2_Output_Target = PN_QT2_Output;}
	dut.trim("qt2_vref").set_target(PN_QT2_Output_Target);

	code = dut.sel("TRK3_DIS").get_working(0);
	if(code == 0){PN_Tracker_Num = 3;}
	else PN_Tracker_Num = 2;

	code = dut.sel("QT3_VOUT").get_working(0);
	if(code == 0){PN_QT3_Output = PN_QVR_Output;}
	else if(code == 1){PN_QT3_Output = 5.0;}
	else if(code == 2){PN_QT3_Output = 3.3;}
	else {PN_QT3_Output = 1.8;}
	if(code == 0){PN_QT3_Output_Target = PN_QVR_Output_Target;}
	else{PN_QT3_Output_Target = PN_QT3_Output;}
	dut.trim("qt3_vref").set_target(PN_QT3_Output_Target);

	//bank3
	code = dut.sel("PREBK_LMT").get_working(0);//0 for low, 1 for high
	if(code == 0){dut.trim("prebk_hscl").set_target(2.4);dut.trim("prebk_lscl").set_target(2.2);}//low
	else {dut.trim("prebk_hscl").set_target(5.0);dut.trim("prebk_lscl").set_target(4.6);}//high

	code = dut.sel("POSTBK_LMT").get_working(0);//0 for low, 1 for high
	if(code == 0){dut.trim("postbk_pkmax").set_target(2.6);dut.trim("postbk_vymax").set_target(-2.3);}
	else {dut.trim("postbk_pkmax").set_target(5.7);dut.trim("postbk_vymax").set_target(-4.6);}

	code = dut.sel("TIMER_INIT").get_working(0);
	if(code == 0){PN_INIT_Timer = 600;}
	else if(code == 1){PN_INIT_Timer = 300;}
	else if(code == 2){PN_INIT_Timer = 150;}
	else PN_INIT_Timer = 50;

	code = dut.sel("SSD_EVS").get_working(0);
	if(code == 0)
	{
		PN_SSD = true;
		PN_EVS = false;
	}
	else
	{
		PN_SSD = false;
		PN_EVS = true;
	}
	//bank4
	code = dut.sel("LOW_UV").get_working(0);
	if(code == 0)
	{
		PN_LOW_UV = false;
	}
	else
	{
		PN_LOW_UV = true;
	}

	code = dut.sel("POSTBK_SS").get_working(0);
	if(code == 0){dut.trim("postbk_ss").set_target(0.2);}
	else if(code == 1){dut.trim("postbk_ss").set_target(2);}
	else {}
}

void get_waferid(int *wafer_id, int *x, int *y)
{
	/*
	Site mapping "+" => skip die
	y --------------------->
	x	1 ++  2 ++  3 ++ 4
	|	+
	|	+
	|	5 ++  6 ++  7 ++ 8
	V

	*/
	int status = 0;
	int wf = 0;
	//char* waferid;
	char waferid[64];
	status = StsGetSingleDieCorXY(0, x[0], y[0]);
	StsGetWaferID(waferid, 63);
	wf = (waferid[7] - '0') * 10 + (waferid[8] - '0');
	if(wf>32){wf=32;}
	if(wf<0){wf=0;}
	SERIAL wafer_id[SITE] = wf;
	//*wafer_id = wf;

	x[0] = x[0];		//site1
	y[0] = y[0];
	x[1] = x[0];		//site2
	y[1] = y[0] + 2;
	x[2] = x[0];		//site3
	y[2] = y[0] + 4;
	x[3] = x[0];		//site4
	y[3] = y[0] + 6;

	x[4] = x[0] + 2;
	y[4] = y[0];
	x[5] = x[0] + 2;
	y[5] = y[0] + 2;
	x[6] = x[0] + 2;
	y[6] = y[0] + 4;
	x[7] = x[0] + 2;
	y[7] = y[0] + 6;

	for (int site = 0; site<SITE_NUM; site++)
	{
		if (x[site] < 0){ x[site] = 0; }
		if (y[site] < 0){ y[site] = 0; }
	}
	for (int site = 1; site<SITE_NUM; site++)
	{
		StsSetDieCorXY(site, x[site], y[site]);
	}
}

int ctl_waferid(bool ft_char, int *x, int *y, int *xy, int *waferid)
{
	bool flag_retest=false;
	int status[SITE_NUM];
	int retest[SITE_NUM];
	SERIAL status[SITE] = STSCBGetRetestStatus(SITE,retest[SITE]);
	SERIAL if(retest[SITE]==1){flag_retest=true;}
	if(!flag_retest){G_INDEX_PRE=G_INDEX;}
	G_INDEX=G_INDEX_PRE;
	if (ft_char)
	{
		SERIAL
		{ 
			G_INDEX++;
			xy[SITE] = G_INDEX;
			waferid[SITE] = G_INDEX / 4096;
			y[SITE] = G_INDEX % 4096 / 64;	
			x[SITE] = G_INDEX % 64;
		}
		//*waferid = 31;//for ft or char
	}
	else
	{
		xy[SITE] = waferid[SITE] * 4096 + y[SITE] * 64 + x[SITE];
	}
	return G_INDEX;
}

void Nvm_ReadFs(int data[][SITE_NUM])
{
	for (int i = 0; i < FBANK_NUM; i++)
	{
		Cmd_Nvm_ReadFs(i, data[i]);
	}
}

void Nvm_Read(int data[][SITE_NUM])
{
	for (int i = 0; i < BANK_NUM; i++)
	{
		Cmd_Nvm_Read(i, data[i]);
	}
}

void Usr_Read(int data[][SITE_NUM])
{
	for (int i = 0; i < USR_NUM; i++)
	{
		CmdReadData(i, data[i]);
	}
}

void  treg2pgs()
{
	std::ofstream pgsfile;
	std::ofstream cppfile;
	map<unsigned int, map<string, unsigned int>> node_map;
	pgsfile.open("pgs.csv");//->file name setting
	cppfile.open("code.cpp");//->file name setting
	// ����ļ��Ƿ�ɹ���
	if (!pgsfile || !cppfile) {
		std::cerr << "�޷����ļ�" << std::endl;
		return;
	}

	int sel_start_work = 0;//if 1, SEL use working as limit, if 0, SEL use start code as limit

	pgsfile << "Function,Symbol,Param,Min,Max,Unit,Format\n";
	
	string trim_str[8] = { "_STEP", "_pre", "_pre_bit", "_post", "_post_bit", "_target", "_guessed", "_updated"};
	string ee_pre_str[2] = { "_READ", "_PRE" };
	string ee_post_str[3] = { "_COMP", "_FINAL", "_FINAL" };

	//trim to pgs
	TRIM_NODE *trim_node;
	string trim_name;
	string trim_unit;
	int trim_steps;
	double trim_target;
	for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++){
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		trim_target = trim_node->get_target(0);
		trim_unit = trim_node->get_base_unit();
		pgsfile << "T_TRIM" << ntrim+1 << "_" << trim_name;
		trim_steps = trim_node->get_steps();
		// "Function,Symbol,Param,Min,Max,Unit,Format\n";
		//steps
		for (int nstep = 0; nstep < trim_steps; nstep++){
			pgsfile << "," << trim_name << trim_str[0] << nstep << "," << trim_name << trim_str[0] << nstep ;//symbol, param
			pgsfile << "," << trim_target*0.1 << "," << trim_target * 2 << "," << trim_unit << ",4"; //min max unit format
			pgsfile << "\n";
		}
		//pre
		pgsfile << "," << trim_name << trim_str[1] << "," << trim_name << trim_str[1] ;//symbol, param
		pgsfile << "," << trim_target*0.1 << "," << trim_target * 2 << "," << trim_unit << ",4"; //min max unit format
		pgsfile << "\n";
		//pre bit
		pgsfile << "," << trim_name << trim_str[2] << "," << trim_name << trim_str[2];//symbol, param
		pgsfile << "," << 0 << "," << trim_steps-1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
		//post
		pgsfile << "," << trim_name << trim_str[3] << "," << trim_name << trim_str[3];//symbol, param
		pgsfile << "," << trim_target*0.9 << "," << trim_target * 1.1 << "," << trim_unit << ",4"; //min max unit format
		pgsfile << "\n";
		//post bit
		pgsfile << "," << trim_name << trim_str[4] << "," << trim_name << trim_str[4];//symbol, param
		pgsfile << "," << 0 << "," << trim_steps-1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
		//target
		pgsfile << "," << trim_name << trim_str[5] << "," << trim_name << trim_str[5];//symbol, param
		pgsfile << ","  << "," << "," << trim_unit << ",4"; //min max unit format
		pgsfile << "\n";
		//guessed
		pgsfile << "," << trim_name << trim_str[6] << "," << trim_name << trim_str[6];//symbol, param
		pgsfile << ","  << ","  << "," << trim_unit << ",4"; //min max unit format
		pgsfile << "\n";
		//updated
		pgsfile << "," << trim_name << trim_str[7] << "," << trim_name << trim_str[7];//symbol, param
		pgsfile << "," << 0 << "," << 1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}

	//EE INIT PGS
	//BANK READ
	ASSY_NODE *assy_node;
	string assy_name;
	int assy_size;
	pgsfile << "T_EE_INIT";
	for (unsigned nassy = 0; nassy < dut.assy.count(); nassy++){
		assy_node = &dut.assy[nassy];
		assy_name = assy_node->get_node_name();
		assy_size = assy_node->count();
		pgsfile << "," << assy_name << ee_pre_str[0] << "," << assy_name << ee_pre_str[0];//symbol, param
		pgsfile << "," << 0 << "," << (1 << assy_size) - 1 << ",DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//TRIM PRE
	for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++){
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		trim_steps = trim_node->get_steps();
		//pre
		pgsfile << "," << trim_name << ee_pre_str[1] << "," << trim_name << ee_pre_str[1];//symbol, param
		pgsfile << "," << 0 << "," << trim_steps-1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//SEL PRE
	SEL_NODE *sel_node;
	string sel_name;
	int sel_limit;
	for (unsigned nsel = 0; nsel < dut.sel.count(); nsel++){
		sel_node = &dut.sel[nsel];
		sel_name = sel_node->get_node_name();
		sel_limit = (sel_start_work ? sel_node->get_working(0): sel_node->get_start(0) );
		//pre
		pgsfile << "," << sel_name << ee_pre_str[1] << "," << sel_name << ee_pre_str[1];//symbol, param
		pgsfile << "," << 0 << "," << sel_limit << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}

	//EE FINAL PGS
	
	//BANK COMP
	pgsfile << "T_EE_FINAL";
	for (unsigned nassy = 0; nassy < dut.assy.count(); nassy++){
		assy_node = &dut.assy[nassy];
		assy_name = assy_node->get_node_name();
		assy_size = assy_node->count();
		pgsfile << "," << assy_name << ee_post_str[0] << "," << assy_name << ee_post_str[0];//symbol, param
		pgsfile << "," << 1 << "," << 1 << ",DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//BANK READ
	for (unsigned nassy = 0; nassy < dut.assy.count(); nassy++){
		assy_node = &dut.assy[nassy];
		assy_name = assy_node->get_node_name();
		assy_size = assy_node->count();
		pgsfile << "," << assy_name << ee_post_str[1] << "," << assy_name << ee_post_str[1];//symbol, param
		pgsfile << "," << 0 << "," << (1 << assy_size) - 1 << ",DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//TRIM FINAL
	for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++){
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		trim_steps = trim_node->get_steps();
		//pre
		pgsfile << "," << trim_name << ee_post_str[2] << "," << trim_name << ee_post_str[2];//symbol, param
		pgsfile << "," << 0 << "," << trim_steps - 1 << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}
	//SEL FINIAL
	for (unsigned nsel = 0; nsel < dut.sel.count(); nsel++){
		sel_node = &dut.sel[nsel];
		sel_name = sel_node->get_node_name();
		sel_limit = (sel_start_work ? sel_node->get_working(0) : sel_node->get_start(0));
		//pre
		pgsfile << "," << sel_name << ee_post_str[2] << "," << sel_name << ee_post_str[2];//symbol, param
		pgsfile << "," << sel_limit << "," << sel_limit << "," << "DB" << ",0"; //min max unit format
		pgsfile << "\n";
	}

	pgsfile.close();//pgs file done
	
	
	cppfile << "//////This file is generated by treg2pgs tool\n//////Below code is measure function declare used in sub.h\n";
	for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++){
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		cppfile << "void measure_" << trim_name << "(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results);\n";
	}

	cppfile << "\n\n//////Below code is measure function defination used in sub.cpp\n";
	for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++){
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();
		cppfile << "void measure_" << trim_name << "(TRIM_NODE *trim_node, TREG_MEASURE_FLAG treg_measure_flag, double *results){\n";
		cppfile << "#ifdef _DEBUG\n";
		cppfile << "    int working = trim_node->get_working(0);\n";
		cppfile << "#endif\n";
		cppfile << "    if (treg_measure_flag == TREG_MEASURE_CHAR) {}\n";
		cppfile << "    if (treg_measure_flag == TREG_MEASURE_PRE) {}\n";
		cppfile << "    if (treg_measure_flag == TREG_MEASURE_POST) {\n";
		cppfile << "        SERIAL {\n";
		cppfile << "            //if (device_trimmed[SITE])\n";
		cppfile << "            //trim_node->copy_read_to_work(SITE); //you should copy read to work for trimmed device\n";
		cppfile << "        }\n";
		cppfile << "    }\n";
		cppfile << "    //efuse_preview();//you should preview code here\n";
		cppfile << "    //you should measure parameter here\n";
		cppfile << "    //SERIAL results[SITE] = -99;//you should save result here\n";
		cppfile << "}\n\n";
	}

	cppfile << "\n\n//////Below code is EE INIT FINAL used in test.cpp\n";
	cppfile << "DUT_API int T_EE_INIT(short funcindex, LPCTSTR funclabel)\n";
	cppfile << "{  \n";
	cppfile << "    //{{AFX_STS_PARAM_PROTOTYPES\n";
	cppfile << "    //}}AFX_STS_PARAM_PROTOTYPES\n";
	cppfile << "\n";
	cppfile << "    // TODO: Add your function code here\n";
	cppfile << "    // add your readback code here\n";
	cppfile << "    // make sure readback value is stored in TREG read_back \n";
	cppfile << "    //Bank READ\n";
	cppfile << "    for (int reg = 0; reg < dut.assy.count(); ++reg)\n";
	cppfile << "    {\n";
	cppfile << "        string EE_str = string(dut.assy[reg].get_name()) + \"_READ\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //TRIM PRE\n";
	cppfile << "    for (int reg = 0; reg < dut.trim.count(); ++reg){\n";
	cppfile << "        string EE_str = string(dut.trim[reg].get_name()) + \"_PRE\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.trim[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //SEL PRE\n";
	cppfile << "    for (int reg = 0; reg < dut.sel.count(); ++reg){\n";
	cppfile << "        string EE_str = string(dut.sel[reg].get_name()) + \"_PRE\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.sel[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //check device trimmed\n";
	cppfile << "    SERIAL{\n";
	cppfile << "        if (dut.assy(\"EFUSE0\").get_read_back(SITE) != 0)\n";
	cppfile << "            device_trimmed[SITE] = 1;\n";
	cppfile << "        else\n";
	cppfile << "            device_trimmed[SITE] = 0;\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    return 0;\n";
	cppfile << "}\n\n";

	cppfile << "DUT_API int T_EE_FINAL(short funcindex, LPCTSTR funclabel)\n";
	cppfile << "{\n";
	cppfile << "    //{{AFX_STS_PARAM_PROTOTYPES\n";
	cppfile << "    //}}AFX_STS_PARAM_PROTOTYPES\n";
	cppfile << "    // TODO: Add your function code here\n";
	cppfile << "    // add your readback code here\n";
	cppfile << "    // make sure readback value is stored in TREG read_back\n";
	cppfile << "\n";
	cppfile << "    //Bank FINAL\n";
	cppfile << "    for (int reg = 0; reg < dut.assy.count(); ++reg)\n";
	cppfile << "    {\n";
	cppfile << "        string EE_str = string(dut.assy[reg].get_name()) + \"_FINAL\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].get_read_back(SITE));\n";
	cppfile << "\n";
	cppfile << "        EE_str = string(dut.assy[reg].get_name()) + \"_COMP\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.assy[reg].comp_read_to_work(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //TRIM FINAL\n";
	cppfile << "    for (int reg = 0; reg < dut.trim.count(); ++reg){\n";
	cppfile << "        string EE_str = string(dut.trim[reg].get_name()) + \"_FINAL\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.trim[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    //SEL FINAL\n";
	cppfile << "    for (int reg = 0; reg < dut.sel.count(); ++reg){\n";
	cppfile << "        string EE_str = string(dut.sel[reg].get_name()) + \"_FINAL\";\n";
	cppfile << "        SERIAL StsGetParam(funcindex, EE_str.c_str())->SetTestResult(SITE, 0, dut.sel[reg].get_read_back(SITE));\n";
	cppfile << "    }\n";
	cppfile << "\n";
	cppfile << "    return 0;\n";
	cppfile << "}\n\n";

	cppfile << "\n\n//////Below code is for TRIM used in test.cpp\n";
	for (unsigned ntrim = 0; ntrim < dut.trim.count(); ntrim++){
		trim_node = &dut.trim[ntrim];
		trim_name = trim_node->get_node_name();

		cppfile << "DUT_API int T_TRIM" << ntrim + 1 << "_" << trim_name << "(short funcindex, LPCTSTR funclabel)\n"; 
		cppfile << "{\n";
		cppfile << "    //{{AFX_STS_PARAM_PROTOTYPES\n";
		cppfile << "    //}}AFX_STS_PARAM_PROTOTYPES\n\n";
		cppfile << "    // TODO: Add your functOion code here\n\n";
		cppfile << "    // Relay Setup here\n";
		cppfile << "    // Power on here\n";
		cppfile << "    // Enter TM here\n";
		cppfile << "    // Preview Fuse here\n";
		cppfile << "    // Set TM n here\n";
		//dut.trim("BG_SYS").execute(measure_BG_SYS, spec, funcindex, funclabel, 1, 0, "BG_SYS");
		cppfile << "	dut.trim(\"" << trim_name << "\").execute(measure_" << trim_name << ", spec, funcindex, funclabel, 1, 0, \"" << trim_name  << "\");\n ";
		cppfile << "    // Power off and clean up here\n";
		cppfile << "    return 0;\n";
		cppfile << "}\n\n";

	}
	cppfile.close();//cpp file done

	MessageBoxA(NULL, "Treg to PGS Information Export Finish !", "System Message", MB_OK);
}

static int getSetting(READER &r, const char *param, const char *setting, int default_value) {
	bool flag = false;
	int return_value = 0; // return 0 if it's not found anywhere

	if (r.getBoolean(param, setting, &flag)) // check for true/false on parameter
		flag ? return_value = default_value : return_value = 0;
	else if (!r.getInteger(param, setting, &return_value)) {     // check for integer on parameter
		if ((r.getSection(_DEFAULT))) {                          // check for _DEFAULT section
			if (r.getBoolean(_DEFAULT, setting, &flag))          // check for true/false on DEFAULT
				flag ? return_value = default_value : return_value = 0;
			else
				r.getInteger(_DEFAULT, setting, &return_value); // check for integer on DEFAULT
		}
	}
	return return_value;
}

void read_partnumber(const char *file_name)
{
	const char *p;
	int   table[256];
	int size = 0;
	READER	reader;
	SECTION  *section = NULL;
	string pathofini = "";
	int ItemCount = 0;
	string fullpathini(file_name);
	int pos = fullpathini.find_last_of('\\');
	if (pos > -1) { pathofini = fullpathini.substr(0, pos + 1); }

	if (!reader.open(file_name)) {
		MessageBox(NULL, "sta.ini not found.", "STA Message", MB_OK);
	}
	else
	{
		while ((section = reader.getNextSection()))
		{
			p = section->getName();

			switch (*p) 
			{
				case '*': // ignore other section headers (SEL,ASSY,ASSY_GRP,TRIM_GRP)
				case '_':
				case '#':
				case '$':
				case '%':
				case '&':
					break;
				default: 
				{ //found
					if (_stricmp(p, "DEFAULT") != 0) // ignore default
					{
						PNarray[ItemCount].name_str = section->getName();
						PNarray[ItemCount].trim_index = getSetting(reader, p, "trim_index", 1);
						PNarray[ItemCount].name_int = getSetting(reader, p, "name_int", 1);
						PNarray[ItemCount].ver_int = getSetting(reader, p, "ver_int", 1);
						PNarray[ItemCount].pin_cnt = getSetting(reader, p, "pin_cnt", 1);
						//dut.assy("FBANK0").set_working(getSetting(reader, p, "T_FBANK0 ", 1));
						//dut.assy("FBANK1").set_working(getSetting(reader, p, "T_FBANK1 ", 1));
						//dut.assy("FBANK2").set_working(getSetting(reader, p, "T_FBANK2 ", 1));
						//dut.assy("FBANK3").set_working(getSetting(reader, p, "T_FBANK3 ", 1));
						//dut.assy("FBANK4").set_working(getSetting(reader, p, "T_FBANK4 ", 1));
						//dut.assy("FBANK5").set_working(getSetting(reader, p, "T_FBANK5 ", 1));
						//dut.assy("FBANK6").set_working(getSetting(reader, p, "T_FBANK6 ", 1));
						//dut.assy("FBANK7").set_working(getSetting(reader, p, "T_FBANK7 ", 1));
						//dut.assy("FBANK8").set_working(getSetting(reader, p, "T_FBANK8 ", 1));
						//string str = reader.getString(p, "STA_CVT_ARRAY");
						ItemCount++;
					}
				} break;
			}	
		}
	}
}

void PartNum_Select_Dialog() 
{
	int OK = -1;
	int Double_OK = -1;
	int times = 1;
	char pcdata[256] = { 0 };
	//string Part_Number = {"SC62583Q","SC62584Q","SC62585Q","SC62586Q","SC62587Q"};
	while (OK != 1 && times > 0)
	{
		/*ѡ���Ϻ�*/
		CInputDlg* pdlg = STSGetDialog("�����Ϻ�����", "��ǰΪADMINģʽ��ʾ����");
		CInputData* devicelist = pdlg->InsertConrolItem("Part Number", CInputData::CONTROL_COMBOX);
		if (pdlg != NULL) {
			
			if (devicelist != NULL) {
				devicelist->InsertSelect("-1");
				devicelist->InsertSelect("SC62583Q");
				devicelist->InsertSelect("SC62584Q");
				devicelist->InsertSelect("SC62585Q");
				devicelist->InsertSelect("SC62586Q");
				devicelist->InsertSelect("SC62587Q");
				devicelist->SetDefaultValue("-1");
			}
		}
		pdlg->ShowDlg();
		//const char* PNP = (devicelist->GetInputStr());
		std::string PN = devicelist->GetInputStr();


		/*ѡ��汾*/
		CInputDlg* pDlg = STSGetDialog("�����Ϻ�ѡ��", "��ǰΪADMINģʽ��ʾ����");
		CInputData* optionlist = pDlg->InsertConrolItem("Option", CInputData::CONTROL_COMBOX);
		
		if (PN == "SC62583Q") {
			if (pDlg != NULL) {
				if (optionlist != NULL) {
					optionlist->InsertSelect("A1");
					optionlist->InsertSelect("A2");
					optionlist->InsertSelect("A3");
					//optionlist->InsertSelect("A4");
					//optionlist->InsertSelect("A5");
					//optionlist->InsertSelect("A6");
					//optionlist->InsertSelect("A7");
					//optionlist->InsertSelect("A8");
					//optionlist->InsertSelect("A9");
				}
			}
		}
		if (PN == "SC62584Q") {
			if (pDlg != NULL) {
				if (optionlist != NULL) {
					optionlist->InsertSelect("A1");
					optionlist->InsertSelect("A2");
					optionlist->InsertSelect("A3");
					optionlist->InsertSelect("A4");
					//optionlist->InsertSelect("A5");
					//optionlist->InsertSelect("A6");
					//optionlist->InsertSelect("A7");
					//optionlist->InsertSelect("A8");
					//optionlist->InsertSelect("A9");
				}
			}
		}
		if (PN == "SC62585Q") {
			if (pDlg != NULL) {
				if (optionlist != NULL) {
					optionlist->InsertSelect("A1");
					optionlist->InsertSelect("A2");
					//optionlist->InsertSelect("A3");
					//optionlist->InsertSelect("A4");
					//optionlist->InsertSelect("A5");
					//optionlist->InsertSelect("A6");
					//optionlist->InsertSelect("A7");
					//optionlist->InsertSelect("A8");
					//optionlist->InsertSelect("A9");
				}
			}
		}
		if (PN == "SC62586Q") {
			if (pDlg != NULL) {
				if (optionlist != NULL) {
					optionlist->InsertSelect("A1");
					optionlist->InsertSelect("A2");
					optionlist->InsertSelect("A3");
					optionlist->InsertSelect("A4");
					optionlist->InsertSelect("A5");
					optionlist->InsertSelect("A6");
					optionlist->InsertSelect("A7");
					optionlist->InsertSelect("A8");
					optionlist->InsertSelect("A9");
				}
			}
		}
		if (PN == "SC62587Q") {
			if (pDlg != NULL) {
				if (optionlist != NULL) {
					optionlist->InsertSelect("A1");
					//optionlist->InsertSelect("A2");
					//optionlist->InsertSelect("A3");
					//optionlist->InsertSelect("A4");
					//optionlist->InsertSelect("A5");
					//optionlist->InsertSelect("A6");
					//optionlist->InsertSelect("A7");
					//optionlist->InsertSelect("A8");
					//optionlist->InsertSelect("A9");
				}
			}
		}
		pDlg->ShowDlg();
		//const char* OPP = (optionlist->GetInputStr());
		std::string OP = optionlist->GetInputStr();

		if (PN == "SC62583Q" && OP == "A1") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62583QA1", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(8);
		}
		if (PN == "SC62583Q" && OP == "A2") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62583QA2", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(9);
		}
		if (PN == "SC62583Q" && OP == "A3") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62583QA3", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(10);
		}
		if (PN == "SC62584Q" && OP == "A1") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62584QA1", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(8);
		}
		if (PN == "SC62584Q" && OP == "A2") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62584QA2", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(8);
		}
		if (PN == "SC62584Q" && OP == "A3") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62584QA3", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(8);
		}
		if (PN == "SC62584Q" && OP == "A4") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62584QA4", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(8);
		}
		if (PN == "SC625835Q" && OP == "A1") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62585QA1", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(8);
		}
		if (PN == "SC625835Q" && OP == "A2") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62585QA2", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(8);
		}
		if (PN == "SC62586Q" && OP == "A1") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62586QA1", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		if (PN == "SC62586Q" && OP == "A2") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62586QA2", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		if (PN == "SC62586Q" && OP == "A3") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62586QA3", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		if (PN == "SC62586Q" && OP == "A4") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62586QA4", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		if (PN == "SC62586Q" && OP == "A5") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62586QA5", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		if (PN == "SC62586Q" && OP == "A6") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62586QA6", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		if (PN == "SC62586Q" && OP == "A7") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62586QA7", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		if (PN == "SC62586Q" && OP == "A8") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62586QA8", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		if (PN == "SC62586Q" && OP == "A9") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62586QA9", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		if (PN == "SC62587Q" && OP == "A1") {
			Double_OK = MessageBoxA(NULL, "�����Ѿ��ҵ����Ϻ������ǣ�SC62587QA1", "���ٴ�ȷ�ϼ������������Ϻ��Ƿ��빤��ƥ�䣡", MB_YESNO);
			sel_partnumber(14);
		}
		times--;
		if (Double_OK == 7) PostQuitMessage(0);
	}
}

void PartNum_Select_Dialog2() 
{
	int OK = -1;
	int Double_OK = -1;
	int times = 1;
	char pcdata[256] = { 0 };
	while (OK != 1 && times > 0)
	{
		/*ѡ���Ϻ�*/
		CInputDlg* pdlg = STSGetDialog("�����Ϻ�����", "��ǰΪADMINģʽ��ʾ����");
		CInputData* devicelist = pdlg->InsertConrolItem("Part Number", CInputData::CONTROL_COMBOX);
		if (pdlg != NULL) 
		{
			if (devicelist != NULL) 
			{
				for(int i=0;i<PN_Count;i++)
				{
					PN_Sel = PNarray[i];
					if((PN_Sel.name_str !="END")&&(PN_Sel.name_str !="NULL"))
					{
						devicelist->InsertSelect(PN_Sel.name_str.c_str());
					}
				}
				devicelist->SetDefaultValue("SC62586QA1");
			}
		}
		pdlg->ShowDlg();
		std::string PN = devicelist->GetInputStr();
		int find_ID = 0;
		for (int i = 0; i < PN_Count; i++)
		{
			if (PN.compare(0, PNarray[i].name_str.length(), PNarray[i].name_str, 0, PNarray[i].name_str.length()) == 0)
			{
				find_ID = i;
			}
		}
		PN_Sel = PNarray[find_ID];
		PN_Index = find_ID;
		Check_Eng_Device();
		times--;
		if (Double_OK == 7) PostQuitMessage(0);
	}
}
