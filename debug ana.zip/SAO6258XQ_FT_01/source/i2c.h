//2025/1/22
//Hunter Liu

class I2C_Class
{
public:
	void initial(double freq, double vih, double vil, double voh, double vol);
	void dut_write_x1(int RegAddress, int WriteData);
	void dut_write_x1(int RegAddress, int *WriteData);
	void dut_read_x1(int RegAddress, int ReadData1[]);
};