#pragma once

#include "stdafx.h"
#include "BoardCheck.h"
#include "assert.h"
#include <fstream>
#include <time.h>
#pragma comment(lib, "User32.lib")
#pragma comment(lib, "Gdi32.lib")

extern "C" int GetPgsFullPath(LPTSTR pgsPath, int chNum);

BoardCheck *boardcheck_ptr;
DWORD serial;

#define ID_REDO					100
#define ID_EXIT                 101
#define ID_LISTBOX              102

//int globalsite_BC;
//BYTE sitesta_BC[SITE_NUM];
//#define SITE_BC globalsite_BC
//#define SERIAL_BC \
//		StsGetSiteStatus(sitesta_BC, SITE_NUM); \
//        for(globalsite_BC=0;globalsite_BC<SITE_NUM;globalsite_BC++) \
//			if(sitesta_BC[SITE_BC]) \

int globalsite_BC;
#define SITE_BC globalsite_BC
#define SERIAL_BC \
        for(globalsite_BC=0;globalsite_BC<SITE_NUM;globalsite_BC++) \
			if(site_connected[SITE_BC]) \

#define REALLOC(ptr,type,count)              \
    {                                        \
        int siz=sizeof(type)*(count);        \
        if(ptr) {                            \
            ptr=(type*)realloc(ptr,siz);     \
            assert(ptr);                     \
        } else {                             \
            ptr=(type*)malloc(siz);          \
            assert(ptr);                     \
            memset(ptr,0,siz);               \
        }                                    \
        assert(ptr);                         \
    }
#define FREE(ptr) if(ptr) {free(ptr);ptr=NULL;}

// common funcitons
string int2str(DWORD n) {
 
    char t[64];
    int i = 0;

	if(n == 0)
		return "0";
 
    while (n) {
		t[i++] = char((n % 10) + '0');
        n /= 10;
    }
    t[i] = 0;

	string result(t);
	result = result.assign(result.rbegin(), result.rend());
 
    return result;
}

string float2str(double f){
    char buf[64];
	_gcvt_s(buf, 64, f, 8);
	string result(buf);
	if(result.length() > 1)
		if(result.find(".") == result.length() - 1){
			string temp(result, 0, result.length() - 1);
			result = temp;
		}

	return result;
}

BOOL IsFileExist(const char * file_name){
	fstream file;
	file.open(file_name, ios::in);
	if(!file){
		return FALSE;
	}
	else{
		file.close();
		return TRUE;
	}

}

BOOL IsFileOpen(string file){
	HANDLE hFile = CreateFile(file.c_str(),		 // file to open
					   GENERIC_READ,		 // open for reading
					   0,					 // share for reading
					   NULL,				 // default security
					   OPEN_EXISTING,		 // existing file only
					   FILE_ATTRIBUTE_NORMAL,// normal file
					   NULL);				 // no attr. template
	
	if(hFile == INVALID_HANDLE_VALUE){	// file is open
		CloseHandle(hFile);  
		return TRUE;
	}
	else{
		CloseHandle(hFile);  
		return FALSE;
	}
}

string GetSysTime(void){
	time_t raw_time;
	tm time_info;
	time(&raw_time);
	localtime_s(&time_info, &raw_time);
	char c_time[32];

	strftime(c_time, sizeof(c_time), "%Y-%m-%d,%H:%M:%S", &time_info);
	string str_time(c_time);

	return str_time;
}

DialogTemplate::DialogTemplate(LPCSTR caption, DWORD style, int x, int y, int w, int h,
        LPCSTR font, WORD fontSize)
{
    usedBufferLength = sizeof(DLGTEMPLATE );
    totalBufferLength = usedBufferLength;

    dialogTemplate = (DLGTEMPLATE*)malloc(totalBufferLength);
    assert(dialogTemplate);

    dialogTemplate->style = style;

    if (font != NULL) {
        dialogTemplate->style |= DS_SETFONT;
    }

    dialogTemplate->x     = x;
    dialogTemplate->y     = y;
    dialogTemplate->cx    = w;
    dialogTemplate->cy    = h;
    dialogTemplate->cdit  = 0;

    dialogTemplate->dwExtendedStyle = 0;

    // The dialog box doesn't have a menu or a special class
    //AppendData(_T("\0"), 2);
    //AppendData(_T("\0"), 2);
	//lzg
    AppendData("\0", 2);
    AppendData("\0", 2);

    // Add the dialog's caption to the template
    AppendString(caption);

    if (font != NULL) {
        AppendData(&fontSize, sizeof(WORD));
        AppendString(font);
    }

}

void DialogTemplate::AddComponent(LPCSTR type, LPCSTR caption, DWORD style, DWORD exStyle,
        int x, int y, int w, int h, WORD id)
{
    DLGITEMTEMPLATE item;

    item.style = style;
    item.x     = x;
    item.y     = y;
    item.cx    = w;
    item.cy    = h;
    item.id    = id;

    item.dwExtendedStyle = exStyle;

    AppendData(&item, sizeof(DLGITEMTEMPLATE));

    AppendString(type);
    AppendString(caption);

    WORD creationDataLength = 0;
    AppendData(&creationDataLength, sizeof(WORD));

    // Increment the component count
    dialogTemplate->cdit++;
}


void DialogTemplate::AddButton(LPCSTR caption, DWORD style, DWORD exStyle, int x, int y,
        int w, int h, WORD id)
{
    AddStandardComponent(0x0080, caption, style, exStyle, x, y, w, h, id);

    WORD creationDataLength = 0;
    AppendData(&creationDataLength, sizeof(WORD));

}

void DialogTemplate::AddEditBox(LPCSTR caption, DWORD style, DWORD exStyle, int x, int y,
        int w, int h, WORD id)
{
    AddStandardComponent(0x0081, caption, style, exStyle, x, y, w, h, id);

    WORD creationDataLength = 0;
    AppendData(&creationDataLength, sizeof(WORD));
}

void DialogTemplate::AddStatic(LPCSTR caption, DWORD style, DWORD exStyle, int x, int y,
        int w, int h, WORD id)
{
    AddStandardComponent(0x0082, caption, style, exStyle, x, y, w, h, id);

    WORD creationDataLength = 0;
    AppendData(&creationDataLength, sizeof(WORD));
}

void DialogTemplate::AddListBox(LPCSTR caption, DWORD style, DWORD exStyle, int x, int y,
        int w, int h, WORD id)
{
    AddStandardComponent(0x0083, caption, style, exStyle, x, y, w, h, id);

    WORD creationDataLength = 0;
    AppendData(&creationDataLength, sizeof(WORD));
}

void DialogTemplate::AddScrollBar(LPCSTR caption, DWORD style, DWORD exStyle, int x, int y,
        int w, int h, WORD id)
{
    AddStandardComponent(0x0084, caption, style, exStyle, x, y, w, h, id);

    WORD creationDataLength = 0;
    AppendData(&creationDataLength, sizeof(WORD));
}

void DialogTemplate::AddComboBox(LPCSTR caption, DWORD style, DWORD exStyle, int x, int y,
        int w, int h, WORD id)
{
    AddStandardComponent(0x0085, caption, style, exStyle, x, y, w, h, id);

    WORD creationDataLength = 0;
    AppendData(&creationDataLength, sizeof(WORD));
}

    /**
     * Returns a pointer to the Win32 dialog template which the object
     * represents. This pointer may become invalid if additional
     * components are added to the template.
     */

DialogTemplate::operator const DLGTEMPLATE*() const
{
    return dialogTemplate;
}

DialogTemplate::~DialogTemplate()
{
    free(dialogTemplate);
}

void DialogTemplate::AddStandardComponent(WORD type, LPCSTR caption, DWORD style,
        DWORD exStyle, int x, int y, int w, int h, WORD id)
{
    DLGITEMTEMPLATE item;

    // DWORD algin the beginning of the component data
    AlignData(sizeof(DWORD));

    item.style = style;
    item.x     = x;
    item.y     = y;
    item.cx    = w;
    item.cy    = h;
    item.id    = id;

    item.dwExtendedStyle = exStyle;

    AppendData(&item, sizeof(DLGITEMTEMPLATE));

    WORD preType = 0xFFFF;

    AppendData(&preType, sizeof(WORD));
    AppendData(&type, sizeof(WORD));

    AppendString(caption);

    // Increment the component count
    dialogTemplate->cdit++;
}

void DialogTemplate::AlignData(int size)
{
    int paddingSize = usedBufferLength % size;

    if (paddingSize != 0) {
        EnsureSpace(paddingSize);
        usedBufferLength += paddingSize;
    }
}

void DialogTemplate::AppendString(LPCSTR string)
{
    int length = MultiByteToWideChar(CP_ACP, 0, string, -1, NULL, 0);

    WCHAR* wideString = (WCHAR*)malloc(sizeof(WCHAR) * length);
    MultiByteToWideChar(CP_ACP, 0, string, -1, wideString, length);

    AppendData(wideString, length * sizeof(WCHAR));
    free(wideString);
}

void DialogTemplate::AppendData(void* data, int dataLength)
{
    EnsureSpace(dataLength);

    memcpy((char*)dialogTemplate + usedBufferLength, data, dataLength);
    usedBufferLength += dataLength;
}

void DialogTemplate::EnsureSpace(int length)
{
    if (length + usedBufferLength > totalBufferLength) {
        totalBufferLength += length * 2;

        void* newBuffer = malloc(totalBufferLength);
        assert(newBuffer);
        memcpy(newBuffer, dialogTemplate, usedBufferLength);

        free(dialogTemplate);
        dialogTemplate = (DLGTEMPLATE*)newBuffer;
    }
}

///////////////////
//
// BoardCheckButton
//
///////////////////
BoardCheckButton::BoardCheckButton(char *aname,int aid,int def_style)
{
    name=_strdup(aname);
    id=aid;
    style=def_style;
}

BoardCheckButton::~BoardCheckButton()
{
    FREE(name);
}

int BoardCheckButton::width()
{
    return (int)(strlen(name)*4.1+30);
}

int BoardCheckButton::height()
{
    return 15;
}

void BoardCheckButton::create_dialog(DialogTemplate *dialog,int x,int y,int *newid)
{
    dialog->AddButton(name,WS_VISIBLE|WS_TABSTOP|style,0,x,y,width(),height(),id);
}


///////////////////
//
// BoardCheckListBox
//
///////////////////
BoardCheckListBox::BoardCheckListBox(char *aname,int aid,int def_style)
{
    name=_strdup(aname);
    id=aid;
    style=def_style;
}

BoardCheckListBox::~BoardCheckListBox()
{
    FREE(name);
}

int BoardCheckListBox::width()
{
    return 291;
}

int BoardCheckListBox::height()
{
    return 267;
}

void BoardCheckListBox::create_dialog(DialogTemplate *dialog,int x,int y,int *newid)
{
    dialog->AddListBox(name,WS_VISIBLE|WS_HSCROLL|LBS_OWNERDRAWVARIABLE|LBS_HASSTRINGS|style,0,x,y,width(),height(),id);
}

//void BoardCheckListBox::command(HWND hDlg,int code,int target_id)
//{
    //if(code==LB_ADDSTRING && target_id==id) {
        //SendDlgItemMessage(hDlg,ID_LISTBOX,LB_ADDSTRING,0,(LPARAM)"Try to add string....");
				//SendDlgItemMessage(hDlg,ID_LISTBOX,LB_ADDSTRING,0,(LPARAM)"Try to add string....");
    //}
//}


///////////////////
//
// BoardCheckGroup
//
///////////////////
BoardCheckGroup::BoardCheckGroup(int vertical,int aospace,int aispace)
{
    is_vertical=vertical;
    no=0;
    ospace=aospace;
    ispace=aispace;
    member=NULL;
}

BoardCheckGroup::~BoardCheckGroup()
{
    int i;
    for(i=0;i<no;i++)
        delete member[i];
    FREE(member);
}

void BoardCheckGroup::add(BoardCheckElement *el)
{
    REALLOC(member,LPBoardCheckElement,++no);
    member[no-1]=el;
}

void BoardCheckGroup::get(HWND hDlg)
{
    int i;
    for(i=0;i<count();i++)
        member[i]->get(hDlg);
}

void BoardCheckGroup::set(HWND hDlg)
{
    int i;
    for(i=0;i<count();i++)
        member[i]->set(hDlg);
}

void BoardCheckGroup::dlg_file(HWND hDlg,char *fname,int len)
{
    int i;
    for(i=0;i<count();i++)
        member[i]->dlg_file(hDlg,fname,len);
}

void BoardCheckGroup::create_dialog(DialogTemplate *dialog,int x,int y,int *newid)
{
    int i;
    int offs=ospace;
    if(!count())
        return;
    for(i=0;i<count();i++)
        if(is_vertical) {
            member[i]->create_dialog(dialog,x+ospace,y+offs,newid);
            offs+=member[i]->height()+ispace;
        } else {
            member[i]->create_dialog(dialog,x+offs,y+ospace,newid);
            offs+=member[i]->width()+ispace;
        }
    id=(*newid)++;
    if(ospace && ispace)
        dialog->AddStatic("",WS_VISIBLE|SS_GRAYFRAME,0,x,y,width(),height(),id);
}

void BoardCheckGroup::command(HWND hDlg,int code,int target_id)
{
    int i;
    for(i=0;i<count();i++)
        member[i]->command(hDlg,code,target_id);
}

int BoardCheckGroup::count()
{
    return no;
}

int BoardCheckGroup::width()
{
    int i;
    int w=0;
    int cnt=count();
    if(!cnt)
        return 0;
    if(is_vertical) {
        for(i=0;i<cnt;i++)
            if(member[i]->width()>w)
                w=member[i]->width();
    } else {
        for(i=0;i<cnt;i++)
            w+=member[i]->width();
        if(cnt)
            w+=(cnt-1)*ispace;
    }
    return w+2*ospace;
}

int BoardCheckGroup::height()
{
    int i;
    int w=0;
    int cnt=count();
    if(!cnt)
        return 0;
    if(!is_vertical) {
        for(i=0;i<cnt;i++)
            if(member[i]->height()>w)
                w=member[i]->height();
    } else {
        for(i=0;i<cnt;i++)
            w+=member[i]->height();
        if(cnt)
            w+=(cnt-1)*ispace;
    }
    return w+2*ospace;
}

///////////////////
//
// BoardCheck
//
///////////////////

BoardCheck::BoardCheck()
{
	input=NULL;
	buttons=NULL;
    dialog=NULL;
	CheckPass=FALSE;
	nBtn=BTN_NONE;
    create_input();
	for(int site=0; site<SITE_NUM; ++site){
		site_connected[site] = 0;
		check_result[site] = TRUE;
	}
}

BoardCheck::~BoardCheck()
{
	if(!dialog){
        delete dialog;
		dialog=NULL;
	}
	if(!input){
        delete input;
		input=NULL;
	}
	if(!listbox){
        delete listbox;
		listbox=NULL;
	}
	if(!buttons){
        delete buttons;
		buttons=NULL;
	}
}

BOOL CALLBACK  BoardCheckDialogProc(HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam)
{

    switch (iMsg) {
        case WM_INITDIALOG :
			{
				for(vector<string>::iterator it=boardcheck_ptr->display_vec.begin(); it!=boardcheck_ptr->display_vec.end(); ++it){
					// Add string into listbox
					SendDlgItemMessage(hDlg,ID_LISTBOX,LB_ADDSTRING,0,(LPARAM)(*it).c_str());
				}

				SendMessage (GetDlgItem(hDlg, ID_LISTBOX), LB_SETHORIZONTALEXTENT, /*boardcheck_ptr->nMaxExtent*/2000,0);

				return TRUE ;
			}
			break;

        case WM_COMMAND :
			{
				//// Redo Board Check
				if(wParam == ID_REDO) {
					boardcheck_ptr->nBtn=BTN_REDO;
					EndDialog(hDlg, TRUE);
					return TRUE;
				}
				//// Exit
				if(wParam == ID_EXIT) {
					boardcheck_ptr->nBtn=BTN_EXIT;
					EndDialog(hDlg, TRUE);
					//PostQuitMessage(0);	// Exit ATE UI
					return TRUE;
				}
				if((wParam & 0xFF) == ID_LISTBOX) {
					return TRUE;
				}
				if(wParam == IDCANCEL) {
					boardcheck_ptr->nBtn=BTN_CANCEL;
					EndDialog(hDlg, TRUE);
					//PostQuitMessage(0);	// Exit ATE UI 
					return TRUE;
				}
				//boardcheck_ptr->input->command(hDlg,HIWORD(wParam),LOWORD (wParam));
			}
            break;
		case WM_CTLCOLORLISTBOX:
			break;
		case WM_DRAWITEM:
			{
				LPDRAWITEMSTRUCT lpDrawItem = (LPDRAWITEMSTRUCT)lParam;
				if (lpDrawItem->CtlType == ODT_LISTBOX || lpDrawItem->CtlID == ID_LISTBOX){
					if(lpDrawItem->itemID == -1)	break;

					char szItemString[2000];
					int nItemStringLen;

					SendDlgItemMessage(hDlg, ID_LISTBOX, LB_GETTEXT, (WPARAM)lpDrawItem->itemID, (LPARAM)szItemString);
					nItemStringLen = strlen(szItemString);

					// ����ѡ��һ��ʱ����һ�мӱ߿�
					if ((lpDrawItem->itemState & ODS_SELECTED) && (lpDrawItem->itemAction & (ODA_SELECT | ODA_DRAWENTIRE))){
						DrawFocusRect(lpDrawItem->hDC, &lpDrawItem->rcItem); 
						//InvertRect(lpDrawItem->hDC, &lpDrawItem->rcItem); //��ɫ
					}
					else if (!(lpDrawItem->itemState & ODS_SELECTED) && (lpDrawItem->itemAction & ODA_SELECT)){
						DrawFocusRect(lpDrawItem->hDC, &lpDrawItem->rcItem);
						//InvertRect(lpDrawItem->hDC, &lpDrawItem->rcItem); //��ɫ
					}

					string item_str(szItemString, 0, nItemStringLen-1);

					// ������ɫ
					if(item_str.find("FAIL") != string::npos){
						SetTextColor(lpDrawItem->hDC, RGB(255, 0, 0));
					}
					else {
						SetTextColor(lpDrawItem->hDC, RGB(0, 0, 0));
					}

					// ���ֱ���ɫ
					if(lpDrawItem->itemState & ODS_SELECTED){	// ���ñ�ѡ���еı�����ɫ
						SetBkMode(lpDrawItem->hDC, OPAQUE);
						//SetBkColor(lpDrawItem->hDC, RGB(255, 255, 255));
						SetBkColor(lpDrawItem->hDC, GetSysColor(COLOR_GRAYTEXT));					
					} else {
						SetBkMode(lpDrawItem->hDC, OPAQUE);
						SetBkColor(lpDrawItem->hDC, GetSysColor(COLOR_WINDOW));					
					}

					DrawText(lpDrawItem->hDC, szItemString, nItemStringLen, &lpDrawItem->rcItem, DT_LEFT | DT_SINGLELINE);
					return TRUE;
				}
			}
			break;
    }
    return FALSE ;
}


void BoardCheck::Display(void)
{
    int id=200; // start value for ids
    HWND shell=GetForegroundWindow();

	if(!IsCheckPass()){
		output_format();

		//delete_input();
		create_input();
		buttons->add(new BoardCheckButton("�������",ID_REDO,BS_DEFPUSHBUTTON));
		buttons->add(new BoardCheckButton("�˳�",ID_EXIT,BS_DEFPUSHBUTTON));
		listbox->add(new BoardCheckListBox("ListBox",ID_LISTBOX));

		string str_result("��Ͻ����");
		SERIAL_BC {
			if(check_result[SITE_BC]){
				str_result = str_result + "��λ(" + int2str(SITE_BC+1) + ") Pass ";
			} else {
				str_result = str_result + "��λ(" + int2str(SITE_BC+1) + ") Fail ";
			}
		}
		dialog=new DialogTemplate(str_result.c_str(), WS_CAPTION | DS_CENTER, 10, 10, 300, 300);
		input->create_dialog(dialog,0,0,&id);
		boardcheck_ptr=this;
		INT_PTR ret = DialogBoxIndirectA(NULL,
			   *dialog,
			   shell,
			   (DLGPROC) BoardCheckDialogProc);

		delete dialog;
		dialog=NULL;
	} 
}

void BoardCheck::create_input(void)
{
	input=new BoardCheckGroup(1,4,0);            // vertical aligned

	listbox=new BoardCheckGroup(0,0,0);
    input->add(listbox);

    buttons=new BoardCheckGroup(0,4,4);
    input->add(buttons);
}

void BoardCheck::delete_input(void)
{
	if(listbox->count()){
        delete listbox;
		listbox=NULL;
	}
	if(buttons->count()){
        delete buttons;
		buttons=NULL;
	}
	if(input->count()){
        delete input;
		input=NULL;
	}
}

BOOL BoardCheck::log(DWORD tnum, const char *component, double *result, double lolim, double hilim, const char *unit)
{
	bc_log.component_vec.push_back(component);
	bc_log.tnum_map[component] = tnum;
	bc_log.lolim_map[component] = lolim;
	bc_log.hilim_map[component] = hilim;
	bc_log.unit_map[component] = unit;

	SERIAL_BC bc_log.data_map[component][SITE_BC] = result[SITE_BC];
	SERIAL_BC{
		if((result[SITE_BC] >= lolim) && (result[SITE_BC] <= hilim)){
			bc_log.flag_map[component][SITE_BC] = "PASS";
		}
		else{
			bc_log.flag_map[component][SITE_BC] = "FAIL";
			CheckPass = FALSE;
			check_result[SITE_BC] = FALSE;
		}
	}
	SERIAL_BC result[SITE_BC] = 9999;

	return TRUE;
}

BOOL BoardCheck::output_format()
{
	for(vector<string>::iterator it=bc_log.component_vec.begin(); it!=bc_log.component_vec.end(); ++it){
		string temp("T" + int2str(bc_log.tnum_map[*it]) + "   ");
		SERIAL_BC{
			temp = temp + "SITE" + int2str(SITE_BC+1) + "=" + bc_log.flag_map[*it][SITE_BC] + "(" + float2str(bc_log.data_map[*it][SITE_BC]) + bc_log.unit_map[*it] + ")   ";
		}
		temp = temp + "Low Limit=" + float2str(bc_log.lolim_map[*it]) + bc_log.unit_map[*it] + "   ";
		temp = temp + "High Limit=" + float2str(bc_log.hilim_map[*it]) + bc_log.unit_map[*it] + "   ";
		temp = temp + *it;
		display_vec.push_back(temp);
	}

	return TRUE;
}

BOOL BoardCheck::IsCheckPass()
{
	for(vector<string>::iterator it=bc_log.component_vec.begin(); it!=bc_log.component_vec.end(); ++it){
		SERIAL_BC{
			if(bc_log.flag_map[*it][SITE_BC] == "FAIL")
				return FALSE;
		}
	}
	return TRUE;
}

BOOL BoardCheck::report()
{
	char pgsfullpath[300];
	GetPgsFullPath(pgsfullpath, 300);
	string fullpathpgs(pgsfullpath);
	string pathofpgs = "";
	int pos = fullpathpgs.find_last_of('\\');
	if (pos > -1)
	{
		pathofpgs = fullpathpgs.substr(0, pos + 1);
	}
	string file_bc = pathofpgs + "source\\bc.csv";

	if(IsFileOpen(file_bc.c_str())){
		MessageBoxA(NULL, "��ȷ�� bc.csv �ļ��Ƿ��Ѵ򿪣�\n����򿪣���رգ����������޷�����", "�����ʾ�Ի���", MB_OK);
	}

	fstream file;
	file.open(file_bc.c_str(), ios::app);

	string time(GetSysTime());
	string result_flag;
	if(IsCheckPass())
		result_flag = "PASS";
	else
		result_flag = "FAIL";
	file << "Time," + time << ","  << "Final," + result_flag  + ",Serial," + int2str(++serial) << endl;
	for(vector<string>::iterator it=bc_log.component_vec.begin(); it!=bc_log.component_vec.end(); ++it){
		string temp("T" + int2str(bc_log.tnum_map[*it]) + ",");
		SERIAL_BC{
			temp = temp + "SITE" + int2str(SITE_BC+1) + "," + bc_log.flag_map[*it][SITE_BC] + "," + float2str(bc_log.data_map[*it][SITE_BC]) + ",";
		}
		temp = temp + "Low Limit," + float2str(bc_log.lolim_map[*it]) + ",";
		temp = temp + "High Limit," + float2str(bc_log.hilim_map[*it]) + "," + bc_log.unit_map[*it] + ",";
		temp = temp + "\"" + *it + "\"";
		file << temp << endl;
	}

	file.flush();
	file.close();

	return TRUE;
}

double get_scale(string str_unit){
	if((str_unit == "mA") || (str_unit == "mV") || (str_unit == "mOhm") || (str_unit == "mF") || (str_unit == "mUnit"))
		return 1e3;
	else if((str_unit == "uA") || (str_unit == "uV") || (str_unit == "uF") || (str_unit == "uUnit"))
		return 1e6;
	else if((str_unit == "nA") || (str_unit == "nV") || (str_unit == "nF") || (str_unit == "nUnit"))
		return 1e9;
	else if((str_unit == "pA") || (str_unit == "pV") || (str_unit == "pF") || (str_unit == "pUnit"))
		return 1e12;
	else if((str_unit == "kOhm") || (str_unit == "kUnit"))
		return 1e-3;
	else if((str_unit == "MOhm") || (str_unit == "MUnit"))
		return 1e-6;

	return 1;
}

BOOL BoardCheck::test_i(FOVIe &fovi_res, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];

	if(vi.mode == FV)
		fovi_res.Set(FV, vi.v, vi.v_range, vi.i_range, FOVIe_RELAY_ON);
	else
		fovi_res.Set(FI, vi.i, vi.v_range, vi.i_range, FOVIe_RELAY_ON);

	delay_ms(vi.delay);

	fovi_res.MeasureVI(vi.sample_times, vi.sample_period, vi.miGain);
	SERIAL_BC result[SITE_BC]=fovi_res.GetMeasResult(SITE_BC, MIRET) * get_scale(unit);	

	fovi_res.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_ON);
	delay_ms(2);
	fovi_res.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_i(FXVIe_PLUS &fovi_res, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];

	if(vi.mode == FV)
		fovi_res.Set(FV, vi.v, vi.fxvi_v_range, vi.fxvi_i_range, FXVIe_PLUS_RELAY_ON);
	else
		fovi_res.Set(FI, vi.i, vi.fxvi_v_range, vi.fxvi_i_range, FXVIe_PLUS_RELAY_ON);

	delay_ms(vi.delay);

	fovi_res.MeasureVI(vi.sample_times, vi.sample_period, vi.fxvi_miGain);
	SERIAL_BC result[SITE_BC]=fovi_res.GetMeasResult(SITE_BC, MIRET) * get_scale(unit);	

	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(2);
	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_if(FXVIe_PLUS &fovi_res, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];

	if(vi.mode == FV)
		fovi_res.Set(FV, vi.v, vi.fxvi_v_range, vi.fxvi_i_range, FXVIe_PLUS_RELAY_FANOUT_ON);
	else
		fovi_res.Set(FI, vi.i, vi.fxvi_v_range, vi.fxvi_i_range, FXVIe_PLUS_RELAY_FANOUT_ON);

	delay_ms(vi.delay);

	fovi_res.MeasureVI(vi.sample_times, vi.sample_period, vi.fxvi_miGain);
	SERIAL_BC result[SITE_BC]=fovi_res.GetMeasResult(SITE_BC, MIRET) * get_scale(unit);	

	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(2);
	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_i(FPVIe &fovi_res, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];

	if(vi.mode == FV)
		fovi_res.Set(FV, vi.v, vi.fpvi_v_range, vi.fpvi_i_range, FPVIe_RELAY_ON);
	else
		fovi_res.Set(FI, vi.i, vi.fpvi_v_range, vi.fpvi_i_range, FPVIe_RELAY_ON);

	delay_ms(vi.delay);

	fovi_res.MeasureVI(vi.sample_times, vi.sample_period, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_NORMAL);
	SERIAL_BC result[SITE_BC]=fovi_res.GetMeasResult(SITE_BC, MIRET) * get_scale(unit);	

	fovi_res.Set(FV, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_ON);
	delay_ms(2);
	fovi_res.Set(FV, 0, FPVIe_5V, FPVIe_10MA, FPVIe_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_i(DCM &dcm, const char* ch, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];
	dcm.SetPPMU(ch, DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_20UA);
	delay_ms(vi.delay);
	dcm.PPMUMeasure(ch, vi.sample_times, vi.sample_period);
	SERIAL_BC result[SITE_BC]=dcm.GetPPMUMeasResult(ch, SITE_BC, AVERAGE_RESULT) * get_scale(unit);	

	dcm.SetPPMU(ch, DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_20UA);
	delay_ms(2);
	dcm.SetPPMU(ch, DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_20UA);
	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_i(ACM &acm_res, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];

	if (vi.mode == FV)
		acm_res.Set(FV, vi.v, vi.acm_v_range, vi.acm_i_range, ACM_RELAY_ON);
	else
		acm_res.Set(FI, vi.i, vi.acm_v_range, vi.acm_i_range, ACM_RELAY_ON);

	delay_ms(vi.delay);

	acm_res.MeasureVI(ACM_MI,vi.sample_times, vi.sample_period);
	SERIAL_BC result[SITE_BC] = acm_res.GetMeasResult(SITE_BC) * get_scale(unit);

	acm_res.Set(FV, 0, ACM_N2P18V, ACM_200UA, ACM_RELAY_ON);
	delay_ms(2);
	acm_res.Set(FV, 0, ACM_N2P18V, ACM_200UA, ACM_RELAY_OFF);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_i(ACM200 &acm_res, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];

	if (vi.mode == FV)
		acm_res.Set(FV, vi.v, vi.acm200_v_range, vi.acm200_i_range, ACM200_RELAY_ON);
	else
		acm_res.Set(FI, vi.i, vi.acm200_v_range, vi.acm200_i_range, ACM200_RELAY_ON);

	delay_ms(vi.delay);

	acm_res.MeasureVI(vi.sample_times, vi.sample_period);
	SERIAL_BC result[SITE_BC] = acm_res.GetMeasResult(SITE_BC,MIRET) * get_scale(unit);

	acm_res.Set(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_ON);
	delay_ms(2);
	acm_res.Set(FV, 0, ACM200_3p6V, ACM200_100UA, ACM200_RELAY_OFF);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}

BOOL BoardCheck::test_v(FOVIe &fovi_res, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];

	if(vi.mode == FV)
		fovi_res.Set(FV, vi.v, vi.v_range, vi.i_range, FOVIe_RELAY_ON);
	else
		fovi_res.Set(FI, vi.i, vi.v_range, vi.i_range, FOVIe_RELAY_ON);

	delay_ms(vi.delay);

    fovi_res.MeasureVI(vi.sample_times, vi.sample_period);
	SERIAL_BC result[SITE_BC]=fovi_res.GetMeasResult(SITE_BC, MVRET) * get_scale(unit);	

	fovi_res.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}

BOOL BoardCheck::test_v(FOVIe &fovi_res1, FOVIe &fovi_res2, FPVIe &fpvi_res, DWORD tnum, const char* component, double *result1)	// dual ch fovi, force v, fpvi measure the diff of fovis
{
	double result[SITE_NUM];
	fovi_res1.Set(FV, 1, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_ON);
	fovi_res2.Set(FV, 3.6, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_ON);
	fpvi_res.Set(FI, 2e-6, FPVIe_10V, FPVIe_10UA, FPVIe_RELAY_ON);

	delay_ms(10);

    fpvi_res.MeasureVI(10, 10);
	SERIAL_BC result[SITE_BC]=fpvi_res.GetMeasResult(SITE_BC, MVRET);	

	fovi_res1.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_ON);
	fovi_res2.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_ON);
	fovi_res1.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_OFF);
	fovi_res2.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_OFF);
	fpvi_res.Set(FI, 0, FPVIe_10V, FPVIe_10UA, FPVIe_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, 2.5, 2.7, "V");

	return TRUE;
}

BOOL BoardCheck::test_v(FOVIe &fovi_force, FOVIe &fovi_measure, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)	// dual ch fovi shorted, one force v, one measure v
{
	double result[SITE_NUM];

	fovi_force.Set(FV, vi.v, vi.v_range, vi.i_range, FOVIe_RELAY_ON);
	fovi_measure.Set(FI, 0, vi.v_range, FOVIe_10UA, FOVIe_RELAY_ON);

	delay_ms(vi.delay);

    fovi_measure.MeasureVI(vi.sample_times, vi.sample_period);
	SERIAL_BC result[SITE_BC]=fovi_measure.GetMeasResult(SITE_BC, MVRET) * get_scale(unit);	

	fovi_force.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_ON);
	fovi_force.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_OFF);

 	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;

}
BOOL BoardCheck::test_v(FOVIe &fovi_force, ACM &acm_measure, Cvi_config &vi, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)	// dual ch fovi shorted, one force v, one measure v
{
	double result[SITE_NUM];

	fovi_force.Set(FV, vi.v, vi.v_range, vi.i_range, FOVIe_RELAY_ON);
	acm_measure.Set(FI, 0, vi.acm_v_range, ACM_5UA, ACM_RELAY_ON);

	delay_ms(vi.delay);

	acm_measure.MeasureVI(ACM_MV,vi.sample_times, vi.sample_period);
	SERIAL_BC result[SITE_BC] = acm_measure.GetMeasResult(SITE_BC) * get_scale(unit);

	fovi_force.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_ON);
	delay_ms(2);//discharge
	fovi_force.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_OFF);
	acm_measure.Set(FV, 0, vi.acm_v_range, ACM_5UA, ACM_RELAY_OFF);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;

}
BOOL BoardCheck::test_v(ACM &acm_measure, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];
	acm_measure.Set(FI, -0.00001, ACM_N2P18V, ACM_5UA, ACM_RELAY_ON);
	delay_ms(5);

	acm_measure.MeasureVI(ACM_MV, 30, 100);
	SERIAL_BC result[SITE_BC] = acm_measure.GetMeasResult(SITE_BC) * get_scale(unit);

	acm_measure.Set(FV, 0, ACM_N2P18V, ACM_5UA, ACM_RELAY_OFF);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_v(ACM200 &acm_measure, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];
	acm_measure.Set(FI, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_SENSE_ON, 5);
	delay_ms(10);

	acm_measure.MeasureVI(30, 100);
	SERIAL_BC result[SITE_BC] = acm_measure.GetMeasResult(SITE_BC,MVRET) * get_scale(unit);

	acm_measure.Set(FV, 0, ACM200_10V, ACM200_10UA, ACM200_RELAY_OFF);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_v(FOVIe &acm_measure, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)	// dual ch fovi shorted, one force v, one measure v
{
	double result[SITE_NUM];
	acm_measure.Set(FI, -0.00001, FOVIe_10V, FOVIe_10UA, FOVIe_RELAY_ON);
	delay_ms(5);

	acm_measure.MeasureVI(30, 100);
	SERIAL_BC result[SITE_BC] = acm_measure.GetMeasResult(SITE_BC,MVRET) * get_scale(unit);

	acm_measure.Set(FV, 0, FOVIe_10V, FOVIe_10UA, FOVIe_RELAY_ON);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_v(FXVIe_PLUS &acm_measure, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];
	acm_measure.Set(FI, -0.00001, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_ON);
	delay_ms(5);

	acm_measure.MeasureVI(30, 100);
	SERIAL_BC result[SITE_BC] = acm_measure.GetMeasResult(SITE_BC,MVRET) * get_scale(unit);

	acm_measure.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_vf(FXVIe_PLUS &acm_measure, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];
	acm_measure.Set(FI, -0.00001, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(5);

	acm_measure.MeasureVI(30, 100);
	SERIAL_BC result[SITE_BC] = acm_measure.GetMeasResult(SITE_BC,MVRET) * get_scale(unit);

	acm_measure.Set(FV, 0, FXVIe_PLUS_10V, FXVIe_PLUS_10UA, FXVIe_PLUS_RELAY_OFF);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_v(FPVIe &acm_measure, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];
	acm_measure.Set(FI, 0, FPVIe_10V, FPVIe_10UA, FPVIe_RELAY_SENSE_ON);
	delay_ms(5);

	acm_measure.MeasureVI(30, 100);
	SERIAL_BC result[SITE_BC] = acm_measure.GetMeasResult(SITE_BC,MVRET) * get_scale(unit);

	acm_measure.Set(FV, 0, FPVIe_10V, FPVIe_10UA, FPVIe_RELAY_OFF);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_v(DCM &dcm, const char* ch, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	dcm.Connect(ch);
	double result[SITE_NUM];
	dcm.SetPPMU(ch, DCM_PPMU_FIMV, -0.00001, DCM_PPMUIRANGE_20UA);
	delay_ms(5);
	dcm.PPMUMeasure(ch, 30, 100);
	SERIAL_BC result[SITE_BC] = dcm.GetPPMUMeasResult(ch, SITE_BC, AVERAGE_RESULT) * get_scale(unit);

	dcm.SetPPMU(ch, DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_20UA);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_v(QVMe &qvm_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];

	QVMe_LADC_VRANG v_range = QVMe_LADC_5V;
	if(hilim < 0.1 * get_scale(unit))
		v_range = QVMe_LADC_100MV;
	else if(hilim < 1 * get_scale(unit))
		v_range = QVMe_LADC_1V;
	else if(hilim < 2 * get_scale(unit))
		v_range = QVMe_LADC_2V;
	else if(hilim < 5 * get_scale(unit))
		v_range = QVMe_LADC_5V;
	else if(hilim < 10 * get_scale(unit))
		v_range = QVMe_LADC_10V;
	else if(hilim < 20 * get_scale(unit))
		v_range = QVMe_LADC_20V;
	else if(hilim < 50 * get_scale(unit))
		v_range = QVMe_LADC_50V;
	else if(hilim < 100 * get_scale(unit))
		v_range = QVMe_LADC_100V;

	qvm_res.Connect();
	delay_ms(5);

	qvm_res.MeasureLADC(100, 10, v_range, QVMe_LADC_10KHz, MEAS_NORMAL);
	SERIAL_BC	result[SITE_BC] = qvm_res.GetMeasResult(SITE_BC, AVERAGE_RESULT) * get_scale(unit);	

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
void BoardCheck::force_v(ACM &acm_measure, double value, bool on)
{
	if(on){acm_measure.Set(FV, value, ACM_N2P18V, ACM_2MA, ACM_RELAY_ON);}
	else 
	{
		acm_measure.Set(FV, 0, ACM_N2P18V, ACM_2MA, ACM_RELAY_ON);
		delay_ms(2);
		acm_measure.Set(FV, 0, ACM_N2P18V, ACM_2MA, ACM_RELAY_OFF);
	}
}
void BoardCheck::force_v(ACM200 &acm_measure, double value, bool on)
{
	if (on){ acm_measure.Set(FV, value, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON, 5); }
	else 
	{
		acm_measure.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_ON, 5);
		delay_ms(2);
		acm_measure.Set(FV, 0, ACM200_10V, ACM200_10MA, ACM200_RELAY_OFF);
	}
}
void BoardCheck::force_v(FOVIe &acm_measure, double value, bool on)
{
	if(on){acm_measure.Set(FV, value, FOVIe_2V, FOVIe_1MA, FOVIe_RELAY_ON);}
	else 
	{
		acm_measure.Set(FV, 0, FOVIe_2V, FOVIe_1MA, FOVIe_RELAY_ON);
		delay_ms(2);
		acm_measure.Set(FV, 0, FOVIe_2V, FOVIe_1MA, FOVIe_RELAY_OFF);
	}
}
void BoardCheck::force_v(FXVIe_PLUS &acm_measure, double value, bool on)
{
	if(on){acm_measure.Set(FV, value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);}
	else 
	{
		acm_measure.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(2);
		acm_measure.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	}
}
void BoardCheck::force_vf(FXVIe_PLUS &acm_measure, double value, bool on)
{
	if (on){ acm_measure.Set(FV, value, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON); }
	else 
	{
		acm_measure.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
		delay_ms(2);
		acm_measure.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);
	}
}
void BoardCheck::force_v(FPVIe &acm_measure, double value, bool on)
{
	if(on){acm_measure.Set(FV, value, FPVIe_2V, FPVIe_10MA, FPVIe_RELAY_ON,5);}
	else 
	{
		acm_measure.Set(FV, 0, FPVIe_2V, FPVIe_10MA, FPVIe_RELAY_ON,5);
		delay_ms(2);
		acm_measure.Set(FV, 0, FPVIe_2V, FPVIe_10MA, FPVIe_RELAY_OFF);
	}
}
void BoardCheck::force_v(DCM &dcm, const char* ch, double value, bool on)
{
	int status;
	//status = dcm.InitPPMU(ch);
	dcm.Connect(ch);
	if(on){status = dcm.SetPPMU(ch, DCM_PPMU_FVMI, value, DCM_PPMUIRANGE_32MA);}
	else 
	{
		status = dcm.SetPPMU(ch, DCM_PPMU_FVMI, 0, DCM_PPMUIRANGE_32MA);
		dcm.InitPPMU(ch);
		dcm.Disconnect(ch);
	}
}
BOOL BoardCheck::contact_check(FOVIe &fovi_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM];

	fovi_res.ContactCheck(FOVIe_HIGH_SIDE);

	delay_ms(1);

	
	SERIAL_BC result[SITE_BC] = fovi_res.GetContactCheckResult(SITE_BC) * get_scale(unit);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::contact_check(FPVIe *fpvi_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM];
	SERIAL_BC fpvi_res[SITE_BC].ContactCheck(FPVIe_ALL_SIDE);

	delay_ms(1);


	SERIAL_BC result[SITE_BC] = fpvi_res[SITE_BC].GetContactCheckResult(SITE_BC) * get_scale(unit);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_v(const char* lpszGroupPinName, const char* lpszPinName, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM];

	dcm.Connect(lpszGroupPinName);
	dcm.SetPPMU(lpszGroupPinName, DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2UA);
	delay_ms(3);
	dcm.PPMUMeasure(lpszGroupPinName, 10, 5);
	SERIAL_BC result[SITE_BC] = dcm.GetPPMUMeasResult(lpszPinName, SITE_BC)* get_scale(unit);
	dcm.InitPPMU(lpszGroupPinName);
	dcm.Disconnect(lpszGroupPinName);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL)	log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_i(const char* lpszGroupPinName, const char* lpszPinName, DWORD tnum, const char* component, double fv,double lolim, double hilim, const char* unit, double *result1)
{
	double result[SITE_NUM];
	
	dcm.Connect(lpszGroupPinName);
	dcm.SetPPMU(lpszGroupPinName, DCM_PPMU_FVMI, fv, DCM_PPMUIRANGE_2UA);
	delay_ms(20);

	dcm.PPMUMeasure(lpszGroupPinName, 20, 5);
	SERIAL_BC result[SITE_BC] = dcm.GetPPMUMeasResult(lpszPinName, SITE_BC)* get_scale(unit);
	dcm.InitPPMU(lpszGroupPinName);
	dcm.Disconnect(lpszGroupPinName);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL)	log(tnum++, component, result, lolim, hilim, unit);
	return TRUE;
}
BOOL BoardCheck::test_r(const char* lpszGroupPinName, const char* lpszPinName, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result3[SITE_NUM];
	double result2[SITE_NUM];
	double result[SITE_NUM];
	double i_set1;
	double i_set2;
	i_set1 = 1.0 / (lolim + hilim)*get_scale(unit);
	if (i_set1 > 0.032) i_set1 = 0.032;
	i_set2 = i_set1*0.5;
	PPMUIRange i_range;
	i_range = get_dcm_i_range(i_set1);
	
	dcm.Connect(lpszGroupPinName);
	dcm.SetPPMU(lpszGroupPinName, DCM_PPMU_FIMV, i_set1, i_range);
	delay_ms(8);

	dcm.PPMUMeasure(lpszGroupPinName, 10, 5);
	SERIAL_BC result3[SITE_BC] = dcm.GetPPMUMeasResult(lpszPinName, SITE_BC)* get_scale(unit);

	dcm.SetPPMU(lpszGroupPinName, DCM_PPMU_FIMV, i_set2, i_range);
	delay_ms(8);

	dcm.PPMUMeasure(lpszGroupPinName, 10, 5);
	SERIAL_BC result2[SITE_BC] = dcm.GetPPMUMeasResult(lpszPinName, SITE_BC)* get_scale(unit);
	SERIAL_BC result[SITE_BC] = abs((result3[SITE_BC] - result2[SITE_BC]) / (i_set2 - i_set1));
	
	dcm.InitPPMU(lpszGroupPinName);
	dcm.Disconnect(lpszGroupPinName);
	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL)	log(tnum++, component, result, lolim, hilim, unit);
	return TRUE;
}
BOOL BoardCheck::test_r(FOVIe &fovi_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double result_i[SITE_NUM];
	double result_r[SITE_NUM];
	double i_set;
	if(delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}

	i_set = 0.8 / (lolim + hilim)*get_scale(unit);
	if (i_set > 1.0) i_set = 1.0;
	if (i_set < 1.0e-4)
	{
		i_set = 10 * i_set;
	}
	FOVIe_IRNG i_range;
	FOVIe_VRNG v_range;
	i_range = get_fovi_i_range(i_set);
	v_range = get_fovi_v_range(i_set*hilim*get_scale(unit));

	fovi_res.Set(FI, i_set, v_range, i_range, FOVIe_RELAY_ON);
	delay_ms(delay);
	fovi_res.MeasureVI(40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = fovi_res.GetMeasResult(SITE_BC, MVRET);
		result_i[SITE_BC] = fovi_res.GetMeasResult(SITE_BC, MIRET);
		result_r[SITE_BC] = result_v[SITE_BC] / (result_i[SITE_BC] + 1e-32);

		result_r[SITE_BC] = result_r[SITE_BC] * get_scale(unit);
	}
	fovi_res.Set(FI, 0, v_range, i_range, FOVIe_RELAY_ON);
	fovi_res.Set(FI, 0, v_range, i_range, FOVIe_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_r[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result_r, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_r(FXVIe_PLUS &fovi_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double result_i[SITE_NUM];
	double result_r[SITE_NUM];
	double i_set;
	if(delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}

	i_set = 0.8 / (lolim + hilim)*get_scale(unit);
	if (i_set > 1.0) i_set = 1.0;
	if (i_set < 1.0e-4)
	{
		i_set = 10 * i_set;
	}
	FXVIe_PLUS_IRNG i_range;
	FXVIe_PLUS_VRNG v_range;
	i_range = get_fxvi_i_range(i_set);
	v_range = get_fxvi_v_range(i_set*hilim*get_scale(unit));
	i_set = 0.01;//10mA
	fovi_res.Set(FI, i_set, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(delay);
	fovi_res.MeasureVI(40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = fovi_res.GetMeasResult(SITE_BC, MVRET);
		result_i[SITE_BC] = fovi_res.GetMeasResult(SITE_BC, MIRET);
		result_r[SITE_BC] = result_v[SITE_BC] / (result_i[SITE_BC] + 1e-32);

		result_r[SITE_BC] = result_r[SITE_BC] * get_scale(unit);
	}
	fovi_res.Set(FI, 0, v_range, i_range, FXVIe_PLUS_RELAY_ON);
	fovi_res.Set(FI, 0, v_range, i_range, FXVIe_PLUS_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_r[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result_r, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_rf(FXVIe_PLUS &fovi_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double result_i[SITE_NUM];
	double result_r[SITE_NUM];
	double i_set;
	if(delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}

	i_set = 0.8 / (lolim + hilim)*get_scale(unit);
	if (i_set > 1.0) i_set = 1.0;
	if (i_set < 1.0e-4)
	{
		i_set = 10 * i_set;
	}
	FXVIe_PLUS_IRNG i_range;
	FXVIe_PLUS_VRNG v_range;
	i_range = get_fxvi_i_range(i_set);
	v_range = get_fxvi_v_range(i_set*hilim*get_scale(unit));
	i_set = 0.01;//10mA
	fovi_res.Set(FI, i_set, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(delay);
	fovi_res.MeasureVI(40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = fovi_res.GetMeasResult(SITE_BC, MVRET);
		result_i[SITE_BC] = fovi_res.GetMeasResult(SITE_BC, MIRET);
		result_r[SITE_BC] = result_v[SITE_BC] / (result_i[SITE_BC] + 1e-32);

		result_r[SITE_BC] = result_r[SITE_BC] * get_scale(unit);
	}
	fovi_res.Set(FI, 0, v_range, i_range, FXVIe_PLUS_RELAY_FANOUT_ON);
	fovi_res.Set(FI, 0, v_range, i_range, FXVIe_PLUS_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_r[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result_r, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_r(ACM &acm_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double result_r[SITE_NUM];
	double i_set;
	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}

	i_set = 0.8 / (lolim + hilim)*get_scale(unit);
	if (i_set > 0.2) i_set = 0.2;
	if (i_set < 1.0e-4)
	{
		i_set = 10 * i_set;
	}
	ACM_IRNG i_range;

	i_range = get_acm_i_range(i_set);
	

	acm_res.Set(FI, i_set, ACM_N2P18V, i_range, ACM_RELAY_ON);
	delay_ms(delay);
	acm_res.MeasureVI(ACM_MV,40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = acm_res.GetMeasResult(SITE_BC);
		result_r[SITE_BC] = result_v[SITE_BC] / (i_set + 1e-32);

		result_r[SITE_BC] = result_r[SITE_BC] * get_scale(unit);
	}
	acm_res.Set(FI, 0, ACM_N2P18V, i_range, ACM_RELAY_ON);
	acm_res.Set(FI, 0, ACM_N2P18V, i_range, ACM_RELAY_OFF);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_r[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_r, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_r(ACM200 &acm_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double result_r[SITE_NUM];
	double i_set;
	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}

	i_set = 0.5 / (lolim + hilim)*get_scale(unit);
	if (i_set > 0.2) i_set = 0.2;
	if (i_set < 1.0e-4)
	{
		i_set = 10 * i_set;
	}
	ACM200_IRNG i_range;
	ACM200_VRNG v_range;
	i_range = get_acm200_i_range(i_set);
	v_range = get_acm200_v_range(i_set*hilim*get_scale(unit));
	
	i_set = 0.01;//10mA
	acm_res.Set(FI, i_set, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);
	delay_ms(delay);
	acm_res.MeasureVI(40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = acm_res.GetMeasResult(SITE_BC,MVRET);
		result_r[SITE_BC] = result_v[SITE_BC] / (i_set + 1e-32);

		result_r[SITE_BC] = result_r[SITE_BC] * get_scale(unit);
	}
	acm_res.Set(FI, 0, ACM200_3p6V, i_range, ACM200_RELAY_ON);
	acm_res.Set(FI, 0, ACM200_3p6V, i_range, ACM200_RELAY_OFF);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_r[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_r, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_r(FPVIe &fpvi_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double result_i[SITE_NUM];
	double result_r[SITE_NUM];

	double i_set;
	if(delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}

	i_set = 0.8 / (lolim + hilim)*get_scale(unit);
	if (i_set > 1.0) i_set = 1.0;
	if (i_set < 1.0e-4)
	{
		i_set = 10 * i_set;
	}
	FPVIe_IRNG i_range;
	FPVIe_VRNG v_range;
	i_range = get_fpvi_i_range(i_set);
	v_range = get_fpvi_v_range(i_set*hilim*get_scale(unit));

		fpvi_res.Set(FI, i_set, v_range, i_range, FPVIe_RELAY_ON);
		delay_ms(delay);
		fpvi_res.MeasureVI(40, 10);
		SERIAL_BC{
			result_v[SITE_BC] = fpvi_res.GetMeasResult(SITE_BC, MVRET);
			result_i[SITE_BC] = fpvi_res.GetMeasResult(SITE_BC, MIRET);
			result_r[SITE_BC] = result_v[SITE_BC] / (result_i[SITE_BC] + 1e-32);

			result_r[SITE_BC] = result_r[SITE_BC] * get_scale(unit);
		}
		fpvi_res.Set(FI, 0, v_range, i_range, FPVIe_RELAY_ON);
		fpvi_res.Set(FI, 0, v_range, i_range, FPVIe_RELAY_OFF);


	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_r[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result_r, lolim, hilim, unit);

	return TRUE;
}

BOOL BoardCheck::test_r(FPVIe *fpvi_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double result_i[SITE_NUM];
	double result_r[SITE_NUM];

	double i_set;
	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}
	i_set = 0.8 / (lolim + hilim)*get_scale(unit);
	if (i_set > 1.0) i_set = 1.0;
	if (i_set < 1.0e-4)
	{
		i_set = 10 * i_set;
	}
	FPVIe_IRNG i_range;
	FPVIe_VRNG v_range;
	i_range = get_fpvi_i_range(i_set);
	v_range = get_fpvi_v_range(i_set*hilim*get_scale(unit));
	SERIAL_BC{
		fpvi_res[SITE_BC].Set(FI, i_set, v_range, i_range, FPVIe_RELAY_ON);
		delay_ms(delay);
		fpvi_res[SITE_BC].MeasureVI(40, 10);
		result_v[SITE_BC] = fpvi_res[SITE_BC].GetMeasResult(SITE_BC, MVRET);
		result_i[SITE_BC] = fpvi_res[SITE_BC].GetMeasResult(SITE_BC, MIRET);
		result_r[SITE_BC] = result_v[SITE_BC] / (result_i[SITE_BC] + 1e-32);
		int site = SITE_BC;
		result_r[SITE_BC] = result_r[SITE_BC] * get_scale(unit);
		fpvi_res[SITE_BC].Set(FI, 0, v_range, i_range, FPVIe_RELAY_ON);
		fpvi_res[SITE_BC].Set(FI, 0, v_range, i_range, FPVIe_RELAY_OFF);
	}

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_r[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_r, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_r(DCM &dcm, const char* ch, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double result_i[SITE_NUM];
	double result_r[SITE_NUM];

	double i_set;
	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}
	i_set = 0.8 / (lolim + hilim)*get_scale(unit);
	if (i_set > 1.0) i_set = 1.0;
	if (i_set < 1.0e-4)
	{
		i_set = 10 * i_set;
	}
	PPMUIRange i_range;
	//FPVIe_VRNG v_range;
	i_range = get_dcm_i_range(i_set);
	//v_range = get_fpvi_v_range(i_set*hilim*get_scale(unit));
	SERIAL_BC{
		//fpvi_res[SITE_BC].Set(FI, i_set, v_range, i_range, FPVIe_RELAY_ON);
		dcm.SetPPMU(ch, DCM_PPMU_FIMV, i_set, i_range);
		delay_ms(delay);
		//fpvi_res[SITE_BC].MeasureVI(40, 10);
		dcm.PPMUMeasure(ch, 40, 10);
		result_v[SITE_BC] = dcm.GetPPMUMeasResult(ch, SITE_BC, AVERAGE_RESULT);
		//result_i[SITE_BC] = fpvi_res[SITE_BC].GetMeasResult(SITE_BC, MIRET);
		result_r[SITE_BC] = result_v[SITE_BC] / (i_set + 1e-32);
		int site = SITE_BC;
		result_r[SITE_BC] = result_r[SITE_BC] * get_scale(unit);
		dcm.SetPPMU(ch, DCM_PPMU_FIMV, 0, i_range);
		//fpvi_res[SITE_BC].Set(FI, 0, v_range, i_range, FPVIe_RELAY_ON);
		//fpvi_res[SITE_BC].Set(FI, 0, v_range, i_range, FPVIe_RELAY_OFF);
	}

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_r[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_r, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_r_up(double Vup, DCM &dcm, const char* ch, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double result_i[SITE_NUM];
	double result_r[SITE_NUM];

	double i_set;
	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}
	i_set = 0.8 / (lolim + hilim)*get_scale(unit);
	if (i_set > 1.0) i_set = 1.0;
	if (i_set < 1.0e-4)
	{
		i_set = 10 * i_set;
	}
	PPMUIRange i_range;
	//FPVIe_VRNG v_range;
	i_range = get_dcm_i_range(i_set);
	//v_range = get_fpvi_v_range(i_set*hilim*get_scale(unit));
	SERIAL_BC{
		//fpvi_res[SITE_BC].Set(FI, i_set, v_range, i_range, FPVIe_RELAY_ON);
		dcm.SetPPMU(ch, DCM_PPMU_FIMV, i_set, i_range);
		delay_ms(delay);
		//fpvi_res[SITE_BC].MeasureVI(40, 10);
		dcm.PPMUMeasure(ch, 40, 10);
		result_v[SITE_BC] = dcm.GetPPMUMeasResult(ch, SITE_BC, AVERAGE_RESULT);
		//result_i[SITE_BC] = fpvi_res[SITE_BC].GetMeasResult(SITE_BC, MIRET);
		result_r[SITE_BC] = (Vup - result_v[SITE_BC]) / (i_set + 1e-32);
		int site = SITE_BC;
		result_r[SITE_BC] = result_r[SITE_BC] * get_scale(unit);
		dcm.SetPPMU(ch, DCM_PPMU_FIMV, 0, i_range);
		//fpvi_res[SITE_BC].Set(FI, 0, v_range, i_range, FPVIe_RELAY_ON);
		//fpvi_res[SITE_BC].Set(FI, 0, v_range, i_range, FPVIe_RELAY_OFF);
	}

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_r[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_r, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_d(ACM200 &acm_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double i_set = 0;
	if (hilim <= 0) {i_set = -0.001;}
	if (lolim >= 0) {i_set = 0.001;}

	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}
	acm_res.Set(FI, i_set, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(delay);
	acm_res.MeasureVI(40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = acm_res.GetMeasResult(SITE_BC,MVRET);
	}
	acm_res.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	acm_res.Set(FI, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_v[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_v, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_d(FOVIe &acm_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double i_set = 0;
	if (hilim <= 0) {i_set = -0.001;}
	if (lolim >= 0) {i_set = 0.001;}

	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}
	acm_res.Set(FI, i_set, FOVIe_2V, FOVIe_1MA, FOVIe_RELAY_ON);
	delay_ms(delay);
	acm_res.MeasureVI(40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = acm_res.GetMeasResult(SITE_BC,MVRET);
	}
	acm_res.Set(FI, 0, FOVIe_2V, FOVIe_1MA, FOVIe_RELAY_ON);
	acm_res.Set(FI, 0, FOVIe_2V, FOVIe_1MA, FOVIe_RELAY_OFF);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_v[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_v, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_d(DCM &dcm, const char* ch, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double i_set = 0;
	if (hilim <= 0) {i_set = -0.001;}
	if (lolim >= 0) {i_set = 0.001;}

	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}
	dcm.SetPPMU(ch, DCM_PPMU_FIMV, i_set, DCM_PPMUIRANGE_2MA);
	delay_ms(delay);
	dcm.PPMUMeasure(ch, 40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = dcm.GetPPMUMeasResult(ch, SITE_BC, AVERAGE_RESULT);
	}
	dcm.SetPPMU(ch, DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);
	//dcm.SetPPMU(ch, DCM_PPMU_FIMV, 0, DCM_PPMUIRANGE_2MA);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_v[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_v, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_d(FXVIe_PLUS &acm_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double i_set = 0;
	if (hilim <= 0) {i_set = -0.001;}
	if (lolim >= 0) {i_set = 0.001;}

	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}
	acm_res.Set(FI, i_set, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	delay_ms(delay);
	acm_res.MeasureVI(40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = acm_res.GetMeasResult(SITE_BC,MVRET);
	}
	acm_res.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_ON);
	acm_res.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_v[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_v, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_df(FXVIe_PLUS &acm_res, DWORD delay, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1)
{
	double result_v[SITE_NUM];
	double i_set = 0;
	if (hilim <= 0) {i_set = -0.001;}
	if (lolim >= 0) {i_set = 0.001;}

	if (delay <= 0){
		string comment;
		comment = "T" + int2str(tnum) + " " + component + " test_r delay can't be less than 0ms";
		MessageBoxA(NULL, comment.c_str(), "�����ʾ�Ի���", MB_OK);
		return FALSE;
	}
	acm_res.Set(FI, i_set, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	delay_ms(delay);
	acm_res.MeasureVI(40, 10);
	SERIAL_BC{
		result_v[SITE_BC] = acm_res.GetMeasResult(SITE_BC,MVRET);
	}
	acm_res.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_FANOUT_ON);
	acm_res.Set(FI, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_v[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_v, lolim, hilim, unit);

	return TRUE;
}
void regression(int points,double *xin,double *yin,double *offs,double *slope,double *rms_err,double *max_err)
{
	double sx=0,sy=0,sxx=0,syy=0,sxy=0;
	double ax,ay;
	double rmserr,maxerr;
	int i;

	for(i=0;i<points;i++) {
		sx+=xin[i]; sy+=yin[i];
		sxx+=xin[i]*xin[i]; sxy+=xin[i]*yin[i];
		syy+=yin[i]*yin[i];
	}
	/* calc best line fit */
	ax=sx/points; ay=sy/points; ; 
	*slope=(sxy-points*ax*ay)/(sxx-points*ax*ax);
	*offs=ay - *slope*ax;

	/* get worst case and rms error compared to best line fit */
	maxerr=sx=sxx=0;
	for(i=0;i<points;i++) {
		double err=yin[i]-(xin[i]**slope+*offs);
		sx+=err;
		sxx+=err*err;
		if(fabs(err)>fabs(maxerr))
			maxerr=fabs(err);
	}
	rmserr=sqrt((points*sxx-sx*sx)/(points*(points-1)));

	if(rms_err)
		*rms_err=rmserr;
	if(max_err)
		*max_err=maxerr;
}

BOOL BoardCheck::test_cap(FOVIe &fovi_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	const int samples = 1000;
	int interval = 10; // us
	double vmax = 5;
	double vmin = 0;
	double i_set = /*(hilim - lolim) / 2*/ lolim / get_scale(unit) * 0.5 * (vmax - vmin) / samples / (interval * 1e-6);

	string str(component);
	str = str + "�еĵ���̫С���޷�����\n���Գ����޸� low test limit";
	if(i_set < 80e-9)
		MessageBoxA(NULL, str.c_str(), "�����ʾ�Ի���", MB_OK);

	FOVIe_IRNG i_range;
	i_range = get_fovi_i_range(i_set);

	fovi_res.Set(FV, 0, FOVIe_5V, FOVIe_100MA, FOVIe_RELAY_ON); // discharge
	delay_ms(20);
	fovi_res.Set(FV, 0, FOVIe_5V, i_range, FOVIe_RELAY_ON); 
	delay_ms(2);
	fovi_res.Set(FI, 0, FOVIe_5V, i_range, FOVIe_RELAY_ON);//update from iset to 0  @12/125

	double pat[samples] = {0};
	for(int i=0; i<samples; ++i)
		pat[i] = i_set;

	fovi_res.AwgClear();
	fovi_res.AwgLoader("awg_cap", FI, FOVIe_5V, i_range, pat, samples);
	fovi_res.AwgSelect("awg_cap", 0, samples-1, samples-1, interval);
	fovi_res.MeasureVI(samples, interval, FOVIe_MI_X1,MEAS_AWG);

	STSEnableAWG(&fovi_res);
	STSEnableMeas(&fovi_res);

	StsAWGRun();
	double cap[SITE_NUM][samples];

	SERIAL_BC	fovi_res.BlockRead(SITE_BC, 0, samples, cap[SITE_BC], MVRET);

	double offset = 0;
	double slope = 0;
	//double t[samples] = {0};
	//for(int i=0; i<samples; ++i)
	//	t[i] = interval * 1e-6;

	double result_c[SITE_NUM]; 
	SERIAL_BC{
		//regression(samples - 50, t, cap[SITE_BC], &offset, &slope, NULL, NULL);
		slope = 0;
		for(int i=200; i<500; ++i){
			slope = slope + (cap[SITE_BC][i+300] - cap[SITE_BC][i]) / (interval * 1e-6 * 300);
		}
		slope /= 300;
		if(slope != 0)
			result_c[SITE_BC] = i_set / slope * get_scale(unit);
		else
			result_c[SITE_BC] = 9999;
	}

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_c[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result_c, lolim, hilim, unit);

	fovi_res.Set(FV, 0, FOVIe_5V, FOVIe_100MA, FOVIe_RELAY_ON); // discharge
	delay_ms(2);//add discharge time 12/25
	fovi_res.Set(FV, 0, FOVIe_5V, FOVIe_100MA, FOVIe_RELAY_OFF);

	return TRUE;
}
BOOL BoardCheck::test_cap(FXVIe_PLUS &fovi_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	const int samples = 1000;
	int interval = 10; // us
	double vmax = 5;
	double vmin = 0;
	double i_set = /*(hilim - lolim) / 2*/ lolim / get_scale(unit) * 0.5 * (vmax - vmin) / samples / (interval * 1e-6);

	string str(component);
	str = str + "�еĵ���̫С���޷�����\n���Գ����޸� low test limit";
	if(i_set < 80e-9)
		MessageBoxA(NULL, str.c_str(), "�����ʾ�Ի���", MB_OK);

	FXVIe_PLUS_IRNG i_range;
	i_range = get_fxvi_i_range(i_set);

	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON); // discharge
	delay_ms(20);
	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, i_range, FXVIe_PLUS_RELAY_ON); 
	delay_ms(2);
	fovi_res.Set(FI, 0, FXVIe_PLUS_3p6V, i_range, FXVIe_PLUS_RELAY_ON);//update from iset to 0  @12/125

	double pat[samples] = {0};
	for(int i=0; i<samples; ++i)
		pat[i] = i_set;

	fovi_res.AwgClear();
	fovi_res.AwgLoader("awg_cap", FI, FXVIe_PLUS_3p6V, i_range, pat, samples);
	fovi_res.AwgSelect("awg_cap", 0, samples-1, samples-1, interval);
	fovi_res.MeasureVI(samples, interval, FXVIe_PLUS_MI_X1,MEAS_AWG);

	STSEnableAWG(&fovi_res);
	STSEnableMeas(&fovi_res);

	StsAWGRun();
	double cap[SITE_NUM][samples];

	SERIAL_BC	fovi_res.BlockRead(SITE_BC, 0, samples, cap[SITE_BC], MVRET);

	double offset = 0;
	double slope = 0;
	//double t[samples] = {0};
	//for(int i=0; i<samples; ++i)
	//	t[i] = interval * 1e-6;

	double result_c[SITE_NUM]; 
	SERIAL_BC{
		//regression(samples - 50, t, cap[SITE_BC], &offset, &slope, NULL, NULL);
		slope = 0;
		for(int i=200; i<500; ++i){
			slope = slope + (cap[SITE_BC][i+300] - cap[SITE_BC][i]) / (interval * 1e-6 * 300);
		}
		slope /= 300;
		if(slope != 0)
			result_c[SITE_BC] = i_set / slope * get_scale(unit);
		else
			result_c[SITE_BC] = 9999;
	}

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_c[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result_c, lolim, hilim, unit);

	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_ON); // discharge
	delay_ms(2);//add discharge time 12/25
	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

	return TRUE;
}
BOOL BoardCheck::test_capf(FXVIe_PLUS &fovi_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	const int samples = 1000;
	int interval = 10; // us
	double vmax = 5;
	double vmin = 0;
	double i_set = /*(hilim - lolim) / 2*/ lolim / get_scale(unit) * 0.5 * (vmax - vmin) / samples / (interval * 1e-6);

	string str(component);
	str = str + "�еĵ���̫С���޷�����\n���Գ����޸� low test limit";
	if(i_set < 80e-9)
		MessageBoxA(NULL, str.c_str(), "�����ʾ�Ի���", MB_OK);

	FXVIe_PLUS_IRNG i_range;
	i_range = get_fxvi_i_range(i_set);

	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON); // discharge
	delay_ms(20);
	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, i_range, FXVIe_PLUS_RELAY_FANOUT_ON); 
	delay_ms(2);
	fovi_res.Set(FI, 0, FXVIe_PLUS_3p6V, i_range, FXVIe_PLUS_RELAY_FANOUT_ON);//update from iset to 0  @12/125

	double pat[samples] = {0};
	for(int i=0; i<samples; ++i)
		pat[i] = i_set;

	fovi_res.AwgClear();
	fovi_res.AwgLoader("awg_cap", FI, FXVIe_PLUS_3p6V, i_range, pat, samples);
	fovi_res.AwgSelect("awg_cap", 0, samples-1, samples-1, interval);
	fovi_res.MeasureVI(samples, interval, FXVIe_PLUS_MI_X1,MEAS_AWG);

	STSEnableAWG(&fovi_res);
	STSEnableMeas(&fovi_res);

	StsAWGRun();
	double cap[SITE_NUM][samples];

	SERIAL_BC	fovi_res.BlockRead(SITE_BC, 0, samples, cap[SITE_BC], MVRET);

	double offset = 0;
	double slope = 0;
	//double t[samples] = {0};
	//for(int i=0; i<samples; ++i)
	//	t[i] = interval * 1e-6;

	double result_c[SITE_NUM]; 
	SERIAL_BC{
		//regression(samples - 50, t, cap[SITE_BC], &offset, &slope, NULL, NULL);
		slope = 0;
		for(int i=200; i<500; ++i){
			slope = slope + (cap[SITE_BC][i+300] - cap[SITE_BC][i]) / (interval * 1e-6 * 300);
		}
		slope /= 300;
		if(slope != 0)
			result_c[SITE_BC] = i_set / slope * get_scale(unit);
		else
			result_c[SITE_BC] = 9999;
	}

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_c[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result_c, lolim, hilim, unit);

	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_FANOUT_ON); // discharge
	delay_ms(2);//add discharge time 12/25
	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_100MA, FXVIe_PLUS_RELAY_OFF);

	return TRUE;
}
BOOL BoardCheck::test_cap(ACM &acm_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	const int samples = 1000;
	int interval = 10; // us
	double vmax = 5;
	double vmin = 0;
	double i_set = /*(hilim - lolim) / 2*/ lolim / get_scale(unit) * 0.5 * (vmax - vmin) / samples / (interval * 1e-6);

	string str(component);
	str = str + "�еĵ���̫С���޷�����\n���Գ����޸� low test limit";
	if (i_set < 80e-9)
		MessageBoxA(NULL, str.c_str(), "�����ʾ�Ի���", MB_OK);

	ACM_IRNG i_range;
	i_range = get_acm_i_range(i_set);

	acm_res.Set(FV, 0, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON); // discharge
	delay_ms(20);
	acm_res.Set(FV, 0, ACM_N2P18V, i_range, ACM_RELAY_ON);
	delay_ms(2);
	acm_res.Set(FI, 0, ACM_N2P18V, i_range, ACM_RELAY_ON);//

	double pat[samples] = { 0 };
	for (int i = 0; i<samples; ++i)
		pat[i] = i_set;

	acm_res.AwgClear();
	acm_res.AwgLoader("awg_cap", FI, ACM_N2P18V, i_range, pat, samples);
	acm_res.AwgSelect("awg_cap", 0, samples - 1, samples - 1, interval);
	acm_res.MeasureVI(ACM_MV, samples, interval, MEAS_AWG);

	STSEnableAWG(&acm_res);
	STSEnableMeas(&acm_res);

	StsAWGRun();
	double cap[SITE_NUM][samples];

	SERIAL_BC	acm_res.BlockRead(SITE_BC, 0, samples, cap[SITE_BC]);

	double offset = 0;
	double slope = 0;
	//double t[samples] = {0};
	//for(int i=0; i<samples; ++i)
	//	t[i] = interval * 1e-6;

	double result_c[SITE_NUM];
	SERIAL_BC{
		//regression(samples - 50, t, cap[SITE_BC], &offset, &slope, NULL, NULL);
		slope = 0;
		for (int i = 200; i<500; ++i){
			slope = slope + (cap[SITE_BC][i + 300] - cap[SITE_BC][i]) / (interval * 1e-6 * 300);
		}
		slope /= 300;
		if (slope != 0)
			result_c[SITE_BC] = i_set / slope * get_scale(unit);
		else
			result_c[SITE_BC] = 9999;
	}

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_c[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_c, lolim, hilim, unit);

	acm_res.Set(FV, 0, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON); // discharge
	delay_ms(2);//add discharge time 12/25
	acm_res.Set(FV, 0, ACM_N2P18V, ACM_20MA, ACM_RELAY_OFF);

	return TRUE;
}
BOOL BoardCheck::test_cap(ACM200 &acm_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	const int samples = 1000;
	int interval = 10; // us
	double vmax = 5;
	double vmin = 0;
	double i_set = /*(hilim - lolim) / 2*/ lolim / get_scale(unit) * 0.5 * (vmax - vmin) / samples / (interval * 1e-6);

	string str(component);
	str = str + "�еĵ���̫С���޷�����\n���Գ����޸� low test limit";
	if (i_set < 80e-9)
		MessageBoxA(NULL, str.c_str(), "�����ʾ�Ի���", MB_OK);

	ACM200_IRNG i_range;
	i_range = get_acm200_i_range(i_set);

	acm_res.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON); // discharge
	delay_ms(20);
	acm_res.Set(FV, 0, ACM200_3p6V, i_range, ACM200_RELAY_ON);
	delay_ms(2);
	acm_res.Set(FI, 0, ACM200_3p6V, i_range, ACM200_RELAY_ON);//

	double pat[samples] = { 0 };
	for (int i = 0; i<samples; ++i)
		pat[i] = i_set;

	acm_res.AwgClear();
	acm_res.AwgLoader("awg_cap", FI, ACM200_3p6V, i_range, pat, samples);
	acm_res.AwgSelect("awg_cap", 0, samples - 1, samples - 1, interval);
	acm_res.MeasureVI(samples, interval, MEAS_AWG);

	STSEnableAWG(&acm_res);
	STSEnableMeas(&acm_res);

	StsAWGRun();
	double cap[SITE_NUM][samples];

	SERIAL_BC	acm_res.BlockRead(SITE_BC, 0, samples, cap[SITE_BC],MVRET);

	double offset = 0;
	double slope = 0;
	//double t[samples] = {0};
	//for(int i=0; i<samples; ++i)
	//	t[i] = interval * 1e-6;

	double result_c[SITE_NUM];
	SERIAL_BC{
		//regression(samples - 50, t, cap[SITE_BC], &offset, &slope, NULL, NULL);
		slope = 0;
		for (int i = 200; i<500; ++i){
			slope = slope + (cap[SITE_BC][i + 300] - cap[SITE_BC][i]) / (interval * 1e-6 * 300);
		}
		slope /= 300;
		if (slope != 0)
			result_c[SITE_BC] = i_set / slope * get_scale(unit);
		else
			result_c[SITE_BC] = 9999;
	}

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_c[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result_c, lolim, hilim, unit);

	acm_res.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON); // discharge
	delay_ms(5);//add discharge time 12/25
	acm_res.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);

	return TRUE;
}

BOOL BoardCheck::test_cap1(FOVIe &fovi_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM]={0};
	double MeasV1[SITE_NUM]={0};
	double MeasV2[SITE_NUM]={0};
	FOVIe_IRNG i_range;

	double cap_i = lolim / get_scale(unit) * 5 / 5e-3; // A
	i_range = get_fovi_i_range(cap_i);

	fovi_res.Set(FV, 0, FOVIe_10V, FOVIe_100MA, FOVIe_RELAY_ON); // discharge
	delay_ms(20);
	fovi_res.Set(FI, 0, FOVIe_10V, i_range, FOVIe_RELAY_ON);
	delay_ms(1);

	fovi_res.Set(FI, cap_i, FOVIe_10V, i_range, FOVIe_RELAY_ON);
	delay_ms(1);

	fovi_res.MeasureVI(10, 10);
	SERIAL_BC MeasV1[SITE_BC] = fovi_res.GetMeasResult(SITE_BC, MVRET);
	delay_ms(5);
	fovi_res.MeasureVI(10, 10);
	SERIAL_BC MeasV2[SITE_BC] = fovi_res.GetMeasResult(SITE_BC, MVRET);

	SERIAL_BC result[SITE_BC] = (cap_i * 5e-3) / (MeasV2[SITE_BC] - MeasV1[SITE_BC] + 1e-12) * get_scale(unit); // F

	fovi_res.Set(FI, 0, FOVIe_10V, i_range, FOVIe_RELAY_ON);
	fovi_res.Set(FV, 0, FOVIe_10V, FOVIe_10MA, FOVIe_RELAY_ON);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}	

BOOL BoardCheck::test_cap(FPVIe &fpvi_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	const int samples = 1000;
	int interval = 10; // us
	double vmax = 5;
	double vmin = 0;
	double i_set = /*(hilim - lolim) / 2*/ lolim / get_scale(unit) * 0.5 * (vmax - vmin) / samples / (interval * 1e-6);

	string str(component);
	str = str + "�еĵ���̫С���޷�����\n���Գ����޸� low test limit";
	if(i_set < 80e-9)
		MessageBoxA(NULL, str.c_str(), "�����ʾ�Ի���", MB_OK);

	FPVIe_IRNG i_range;
	i_range = get_fpvi_i_range(i_set);

	fpvi_res.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON); // discharge
	delay_ms(20);
	fpvi_res.Set(FV, 0, FPVIe_5V, i_range, FPVIe_RELAY_ON); 
	delay_ms(2);
	fpvi_res.Set(FI, 0, FPVIe_5V, i_range, FPVIe_RELAY_ON);

	double pat[samples] = {0};
	for(int i=0; i<samples; ++i)
		pat[i] = i_set;

	fpvi_res.AwgClear();
	fpvi_res.AwgLoader("awg_cap", FI, FPVIe_5V, i_range, pat, samples);
	fpvi_res.AwgSelect("awg_cap", 0, samples-1, samples-1, interval);
	fpvi_res.MeasureVI(samples, interval, FPVIe_MV_X1, FPVIe_MI_X1, MEAS_AWG);

	STSEnableAWG(&fpvi_res);
	STSEnableMeas(&fpvi_res);

	StsAWGRun();
	double cap[SITE_NUM][samples];

	SERIAL_BC	fpvi_res.BlockRead(SITE_BC, 0, samples, cap[SITE_BC], MVRET);

	double offset = 0;
	double slope = 0;
	//double t[samples] = {0};
	//for(int i=0; i<samples; ++i)
	//	t[i] = interval * 1e-6;

	double result_c[SITE_NUM]; 
	SERIAL_BC{
		//regression(samples - 50, t, cap[SITE_BC], &offset, &slope, NULL, NULL);
		slope = 0;
		for(int i=200; i<500; ++i){
			slope = slope + (cap[SITE_BC][i+300] - cap[SITE_BC][i]) / (interval * 1e-6 * 300);
		}
		slope /= 300;
		if(slope != 0)
			result_c[SITE_BC] = i_set / slope * get_scale(unit);
		else
			result_c[SITE_BC] = 9999;
	}

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result_c[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result_c, lolim, hilim, unit);

	fpvi_res.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_ON); // discharge
	fpvi_res.Set(FV, 0, FPVIe_5V, FPVIe_100MA, FPVIe_RELAY_OFF);

	return TRUE;
}


BOOL BoardCheck::test_cap1(FPVIe &fpvi_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM]={0};
	double MeasV1[SITE_NUM]={0};
	double MeasV2[SITE_NUM]={0};
	FPVIe_IRNG i_range;

	double cap_i = lolim / get_scale(unit) * 5 / 5e-3; // A
	i_range = get_fpvi_i_range(cap_i);

	fpvi_res.Set(FV, 0, FPVIe_10V, FPVIe_100MA, FPVIe_RELAY_ON); // discharge
	delay_ms(20);
	fpvi_res.Set(FI, 0, FPVIe_10V, i_range, FPVIe_RELAY_ON);
	delay_ms(1);

	fpvi_res.Set(FI, cap_i, FPVIe_10V, i_range, FPVIe_RELAY_ON);
	delay_ms(1);

	fpvi_res.MeasureVI(10, 10);
	SERIAL_BC MeasV1[SITE_BC] = fpvi_res.GetMeasResult(SITE_BC, MVRET);
	delay_ms(5);
	fpvi_res.MeasureVI(10, 10);
	SERIAL_BC MeasV2[SITE_BC] = fpvi_res.GetMeasResult(SITE_BC, MVRET);

	SERIAL_BC result[SITE_BC] = (cap_i * 5e-3) / (MeasV2[SITE_BC] - MeasV1[SITE_BC] + 1e-12) * get_scale(unit); // F

	fpvi_res.Set(FI, 0, FPVIe_10V, i_range, FPVIe_RELAY_ON);
	fpvi_res.Set(FV, 0, FPVIe_10V, FPVIe_10MA, FPVIe_RELAY_ON);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}	


BOOL BoardCheck::test_cap1(ACM &acm_res, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM] = { 0 };
	double MeasV1[SITE_NUM] = { 0 };
	double MeasV2[SITE_NUM] = { 0 };
	ACM_IRNG i_range;
	double t0;
	double cap_i = lolim / get_scale(unit) * 5 / 5e-3 / 4.0; // A
	i_range = get_acm_i_range(cap_i);

	acm_res.Set(FV, 0, ACM_N2P18V, ACM_200MA, ACM_RELAY_ON); // discharge
	delay_ms(20);
	acm_res.Set(FI, 0, ACM_N2P18V, i_range, ACM_RELAY_ON);
	delay_ms(1);

	acm_res.Set(FI, cap_i, ACM_N2P18V, i_range, ACM_RELAY_ON);
	delay_ms(5);
	STSSetTimeCheck(0);
	acm_res.MeasureVI(ACM_MV, 10, 10);
	SERIAL_BC MeasV1[SITE_BC] = acm_res.GetMeasResult(SITE_BC);
	delay_ms(5);
	acm_res.MeasureVI(ACM_MV, 10, 10);
	t0 = STSGetTimeElapsed(0);
	SERIAL_BC MeasV2[SITE_BC] = acm_res.GetMeasResult(SITE_BC);

	SERIAL_BC result[SITE_BC] = (cap_i * (t0 - 0.1)*1e-3) / (MeasV2[SITE_BC] - MeasV1[SITE_BC] + 1e-12) * get_scale(unit); // F

	acm_res.Set(FI, 0, ACM_N2P18V, i_range, ACM_RELAY_ON);
	acm_res.Set(FV, 0, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON);

	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum++, component, result, lolim, hilim, unit);

	return TRUE;
}


//BOOL BoardCheck::test_dcm_init(){
//	dcm.Connect();
//	dcm.SetClockFreq(1e3);
//	for(int i=0; i<8; ++i){
//		dcm.SetWaveFormat(i, "NRZ");
//		dcm.SetDelay(i, 0, 0);
//	}
//	dcm.SetVIH(5);
//	dcm.SetVIL(0);
//
//	return TRUE;
//}


//BOOL BoardCheck::test_dcm_L(FOVI &fovi_res, int* dio_ch, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
//	string line("11111111");
//	SERIAL_BC {
//		int pos = 7 - dio_ch[SITE_BC];
//		line[pos] = '0';				
//	}
//	char * p=new char[9];
//	strcpy_s(p, 9, line.c_str());
//	dcm.LoadPattern(1, p);
//	dcm.LoadPattern(2, p);
//	delete p;
//	p = NULL;
//
//	dcm.LoopSet(1, 2, -1); // infinite loop 
//	dcm.RunPattern(1, 2);
//   	delay_ms(2);
//
//	Cvi_config vi; // default FV,3V,0A,FOVIe_5V,FOVIe_10MA,10ms,100 sample times,10 us interval
//	vi.mode = FI;
//	vi.i_range = FOVIe_10UA;
//
//	test_v(fovi_res, vi, tnum, component, lolim, hilim, unit, result1);
//
//	dcm.StopPattern();
//
//	return TRUE;
//}


//BOOL BoardCheck::test_dcm_H(FOVIe &fovi_res, int* dio_ch, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
//	string line("00000000");
//	SERIAL_BC {
//		int pos = 7 - dio_ch[SITE_BC];
//		line[pos] = '1';				
//	}
//	char * p=new char[9];
//	strcpy_s(p, 9, line.c_str());
//	dcm.LoadPattern(1, p);
//	dcm.LoadPattern(2, p);
//	delete p;
//	p = NULL;
//
//	dcm.LoopSet(1, 2, -1); // infinite loop 
//	dcm.RunPattern(1, 2);
//   	delay_ms(2);
//
//	Cvi_config vi; // default FV,3V,0A,FOVIe_5V,FOVIe_10MA,10ms,100 sample times,10 us interval
//	vi.mode = FI;
//	vi.i_range = FOVIe_10UA;
//
//	test_v(fovi_res, vi, tnum, component, lolim, hilim, unit, result1);
//
//	dcm.StopPattern();
//
//	return TRUE;
//}	

//BOOL BoardCheck::test_dcm_Z(FOVIe &fovi_res, int* dio_ch, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
//	string line("00000000");
//	SERIAL_BC {
//		int pos = 7 - dio_ch[SITE_BC];
//		line[pos] = 'X';				
//	}
//	char * p=new char[9];
//	strcpy_s(p, 9, line.c_str());
//	dcm.LoadPattern(1, p);
//	dcm.LoadPattern(2, p);
//	delete p;
//	p = NULL;
//
//	dcm.LoopSet(1, 2, -1); // infinite loop 
//	dcm.RunPattern(1, 2);
//   	delay_ms(2);
//
//	Cvi_config vi; // default FV,3V,0A,FOVIe_5V,FOVIe_10MA,10ms,100 sample times,10 us interval
//	vi.mode = FV;
//	vi.i_range = FOVIe_10UA;
//
//	test_i(fovi_res, vi, tnum, component, lolim, hilim, unit, result1);
//
//	dcm.StopPattern();
//
//	return TRUE;
//}	

BOOL BoardCheck::test_qtmu(FOVIe &fovi_res, QTMUe *qtmu, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM];
	fovi_res.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_ON);

	SERIAL_BC{
		qtmu[SITE_BC].SetInSource(QTMUe_SINGLE_SOURCE_A);
		qtmu[SITE_BC].Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS);
		qtmu[SITE_BC].Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.0, QTMUe_FILTER_PASS);
		
		qtmu[SITE_BC].Connect(QTMUe_RELAY_CHA);
		delay_ms(1);

		qtmu[SITE_BC].Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 1, 10, QTMUe_TRANGE_US);

		fovi_res.Pulse(5, 1000, -500, 200, 10);
   		delay_ms(2);
	//	qtmu.SinglePlsMeas(SITE_BC);
		result[SITE_BC] = qtmu[SITE_BC].GetMeasureResult(SITE_BC);
		qtmu[SITE_BC].Disconnect(QTMUe_RELAY_CHA);
	}

	fovi_res.Set(FV, 0, FOVIe_5V, FOVIe_10MA, FOVIe_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_qtmu(FXVIe_PLUS &fovi_res, QTMUe *qtmu, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM];
	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_ON);

	SERIAL_BC{
		qtmu[SITE_BC].SetInSource(QTMUe_SINGLE_SOURCE_A);
		qtmu[SITE_BC].Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS);
		qtmu[SITE_BC].Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.0, QTMUe_FILTER_PASS);
		
		qtmu[SITE_BC].Connect(QTMUe_RELAY_CHA);
		delay_ms(1);

		qtmu[SITE_BC].Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 1, 10, QTMUe_TRANGE_US);

		fovi_res.Pulse(5, 1000, -500, 200, 10);
   		delay_ms(2);
	//	qtmu.SinglePlsMeas(SITE_BC);
		result[SITE_BC] = qtmu[SITE_BC].GetMeasureResult(SITE_BC);
		qtmu[SITE_BC].Disconnect(QTMUe_RELAY_CHA);
	}

	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_qtmuf(FXVIe_PLUS &fovi_res, QTMUe *qtmu, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM];
	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_FANOUT_ON);

	SERIAL_BC{
		qtmu[SITE_BC].SetInSource(QTMUe_SINGLE_SOURCE_A);
		qtmu[SITE_BC].Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS);
		qtmu[SITE_BC].Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.0, QTMUe_FILTER_PASS);
		
		qtmu[SITE_BC].Connect(QTMUe_RELAY_CHA);
		delay_ms(1);

		qtmu[SITE_BC].Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 1, 10, QTMUe_TRANGE_US);

		fovi_res.Pulse(5, 1000, -500, 200, 10);
   		delay_ms(2);
	//	qtmu.SinglePlsMeas(SITE_BC);
		result[SITE_BC] = qtmu[SITE_BC].GetMeasureResult(SITE_BC);
		qtmu[SITE_BC].Disconnect(QTMUe_RELAY_CHA);
	}

	fovi_res.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_10MA, FXVIe_PLUS_RELAY_OFF);

	if(result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if(result1 == NULL) log(tnum, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::test_qtmu(ACM &acm_res, QTMUe &qtmu, QTMUe_SOURCE_AB source, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM];
	QTMUe_RELAY_CHANNEL channel;
	acm_res.Set(FV, 0, ACM_N2P18V, ACM_20MA, ACM_RELAY_ON);


	qtmu.SetInSource(source);
	qtmu.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS);
	qtmu.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.0, QTMUe_FILTER_PASS);
	if (source == QTMUe_SINGLE_SOURCE_A)
		channel=QTMUe_RELAY_CHA;
	else if (source == QTMUe_SINGLE_SOURCE_B)
		channel = QTMUe_RELAY_CHB;
	else
		channel = QTMUe_RELAY_CHAB;

	qtmu.Connect(channel);
	delay_ms(1);

	qtmu.Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 1, 10, QTMUe_TRANGE_US);

	acm_res.Pulse(5, 1000, -500, ACM_MV,200, 10);
	delay_ms(2);
		
	SERIAL_BC result[SITE_BC] = qtmu.GetMeasureResult(SITE_BC);
	qtmu.Disconnect(channel);
	acm_res.Set(FV, 0, ACM_N2P18V, ACM_20MA, ACM_RELAY_OFF);


	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum, component, result, lolim, hilim, unit);

	return TRUE;
}

BOOL BoardCheck::test_qtmu(ACM200 &acm_res, QTMUe &qtmu, QTMUe_SOURCE_AB source, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM];
	QTMUe_RELAY_CHANNEL channel;
	acm_res.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_ON);


	qtmu.SetInSource(source);
	qtmu.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.5, QTMUe_FILTER_PASS);
	qtmu.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_NEG, 2.0, QTMUe_FILTER_PASS);
	if (source == QTMUe_SINGLE_SOURCE_A)
		channel=QTMUe_RELAY_CHA;
	else if (source == QTMUe_SINGLE_SOURCE_B)
		channel = QTMUe_RELAY_CHB;
	else
		channel = QTMUe_RELAY_CHAB;

	qtmu.Connect(channel);
	delay_ms(1);

	qtmu.Measure(QTMUe_MU1, QTMUe_MEAS_TIME, 1, 10, QTMUe_TRANGE_US);

	acm_res.Pulse(5, 1000, -500, 200, 10);
	delay_ms(2);
		
	SERIAL_BC result[SITE_BC] = qtmu.GetMeasureResult(SITE_BC);
	qtmu.Disconnect(channel);
	acm_res.Set(FV, 0, ACM200_3p6V, ACM200_10MA, ACM200_RELAY_OFF);


	if (result1 != NULL)	SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum, component, result, lolim, hilim, unit);

	return TRUE;
}

BOOL BoardCheck::test_qtmu_freq(QTMUe &qtmu, QTMUe_SOURCE_AB source, DWORD tnum, const char* component, double lolim, double hilim, const char* unit, double *result1){
	double result[SITE_NUM];
//	QTMUe_RELAY_CHANNEL channel;

	/*qtmu.SetInSource(source);
	qtmu.Start(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.0, QTMUe_FILTER_PASS);
	qtmu.Stop(QTMUe_MU1, QTMUe_10V, QTMUe_POS, 2.0, QTMUe_FILTER_PASS);
	if (source == QTMUe_SINGLE_SOURCE_A)
		channel = QTMUe_RELAY_CHA;
	else if (source == QTMUe_SINGLE_SOURCE_B)
		channel = QTMUe_RELAY_CHB;
	else
		channel = QTMUe_RELAY_CHAB;

	qtmu.Connect(channel);
	qtmu.Measure(QTMUe_MU1, QTMUe_MEAS_FREQ, 30, 5, QTMUe_TRANGE_MS);*/

	SERIAL_BC result[SITE_BC] = qtmu.GetMeasureResult(SITE_BC);
	//qtmu.Disconnect(channel);
	
	if (result1 != NULL) SERIAL_BC result1[SITE_BC] = result[SITE_BC];
	if (result1 == NULL) log(tnum, component, result, lolim, hilim, unit);

	return TRUE;
}
BOOL BoardCheck::Board_ID_Check(const char* boardName, const char* rev, const char* SCLChannel, const char* SDAChannel)
{
	BYTE EEPROM_ADDR =0xA4;
	ULONG nReadData1 = 0 ;
	ULONG nReadData[512] = {0};
	string bname_read="";
	string brev_read = "";
	string bname(boardName);
	string brev(rev);
	string info;
	int find = 0;
	int acknack;
	char c1[1];
	
	//total 4k bits =512 bytes
	dcm.I2CSet(10000, 1, DCM_REG8, SCLChannel, SDAChannel);
	dcm.I2CConnect();//Connect I2C relay
	dcm.I2CSetPinLevel(5.0, 0, 2.0, 1.9);
	dcm.I2CSetSCLEdge(0, 10000*0.7);
	dcm.I2CSetSDAEdge(10000*0.1, 10000*0.995, 10000*0.1, 10000*0.95);
	delay_ms(1);
	dcm.I2CReadData(EEPROM_ADDR, 0, 1);
	delay_ms(1);
	acknack=dcm.I2CGetNACKIndex(0);
	nReadData1 = dcm.I2CGetReadData(0, 0);
	if (nReadData1 == 255)
	{
		MessageBoxA(NULL, "û�з��ְ��ӱ�ţ�����ϵ����ʦ���", "���ӱ�ż��Ի���", MB_OK);
		dcm.I2CDisconnect();
		return false;
		//need write data
	}
	else
	{
		dcm.I2CReadData(EEPROM_ADDR, 0, 64);
		delay_ms(1);
		for (int addr = 0; addr < 64; ++addr)
		{
			nReadData[addr] = dcm.I2CGetReadData(0, addr);
			c1[0] = (char)nReadData[addr];//ascii transfer to char
			if (nReadData[addr] == 124) find++;
			else if (find==0)	bname_read = bname_read + c1[0];
			else if (find == 1)	brev_read = brev_read + c1[0];
		}
		dcm.I2CDisconnect();
		if ((bname_read.compare(bname) == 0) && (brev_read.compare(brev) == 0))
			return true;
		else
		{
			info = "���ӱ����д��ֵ������д��ֵΪ ";
			info.append("��������");
			info.append(bname_read);
			info.append("���Ӱ汾�ţ�");
			info.append(brev_read);
			MessageBoxA(NULL, info.c_str(), "���ӱ�ż��Ի���", MB_OK);
			return false;
		}
		
		
	}
	return true;

}

BOOL BoardCheck::Board_ID_Read(string* boardName, string* rev, string* number, const char* SCLChannel, const char* SDAChannel)
{
	BYTE EEPROM_ADDR = 0xA4;
	ULONG nReadData1 = 0;
	ULONG nReadData[512] = { 0 };
	string bname_read = "";
	string brev_read = "";
	string bnumber_read = "";
	string info;
	int find = 0;
	char c1[1];

	//total 4k bits =512 bytes
	dcm.I2CSet(10000, 1, DCM_REG8, SCLChannel, SDAChannel);
	dcm.I2CConnect();//Connect I2C relay
	dcm.I2CSetPinLevel(5.0, 0, 2.0, 1.9);
	dcm.I2CSetSCLEdge(0, 10000 * 0.7);
	dcm.I2CSetSDAEdge(10000 * 0.1, 10000 * 0.995, 10000 * 0.1, 10000 * 0.95);
	delay_ms(1);
	dcm.I2CReadData(EEPROM_ADDR, 0, 1);
	delay_ms(1);
	nReadData1 = dcm.I2CGetReadData(0, 0);
	if (nReadData1 == 255)
	{
		MessageBoxA(NULL, "û�з��ְ��ӱ�ţ�����ϵ����ʦ���", "���ӱ�ż��Ի���", MB_OK);
		dcm.I2CDisconnect();
		return false;
		//need write data
	}
	else
	{
		dcm.I2CReadData(EEPROM_ADDR, 0, 64);
		delay_ms(1);
		for (int addr = 0; addr < 64; ++addr)
		{
			nReadData[addr] = dcm.I2CGetReadData(0, addr);
			c1[0] = (char)nReadData[addr];//ascii transfer to char
			if (nReadData[addr] == 124)  find++;
			else if (find == 0)	bname_read = bname_read + c1[0];
			else if (find == 1)	brev_read = brev_read + c1[0];
			else if (find == 2)	bnumber_read = bnumber_read + c1[0];
		}
		(*boardName)=bname_read;
		//boardName( bname_read.c_str());
		(*rev) = brev_read;
		(*number) = bnumber_read;
		dcm.I2CDisconnect();
		return true;
	

	}

}
BOOL BoardCheck::Board_ID_Write(const char* boardName, const char* rev, const char* number, const char* SCLChannel, const char* SDAChannel)
{
	BYTE EEPROM_ADDR = 0xA4;
	ULONG nReadData1 = 0;
	ULONG nReadData[512] = { 0 };
	string bname(boardName);
	string brev(rev);
	string bnumber(number);
	string info;
	int find = 0;
	ULONG ulWriteData[SITE_NUM] = { 0 };
	//total 4k bits =512 bytes
	dcm.I2CSet(10000, 1, DCM_REG8, SCLChannel, SDAChannel);
	dcm.I2CConnect();//Connect I2C relay
	dcm.I2CSetPinLevel(5.0, 0, 2.0, 1.9);
	dcm.I2CSetSCLEdge(0, 10000 * 0.7);
	dcm.I2CSetSDAEdge(10000 * 0.1, 10000 * 0.995, 10000 * 0.1, 10000 * 0.95);
	//write  board name
	for (unsigned int i = 0; i < bname.length(); i++){
		SERIAL ulWriteData[SITE] = (DWORD)bname[i];
		dcm.I2CWriteData(EEPROM_ADDR, i , 1, ulWriteData);
		delay_ms(1);
	}
	SERIAL ulWriteData[SITE] = 124;//'|'=124
	dcm.I2CWriteData(EEPROM_ADDR, bname.length(), 1, ulWriteData);
	delay_ms(1);
	//write  board rev

	for (unsigned int i = 0; i < brev.length(); i++){
		SERIAL ulWriteData[SITE] = (DWORD)brev[i];
		dcm.I2CWriteData(EEPROM_ADDR, bname.length() + i + 1, 1, ulWriteData);
		delay_ms(1);
	}
	SERIAL ulWriteData[SITE] = 124;//'|'=124
	dcm.I2CWriteData(EEPROM_ADDR, bname.length() + brev.length() +1, 1, ulWriteData);
	delay_ms(1);
	//write  board number
	for (unsigned int i = 0; i < bnumber.length(); i++){
		SERIAL ulWriteData[SITE] = (DWORD)bnumber[i];
		dcm.I2CWriteData(EEPROM_ADDR, bname.length() + brev.length() + i + 2, 1, ulWriteData);
		delay_ms(1);
	}
	SERIAL ulWriteData[SITE] = 124;//'|'=124
	dcm.I2CWriteData(EEPROM_ADDR, bname.length() + brev.length() + bnumber.length() + 2, 1, ulWriteData);
	delay_ms(1);
	dcm.I2CReadData(EEPROM_ADDR, 0, 64);
	delay_ms(1);
	for (int addr = 0; addr < 64; ++addr)
	{
		nReadData[addr] = dcm.I2CGetReadData(0, addr);
		
	}
	dcm.I2CDisconnect();
	return true;


}