#include "stdafx.h"
#include "fifo.h"

//Fifo_Node node_array[MAX_NODE_LEN];
//int node_array_idx = 0;

void insert_first(Fifo_Node* head, Fifo_Node* node)
{
	node->next = head->next;
	node->prev = head;

	// equality: head->next->prev = node;
	node->next->prev = node;
	head->next = node;
}

void delete_node(const Fifo_Node* node)
{
	Fifo_Node* prev_node = node->prev;
	Fifo_Node* next_node = node->next;
	// current node - node

	prev_node->next = next_node;
	next_node->prev = prev_node;
}

void delete_node_v1(const Fifo_Node* node)
{
	// current node - node

	node->prev->next = node->next;
	node->next->prev = node->prev;
}

void delete_node_v2(Fifo_Node* node)
{
	// current node - node

	node->prev->next = node->next;
	node->next->prev = node->prev;

	node->prev = node->next = node;
}

void init_queue(Fifo_Queue* queue)
{
	(queue->head).prev = (queue->head).next = &(queue->head);
	queue->count = 0;
}

void in_queue(Fifo_Queue* queue, Fifo_Node* node)
{
	insert_first(&(queue->head), node);
	queue->count += 1;
}

Fifo_Node* out_queue(Fifo_Queue* queue)
{
	if (queue->count <= 0)
	{
		return NULL;
	}

	Fifo_Node* ret = (queue->head).prev;
	delete_node(ret);
	queue->count -= 1;

	return ret;
}

void display(const Fifo_Node* head)
{
	int n = 1;

	Fifo_Node* node = head->next;
	while (node != head)
	{
		printf("node %d: %d\n", n, node->data);
		++n;
		node = node->next;
	}
}

void display_v1(const Fifo_Node* head)
{
	int n = 1;

	Fifo_Node* node = head->prev;
	while (node != head)
	{
		printf("node %d: %d\n", n, node->data);
		++n;
		node = node->prev;
	}
}