#include "stdafx.h"
#include "cfg.h"
#include "sub.h"
#include "lsi.h"
#include "BoardCheck.h"
#define		YES 	6
#define		NO		7
extern string int2str(DWORD n);

/* No repeat: board_check_repeat = -1 */
int board_check_repeat = -1; // set repeat count

void connected_site_check(BoardCheck& bc){

	//update for 8300
	double site_check_specl = 0;
	double site_check_spech = 0;
	double result[SITE_NUM]={0};
	//enable all sites
	for(int site=0; site<SITE_NUM; ++site) bc.SetSiteConnected(site, 0); // inital for site check component measure

	//can only enable valid site for engineering use
	if (0)
	{
		//STSSetSiteStatus(0xFFFFFFFF); //set bc site
		SERIAL{ bc.SetSiteConnected(SITE, 1); }
	}
	else{
		bc.SetSiteConnected(0, 1);
		bc.SetSiteConnected(1, 1);
		bc.SetSiteConnected(2, 1);
		bc.SetSiteConnected(3, 1);
		bc.SetSiteConnected(4, 1);
		bc.SetSiteConnected(5, 1);
		bc.SetSiteConnected(6, 1);
		bc.SetSiteConnected(7, 1);
	}
}

BOOL board_check_function(int &nBtn, BOOL &flag_pass)
{
	//////////////////////////////////////////////////////////////////
	/* Common usage format, don't change this if no specific need   */
	BoardCheck bc;
	double result[SITE_NUM];
	 string board_name;
	 string board_rev;
	 string board_number;
	for(int site=0; site<SITE_NUM; ++site) result[site]=9999;
	DWORD tnum=1;
	
	bool stoponfail = 1;
	C_I2C_Connect;
	delay_ms(1);
	//bc.Board_ID_Write("SC6258XN48", "A", "2", "S24_6", "S24_5");
	//	------------Board ID Check---------------
	if (1)
	{
		if (bc.Board_ID_Check("SC6258XN48", "A", "S24_6", "S24_5"))
		{
			bc.Board_ID_Read(&board_name, &board_rev, &board_number, "S24_6", "S24_5");
		}
		else
		{
			nBtn = BTN_EXIT;
			return FALSE;
		}
	}

	//BOOL Board_ID_Check(const char* boardName, const char* rev, const char* SCLChannel, const char* SDAChannel);
	//BOOL Board_ID_Write(const char* boardName, const char* rev, const char* number, const char* SCLChannel, const char* SDAChannel);
	//BOOL Board_ID_Read(const char* boardName, const char* rev, const char* number, const char* SCLChannel, const char* SDAChannel);
	C_I2C_DisConnect;
	delay_ms(1);

	int sel_flag = NO;
	bc.ClearSiteConnected();
	while((bc.IsNoSiteConnected() || (sel_flag == NO)) && (board_check_repeat == -1)){
		connected_site_check(bc);

		if (bc.IsNoSiteConnected() && DEBUG_MODE){
			if(MessageBoxA(NULL, "û��ʹ���κι�λ! \n��ȷ��: ���������ѡ��-��(Y)\n����˳���ѡ��-��(N)", "�����ʾ�Ի���", MB_YESNO) == IDNO){
				nBtn = BTN_EXIT;
				return FALSE;
			} 
			continue;
		}
		sel_flag = YES;
	}
	

	/* Common usage format, don't change this if no specific need   */
	//////////////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////////////////
	/********************** User Define Begin ***********************/
	C_All_Open;
	C_FXVI_ACM_GND_Connect;
	all_resource_off();
	LSI_Init(K_EN_SPI, K_EN_OUT, K_SEL_SPI, K_EN_EXSI, K_GAIN0, K_GAIN1, K_EN_LDO);
	LSI_DisConnect();

	double TempDiode[SITE_NUM];
	double TempSensor[SITE_NUM];
	double TempLsi[SITE_NUM];

	double volt[SITE_NUM];
	C_ACM_DIODE_Connect;
	delay_ms(1);
	temp_meas_board(volt, TempDiode);
	C_ACM_DIODE_DisConnect;
	delay_ms(1);

	Sensor_Connect();
	//Sensor_ReadID(id);
	Sensor_Start();
	delay_ms(5);
	Sensor_Read(TempSensor);
	Sensor_Stop();
	Sensor_DisConnect();
	delay_ms(500);
	LSI_Read_Temp(TempLsi);

	bc.log(tnum++, "Temperature HW1", TempDiode, -100, 200, "C");
	bc.log(tnum++, "Temperature HW2", TempSensor, -100, 200, "C");
	bc.log(tnum++, "Temperature LSI", TempLsi, -100, 200, "C");

	
	Cvi_config vi; // default FV,3V,0A,FOVIe_5V,FOVI_10MA,10ms,100 sample times,10 us interval

//	/*** Connections and components ***/
	//double spec_h = 0.1;
	//double spec_l = -0.1;
	//double leak_spel = -100; //nA
	//double leak_speh = 100;  //nA
	//double cap1uF_l = 0.2;
	//double cap1uF_h = 2.5;
	//double cap4p7uF_l = 1.5;
	//double cap4p7uF_h = 7;
	//double cap2p2nF_l = 0.5;
	//double cap2p2nF_h = 5;
	//double cap10nF_l = 5;
	//double cap10nF_h = 15;
	//double cap100nF_l = 50;
	//double cap100nF_h = 150;
	//double cap10uF_l = 5;
	//double cap10uF_h = 15;
	//double cap1nF_l = 0.5;
	//double cap1nF_h = 2.5;

	fxvi0.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi1.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi2.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi3.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi4.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	fxvi5.Set(FV, 0, FXVIe_PLUS_3p6V, FXVIe_PLUS_1MA, FXVIe_PLUS_RELAY_OFF);
	acm0.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm1.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm2.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm3.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm4.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm5.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//posin
	acm6.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);//possw
	acm7.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm8.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm10.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	acm11.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_OFF);

	double results[SITE_NUM];
	bool has_lsi[SITE_NUM];

	//ACM,FXVI Low side
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;

	//double TempDiode[SITE_NUM];
	//double TempSensor[SITE_NUM];
	//Get_HW_Temp(true, true, TempDiode, TempSensor);
	//bc.log(tnum++, "TempDiode", TempDiode, -99, 199, "C");
	//bc.log(tnum++, "TempSensor", TempSensor, -99, 199, "C");

	//Cap

	////PSRR IN CAP
	//C_FXVI_PSRR_Connect;
	//delay_ms(2);
	//bc.test_capf(fxvi5, tnum++, "PSRR CAP,10uF", 8, 15, "uF");
	//C_FXVI_PSRR_DisConnect;
	//delay_ms(2);

	//VST, C3, C5
	bc.test_capf(fxvi4, tnum++, "VST C5,10nF", 5, 20, "nF");
	C_VST_CAP_Connect;
	delay_ms(2);
	bc.test_capf(fxvi4, tnum++, "VST C3,6.8uF", 5, 10, "uF");
	bc.force_v(fxvi4, 0, true);
	delay_ms(5);
	bc.force_v(fxvi4, 0, false);
	C_VST_CAP_DisConnect;
	delay_ms(2);

	//VS1, C4, C6
	C_FPVIL_AG_Connect;
	C_FPVIH_VS1_Connect;
	delay_ms(2);
	bc.test_cap(fpvi0, tnum++, "VS1 C6,10nF", 5, 20, "nF");
	C_VS1_CAP_Connect;
	delay_ms(2);
	bc.test_cap(fpvi0, tnum++, "VS1 C4,6.8uF", 5, 10, "uF");
	bc.force_v(fpvi0, 0, true);
	delay_ms(5);
	bc.force_v(fpvi0, 0, false);
	C_VS1_CAP_DisConnect;
	delay_ms(2);
	C_FPVIH_VS1_DisConnect;
	C_FPVIL_AG_DisConnect;
	delay_ms(2);

	//QST, C7, C18
	bc.test_cap(acm0, tnum++, "QST C7,10nF", 5, 20, "nF");
	C_QST_CAP_Connect;
	delay_ms(2);
	bc.test_cap(acm0, tnum++, "QST C18,680nF", 500, 1000, "nF");
	bc.force_v(acm0, 0, true);
	delay_ms(5);
	bc.force_v(acm0, 0, false);
	C_QST_CAP_DisConnect;
	delay_ms(2);

	//FB, C9, C19
	cbitclose(K213);
	delay_ms(2);
	bc.test_cap(acm11, tnum++, "FB C9,10nF", 5, 20, "nF");
	C_FB_CAP_Connect;
	delay_ms(2);
	bc.test_cap(acm11, tnum++, "FB C19,4.7uF", 3, 10, "uF");
	bc.force_v(acm11, 0, true);
	delay_ms(5);
	bc.force_v(acm11, 0, false);
	C_FB_CAP_DisConnect;
	delay_ms(2);
	cbitopen(K213);
	delay_ms(2);

	//POSIN, C10, C20
	bc.test_cap(acm5, tnum++, "POSIN C10,10nF", 5, 20, "nF");
	C_POSIN_CAP_Connect;
	delay_ms(2);
	bc.test_cap(acm5, tnum++, "POSIN C20,6.8uF", 5, 10, "uF");
	bc.force_v(acm5, 0, true);
	delay_ms(5);
	bc.force_v(acm5, 0, false);
	C_POSIN_CAP_DisConnect;
	delay_ms(2);

	//QUC, C12, C21
	bc.test_cap(acm2, tnum++, "QUC C12,10nF", 5, 20, "nF");
	C_QUC_CAP_Connect;
	delay_ms(2);
	bc.test_cap(acm2, tnum++, "QUC C21,6.8uF", 5, 10, "uF");
	bc.force_v(acm2, 0, true);
	delay_ms(5);
	bc.force_v(acm2, 0, false);
	C_QUC_CAP_DisConnect;
	delay_ms(2);

	//QVR, C13, C22
	bc.test_cap(acm3, tnum++, "QVR C13,10nF", 5, 20, "nF");
	C_QVR_CAP_Connect;
	delay_ms(2);
	bc.test_cap(acm3, tnum++, "QVR C22,6.8uF", 5, 10, "uF");
	bc.force_v(acm3, 0, true);
	delay_ms(5);
	bc.force_v(acm3, 0, false);
	C_QVR_CAP_DisConnect;
	delay_ms(2);

	//QCO, C14, C23
	bc.test_cap(acm4, tnum++, "QCO C14,10nF", 5, 20, "nF");
	C_QCO_CAP_Connect;
	delay_ms(2);
	bc.test_cap(acm4, tnum++, "QCO C23,6.8uF", 5, 10, "uF");
	bc.force_v(acm4, 0, true);
	delay_ms(5);
	bc.force_v(acm4, 0, false);
	C_QCO_CAP_DisConnect;
	delay_ms(2);

	//QT1, C15, C24
	bc.test_cap(fxvi1, tnum++, "QT1 C15,10nF", 5, 20, "nF");
	C_QT1_CAP_Connect;
	delay_ms(2);
	bc.test_cap(fxvi1, tnum++, "QT1 C24,6.8uF", 5, 10, "uF");
	bc.force_v(fxvi1, 0, true);
	delay_ms(5);
	bc.force_v(fxvi1, 0, false);
	C_QT1_CAP_DisConnect;
	delay_ms(2);

	//QT2, C16, C26
	bc.test_cap(fxvi2, tnum++, "QT2 C16,10nF", 5, 20, "nF");
	C_QT2_CAP_Connect;
	delay_ms(2);
	bc.test_cap(fxvi2, tnum++, "QT2 C26,6.8uF", 5, 10, "uF");
	bc.force_v(fxvi2, 0, true);
	delay_ms(5);
	bc.force_v(fxvi2, 0, false);
	C_QT2_CAP_DisConnect;
	delay_ms(2);

	//QT3, C17, C27
	bc.test_cap(fxvi3, tnum++, "QT3 C17,10nF", 5, 20, "nF");
	C_QT3_CAP_Connect;
	delay_ms(2);
	bc.test_cap(fxvi3, tnum++, "QT3 C27,6.8uF", 5, 10, "uF");
	bc.force_v(fxvi3, 0, true);
	delay_ms(5);
	bc.force_v(fxvi3, 0, false);
	C_QT3_CAP_DisConnect;
	delay_ms(2);

	//Relay
	////////////////////////////////FPVI//////////////////////////////////
	////K1?
	//C_FPVIH_QVR_Connect;
	//C_FPVIL_AG_Connect;
	//delay_ms(2);
	//bc.force_v(fpvi0, 0, true);
	//delay_ms(2);
	//bc.test_v(A_QVR, tnum++, "K1 on V0", -0.1, 0.1, "V");
	////bc.test_r(A_QVR, 2, tnum++, "K1 on R", 1.0, 8.0, "Ohm");
	//bc.force_v(fpvi0, 0.5, true);
	//delay_ms(2);
	//bc.test_v(A_QVR, tnum++, "K1 on V1", 0.4, 0.6, "V");
	//C_FPVIH_QVR_DisConnect;
	//C_FPVIL_AG_DisConnect;
	//delay_ms(2);
	//bc.test_i(A_QVR, vi, tnum++, "K1 off", -0.1, 0.1, "A");
	//bc.force_v(fpvi0, 0, false);


	//K1?
	C_FPVIH_QVR_Connect;
	C_FPVIL_AG_Connect;
	delay_ms(2);
	bc.force_v(acm3, 0, true);
	delay_ms(2);
	bc.test_v(fpvi0, tnum++, "K1 on V0", -0.1, 0.1, "V");
	//bc.test_r(fpvi0, 2, tnum++, "K1 on R", 1.0, 8.0, "Ohm");
	bc.force_v(acm3, 0.5, true);
	delay_ms(2);
	bc.test_v(fpvi0, tnum++, "K1 on V1", 0.4, 0.6, "V");
	C_FPVIH_QVR_DisConnect;
	C_FPVIL_AG_DisConnect;
	delay_ms(2);
	bc.test_i(fpvi0, vi, tnum++, "K1 off", -0.1, 0.1, "A");
	bc.force_v(acm3, 0, false);

	//K2
	C_FPVIH_QCO_Connect;
	C_FPVIL_AG_Connect;
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(A_QCO, tnum++, "K2 on V0", -0.1, 0.1, "V");
	//bc.test_r(A_QCO, 2, tnum++, "K2 on R", 0.5, 8.0, "Ohm");
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(A_QCO, tnum++, "K2 on V1", 0.4, 0.6, "V");
	C_FPVIH_QCO_DisConnect;
	C_FPVIL_AG_DisConnect;
	delay_ms(2);
	bc.test_i(A_QCO, vi, tnum++, "K2 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);

	//K3
	C_FPVIH_QUC_Connect;
	C_FPVIL_AG_Connect;
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(A_QUC, tnum++, "K3 on V0", -0.1, 0.1, "V");
	//bc.test_r(A_QUC, 2, tnum++, "K3 on R", 0.1, 8.0, "Ohm");
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(A_QUC, tnum++, "K3 on V1", 0.4, 0.6, "V");
	C_FPVIH_QUC_DisConnect;
	C_FPVIL_AG_DisConnect;
	delay_ms(2);
	bc.test_i(A_QUC, vi, tnum++, "K3 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	
	//K4
	C_FPVIH_POSSW_Connect;
	C_FPVIL_AG_Connect;
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(A_POSSW, tnum++, "K4 on V0", -0.1, 0.1, "V");
	//bc.test_r(A_POSSW, 2, tnum++, "K4 on R", 1.0, 8.0, "Ohm");//
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(A_POSSW, tnum++, "K4 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSSW_DisConnect;
	C_FPVIL_AG_DisConnect;
	delay_ms(2);
	bc.test_i(A_POSSW, vi, tnum++, "K4 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	
	//K5
	C_FPVIH_POSIN_Connect;
	C_FPVIL_AG_Connect;
	delay_ms(2);
	bc.force_v(A_POSIN, 0, true);
	delay_ms(2);
	bc.test_v(fpvi0, tnum++, "K5 on V0", -0.1, 0.1, "V");
	//bc.test_r(fpvi0, 2, tnum++, "K5 on R", 0.1, 8.0, "Ohm");
	bc.force_v(A_POSIN, 0.5, true);
	delay_ms(2);
	bc.test_v(fpvi0, tnum++, "K5 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_AG_DisConnect;
	delay_ms(2);
	bc.test_i(fpvi0, vi, tnum++, "K5 off", -0.1, 0.1, "A");
	bc.force_v(A_POSIN, 0, false);
	
	//K6,K213,need cbitB
	C_FPVIH_FB_Connect;
	C_FPVIL_AG_Connect;
	cbitclose(K213);
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(A_FB1, tnum++, "K213 on, K6 on V0", -0.1, 0.1, "V");
	//bc.test_r(A_FB1, 2, tnum++, "K213 on, K6 on R", 5.0, 30.0, "Ohm");
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(A_FB1, tnum++, "K213 on, K6 on V1", 0.4, 0.6, "V");
	C_FPVIH_FB_DisConnect;
	C_FPVIL_AG_DisConnect;
	cbitopen(K213);
	delay_ms(2);
	bc.test_i(A_FB1, vi, tnum++, "K213 on, K6 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	
	//K7,K20
	C_FPVIH_SW_Connect;
	C_FPVIL_AG_Connect;
	cbitclose(K20);
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K20 on, K7 on V0", -0.1, 0.1, "V");
	//bc.test_r(fxvi0, 2, tnum++, "K20 on, K7 on R", 1.0, 8.0, "Ohm");//
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K20 on, K7 on V1", 0.4, 0.6, "V");
	C_FPVIH_SW_DisConnect;
	C_FPVIL_AG_DisConnect;
	cbitopen(K20);
	delay_ms(2);
	bc.test_i(fxvi0, vi, tnum++, "K20 on, K7 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	
	//K8,fxvi4f
	C_FPVIH_VST_Connect;
	C_FPVIL_AG_Connect;
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "FXVI4F on, K8 on V0", -0.1, 0.1, "V");
	//bc.test_rf(fxvi4, 2, tnum++, "FXVI4F on, K8 on R", 1.0, 5.0, "Ohm");//pass
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "FXVI4F on, K8 on V1", 0.4, 0.6, "V");
	C_FPVIH_VST_DisConnect;
	C_FPVIL_AG_DisConnect;
	delay_ms(2);
	bc.test_if(fxvi4, vi, tnum++, "FXVI4F on, K8 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	
	//K9,K123,fxvi4f
	C_FPVIH_VS1_Connect;
	C_FPVIL_AG_Connect;
	cbitclose(K123);
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "FXVI4F on, K123 on, K9 on V0", -0.1, 0.1, "V");
	//bc.test_rf(fxvi4, 2, tnum++, "FXVI4F on, K123 on, K9 on R", 0.5, 5.0, "Ohm");
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "FXVI4F on, K123 on, K9 on V1", 0.4, 0.6, "V");
	C_FPVIH_VS1_DisConnect;
	C_FPVIL_AG_DisConnect;
	cbitopen(K123);
	delay_ms(2);
	bc.test_if(fxvi4, vi, tnum++, "FXVI4F on, K123 on, K9 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	
	//K10,K21
	C_FPVIH_RSH_Connect;
	C_FPVIL_AG_Connect;
	cbitclose(K101);
	cbitclose(K21);
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K21 on, K10 on V0", -0.1, 0.1, "V");
	//bc.test_r(fxvi0, 2, tnum++, "K21 on, K10 on R", 5.0, 15.0, "Ohm");
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K21 on, K10 on V1", 0.4, 0.6, "V");
	C_FPVIH_RSH_DisConnect;
	C_FPVIL_AG_DisConnect;
	cbitopen(K21);
	cbitopen(K101);
	delay_ms(2);
	bc.test_i(fxvi0, vi, tnum++, "K21 on, K10 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	
	//K11,K5
	C_FPVIH_POSIN_Connect;
	C_FPVIL_POSG_Connect;
	C_POSG_GND_Connect;
	delay_ms(2);
	bc.force_v(A_POSIN, 0, true);
	delay_ms(2);
	bc.test_v(fpvi0, tnum++, "K5 on, K11 on V0", -0.1, 0.1, "V");
	//bc.test_r(fpvi0, 2, tnum++, "K5 on, K11 on R", 0.5, 8.0, "Ohm");
	bc.force_v(A_POSIN, 0.5, true);
	delay_ms(2);
	bc.test_v(fpvi0, tnum++, "K5 on, K11 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_POSG_DisConnect;
	C_POSG_GND_DisConnect;
	delay_ms(2);
	bc.test_i(fpvi0, vi, tnum++, "K5 on, K11 off", -0.1, 0.1, "A");
	bc.force_v(A_POSIN, 0, false);
	
	//K12,K5
	C_FPVIH_POSIN_Connect;
	C_FPVIL_POSSW_Connect;
	delay_ms(2);
	bc.force_v(acm5, 0, true);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(acm6, tnum++, "K5 on, K12 on V0", -0.1, 0.1, "V");
	//bc.test_r(acm6, 2, tnum++, "K5 on, K12 on R", 1.0, 8.0, "Ohm");//
	bc.force_v(fpvi0, -0.5, true);
	delay_ms(2);
	bc.test_v(acm6, tnum++, "K5 on, K12 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_POSSW_DisConnect;
	delay_ms(2);
	bc.test_i(acm6, vi, tnum++, "K5 on, K12 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	bc.force_v(acm5, 0, false);
	
	//K13,K213,K5,need cbitB
	C_FPVIH_POSIN_Connect;
	C_FPVIL_FB_Connect;
	cbitclose(K213);//ACM to FB
	delay_ms(2);
	bc.force_v(A_POSIN, 0, true);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(A_FB1, tnum++, "K213 on, K5 on, K13 on V0", -0.1, 0.1, "V");
	//bc.test_r(A_FB1, 2, tnum++, "K213 on, K5 on, K13 on R", 0.5, 15.0, "Ohm");
	bc.force_v(fpvi0, -0.5, true);
	delay_ms(2);
	bc.test_v(A_FB1, tnum++, "K213 on, K5 on, K13 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_FB_DisConnect;
	cbitopen(K213);
	delay_ms(2);
	bc.test_i(A_FB1, vi, tnum++, "K213 on, K5 on, K13 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	bc.force_v(A_POSIN, 0, false);
	
	//K14,K5
	C_FPVIH_POSIN_Connect;
	C_FPVIL_PG_Connect;
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(A_POSIN, tnum++, "K5 on, K14 on V0", -0.1, 0.1, "V");
	//bc.test_r(A_POSIN, 2, tnum++, "K5 on, K14 on R", 0.5, 8.0, "Ohm");
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(A_POSIN, tnum++, "K5 on, K14 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_PG_DisConnect;
	delay_ms(2);
	bc.test_i(A_POSIN, vi, tnum++, "K5 on, K14 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	
	//K15,K20,K5
	C_FPVIH_POSIN_Connect;
	C_FPVIL_SW_Connect;
	cbitclose(K20);
	delay_ms(2);
	bc.force_v(acm5, 0, true);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K20 on, K5 on, K15 on V0", -0.1, 0.1, "V");
	//bc.test_r(fxvi0, 2, tnum++, "K20 on, K5 on, K15 on R", 1.0, 8.0, "Ohm");//
	bc.force_v(fpvi0, -0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K20 on, K5 on, K15 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_SW_DisConnect;
	cbitopen(K20);
	delay_ms(2);
	bc.test_i(fxvi0, vi, tnum++, "K20 on, K5 on, K15 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	bc.force_v(acm5, 0, false);
	
	//K16,K22,K5,K101
	C_FPVIH_POSIN_Connect;
	C_FPVIL_RSL_Connect;
	cbitclose(K101);
	cbitclose(K22);
	delay_ms(2);
	bc.force_v(acm5, 0, true);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K101 on, K22 on, K5 on, K16 on V0", -0.1, 0.1, "V");
	//bc.test_r(fxvi0, 2, tnum++, "K101 on, K22 on, K5 on, K16 on R", 1.0, 15.0, "Ohm");
	bc.force_v(fpvi0, -0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K101 on, K22 on, K5 on, K16 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_RSL_DisConnect;
	cbitopen(K22);
	cbitopen(K101);
	delay_ms(2);
	bc.test_i(fxvi0, vi, tnum++, "K101 on, K22 on, K5 on, K16 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	bc.force_v(acm5, 0, false);
	
	//K17,K56,K5,FXVI5F
	C_FPVIH_POSIN_Connect;
	C_FPVIL_BSG_Connect;
	cbitopen(K144);//BSG to AG
	delay_ms(2);
	cbitclose(K56);
	delay_ms(2);
	bc.force_v(acm5, 0, true);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "FXVI5F on, K56 on, K5 on, K17 on V0", -0.1, 0.1, "V");
	//bc.test_rf(fxvi5, 2, tnum++, "FXVI5F on, K56 on, K5 on, K17 on R", 1.0, 8.0, "Ohm");//
	bc.force_v(fpvi0, -0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "FXVI5F on, K56 on, K5 on, K17 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_BSG_DisConnect;
	cbitopen(K56);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "FXVI5F on, K56 on, K5 on, K17 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);
	bc.force_v(acm5, 0, false);
	cbitclose(K144);//BSG to AG
	delay_ms(2);
	
	//K18,K5
	C_FPVIH_POSIN_Connect;
	C_FPVIL_AG_Connect;
	delay_ms(2);
	bc.force_v(fpvi0, 0, true);
	delay_ms(2);
	bc.test_v(A_POSIN, tnum++, "K5 on, K18 on V0", -0.1, 0.1, "V");
	//bc.test_r(A_POSIN, 2, tnum++, "K5 on, K18 on R", 0.5, 15.0, "Ohm");
	bc.force_v(fpvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(A_POSIN, tnum++, "K5 on, K18 on V1", 0.4, 0.6, "V");
	C_FPVIH_POSIN_DisConnect;
	C_FPVIL_AG_DisConnect;
	delay_ms(2);
	bc.test_i(A_POSIN, vi, tnum++, "K5 on, K18 off", -0.1, 0.1, "A");
	bc.force_v(fpvi0, 0, false);

	//////////////////////////////////FXVI//////////////////////////////////
	////K19,K213?
	//cbitclose(K19,K213);
	//delay_ms(2);
	//bc.force_v(fxvi0, 0, true);
	//delay_ms(2);
	//bc.test_v(acm11, tnum++, "K213 on, K19 on", -0.1, 0.1, "V");
	//bc.test_r(acm11, 2, tnum++, "K213 on, K19 on", 1.0, 10.0, "Ohm");
	//bc.force_v(fxvi0, 0.5, true);
	//delay_ms(2);
	//bc.test_v(fxvi0, tnum++, "K213 on, K19 on", 0.4, 0.6, "V");
	//cbitopen(K19,K213);
	//delay_ms(2);
	//bc.test_v(acm11, tnum++, "K213 on, K19 on", -0.1, 0.1, "V");
	//bc.test_i(acm11, vi, tnum++, "K213 on, K19 off", -0.1, 0.1, "A");
	//bc.force_v(fxvi0, 0, false);

	////K20,tested

	//////K21,K213
	////cbitclose(K21,K213);
	////delay_ms(2);
	////bc.force_v(acm11, 0, true);
	////delay_ms(2);
	////bc.test_v(fxvi0, tnum++, "K213 on, K21 on", -0.1, 0.1, "V");
	////bc.test_r(fxvi0, 2, tnum++, "K213 on, K21 on", 1.0, 10.0, "Ohm");
	////bc.force_v(acm11, 0.5, true);
	////delay_ms(2);
	////bc.test_v(fxvi0, tnum++, "K213 on, K21 on", 0.4, 0.6, "V");
	////cbitopen(K21,K213);
	////delay_ms(2);
	////bc.test_v(fxvi0, tnum++, "K213 on, K21 on", -0.1, 0.1, "V");
	////bc.test_i(fxvi0, vi, tnum++, "K213 on, K21 off", -0.1, 0.1, "A");
	////bc.force_v(acm11, 0, false);

	//////K22,K213
	////cbitclose(K21,K213);
	////delay_ms(2);
	////bc.force_v(acm11, 0, true);
	////delay_ms(2);
	////bc.test_v(fxvi0, tnum++, "K213 on, K21 on", -0.1, 0.1, "V");
	////bc.test_r(fxvi0, 2, tnum++, "K213 on, K21 on", 1.0, 10.0, "Ohm");
	////bc.force_v(acm11, 0.5, true);
	////delay_ms(2);
	////bc.test_v(fxvi0, tnum++, "K213 on, K21 on", 0.4, 0.6, "V");
	////cbitopen(K21,K213);
	////delay_ms(2);
	////bc.test_v(fxvi0, tnum++, "K213 on, K21 on", -0.1, 0.1, "V");
	////bc.test_i(fxvi0, vi, tnum++, "K213 on, K21 off", -0.1, 0.1, "A");
	////bc.force_v(acm11, 0, false);

	//K30,K106,ENA
	cbitclose(K30,K106);
	delay_ms(2);
	bc.force_v(dcm, "D7", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K106 on, K30 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K106 on, K30 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D7", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K106 on, K30 on V2", 0.4, 0.6, "V");
	cbitopen(K30, K106);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K106 off, K30 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D7", 0, false);

	//K31,K107
	cbitclose(K31,K107);
	delay_ms(2);
	bc.force_v(dcm, "D6", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K107 on, K31 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K107 on, K31 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D6", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K107 on, K31 on V2", 0.4, 0.6, "V");
	cbitopen(K31,K107);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K107 off, K31 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D6", 0, false);
	
	//K32,K113
	cbitclose(K32,K113);
	delay_ms(2);
	bc.force_v(dcm, "D5", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K113 on, K32 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K107 on, K32 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D5", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K113 on, K32 on V2", 0.4, 0.6, "V");
	cbitopen(K32,K113);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K113 off, K32 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D5", 0, false);
	
	//K33,K114
	cbitclose(K33,K114);
	delay_ms(2);
	bc.force_v(dcm, "D4", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K114 on, K33 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K114 on, K33 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D4", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K114 on, K33 on V2", 0.4, 0.6, "V");
	cbitopen(K33,K114);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K114 off, K33 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D4", 0, false);
	
	//K34
	cbitclose(K34);
	delay_ms(2);
	bc.force_v(dcm, "SDI", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K34 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K34 on R", 10.0, 20.0, "Ohm");
	bc.force_v(dcm, "SDI", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K34 on V2", 0.4, 0.6, "V");
	cbitopen(K34);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K34 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "SDI", 0, false);
	
	//K35
	cbitclose(K35);
	delay_ms(2);
	bc.force_v(dcm, "SDO", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K35 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K35 on R", 10.0, 20.0, "Ohm");
	bc.force_v(dcm, "SDO", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K35 on V2", 0.4, 0.6, "V");
	cbitopen(K35);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K35 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "SDO", 0, false);
	
	//K36
	cbitclose(K36);
	delay_ms(2);
	bc.force_v(dcm, "SCK", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K36 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K36 on R", 10.0, 20.0, "Ohm");
	bc.force_v(dcm, "SCK", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K36 on V2", 0.4, 0.6, "V");
	cbitopen(K36);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K36 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "SCK", 0, false);
	
	//K37
	cbitclose(K37);
	delay_ms(2);
	bc.force_v(dcm, "CS", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K37 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K37 on R", 10.0, 20.0, "Ohm");
	bc.force_v(dcm, "CS", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K37 on V2", 0.4, 0.6, "V");
	cbitopen(K37);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K37 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "CS", 0, false);
	
	//K38,K108
	cbitclose(K38,K108);
	delay_ms(2);
	bc.force_v(dcm, "D6", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K108 on, K38 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K108 on, K38 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D6", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K108 on, K38 on V2", 0.4, 0.6, "V");
	cbitopen(K38,K108);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K108 off, K38 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D6", 0, false);
	
	//K39,K111
	cbitclose(K39,K111);
	delay_ms(2);
	bc.force_v(dcm, "D5", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K111 on, K39 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K111 on, K39 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D5", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K111 on, K39 on V2", 0.4, 0.6, "V");
	cbitopen(K39,K111);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K111 off, K39 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D5", 0, false);
	
	//K40,K112
	cbitclose(K40,K112);
	delay_ms(2);
	bc.force_v(dcm, "D5", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K112 on, K40 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K112 on, K40 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D5", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K112 on, K40 on V2", 0.4, 0.6, "V");
	cbitopen(K40,K112);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K112 off, K40 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D5", 0, false);
	
	//K41,K105
	cbitclose(K41,K105);
	delay_ms(2);
	bc.force_v(dcm, "D6", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K105 on, K41 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K105 on, K41 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D6", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K105 on, K41 on V2", 0.4, 0.6, "V");
	cbitopen(K41, K105);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K105 off, K41 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D6", 0, false);

	//K42,K115
	cbitclose(K42,K115);
	delay_ms(2);
	bc.force_v(dcm, "D4", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K115 on, K42 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K115 on, K42 on R", 10.0, 20.0, "Ohm");
	bc.force_v(dcm, "D4", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K115 on, K42 on V2", 0.4, 0.6, "V");
	cbitopen(K42,K115);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K115 off, K42 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D4", 0, false);
	
	//K43,K99
	cbitclose(K43,K99);
	delay_ms(2);
	bc.force_v(dcm, "D7", 0, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K99 on, K43 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi5, 2, tnum++, "K99 on, K43 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D7", 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi5, tnum++, "K99 on, K43 on V2", 0.4, 0.6, "V");
	cbitopen(K43,K99);
	delay_ms(2);
	bc.test_i(fxvi5, vi, tnum++, "K99 off, K43 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D7", 0, false);
	
	//K50,K131
	cbitclose(K50,K131);
	delay_ms(2);
	bc.force_v(fxvi4, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K50 on, K131 on V0", -0.1, 0.1, "V");
	//bc.test_rf(fxvi5, 2, tnum++, "K50 on, K131 on R", 5.0, 15.0, "Ohm");
	bc.force_v(fxvi4, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K50 on, K131 on V1", 0.4, 0.6, "V");
	cbitopen(K50,K131);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "K50 off, K131 off", -0.1, 0.1, "A");
	bc.force_v(fxvi4, 0, false);
	
	//K51,K132
	cbitclose(K51, K132);
	delay_ms(2);
	bc.force_v(fxvi4, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K51 on, K132 on V0", -0.1, 0.1, "V");
	//bc.test_rf(fxvi5, 2, tnum++, "K51 on, K132 on R", 5.0, 15.0, "Ohm");
	bc.force_v(fxvi4, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K51 on, K132 on V1", 0.4, 0.6, "V");
	cbitopen(K51, K132);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "K51 off, K132 off", -0.1, 0.1, "A");
	bc.force_v(fxvi4, 0, false);
	
	//K52,K168
	cbitclose(K52,K168);
	delay_ms(2);
	bc.force_v(fxvi2, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K168 on, K52 on V0", -0.1, 0.1, "V");
	//bc.test_rf(fxvi5, 2, tnum++, "K168 on, K52 on R", 5.0, 15.0, "Ohm");
	bc.force_v(fxvi2, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K168 on, K52 on V1", 0.4, 0.6, "V");
	cbitopen(K52,K168);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "K168 off, K52 off", -0.1, 0.1, "A");
	bc.force_v(fxvi2, 0, false);
	
	//K53,K166
	cbitclose(K53,K166);
	delay_ms(2);
	bc.force_v(fxvi1, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K166 on, K53 on V0", -0.1, 0.1, "V");
	//bc.test_rf(fxvi5, 2, tnum++, "K166 on, K53 on R", 1.0, 15.0, "Ohm");
	bc.force_v(fxvi1, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K166 on, K53 on V1", 0.4, 0.6, "V");
	cbitopen(K53,K166);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "K166 off, K53 off", -0.1, 0.1, "A");
	bc.force_v(fxvi1, 0, false);
	
	//K54,K151,K20
	cbitclose(K54,K151,K20);
	delay_ms(2);
	bc.force_v(fxvi0, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K20 on, K151 on, K54 on V0", -0.1, 0.1, "V");
	bc.test_rf(fxvi5, 2, tnum++, "K20 on, K151 on, K54 on R", 0.5, 5.0, "Ohm");
	bc.force_v(fxvi0, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K20 on, K151 on, K54 on V1", 0.4, 0.6, "V");
	cbitopen(K54, K151, K20);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "K20 off, K151 off, K54 off", -0.1, 0.1, "A");
	bc.force_v(fxvi0, 0, false);
	
	//K55,K130
	cbitclose(K55,K130);
	delay_ms(2);
	bc.force_v(fxvi4, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K130 on, K55 on V0", -0.1, 0.1, "V");
	bc.test_rf(fxvi5, 2, tnum++, "K130 on, K55 on R", 0.5, 5.0, "Ohm");
	bc.force_v(fxvi4, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K130 on, K55 on V1", 0.4, 0.6, "V");
	cbitopen(K55,K130);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "K130 off, K55 off", -0.1, 0.1, "A");
	bc.force_v(fxvi4, 0, false);
	
	//K56,tested
	
	//K57
	cbitclose(K57);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K57 on V0", -0.1, 0.1, "V");
	bc.test_rf(fxvi5, 2, tnum++, "K57 on R", 1.0, 10.0, "Ohm");
	cbitopen(K57);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "K57 off", -0.1, 0.1, "A");

	//K58 NA
	//K59 NA
	
	//K60,K22
	cbitclose(K60,K22);
	delay_ms(2);
	bc.force_v(fxvi0, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K22 on, K60 on V0", -0.1, 0.1, "V");
	bc.test_rf(fxvi5, 2, tnum++, "K22 on, K60 on R", 0.5, 5.0, "Ohm");
	bc.force_v(fxvi0, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K22 on, K60 on V1", 0.4, 0.6, "V");
	cbitopen(K60,K22);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "K22 off, K60 off", -0.1, 0.1, "A");
	bc.force_v(fxvi0, 0, false);

	//K61 NA
	
	//K62,K64,K180
	cbitclose(K62,K64,K180);
	delay_ms(2);
	bc.force_v(acm9, 0, true);
	delay_ms(2);
	bc.test_v(acm8, tnum++, "K180 on, K64 on, K62 on V0", -0.1, 0.1, "V");
	//bc.test_r(acm8, 2, tnum++, "K180 on, K64 on, K62 on R", 40.0, 80.0, "Ohm");
	bc.force_v(acm9, 0.5, true);
	delay_ms(2);
	bc.test_v(acm8, tnum++, "K180 on, K64 on, K62 on V1", 0.4, 0.6, "V");
	cbitopen(K62,K64,K180);
	delay_ms(2);
	bc.test_i(acm8, vi, tnum++, "K180 off, K64 off, K62 off", -0.1, 0.1, "A");
	bc.force_v(acm9, 0, false);
	
	//K62,K77,K180
	cbitclose(K62,K77,K180);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(acm8, tnum++, "K180 on, K77 on, K62 on V0", -0.1, 0.1, "V");
	//bc.test_r(acm8, 2, tnum++, "K180 on, K77 on, K62 on R", 40.0, 80.0, "Ohm");
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(acm8, tnum++, "K180 on, K77 on, K62 on V1", 0.4, 0.6, "V");
	cbitopen(K62,K77,K180);
	delay_ms(2);
	bc.test_i(acm8, vi, tnum++, "K180 K77, K64 off, K62 off", -0.1, 0.1, "A");
	bc.force_v(acm1, 0, false);

	//K63,K77,K173
	cbitclose(K63,K77,K173);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(acm9, tnum++, "K173 on, K77 on, K63 on V0", -0.1, 0.1, "V");
	bc.test_r(acm9, 2, tnum++, "K173 on, K77 on, K63 on R", 40.0, 80.0, "Ohm");
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(acm9, tnum++, "K173 on, K77 on, K63 on V1", 0.4, 0.6, "V");
	cbitopen(K63,K77,K173);
	delay_ms(2);
	bc.test_i(acm9, vi, tnum++, "K173 K77, K64 off, K63 off", -0.1, 0.1, "A");
	bc.force_v(acm1, 0, false);

	//K65,K77,K172
	cbitclose(K65,K77,K172);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(acm9, tnum++, "K172 on, K77 on, K65 on V0", -0.1, 0.1, "V");
	bc.test_r(acm9, 2, tnum++, "K172 on, K77 on, K65 on R", 40.0, 80.0, "Ohm");
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(acm9, tnum++, "K172 on, K77 on, K65 on V1", 0.4, 0.6, "V");
	cbitopen(K65,K77,K172);
	delay_ms(2);
	bc.test_i(acm9, vi, tnum++, "K172 K77, K64 off, K65 off", -0.1, 0.1, "A");
	bc.force_v(acm1, 0, false);

	//K70,K65
	cbitclose(K65,K70);
	delay_ms(2);
	bc.force_v(acm9, 0, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K70 on, K65 on V0", -0.1, 0.1, "V");
	bc.test_r(acm10, 2, tnum++, "K70 on, K65 on R", 1.0, 10.0, "Ohm");
	bc.force_v(acm9, 0.5, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K70 on, K65 on V1", 0.4, 0.6, "V");
	cbitopen(K65, K70);
	delay_ms(2);
	bc.test_i(acm10, vi, tnum++, "K70 off, K65 off", -0.1, 0.1, "A");
	bc.force_v(acm9, 0, false);

	//K71,K63
	cbitclose(K71,K63);
	delay_ms(2);
	bc.force_v(acm9, 0, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K71 on, K63 on V0", -0.1, 0.1, "V");
	bc.test_r(acm10, 2, tnum++, "K71 on, K63 on R", 1.0, 10.0, "Ohm");
	bc.force_v(acm9, 0.5, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K71 on, K63 on V1", 0.4, 0.6, "V");
	cbitopen(K71,K63);
	delay_ms(2);
	bc.test_i(acm10, vi, tnum++, "K71 off, K63 off", -0.1, 0.1, "A");
	bc.force_v(acm9, 0, false);

	//K72 NA

	//K73,K77,K177
	cbitclose(K73,K77,K177);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K177 on, K77 on, K73 on V0", -0.1, 0.1, "V");
	bc.test_r(acm10, 2, tnum++, "K177 on, K77 on, K73 on R", 40.0, 60.0, "Ohm");
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K177 on, K77 on, K73 on V1", 0.4, 0.6, "V");
	cbitopen(K73,K77,K177);
	delay_ms(2);
	bc.test_i(acm10, vi, tnum++, "K177 off, K77 off, K73 off", -0.1, 0.1, "A");
	bc.force_v(acm1, 0, false);
	
	//K74,K79
	cbitclose(K74,K79);
	delay_ms(2);
	bc.force_v(dcm, "D5", 0, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K74 on, K79 on V0", -0.1, 0.1, "V");
	bc.test_r(acm10, 2, tnum++, "K74 on, K79 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D5", 0.5, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K74 on, K79 on V1", 0.4, 0.6, "V");
	cbitopen(K74,K79);
	delay_ms(2);
	bc.test_i(acm10, vi, tnum++, "K74 off, K79 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D5", 0, false);

	//K75
	cbitclose(K75);
	delay_ms(2);
	bc.test_d(acm10, 2, tnum++, "K75 on D", -0.9, -0.3, "V");
	cbitopen(K75);
	delay_ms(2);
	bc.test_i(acm10, vi, tnum++, "K75 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D5", 0, false);
	
	//K76
	cbitclose(K76);
	delay_ms(2);
	bc.test_v(dcm, "DCM6", tnum++, "K76 on V", 4.8, 5.2, "V");
	cbitopen(K76);
	delay_ms(2);
	bc.test_i(dcm, "DCM6", vi, tnum++, "K76 off", -0.1, 0.1, "A");
	
	//K78,K110
	cbitclose(K78,K110);
	delay_ms(2);
	bc.force_v(dcm, "D5", 0, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K78 on, K110 on V0", -0.1, 0.1, "V");
	bc.test_r(acm1, 2, tnum++, "K78 on, K110 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D5", 0.5, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K78 on, K110 on V1", 0.4, 0.6, "V");
	cbitopen(K78,K110);
	delay_ms(2);
	bc.test_i(acm1, vi, tnum++, "K78 off, K110 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D5", 0, false);
	
	//K80
	cbitclose(K80);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K80 on V", 4.8, 5.2, "V");
	cbitopen(K80);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K80 off", -0.1, 0.1, "A");
	
	//K154,K19,K214
	cbitclose(K154,K19,K214);
	delay_ms(2);
	bc.force_v(acm11, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K154 on, K19 on, K214 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi0, 2, tnum++, "K154 on, K19 on, K214 on R", 1.0, 10.0, "Ohm");
	bc.force_v(acm11, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K154 on, K19 on, K214 on V1", 0.4, 0.6, "V");
	cbitopen(K154,K19,K214);
	delay_ms(2);
	bc.test_i(fxvi0, vi, tnum++, "K154 off, K19 off, K214 off", -0.1, 0.1, "A");
	bc.force_v(acm11, 0, false);
	
	//K155,K19,K215
	cbitclose(K155,K19,K215);
	delay_ms(2);
	bc.force_v(acm11, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K155 on, K19 on, K215 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi0, 2, tnum++, "K155 on, K19 on, K215 on R", 1.0, 10.0, "Ohm");
	bc.force_v(acm11, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K155 on, K19 on, K215 on V1", 0.4, 0.6, "V");
	cbitopen(K155,K19,K215);
	delay_ms(2);
	bc.test_i(fxvi0, vi, tnum++, "K155 off, K19 off, K215 off", -0.1, 0.1, "A");
	bc.force_v(acm11, 0, false);
	
	//K156,K19,K216
	cbitclose(K156,K19,K216);
	delay_ms(2);
	bc.force_v(acm11, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K156 on, K19 on, K216 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi0, 2, tnum++, "K156 on, K19 on, K216 on R", 1.0, 10.0, "Ohm");
	bc.force_v(acm11, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K156 on, K19 on, K216 on V1", 0.4, 0.6, "V");
	cbitopen(K156,K19,K216);
	delay_ms(2);
	bc.test_i(fxvi0, vi, tnum++, "K156 off, K19 off, K216 off", -0.1, 0.1, "A");
	bc.force_v(acm11, 0, false);
	
	//K157,K19
	cbitclose(K157,K19);
	delay_ms(2);
	bc.force_v(acm5, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K157 on, K19 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi0, 2, tnum++, "K157 on, K19 on R", 0.1, 5.0, "Ohm");
	bc.force_v(acm5, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K157 on, K19 on V1", 0.4, 0.6, "V");
	cbitopen(K157,K19);
	delay_ms(2);
	bc.test_i(fxvi0, vi, tnum++, "K157 off, K19 off", -0.1, 0.1, "A");
	bc.force_v(acm5, 0, false);
	
	//K160,K218
	cbitclose(K160,K218);
	delay_ms(2);
	bc.force_v(acm11, 0, true);
	delay_ms(2);
	bc.test_v(acm2, tnum++, "K160 on, K218 on V0", -0.1, 0.1, "V");
	bc.test_r(acm2, 2, tnum++, "K160 on, K218 on R", 1.0, 15.0, "Ohm");
	bc.force_v(acm11, 0.5, true);
	delay_ms(2);
	bc.test_v(acm2, tnum++, "K160 on, K218 on V1", 0.4, 0.6, "V");
	cbitopen(K160,K218);
	delay_ms(2);
	bc.test_i(acm2, vi, tnum++, "K160 off, K218 off", -0.1, 0.1, "A");
	bc.force_v(acm11, 0, false);
	
	////K166,K53,tested
	//cbitclose(K166,K53);
	//delay_ms(2);
	//bc.force_vf(fxvi5, 0, true);
	//delay_ms(2);
	//bc.test_v(fxvi1, tnum++, "K166 on, K53 on V0", -0.1, 0.1, "V");
	//bc.test_r(fxvi1, 2, tnum++, "K166 on, K53 on R", 5.0, 15.0, "Ohm");
	//bc.force_vf(fxvi5, 0.5, true);
	//delay_ms(2);
	//bc.test_v(fxvi1, tnum++, "K166 on, K53 on V1", 0.4, 0.6, "V");
	//cbitopen(K166,K53);
	//delay_ms(2);
	//bc.test_i(fxvi1, vi, tnum++, "K166 off, K53 off", -0.1, 0.1, "A");
	//bc.force_vf(fxvi5, 0, false);
	
	////K168,K52,tested
	//cbitclose(K168,K52);
	//delay_ms(2);
	//bc.force_vf(fxvi5, 0, true);
	//delay_ms(2);
	//bc.test_v(fxvi2, tnum++, "K168 on, K52 on V0", -0.1, 0.1, "V");
	//bc.test_r(fxvi2, 2, tnum++, "K168 on, K52 on R", 5.0, 15.0, "Ohm");
	//bc.force_vf(fxvi5, 0.5, true);
	//delay_ms(2);
	//bc.test_v(fxvi2, tnum++, "K168 on, K52 on V1", 0.4, 0.6, "V");
	//cbitopen(K168,K52);
	//delay_ms(2);
	//bc.test_i(fxvi2, vi, tnum++, "K168 off, K52 off", -0.1, 0.1, "A");
	//bc.force_vf(fxvi5, 0, false);

	////////////////QVM/////////////
	//result[SITE_NUM];
	//qvm0.Connect();

	////K81 NA
	////K82 NA
	////K83 NA
	////K84 NA
	//qvm.MeasureLADC(100, 10, QVMe_LADC_5V, QVMe_LADC_10KHz, MEAS_NORMAL);

	//result[0] = qvm0.GetMeasResult(0, AVERAGE_RESULT);
	//result[1] = qvm1.GetMeasResult(1, AVERAGE_RESULT);
	//result[2] = qvm2.GetMeasResult(2, AVERAGE_RESULT);
	//result[3] = qvm3.GetMeasResult(3, AVERAGE_RESULT);
	////K85,K115,K116,K91
	//cbitclose(K85,K115,K116,K91);
	//delay_ms(2);
	//bc.force_v(dcm, "DCM4", 0, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K85 on, K115 on, K116 on V0", -0.1, 0.1, "V");
	//bc.force_v(dcm, "DCM4", 0.5, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K85 on, K115 on, K116 on V1", 0.4, 0.6, "V");
	//bc.force_v(dcm, "DCM4", 0, false);
	//cbitopen(K85,K115,K116,K91);
	//delay_ms(2);
	
	////K86,K77,K91
	//cbitclose(K86,K77,K91);
	//delay_ms(2);
	//bc.force_v(acm1, 0, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K86 on, K77 on", -0.1, 0.1, "V");
	//bc.force_v(acm1, 0.5, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K86 on, K77 on", 0.4, 0.6, "V");
	//cbitopen(K86,K77,K91);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K86 off, K77 off", -0.1, 0.1, "V");
	//bc.force_v(acm1, 0, false);

	////K87,K78,K91
	//cbitclose(K87,K78,K91);
	//delay_ms(2);
	//bc.force_v(acm1, 0, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K87 on, K78 on", -0.1, 0.1, "V");
	//bc.force_v(acm1, 0.5, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K87 on, K78 on", 0.4, 0.6, "V");
	//cbitopen(K87,K78,K91);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K87 off, K78 off", -0.1, 0.1, "V");
	//bc.force_v(acm1, 0, false);

	////K88 NA

	////K89,K21,K91
	//cbitclose(K89,K21,K91);
	//delay_ms(2);
	//bc.force_v(fxvi0, 0, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K89 on, K21 on", -0.1, 0.1, "V");
	//bc.force_v(fxvi0, 0.5, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K89 on, K21 on", 0.4, 0.6, "V");
	//cbitopen(K89,K21,K91);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K89 off, K21 off", -0.1, 0.1, "V");
	//bc.force_v(fxvi0, 0, false);
	//
	////K89,K21,K90,K60
	//cbitclose(K89,K21,K90,K60);
	//delay_ms(2);
	//bc.force_vf(fxvi5, 0, true);
	//bc.force_v(fxvi0, 0, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K89 on, K90 on", -0.1, 0.1, "V");
	//bc.force_v(fxvi0, 0.5, true);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K89 on, K90 on", 0.4, 0.6, "V");
	//cbitopen(K89,K21,K90,K60);
	//delay_ms(2);
	//bc.test_v(qvm0, tnum++, "K89 off, K90 off", -0.1, 0.1, "V");
	//bc.force_v(fxvi0, 0, false);
	//bc.force_vf(fxvi5, 0, false);

	//////////////////Connection/////////////
	//K92 NA
	//K93 NA
	//K94 NA
	//K95 NA
	
	//K124,K63
	cbitclose(K124,K63);
	delay_ms(2);
	bc.force_v(acm9, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "K124 on, K63 on V0", -0.1, 0.1, "V");
	bc.test_rf(fxvi4, 2, tnum++, "K124 on, K63 on R", 1.0, 15.0, "Ohm");
	bc.force_v(acm9, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "K124 on, K63 on V1", 0.4, 0.6, "V");
	cbitopen(K124,K63);
	delay_ms(2);
	bc.test_if(fxvi4, vi, tnum++, "K124 off, K63 off", -0.1, 0.1, "A");
	bc.force_v(acm9, 0, false);
	
	//K125,K65
	cbitclose(K125,K65);
	delay_ms(2);
	bc.force_v(acm9, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "K125 on, K65 on V0", -0.1, 0.1, "V");
	bc.test_rf(fxvi4, 2, tnum++, "K125 on, K65 on R", 1.0, 15.0, "Ohm");
	bc.force_v(acm9, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "K125 on, K65 on V1", 0.4, 0.6, "V");
	cbitopen(K125,K65);
	delay_ms(2);
	bc.test_if(fxvi4, vi, tnum++, "K125 off, K65 off", -0.1, 0.1, "A");
	bc.force_v(acm9, 0, false);
	
	////K130,K55,tested
	//cbitclose(K130,K55);
	//delay_ms(2);
	//bc.force_vf(fxvi5, 0, true);
	//delay_ms(2);
	//bc.test_v(fxvi4, tnum++, "K130 on, K55 on V0", -0.1, 0.1, "V");
	//bc.test_r(fxvi4, 2, tnum++, "K130 on, K55 on R", 0.5, 5.0, "Ohm");
	//bc.force_vf(fxvi5, 0.5, true);
	//delay_ms(2);
	//bc.test_v(fxvi4, tnum++, "K130 on, K55 on V1", 0.4, 0.6, "V");
	//cbitopen(K130,K55);
	//delay_ms(2);
	//bc.test_i(fxvi4, vi, tnum++, "K130 off, K55 off", -0.1, 0.1, "A");
	//bc.force_vf(fxvi5, 0, false);

	//K131,K50
	cbitclose(K131,K50);
	delay_ms(2);
	bc.force_vf(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(fxvi4, tnum++, "K131 on, K50 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi4, 2, tnum++, "K131 on, K50 on R", 1.0, 15.0, "Ohm");
	bc.force_vf(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi4, tnum++, "K131 on, K50 on V1", 0.4, 0.6, "V");
	cbitopen(K131,K50);
	delay_ms(2);
	bc.test_i(fxvi4, vi, tnum++, "K131 off, K50 off", -0.1, 0.1, "A");
	bc.force_vf(fxvi5, 0, false);
	
	//K132,K51
	cbitclose(K132,K51);
	delay_ms(2);
	bc.force_vf(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(fxvi4, tnum++, "K132 on, K51 on V0", -0.1, 0.1, "V");
	bc.test_r(fxvi4, 2, tnum++, "K132 on, K51 on R", 1.0, 15.0, "Ohm");
	bc.force_vf(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi4, tnum++, "K132 on, K51 on V1", 0.4, 0.6, "V");
	cbitopen(K132,K51);
	delay_ms(2);
	bc.test_i(fxvi4, vi, tnum++, "K132 off, K51 off", -0.1, 0.1, "A");
	bc.force_vf(fxvi5, 0, false);

	//K133 NA
	//K134 NA

	////////////////////////////////////////////////////

	//K135,K60,R10
	cbitclose(K135,K60);
	delay_ms(2);
	bc.test_vf(fxvi5, tnum++, "K135 on, K60 on, R10 10Ohm", -0.1, 0.1, "V");
	bc.test_rf(fxvi5, 2, tnum++, "K135 on, K60 on, R10 100Ohm", 90.0, 120.0, "Ohm");
	cbitopen(K135,K60);
	delay_ms(2);
	bc.test_if(fxvi5, vi, tnum++, "K135 off, K60 off, R10 100Ohm", -0.1, 0.1, "A");
	
	//K136,K62,R11
	cbitclose(K136,K62);
	delay_ms(2);
	bc.test_v(acm8, tnum++, "K136 on, K62 on, R11 10Ohm", -0.1, 0.1, "V");
	bc.test_r(acm8, 2, tnum++, "K136 on, K62 on, R11 100Ohm", 90.0, 120.0, "Ohm");
	cbitopen(K136,K62);
	delay_ms(2);
	bc.test_i(acm8, vi, tnum++, "K136 off, K62 off, R11 100Ohm", -0.1, 0.1, "A");
	
	////K137,K103,R12
	//cbitclose(K137,K103);
	//delay_ms(2);
	//bc.test_v(dcm, "DCM7", tnum++, "K137 on, K103 on, R12 4.7kOhm", 4.9, 5.1, "V");
	//bc.test_r_up(5.0, dcm, "DCM7", 2, tnum++, "K137 on, K103 on, R12 4.7kOhm", 4.5, 5.0, "kOhm");//need to check
	//cbitopen(K137,K103);
	//delay_ms(2);
	//bc.test_i(dcm, "DCM7", vi, tnum++, "K137 off, K103 off, R12 4.7kOhm", -0.1, 0.1, "A");
	
	//K138,K103,R13
	cbitclose(K138,K103);
	delay_ms(2);
	bc.test_v(dcm, "DCM7", tnum++, "K138 on, K103 on, R13 100Ohm", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM7", 2, tnum++, "K138 on, K103 on, R13 100Ohm", 90.0, 120.0, "Ohm");
	cbitopen(K138,K103);
	delay_ms(2);
	bc.test_i(dcm, "DCM7", vi, tnum++, "K138 off, K103 off, R13 100Ohm", -0.1, 0.1, "A");
	
	//K139,K104,R14
	cbitclose(K139,K104);
	delay_ms(2);
	bc.test_v(dcm, "DCM6", tnum++, "K139 on, K104 on, R14 100Ohm", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM6", 2, tnum++, "K139 on, K104 on, R14 100Ohm", 90.0, 120.0, "Ohm");
	cbitopen(K139,K104);
	delay_ms(2);
	bc.test_i(dcm, "DCM6", vi, tnum++, "K139 off, K104 off, R14 100Ohm", -0.1, 0.1, "A");
	
	//K140,K105,R15
	cbitclose(K140,K105);
	delay_ms(2);
	bc.test_v(dcm, "DCM6", tnum++, "K140 on, K105 on, R15 100Ohm", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM6", 2, tnum++, "K140 on, K105 on, R15 100Ohm", 90.0, 120.0, "Ohm");
	cbitopen(K140,K105);
	delay_ms(2);
	bc.test_i(dcm, "DCM6", vi, tnum++, "K140 off, K105 off, R15 100Ohm", -0.1, 0.1, "A");
	
	////K141,K111,R29
	//cbitclose(K141,K111);
	//delay_ms(2);
	//bc.test_v(dcm, "DCM5", tnum++, "K141 on, K111 on, R29 4.7kOhm", 4.9, 5.1, "V");
	//bc.test_r_up(5.0, dcm, "DCM5", 2, tnum++, "K141 on, K111 on, R29 4.7kOhm", 4.5, 5.0, "kOhm");//need to check
	//cbitopen(K141,K111);
	//delay_ms(2);
	//bc.test_i(dcm, "DCM5", vi, tnum++, "K141 off, K111 off, R29 4.7kOhm", -0.1, 0.1, "A");
	
	//K142,K115,R30
	cbitclose(K142,K115);
	delay_ms(2);
	bc.test_v(dcm, "DCM4", tnum++, "K142 on, K115 on, R30 100Ohm", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM4", 2, tnum++, "K142 on, K115 on, R30 100Ohm", 90.0, 120.0, "Ohm");
	cbitopen(K142,K115);
	delay_ms(2);
	bc.test_i(dcm, "DCM4", vi, tnum++, "K142 off, K115 off, R30 100Ohm", -0.1, 0.1, "A");
	
	//K20,K150,R43
	cbitclose(K20,K150);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "K20 on, K150 on, R43 1kOhm", -0.1, 0.1, "V");
	bc.test_r(fxvi0, 2, tnum++, "K20 on, K150 on, R43 1kOhm", 0.8, 1.2, "kOhm");
	cbitopen(K20,K150);
	delay_ms(2);
	bc.test_i(fxvi0, vi, tnum++, "K20 off, K150 off, R43 1kOhm", -0.1, 0.1, "A");
	
	//K219,K162,R35
	cbitclose(K219,K162);
	delay_ms(2);
	bc.test_v(acm11, tnum++, "K219 on, K162 on, R35 100Ohm", -0.1, 0.1, "V");
	bc.test_r(acm11, 2, tnum++, "K219 on, K162 on, R35 100Ohm", 90.0, 120.0, "Ohm");
	cbitopen(K219,K162);
	delay_ms(2);
	bc.test_i(acm11, vi, tnum++, "K219 off, K162 off, R35 100Ohm", -0.1, 0.1, "A");
	
	////K219,K163,R44
	//cbitclose(K219,K163);
	//delay_ms(2);
	//bc.test_v(acm11, tnum++, "K219 on, K163 on, R44 4.7kOhm", 4.9, 5.1, "V");
	//bc.test_r(acm11, 2, tnum++, "K219 on, K163 on, R44 4.7kOhm", 4.5, 5.0, "kOhm");//need to check
	//cbitopen(K219,K163);
	//delay_ms(2);
	//bc.test_i(acm11, vi, tnum++, "K219 off, K163 off, R44 4.7kOhm", -0.1, 0.1, "A");


	//////////////////ABUF,DBUF//////////////////////////////
	
	//K171,K78,K64
	cbitclose(K171,K78,K64);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(acm9, tnum++, "K171 on, K78 on, K64 on V0", -0.1, 0.1, "V");
	//bc.test_r(acm9, 2, tnum++, "K171 on, K78 on, K64 on R", 50.0, 70.0, "Ohm");
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(acm9, tnum++, "K171 on, K78 on, K64 on V1", 0.4, 0.6, "V");
	cbitopen(K171,K78,K64);
	delay_ms(2);
	bc.test_i(acm9, vi, tnum++, "K171 off, K78 off, K64 off", -0.1, 0.1, "A");
	bc.force_v(acm1, 0, false);
	
	////K172,K77,K65,tested
	//cbitclose(K172,K77,K65);
	//delay_ms(2);
	//bc.force_v(acm9, 0, true);
	//delay_ms(2);
	//bc.test_v(acm1, tnum++, "K172 on, K77 on, K65 on V0", -0.1, 0.1, "V");
	//bc.test_r(acm1, 2, tnum++, "K172 on, K77 on, K65 on R", 1.0, 10.0, "Ohm");
	//bc.force_v(acm9, 0.5, true);
	//delay_ms(2);
	//bc.test_v(acm1, tnum++, "K172 on, K77 on, K65 on V1", 0.4, 0.6, "V");
	//cbitopen(K172,K77,K65);
	//delay_ms(2);
	//bc.test_i(acm1, vi, tnum++, "K172 off, K77 off, K65 off", -0.1, 0.1, "A");
	//bc.force_v(acm9, 0, false);
	
	////K173,K77,K63,tested
	//cbitclose(K173,K77,K63);
	//delay_ms(2);
	//bc.force_v(acm9, 0, true);
	//delay_ms(2);
	//bc.test_v(acm1, tnum++, "K173 on, K77 on, K63 on V0", -0.1, 0.1, "V");
	//bc.test_r(acm1, 2, tnum++, "K173 on, K77 on, K63 on R", 1.0, 10.0, "Ohm");
	//bc.force_v(acm9, 0.5, true);
	//delay_ms(2);
	//bc.test_v(acm1, tnum++, "K173 on, K77 on, K63 on V1", 0.4, 0.6, "V");
	//cbitopen(K173,K77,K63);
	//delay_ms(2);
	//bc.test_i(acm1, vi, tnum++, "K173 off, K77 off, K63 off", -0.1, 0.1, "A");
	//bc.force_v(acm9, 0, false);
	
	//K174,K77,K21
	cbitclose(K174,K77,K21);
	delay_ms(2);
	bc.force_v(fxvi0, 0, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K174 on, K77 on, K21 on V0", -0.1, 0.1, "V");
	bc.test_r(acm1, 2, tnum++, "K174 on, K77 on, K21 on R", 50.0, 70.0, "Ohm");
	bc.force_v(fxvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K174 on, K77 on, K21 on V1", 0.4, 0.6, "V");
	cbitopen(K174,K77,K21);
	delay_ms(2);
	bc.test_i(acm1, vi, tnum++, "K174 off, K77 off, K21 off", -0.1, 0.1, "A");
	bc.force_v(fxvi0, 0, false);
	
	//K175,K77,K20
	cbitclose(K175,K77,K20);
	delay_ms(2);
	bc.force_v(fxvi0, 0, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K175 on, K77 on, K20 on V0", -0.1, 0.1, "V");
	bc.test_r(acm1, 2, tnum++, "K175 on, K77 on, K20 on R", 40.0, 60.0, "Ohm");
	bc.force_v(fxvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K175 on, K77 on, K20 on V1", 0.4, 0.6, "V");
	cbitopen(K175,K77,K20);
	delay_ms(2);
	bc.test_i(acm1, vi, tnum++, "K175 off, K77 off, K20 off", -0.1, 0.1, "A");
	bc.force_v(fxvi0, 0, false);
	
	//K176,K77
	cbitclose(K176,K77);
	delay_ms(2);
	bc.force_v(acm6, 0, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K175 on, K77 on V0", -0.1, 0.1, "V");
	bc.test_r(acm1, 2, tnum++, "K175 on, K77 on R", 40.0, 60.0, "Ohm");
	bc.force_v(acm6, 0.5, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K175 on, K77 on V1", 0.4, 0.6, "V");
	cbitopen(K176,K77);
	delay_ms(2);
	bc.test_i(acm1, vi, tnum++, "K175 off, K77 off", -0.1, 0.1, "A");
	bc.force_v(acm6, 0, false);
	
	////K177,K77,K73,tested
	//cbitclose(K177,K77,K73);
	//delay_ms(2);
	//bc.force_v(acm10, 0, true);
	//delay_ms(2);
	//bc.test_v(acm1, tnum++, "K177 on, K77 on, K73 on V0", -0.1, 0.1, "V");
	//bc.test_r(acm1, 2, tnum++, "K177 on, K77 on, K73 on R", 1.0, 10.0, "Ohm");
	//bc.force_v(acm10, 0.5, true);
	//delay_ms(2);
	//bc.test_v(acm1, tnum++, "K177 on, K77 on, K73 on V1", 0.4, 0.6, "V");
	//cbitopen(K177,K77,K73);
	//delay_ms(2);
	//bc.test_i(acm1, vi, tnum++, "K177 off, K77 off, K73 off", -0.1, 0.1, "A");
	//bc.force_v(acm10, 0, false);
	
	//K152, K230, K20, K213
	cbitclose(K152, K230, K20, K213);
	delay_ms(2);
	bc.force_v(fxvi0, 0, true);
	delay_ms(5);
	bc.test_v(acm11, tnum++, "K152 on, K230 on, K213 on, K20 on V0", -0.1, 0.1, "V");
	bc.force_v(fxvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(acm11, tnum++, "K152 on, K230 on, K213 on, K20 on V1", 0.4, 0.6, "V");
	cbitopen(K152, K230, K20, K213);
	delay_ms(2);
	bc.test_i(acm11, vi, tnum++, "K152 off, K230 off, K213 off, K20 off", -0.1, 0.1, "A");
	bc.force_v(fxvi0, 0, false);

	//K178,K230,K20,K77
	cbitclose(K178,K230,K20,K77);
	delay_ms(2);
	bc.force_v(fxvi0, 0, true);
	delay_ms(5);
	bc.test_v(acm1, tnum++, "K178 on, K77 on, K230 on, K20 on V0", -0.1, 0.1, "V");
	bc.force_v(fxvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K178 on, K77 on, K230 on, K20 on V1", 0.4, 0.6, "V");
	cbitopen(K178, K230, K20, K77);
	delay_ms(2);
	bc.test_i(acm1, vi, tnum++, "K178 off, K77 off, K230 off, K20 off", -0.1, 0.1, "A");
	bc.force_v(fxvi0, 0, false);
	
	//K159, K233
	cbitclose(K159, K233);
	delay_ms(2);
	bc.force_v(acm6, 0, true);
	delay_ms(5);
	bc.test_v(acm7, tnum++, "K159 on, K233 on V0", -0.1, 0.1, "V");
	bc.force_v(acm6, 0.5, true);
	delay_ms(2);
	bc.test_v(acm7, tnum++, "K159 on, K233 on V1", 0.4, 0.6, "V");
	cbitopen(K159, K233);
	delay_ms(2);
	bc.test_i(acm7, vi, tnum++, "K159 off, K233off", -0.1, 0.1, "A");
	bc.force_v(acm6, 0, false);

	//K179,K233,K77
	cbitclose(K179, K233, K77);
	delay_ms(2);
	bc.force_v(acm6, 0, true);
	delay_ms(5);
	bc.test_v(acm1, tnum++, "K179 on, K77 on, K23 on V0", -0.1, 0.1, "V");
	bc.force_v(acm6, 0.5, true);
	delay_ms(2);
	bc.test_v(acm1, tnum++, "K179 on, K77 on, K23 on V1", 0.4, 0.6, "V");
	cbitopen(K179, K233, K77);
	delay_ms(2);
	bc.test_i(acm1, vi, tnum++, "K179 off, K77 off, K23 off", -0.1, 0.1, "A");
	bc.force_v(acm6, 0, false);
	
	////K180,K77,K62,tested
	//cbitclose(K180,K77,K62);
	//delay_ms(2);
	//bc.force_v(acm8, 0, true);
	//delay_ms(2);
	//bc.test_v(acm1, tnum++, "K180 on, K77 on, K62 on V0", -0.1, 0.1, "V");
	//bc.test_r(acm1, 2, tnum++, "K180 on, K77 on, K62 on R", 1.0, 10.0, "Ohm");
	//bc.force_v(acm8, 0.5, true);
	//delay_ms(2);
	//bc.test_v(acm1, tnum++, "K180 on, K77 on, K62 on V1", 0.4, 0.6, "V");
	//cbitopen(K180,K77,K62);
	//delay_ms(2);
	//bc.test_i(acm1, vi, tnum++, "K180 off, K77 off, K62 off", -0.1, 0.1, "A");
	//bc.force_v(acm8, 0, false);
	
	//K181,K79,K78
	cbitclose(K181,K79,K78);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K181 on, K79 on, K78 on V0", -0.1, 0.1, "V");
	//bc.test_r(dcm, "DCM5", 2, tnum++, "K181 on, K79 on, K78 on R", 50.0, 80.0, "Ohm");
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K181 on, K79 on, K78 on V1", 0.4, 0.6, "V");
	cbitopen(K181,K79,K78);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K181 off, K79 off, K78 off", -0.1, 0.1, "A");
	bc.force_v(acm1, 0, false);
	
	//K182,K79,K103
	cbitclose(K182,K79,K103);
	delay_ms(2);
	bc.force_v(dcm, "DCM7", 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K182 on, K79 on, K103 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K182 on, K79 on, K103 on R", 50.0, 80.0, "Ohm");
	bc.force_v(dcm, "DCM7", 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K182 on, K79 on, K103 on V1", 0.4, 0.6, "V");
	cbitopen(K182,K79,K103);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K182 off, K79 off, K103 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "DCM7", 0, false);
	
	//K183,K79,K65
	cbitclose(K183,K79,K65);
	delay_ms(2);
	bc.force_v(acm9, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K183 on, K79 on, K65 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K183 on, K79 on, K65 on R", 50.0, 80.0, "Ohm");
	bc.force_v(acm9, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K183 on, K79 on, K65 on V1", 0.4, 0.6, "V");
	cbitopen(K183,K79,K65);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K183 off, K79 off, K65 off", -0.1, 0.1, "A");
	bc.force_v(acm9, 0, false);
	
	//K184,K79,K63
	cbitclose(K184,K79,K63);
	delay_ms(2);
	bc.force_v(acm9, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K184 on, K79 on, K63 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K184 on, K79 on, K63 on R", 50.0, 80.0, "Ohm");
	bc.force_v(acm9, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K184 on, K79 on, K63 on V1", 0.4, 0.6, "V");
	cbitopen(K184,K79,K63);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K184 off, K79 off, K63 off", -0.1, 0.1, "A");
	bc.force_v(acm9, 0, false);
	
	//K185,K79,K99
	cbitclose(K185,K79,K99);
	delay_ms(2);
	bc.force_v(dcm, "DCM7", 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K185 on, K79 on, K99 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K185 on, K79 on, K99 on R", 50.0, 80.0, "Ohm");
	bc.force_v(dcm, "DCM7", 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K185 on, K79 on, K99 on V1", 0.4, 0.6, "V");
	cbitopen(K185,K79,K99);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K185 off, K79 off, K99 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "DCM7", 0, false);
	
	//K186,K79,K20
	cbitclose(K186,K79,K20);
	delay_ms(2);
	bc.force_v(fxvi0, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K186 on, K79 on, K20 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K186 on, K79 on, K20 on R", 50.0, 80.0, "Ohm");
	bc.force_v(fxvi0, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K186 on, K79 on, K20 on V1", 0.4, 0.6, "V");
	cbitopen(K186,K79,K20);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K186 off, K79 off, K20 off", -0.1, 0.1, "A");
	bc.force_v(fxvi0, 0, false);
	
	//K187,K79
	cbitclose(K187,K79);
	delay_ms(2);
	bc.force_v(acm6, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K187 on, K79 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K187 on, K79 on R", 50.0, 80.0, "Ohm");
	bc.force_v(acm6, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K187 on, K79 on V1", 0.4, 0.6, "V");
	cbitopen(K187,K79);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K187 off, K79 off", -0.1, 0.1, "A");
	bc.force_v(acm6, 0, false);

	////K188,K79,K108,K109,DDS OUT
	//cbitclose(K188,K79,K108,K109);
	//delay_ms(2);
	//bc.force_v(dcm, "DCM6", 0, true);
	//delay_ms(2);
	//bc.test_v(dcm, "DCM5", tnum++, "K188 on, K79 on, K108 on, K109 on V0", -0.1, 0.1, "V");
	//bc.test_r(dcm, "DCM5", 2, tnum++, "K188 on, K79 on, K108 on, K109 on R", 50.0, 80.0, "Ohm");
	//bc.force_v(dcm, "DCM6", 0.5, true);
	//delay_ms(2);
	//bc.test_v(dcm, "DCM5", tnum++, "K188 on, K79 on, K108 on, K109 on V1", 0.4, 0.6, "V");
	//cbitopen(K188,K79,K108,K109);
	//delay_ms(2);
	//bc.test_i(dcm, "DCM5", vi, tnum++, "K188 off, K79 off, K108 off, K109 off", -0.1, 0.1, "A");
	//bc.force_v(dcm, "DCM6", 0, false);
	//
	////K188,K79,K115,K116,DDS OUT
	//cbitclose(K188,K79,K115,K116);
	//delay_ms(2);
	//bc.force_v(dcm, "DCM4", 0, true);
	//delay_ms(2);
	//bc.test_v(dcm, "DCM5", tnum++, "K188 on, K79 on, K115 on, K116 on V0", -0.1, 0.1, "V");
	//bc.test_r(dcm, "DCM5", 2, tnum++, "K188 on, K79 on, K115 on, K116 on R", 50.0, 80.0, "Ohm");
	//bc.force_v(dcm, "DCM4", 0.5, true);
	//delay_ms(2);
	//bc.test_v(dcm, "DCM5", tnum++, "K188 on, K79 on, K115 on, K116 on V1", 0.4, 0.6, "V");
	//cbitopen(K188,K79,K115,K116);
	//delay_ms(2);
	//bc.test_i(dcm, "DCM5", vi, tnum++, "K188 off, K79 off, K115 off, K116 off", -0.1, 0.1, "A");
	//bc.force_v(dcm, "DCM4", 0, false);
	
	//K189,K79,K30
	cbitclose(K189,K79,K30);
	delay_ms(2);
	bc.force_v(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K189 on, K79 on, K30 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K189 on, K79 on, K30 on R", 50.0, 80.0, "Ohm");
	bc.force_v(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K189 on, K79 on, K30 on V1", 0.4, 0.6, "V");
	cbitopen(K189,K79,K30);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K189 off, K79 off, K30 off", -0.1, 0.1, "A");
	bc.force_v(fxvi5, 0, false);
	
	//K190,K79,K31
	cbitclose(K190,K79,K31);
	delay_ms(2);
	bc.force_v(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K190 on, K79 on, K31 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K190 on, K79 on, K31 on R", 50.0, 80.0, "Ohm");
	bc.force_v(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K190 on, K79 on, K31 on V1", 0.4, 0.6, "V");
	cbitopen(K190,K79,K31);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K190 off, K79 off, K31 off", -0.1, 0.1, "A");
	bc.force_v(fxvi5, 0, false);
	
	//K191,K79,K73
	cbitclose(K191,K79,K73);
	delay_ms(2);
	bc.force_v(acm10, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K191 on, K79 on, K73 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K191 on, K79 on, K73 on R", 50.0, 80.0, "Ohm");
	bc.force_v(acm10, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K191 on, K79 on, K73 on V1", 0.4, 0.6, "V");
	cbitopen(K191,K79,K73);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K191 off, K79 off, K73 off", -0.1, 0.1, "A");
	bc.force_v(acm10, 0, false);
	
	//K192,K79,K62
	cbitclose(K192,K79,K62);
	delay_ms(2);
	bc.force_v(acm8, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K192 on, K79 on, K62 on V0", -0.1, 0.1, "V");
	//bc.test_r(dcm, "DCM5", 2, tnum++, "K192 on, K79 on, K62 on R", 50.0, 80.0, "Ohm");
	bc.force_v(acm8, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K192 on, K79 on, K62 on V1", 0.4, 0.6, "V");
	cbitopen(K192,K79,K62);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K192 off, K79 off, K62 off", -0.1, 0.1, "A");
	bc.force_v(acm8, 0, false);
	
	//K193,K79,K40
	cbitclose(K193,K79,K40);
	delay_ms(2);
	bc.force_v(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K193 on, K79 on, K40 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K193 on, K79 on, K40 on R", 50.0, 80.0, "Ohm");
	bc.force_v(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K193 on, K79 on, K40 on V1", 0.4, 0.6, "V");
	cbitopen(K193,K79,K40);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K193 off, K79 off, K40 off", -0.1, 0.1, "A");
	bc.force_v(fxvi5, 0, false);
	
	//K194,K79,K39
	cbitclose(K194,K79,K39);
	delay_ms(2);
	bc.force_v(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K194 on, K79 on, K39 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K194 on, K79 on, K39 on R", 50.0, 80.0, "Ohm");
	bc.force_v(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K194 on, K79 on, K39 on V1", 0.4, 0.6, "V");
	cbitopen(K194,K79,K39);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K194 off, K79 off, K39 off", -0.1, 0.1, "A");
	bc.force_v(fxvi5, 0, false);
	
	//K195,K79,K42
	cbitclose(K195,K79,K42);
	delay_ms(2);
	bc.force_v(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K195 on, K79 on, K42 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K195 on, K79 on, K42 on R", 50.0, 80.0, "Ohm");
	bc.force_v(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K195 on, K79 on, K42 on V1", 0.4, 0.6, "V");
	cbitopen(K195,K79,K42);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K195 off, K79 off, K42 off", -0.1, 0.1, "A");
	bc.force_v(fxvi5, 0, false);
	
	//K196,K79,K33
	cbitclose(K196,K79,K33);
	delay_ms(2);
	bc.force_v(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K196 on, K79 on, K33 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K196 on, K79 on, K33 on R", 50.0, 80.0, "Ohm");
	bc.force_v(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K196 on, K79 on, K33 on V1", 0.4, 0.6, "V");
	cbitopen(K196,K79,K33);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K196 off, K79 off, K33 off", -0.1, 0.1, "A");
	bc.force_v(fxvi5, 0, false);
	
	//K197,K79,K32
	cbitclose(K197,K79,K32);
	delay_ms(2);
	bc.force_v(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K197 on, K79 on, K32 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K197 on, K79 on, K32 on R", 50.0, 80.0, "Ohm");
	bc.force_v(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K197 on, K79 on, K32 on V1", 0.4, 0.6, "V");
	cbitopen(K197,K79,K32);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K197 off, K79 off, K32 off", -0.1, 0.1, "A");
	bc.force_v(fxvi5, 0, false);
	
	//K198,K79,K38
	cbitclose(K198,K79,K38);
	delay_ms(2);
	bc.force_v(fxvi5, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K198 on, K79 on, K38 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K198 on, K79 on, K38 on R", 50.0, 80.0, "Ohm");
	bc.force_v(fxvi5, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K198 on, K79 on, K38 on V1", 0.4, 0.6, "V");
	cbitopen(K198,K79,K38);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K198 off, K79 off, K38 off", -0.1, 0.1, "A");
	bc.force_v(fxvi5, 0, false);
	
	//K199,K79,K77
	cbitclose(K199,K79,K77);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K199 on, K79 on, K77 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K199 on, K79 on, K77 on R", 50.0, 80.0, "Ohm");
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K199 on, K79 on, K77 on V1", 0.4, 0.6, "V");
	cbitopen(K199,K79,K77);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K199 off, K79 off, K77 off", -0.1, 0.1, "A");
	bc.force_v(acm1, 0, false);
	
	//K201,K202,K213
	cbitclose(K201,K202,K213);
	delay_ms(2);
	bc.force_v(acm11, 0, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "K201 on, K202 on, K213 on V0", -0.1, 0.1, "V");
	bc.test_rf(fxvi4, 2, tnum++, "K201 on, K202 on, K213 on R", 0.5, 5.0, "Ohm");
	bc.force_v(acm11, 0.5, true);
	delay_ms(2);
	bc.test_vf(fxvi4, tnum++, "K201 on, K202 on, K213 on V1", 0.4, 0.6, "V");
	cbitopen(K201,K202,K213);
	delay_ms(2);
	bc.test_if(fxvi4, vi, tnum++, "K201 off, K202 off, K213 off", -0.1, 0.1, "A");
	bc.force_v(acm11, 0, false);
	
	//K203,K204
	cbitclose(K203,K204);
	delay_ms(2);
	bc.force_v(acm2, 0, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K204 on V0", -0.1, 0.1, "V");
	bc.test_r(acm0, 2, tnum++, "K203 on, K204 on R", 1.0, 10.0, "Ohm");
	bc.force_v(acm2, 0.5, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K204 on V1", 0.4, 0.6, "V");
	cbitopen(K203,K204);
	delay_ms(2);
	bc.test_i(acm0, vi, tnum++, "K203 off, K204 off", -0.1, 0.1, "A");
	bc.force_v(acm2, 0, false);
	
	//K203,K205
	cbitclose(K203,K205);
	delay_ms(2);
	bc.force_v(acm4, 0, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K205 on V0", -0.1, 0.1, "V");
	bc.test_r(acm0, 2, tnum++, "K203 on, K205 on R", 1.0, 10.0, "Ohm");
	bc.force_v(acm4, 0.5, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K205 on V1", 0.4, 0.6, "V");
	cbitopen(K203,K205);
	delay_ms(2);
	bc.test_i(acm0, vi, tnum++, "K203 off, K205 off", -0.1, 0.1, "A");
	bc.force_v(acm4, 0, false);
	
	//K203,K206
	cbitclose(K203,K206);
	delay_ms(2);
	bc.force_v(acm3, 0, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K206 on V0", -0.1, 0.1, "V");
	bc.test_r(acm0, 2, tnum++, "K203 on, K206 on R", 1.0, 10.0, "Ohm");
	bc.force_v(acm3, 0.5, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K206 on V1", 0.4, 0.6, "V");
	cbitopen(K203,K206);
	delay_ms(2);
	bc.test_i(acm0, vi, tnum++, "K203 off, K206 off", -0.1, 0.1, "A");
	bc.force_v(acm3, 0, false);
	
	//K203,K207
	cbitclose(K203,K207);
	delay_ms(2);
	bc.force_v(fxvi1, 0, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K207 on V0", -0.1, 0.1, "V");
	bc.test_r(acm0, 2, tnum++, "K203 on, K207 on R", 1.0, 10.0, "Ohm");
	bc.force_v(fxvi1, 0.5, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K207 on V1", 0.4, 0.6, "V");
	cbitopen(K203,K207);
	delay_ms(2);
	bc.test_i(acm0, vi, tnum++, "K203 off, K207 off", -0.1, 0.1, "A");
	bc.force_v(fxvi1, 0, false);
	
	//K203,K208
	cbitclose(K203,K208);
	delay_ms(2);
	bc.force_v(fxvi2, 0, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K208 on V0", -0.1, 0.1, "V");
	bc.test_r(acm0, 2, tnum++, "K203 on, K208 on R", 1.0, 10.0, "Ohm");
	bc.force_v(fxvi2, 0.5, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K208 on V1", 0.4, 0.6, "V");
	cbitopen(K203,K208);
	delay_ms(2);
	bc.test_i(acm0, vi, tnum++, "K203 off, K208 off", -0.1, 0.1, "A");
	bc.force_v(fxvi2, 0, false);
	
	//K203,K209
	cbitclose(K203,K209);
	delay_ms(2);
	bc.force_v(fxvi3, 0, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K209 on V0", -0.1, 0.1, "V");
	bc.test_r(acm0, 2, tnum++, "K203 on, K209 on R", 1.0, 10.0, "Ohm");
	bc.force_v(fxvi3, 0.5, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K209 on V1", 0.4, 0.6, "V");
	cbitopen(K203,K209);
	delay_ms(2);
	bc.test_i(acm0, vi, tnum++, "K203 off, K209 off", -0.1, 0.1, "A");
	bc.force_v(fxvi3, 0, false);
	
	//K203,K210
	cbitclose(K203,K210);
	delay_ms(2);
	bc.force_vf(fxvi4, 0, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K210 on V0", -0.1, 0.1, "V");
	bc.test_r(acm0, 2, tnum++, "K203 on, K210 on R", 1.0, 10.0, "Ohm");
	bc.force_vf(fxvi4, 0.5, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K210 on V1", 0.4, 0.6, "V");
	cbitopen(K203,K210);
	delay_ms(2);
	bc.test_i(acm0, vi, tnum++, "K203 off, K210 off", -0.1, 0.1, "A");
	bc.force_vf(fxvi4, 0, false);
	
	//K203,K211
	cbitclose(K203,K211);
	delay_ms(2);
	bc.force_v(fxvi4, 0, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K211 on V0", -0.1, 0.1, "V");
	bc.test_r(acm0, 2, tnum++, "K203 on, K211 on R", 1.0, 10.0, "Ohm");
	bc.force_v(fxvi4, 0.5, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K203 on, K211 on V1", 0.4, 0.6, "V");
	cbitopen(K203,K211);
	delay_ms(2);
	bc.test_i(acm0, vi, tnum++, "K203 off, K211 off", -0.1, 0.1, "A");
	bc.force_v(fxvi4, 0, false);
	
	//K220,K221,K79
	cbitclose(K220,K221,K79);
	delay_ms(2);
	bc.force_v(dcm, "D_CS", 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K220 on, K221 on, K79 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K220 on, K221 on, K79 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "D_CS", 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K220 on, K221 on, K79 on V1", 0.4, 0.6, "V");
	cbitopen(K220,K221,K79);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K220 off, K221 off, K79 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "D_CS", 0, false);
	
	//K220,K222,K79,K114
	cbitclose(K220,K222,K79,K114);
	delay_ms(2);
	bc.force_v(dcm, "DCM4", 0, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K220 on, K222 on, K79 on V0", -0.1, 0.1, "V");
	bc.test_r(dcm, "DCM5", 2, tnum++, "K220 on, K222 on, K79 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "DCM4", 0.5, true);
	delay_ms(2);
	bc.test_v(dcm, "DCM5", tnum++, "K220 on, K222 on, K79 on V1", 0.4, 0.6, "V");
	cbitopen(K220,K222,K79,K114);
	delay_ms(2);
	bc.test_i(dcm, "DCM5", vi, tnum++, "K220 off, K222 off, K79 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "DCM4", 0, false);
	
	//K223,K224,K203,K79
	cbitclose(K223,K224,K203,K79);
	delay_ms(2);
	bc.force_v(dcm, "DCM5", 0, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K223 on, K224 on, K203 on, K79 on V0", -0.1, 0.1, "V");
	bc.test_r(acm0, 2, tnum++, "K223 on, K224 on, K203 on, K79 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "DCM5", 0.5, true);
	delay_ms(2);
	bc.test_v(acm0, tnum++, "K223 on, K224 on, K203 on, K79 on V1", 0.4, 0.6, "V");
	cbitopen(K223,K224,K203,K79);
	delay_ms(2);
	bc.test_i(acm0, vi, tnum++, "K223 off, K224 off, K203 on, K79 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "DCM5", 0, false);
	
	//K223,K225,K74,K113
	cbitclose(K223,K225,K74,K113);
	delay_ms(2);
	bc.force_v(dcm, "DCM5", 0, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K223 on, K225 on, K113 on, K74 on V0", -0.1, 0.1, "V");
	bc.test_r(acm10, 2, tnum++, "K223 on, K225 on, K113 on, K74 on R", 1.0, 10.0, "Ohm");
	bc.force_v(dcm, "DCM5", 0.5, true);
	delay_ms(2);
	bc.test_v(acm10, tnum++, "K223 on, K225 on, K113 on, K74 on V1", 0.4, 0.6, "V");
	cbitopen(K223,K225,K74,K113);
	delay_ms(2);
	bc.test_i(acm10, vi, tnum++, "K223 off, K225 off, K113 off, K74 off", -0.1, 0.1, "A");
	bc.force_v(dcm, "DCM5", 0, false);

	//qt123 to qvr resource offset
	double os1[SITE_NUM];
	double os2[SITE_NUM];
	double os3[SITE_NUM];
	cbitclose(K206,K207,K208,K209);
	delay_ms(2);
	test_qtx_qvr_resource_os(5.0, os1, os2, os3);
	cbitopen(K206,K207,K208,K209);
	delay_ms(2);
	bc.log(tnum++, "QT1_Resource_Error", os1, -10.0, 10.0, "mV");
	bc.log(tnum++, "QT2_Resource_Error", os2, -10.0, 10.0, "mV");
	bc.log(tnum++, "QT3_Resource_Error", os3, -10.0, 10.0, "mV");

	/////////////////////LSI////////////////////////
	cbit.SetOn(-1);
	//LDO
	cbitclose(K92, K94);
	cbitclose(K21);//fxvi0,rsh
	cbitclose(K174);//abufi
	cbitclose(K77);//acm1,abufo
	cbitopen(K_EN_LDO);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "LDO off V0", -0.1, 0.1, "V");
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "LDO off V1", 0.4, 0.6, "V");
	bc.force_v(acm1, 0, true);
	//
	cbitopen(K92, K93, K94, K95);
	delay_ms(2);
	cbitclose(K93, K94);
	delay_ms(2);
	cbitclose(K_EN_LDO);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "ACM plus LDO on V0", 4.7, 4.9, "V");//add 4.8V
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "ACM plus LDO on V1", 5.2, 5.4, "V");//add 5.3V
	bc.force_v(acm1, 0, true);
	cbitopen(K_EN_LDO);
	cbitopen(K92, K93, K94, K95);
	delay_ms(2);
	bc.force_v(acm1, 0, false);
	//	
	cbitopen(K92, K93, K94, K95);
	delay_ms(2);
	cbitclose(K92, K95);
	delay_ms(2);
	cbitclose(K_EN_LDO);
	delay_ms(2);
	bc.force_v(acm1, 0, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "FXVI plus LDO on V0", -4.9, -4.7, "V");//-4.8V
	bc.force_v(acm1, 0.5, true);
	delay_ms(2);
	bc.test_v(fxvi0, tnum++, "FXVI plus LDO on V1", -4.4, -4.2, "V");//-4.3V
	bc.force_v(acm1, 0, true);
	cbitopen(K_EN_LDO);
	cbitopen(K92, K93, K94, K95);
	delay_ms(2);
	bc.force_v(acm1, 0, false);
	cbitopen(K21);//fxvi0,rsh
	cbitopen(K174);//abufi
	cbitopen(K77);//acm1,abufo
	cbitopen(K_EN_LDO);


	C_All_Open;
	C_FXVI_ACM_GND_Connect;
	all_resource_off();
	//double result[SITE_NUM];
	int haslsi[SITE_NUM];
	double res[SITE_NUM];
	double gain[SITE_NUM];
	double vldo[SITE_NUM];
	double clk[SITE_NUM];
	double vmax[SITE_NUM];
	double vmin[SITE_NUM];
	double gain1[SITE_NUM];
	double gain2[SITE_NUM];
	double gain3[SITE_NUM];
	double gain4[SITE_NUM];

	Check_LSI_Exist(haslsi, res);
	SERIAL result[SITE] = haslsi[SITE];
	bc.log(tnum++, "LSI EXIST", result, 0.5, 1.5, "DB");

	Check_LDO_Vout(vldo);
	bc.log(tnum++, "LSI LDO", vldo, 4.5, 5.1, "V");

	Check_DFI_Gain(gain);
	bc.log(tnum++, "LSI DFI GAIN", gain, 18, 22, "DB");

	Check_LSI_Gain(gain1, gain2, gain3, gain4);
	bc.log(tnum++, "LSI GAIN0", gain1, 4, 8, "V");//6
	bc.log(tnum++, "LSI GAIN1", gain2, 9, 13, "V");//11
	bc.log(tnum++, "LSI GAIN2", gain3, 48, 54, "V");//51
	bc.log(tnum++, "LSI GAIN3", gain4, 80, 86, "V");//83

	Check_DDS_DIV(clk, vmax, vmin);
	bc.log(tnum++, "LSI CLK", clk, 99, 101, "KHz");
	bc.log(tnum++, "LSI VMIN", vmin, 0.0, 0.1, "V");
	bc.log(tnum++, "LSI VMAX", vmax, 3.0, 3.3, "V");

	LSI_Connect();
	AD8400_Connect();
	AD8400_SetResDiv(0);
	AD8400_DisConnect();
	LSI_DisConnect();

	C_All_Open;
	all_resource_off();
	C_FXVI_ACM_GND_Connect;
	C_AGS_BSG_PG_GND_Connect;
	//qvm
	double vqvm[SITE_NUM];
	double vacm[SITE_NUM];
	double vfpvi[SITE_NUM];
	double result0[SITE_NUM];
	double result1[SITE_NUM];

	QVM_Init();

	//fpvi0.Set(FI, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_SENSE_ON);
	acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(2);
	QVM_Connect();
	//C_FPVIH_RSH_Connect;
	//C_FPVIL_RSL_Connect;
	//C_FPVIL_AG_Connect;
	C_QVMH_RSH_Connect;
	//C_QVML_RSL_Connect;
	C_QVML_GND_Connect;
	C_QVMH_ABUFO_Connect;
	C_ACM_ABUFO_Connect;
	//C_RSL_PD_Connect;
	delay_ms(2);
	acm9.Set(FV, 0.5, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(2);
	QVM_Measure(20, 10, QVMe_LADC_5V, result1);
	//C_QVM_1357;
	//delay_ms(2);
	//qvm.MeasureLADC(20, 10, QVMe_LADC_20V, QVMe_LADC_400KHz, MEAS_NORMAL);
	//QVM_GetResult1357(result1);
	//C_QVM_2468;
	//delay_ms(2);
	//qvm.MeasureLADC(20, 10, QVMe_LADC_20V, QVMe_LADC_400KHz, MEAS_NORMAL);
	//QVM_GetResult2468(result1);
	//fpvi0.MeasureVI(20,10);
	acm9.MeasureVI(20, 10); //ACM200_1 measurement 
	Get_Result(acm9, vacm, MVRET, AVERAGE_RESULT);
	//Get_Result(fpvi0, vfpvi, MVRET);
	SERIAL vqvm[SITE]=result1[SITE];
	acm9.Set(FV, 0.5, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_ON);
	delay_ms(2);
	//fpvi0.Set(FV, 0, FPVIe_1V, FPVIe_1MA, FPVIe_RELAY_OFF);
	acm9.Set(FV, 0, ACM200_3p6V, ACM200_1MA, ACM200_RELAY_OFF);
	//C_FPVIH_RSH_DisConnect;
	//C_FPVIL_RSL_DisConnect;
	C_QVMH_DisConnect;
	C_QVML_DisConnect;
	C_ACM_ABUFO_DisConnect;
	//C_RSL_PD_DisConnect;
	QVM_DisConnect();
	bc.log(tnum++, "QVM_0.5V,KQVM", vqvm, 0.4, 0.6, "V");
	//bc.log(tnum++, "FPVI_0.5V", vfpvi, 0.4, 0.6, "V");
	bc.log(tnum++, "ACM_0.5V,KQVM", vacm, 0.4, 0.6, "V");

	C_All_Open;
	all_resource_off();

	////////////////////////////////
	cbit.SetOn(-1);

//	/*********************** User Define End ************************/
//	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	/* Common usage format, don't change this if no specific need   */
	if(board_check_repeat < 0)
		bc.Display();
	nBtn = bc.get_nBtn();
	flag_pass = bc.IsCheckPass();
	bc.report();
	//////////////////////////////////////////////////////////////////

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////
/* run_diags() define the boardcheck flow, as a part of boardcheck library
   don't change this function if no specific need       				 */
///////////////////////////////////////////////////////////////////////////
BOOL run_diags(void)
{
	int nBtn = BTN_REDO;
	BOOL flag_pass = FALSE;

	if(MessageBoxA(NULL, "��ϼ�����ʼ! \n\n�����������ȷ�ϲ�������û����Ʒ��ѡ��-��(Y)\n����˳���ѡ��-��(N)", "�����ʾ�Ի���", MB_YESNO) == IDNO){
		PostQuitMessage(0);
		return FALSE;
	} 

	if(board_check_repeat < 0){
		while((nBtn == BTN_REDO) && (flag_pass == FALSE))
		{
			board_check_function(nBtn, flag_pass);
		}
		if((nBtn == BTN_EXIT) || (nBtn == BTN_CANCEL))
			PostQuitMessage(0);	
		if(flag_pass == TRUE)
			MessageBoxA(NULL, "��ϳɹ���\n����ȷ�ϣ���ʼ����", "�����ʾ�Ի���", MB_OK);
	}

	string message_str;
	message_str = "�ظ�����" + int2str(board_check_repeat) + "��\n����ȷ����ť��ʼ\n����������Զ��˳�\n������鿴 bc.csv";
	if(board_check_repeat > 0)
		MessageBoxA(NULL, message_str.c_str(), "�����ʾ�Ի���", MB_OK);

	while(board_check_repeat-- > 0)
	{
		board_check_function(nBtn, flag_pass);
   		delay_ms(100);

		if(board_check_repeat == 1)
			PostQuitMessage(0);	
	}


	return TRUE;
}
